"""
    resolveurl XBMC Addon
    Copyright (C) 2011 t0mm0

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import os
import hashlib
from resolveurl.lib import log_utils
from resolveurl.lib.net import Net, get_ua  # @UnusedImport  # NOQA
from resolveurl.lib import cache  # @UnusedImport  # NOQA
from resolveurl.lib import kodi
from resolveurl.lib import pyaes

logger = log_utils.Logger.get_logger()
addon_path = kodi.get_path()
plugins_path = os.path.join(addon_path, 'lib', 'resolveurl', 'plugins')
profile_path = kodi.translate_path(kodi.get_profile())
settings_file = os.path.join(addon_path, 'resources', 'settings.xml')
settings_path = os.path.join(addon_path, 'resources')
user_settings_file = os.path.join(profile_path, 'settings.xml')
addon_version = kodi.get_version()
kodi_version = kodi.kodi_version()
get_setting = kodi.get_setting
set_setting = kodi.set_setting
open_settings = kodi.open_settings
has_addon = kodi.has_addon
i18n = kodi.i18n
translate_path = kodi.translate_path

# Supported video formats
VIDEO_FORMATS = kodi.supported_video_extensions()

# QR-Code file
QR_FILE = kodi.translate_path('special://temp/qr_img.png')

# temporary subtitles file
VTT_FILE = kodi.translate_path('special://temp/temp_subs.en.vtt')

# Byparr Support
BP_ENABLED = kodi.get_setting('bp_enable') == 'true'
BP_URL = kodi.get_setting('bp_url')
BP_TIMEOUT = int(kodi.get_setting('bp_timeout') or '60')

SMR_USER_AGENT = 'ResolveURL for Kodi/%s' % (addon_version)
RAND_UA = get_ua()


def log_file_hash(path):
    try:
        with open(path, 'r') as f:
            py_data = f.read()
    except:
        py_data = ''

    logger.log('%s hash: %s' % (os.path.basename(path), hashlib.md5(py_data).hexdigest()))


def make_qr_file(url):
    import pyqrcode
    image_url = pyqrcode.create(url)
    image_url.png(QR_FILE, scale=4.4)
    return QR_FILE


def file_length(py_path, key=''):
    try:
        with open(py_path, 'r') as f:
            old_py = f.read()
        if key:
            old_py = encrypt_py(old_py, key)
        old_len = len(old_py)
    except:
        old_len = -1

    return old_len


def decrypt_py(cipher_text, key):
    if cipher_text:
        try:
            scraper_key = hashlib.sha256(key).digest()
            IV = '\0' * 16
            decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(scraper_key, IV))
            plain_text = decrypter.feed(cipher_text)
            plain_text += decrypter.feed()
            if 'import' not in plain_text:
                plain_text = ''
        except Exception as e:
            logger.log_warning('Exception during Py Decrypt: %s' % (e))
            plain_text = ''
    else:
        plain_text = ''

    return plain_text


def encrypt_py(plain_text, key):
    if plain_text:
        try:
            scraper_key = hashlib.sha256(key).digest()
            IV = '\0' * 16
            decrypter = pyaes.Encrypter(pyaes.AESModeOfOperationCBC(scraper_key, IV))
            cipher_text = decrypter.feed(plain_text)
            cipher_text += decrypter.feed()
        except Exception as e:
            logger.log_warning('Exception during Py Encrypt: %s' % (e))
            cipher_text = ''
    else:
        cipher_text = ''

    return cipher_text


def write_subs(subs_file):
    if kodi_version >= 19.0:
        with open(VTT_FILE, 'w', encoding='utf-8') as f:
            f.write(subs_file)
    else:
        with open(VTT_FILE, 'w') as f:
            f.write(subs_file.encode('utf8'))
    return VTT_FILE
