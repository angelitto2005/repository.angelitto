# -*- coding: utf-8 -*-
# Fișierul key.py
api_keys = [
    "AIzaSyC-U0ZsN3yMFgXUqrEu72N_3iAQZO2IkyU",
    "AIzaSyCWW8OXnc7QwIUTs_W0FCEVrZEm3qliDzk",
]
