import sys
import os
import xbmcgui
import xbmcplugin
import xbmc
import xbmcvfs
import urllib.parse
from urllib.parse import urlencode, quote, quote_plus
import json
import re
import time
import datetime

from resources.lib.core.config import (
    BASE_URL, API_KEY, IMG_BASE, BACKDROP_BASE, HANDLE, ADDON,
    TMDB_SESSION_FILE, FAVORITES_FILE,
    TMDB_LISTS_CACHE_FILE, LISTS_CACHE_TTL, TV_META_CACHE,
    TMDB_V4_BASE_URL, TMDB_IMAGE_BASE, IMAGE_RESOLUTION,
    TMDB_V4_TOKEN_FILE, TMDB_V4_READ_TOKEN, _fmt_dmy, calendar_localized_label,
    calendar_window_days, calendar_sort_flags,
    get_plot_language_code, provider_color, provider_icon, provider_title,
    lazy_requests as requests
)
from resources.lib.core.utils import get_json, get_language, log, paginate_list, read_json, write_json, get_genres_string, set_resume_point, select_ext_info_params, calendar_row_click_params, sort_calendar_items, calendar_context_menu, is_season_fully_watched, prefetch_air_times, get_episode_air_time, get_episode_air_times_map, get_episode_air_stamps, get_episode_air_stamp, air_effective_date, movie_release_air_time, AIR_TIME_TOKEN, apply_air_time, apply_air_times_to_cache_items, style_page_nav_item, next_page_plot, next_page_label, PLUGIN_URL, plugin_url
from resources.lib.core.cache import cache_object, MainCache, get_fast_cache, set_fast_cache, UP_NEXT_STALE_MAX_S, mark_upnext_cache_built
from resources.lib.core.list_render import (render_from_fast_cache, _set_views_apply, _safe_set_prop,
                                            next_episodes_cache_key)
from resources.lib.lists import menus
from resources.lib.providers import trakt_sync
from resources.lib.core.config import PAGE_LIMIT
from concurrent.futures import ThreadPoolExecutor, as_completed

LANG = get_language()
VIDEO_LANGS = "en,null,xx,ro,hi,ta,te,ml,kn,bn,pa,gu,mr,ur,or,as,es,fr,de,it,ru,ja,ko,zh"

SEARCH_HISTORY_FILE = os.path.join(ADDON.getAddonInfo('profile'), 'search_history.json')
ADDON_PATH = ADDON.getAddonInfo('path')
TRAKT_ICON = provider_icon('trakt')
TMDB_ICON = provider_icon('tmdb')
TMDbmovies_ICON = os.path.join(ADDON_PATH, 'icon.png')
NEXT_PAGE_ICON = os.path.join(ADDON_PATH, 'resources', 'media', 'item_next.png')


def _imdb_trailer_mode():
    """True when the trailer player setting points at IMDb."""
    try:
        from resources.lib.core.config import get_trailer_mode
        return get_trailer_mode() == 'imdb'
    except Exception:
        return False


# === LOCK DE CONSTRUCTIE PE LISTA (anti-race container vs widget) ===============
# Aceeasi lista (Up Next / In Progress) e ceruta simultan de mai multe procese:
# containerul, widget-ul din skin (reincarcat dupa UpdateLibrary) si refresh-urile
# venite la stop. Fara lock, fiecare o re-construia in paralel (3-5s fiecare), iar
# endOfDirectory concurente lasau containerul GOL pina la refresh-ul urmator.
_LIST_BUILD_TTL = 45.0    # cat timp stampul e proaspat, celalalt proces traieste

def _list_build_prop(cache_key):
    return 'tmdbmovies.list_build_' + str(cache_key)

def _list_build_wait(cache_key):
    """Daca alt proces construieste deja aceeasi lista, ii lasam sa termine.

    Semantica e "asteapta cat timp celalalt traieste", NU "asteapta 3 secunde si
    construieste oricum". Pe Android (ARM 32-bit) un build de 164 de randuri
    dura ~20s, iar vechea limita de 3s facea ca randarea sa nu-l primeasca si
    sa construiasca a doua oara IN PARALEL: 21s + 21s cu ~13s de suprapunere,
    pe un box cu 1-2 nuclee. Doua constructii paralele sunt intotdeauna mai
    lente decat una singura, deci asteptarea e intotdeauna mai ieftina.
    """
    try:
        w = xbmcgui.Window(10000)
    except:
        return None
    try:
        _started = float(w.getProperty(_list_build_prop(cache_key)) or 0)
    except:
        _started = 0.0
    if _started and time.time() - _started < _LIST_BUILD_TTL:
        while time.time() - _started < _LIST_BUILD_TTL:
            try:
                if xbmc.Monitor().abortRequested():
                    return None
            except:
                pass
            # fresh_only=True: copia din fereastra stale-while-revalidate NU e
            # dovada ca alt proces a terminat build-ul. Fara asta, cel care
            # astepta prelua lista VECHE, raporta "build preluat de alt proces"
            # si nu-si mai construia varianta - de aici stopul din 09:50, unde
            # una din cele doua liste Up Next a ramas nereconstruita (log),
            # iar safety pass-ul a re-randat-o veche.
            data = get_fast_cache(cache_key, fresh_only=True)
            if data:
                return data
            xbmc.sleep(150)
        # celalalt nu a scris cache-ul in timp util -> preluam noi
    try:
        w.setProperty(_list_build_prop(cache_key), str(time.time()))
    except:
        pass
    return None

def _list_build_clear(cache_key):
    try:
        xbmcgui.Window(10000).clearProperty(_list_build_prop(cache_key))
    except:
        pass

# Durata ultimei constructii reale a listei Up Next, in ms. O folosim ca sa
# decidem daca pre-randarea de la stop merita sa porneasca: pe un box lent ea
# nu poate "castiga" fata de timpul in care utilizatorul inchide dialogurile,
# si doar incetineaza randarea reala.
_LAST_NEXT_BUILD_MS = 0.0


def get_last_next_build_ms():
    return _LAST_NEXT_BUILD_MS


# Memo per proces pentru sezoane: aceeasi randare cere sezonul de doua ori
# (warm-up in thread + bucla de rinduri). Fara memo, JSON-ul fiecarui sezon se
# re-parseaza de doua ori per serial (5-20ms x zeci de seriale).
_SEASON_MEMO = {}

def _season_memo_get(mkey):
    if not mkey:
        return None
    try:
        return _SEASON_MEMO.get(mkey)
    except:
        return None

def _season_memo_set(mkey, data):
    try:
        if not mkey or data is None:
            return
        if len(_SEASON_MEMO) > 200:
            _SEASON_MEMO.clear()
        _SEASON_MEMO[mkey] = data
    except:
        pass


# === THREADING PREFETCHER (OPTIMIZAT PENTRU STABILITATE UI) ===
# Script-uri non-latine (CJK, kana, hangul, chirilic, ebraic, arab, grec, devanagari).
# Folosit la fallback-ul de titlu EN in prefetch/calendar — titlurile in astfel de
# script-uri ar aparea ca patratele in fontul Kodi.
_NON_LATIN_RE = re.compile(r'[\u0400-\u052f\u0590-\u05ff\u0600-\u06ff\u0370-\u03ff'
                           r'\u0900-\u097f\u3040-\u30ff\u3400-\u9fff\uf900-\ufaff'
                           r'\uac00-\ud7af\uff00-\uffef]')


def prefetch_metadata_parallel(items, media_type):
    """Prefetch metadata in background with early abort. Uses user's language so data
    can be served directly from pool without re-fetch. Separate session + short timeout."""
    if not items: return
    
    import threading, time, requests
    from resources.lib.core.config import BASE_URL, API_KEY, get_headers, get_plot_language, get_plot_language_code, get_plot_img_lang
    from resources.lib.core.cache import ram_pool_set, ram_cache_set_tvshow, ram_cache_get_tvshow, ram_pool_get
    
    current_lang = get_plot_language_code()
    url_lang = get_plot_language()
    img_lang = 'en,null,xx' if current_lang == 'en' else get_plot_img_lang()
    
    prefetch_session = requests.Session()
    
    def fetch_task(item):
        if xbmc.Monitor().abortRequested(): return
        tid = str(item.get('id') or item.get('tmdb_id') or '')
        if not tid or tid == 'None': return
        # Deja in cache-ul RAM (limba curenta) -> nu mai consumam o cerere TMDb si,
        # mai important, nu mai asteptam deadline-ul de 1.5s de mai jos: Up Next
        # dupa un episod vazut se re-randa din cache aproape instant.
        try:
            _hit = ram_pool_get(tid) or ram_cache_get_tvshow(tid)
            if _hit and _hit.get('_cached_lang') == current_lang:
                return
        except:
            pass
        m_type = item.get('media_type') or ('movie' if media_type == 'movie' else 'tv')
        endpoint = 'movie' if m_type == 'movie' else 'tv'
        try:
            url = (f"{BASE_URL}/{endpoint}/{tid}?api_key={API_KEY}&language={url_lang}"
                   f"&append_to_response=external_ids,images,content_ratings,release_dates"
                   f"&include_image_language={img_lang}")
            res = prefetch_session.get(url, headers=get_headers(), timeout=1.0)
            if res.status_code == 200:
                data = res.json()
                # Fallback EN: daca limba localizata nu exista pe TMDb (ex.
                # seriale/filme fara traducere RO), overview-ul vine GOL sau
                # titlul ramane in script non-latin (CJK/cyrilic/etc.) —
                # completam din EN ca lista sa aiba plot si titlu lizibil.
                localized_title = data.get('title') or data.get('name') or ''
                if url_lang != 'en-US' and (not data.get('overview') or not data.get('tagline') or _NON_LATIN_RE.search(localized_title)):
                    try:
                        url_en = f"{BASE_URL}/{endpoint}/{tid}?api_key={API_KEY}&language=en-US"
                        res_en = prefetch_session.get(url_en, headers=get_headers(), timeout=1.0)
                        if res_en.status_code == 200:
                            en_data = res_en.json()
                            if not data.get('overview'):
                                data['overview'] = en_data.get('overview') or ''
                            if not data.get('tagline'):
                                data['tagline'] = en_data.get('tagline') or ''
                            if _NON_LATIN_RE.search(localized_title):
                                if 'title' in data:
                                    data['title'] = en_data.get('title') or data['title']
                                if 'name' in data:
                                    data['name'] = en_data.get('name') or data['name']
                    except:
                        pass
                data['_cached_lang'] = current_lang
                data['_lightweight'] = True
                _extract_mpaa(data, m_type)
                _ensure_clearlogo(data)
                ram_pool_set(str(tid), data)
                if m_type != 'movie':
                    ram_cache_set_tvshow(tid, data)
        except:
            pass
    
    threads = []
    for item in items:
        t = threading.Thread(target=fetch_task, args=(item,))
        t.daemon = True
        threads.append(t)
        t.start()
    
    deadline = time.time() + 1.5
    for t in threads:
        remaining = deadline - time.time()
        if remaining > 0:
            t.join(timeout=remaining)
        else:
            break
    
    # Close prefetch session to abort in-flight requests → remaining threads exit fast
    try:
        prefetch_session.close()
    except:
        pass

# =============================================================================
# FUNCTIE PENTRU LOCALIZARE COMPLETA (PLOT, POSTER, FANART in RO, Nume in EN)
# =============================================================================
def get_localized_assets(media_type, original_plot='', original_poster='', original_backdrop='', full_details=None):
    try:
        from resources.lib.core.config import get_plot_language_code
        lang_code = get_plot_language_code()
        if lang_code == 'en':
            return original_plot, original_poster, original_backdrop
    except:
        return original_plot, original_poster, original_backdrop

    out_plot = original_plot
    out_poster = original_poster
    out_backdrop = original_backdrop

    if full_details:
        translations = full_details.get('translations', {}).get('translations', [])
        for t in translations:
            if t.get('iso_639_1') == lang_code:
                localized = t.get('data', {}).get('overview')
                if localized: out_plot = localized
                break
        
        images = full_details.get('images', {})
        
        posters = images.get('posters', []) or images.get('stills', [])
        for p in posters:
            if p.get('iso_639_1') == lang_code:
                out_poster = p.get('file_path')
                break
        
        backdrops = images.get('backdrops', [])
        for b in backdrops:
            if b.get('iso_639_1') == lang_code:
                out_backdrop = b.get('file_path')
                break

    return out_plot, out_poster, out_backdrop

# =============================================================================
# HELPER PENTRU IMAGINI LISTE TMDB
# =============================================================================
def get_list_image_url(image_path, image_type='poster'):
    """
    Construieste URL-ul complet pentru imaginile listelor TMDb.
    """
    if not image_path:
        return None
    
    # Daca e deja URL complet, returnam direct
    if image_path.startswith('http'):
        return image_path
    
    # Alegem rezolutia bazata pe tip
    if image_type in ['fanart', 'backdrop']:
        return f"{BACKDROP_BASE}{image_path}"
    else:
        return f"{IMG_BASE}{image_path}"


def set_metadata(li, info_data, unique_ids=None, watched_info=None):
    try:
        tag = li.getVideoInfoTag()
        if not tag: return

        # 1. SET MEDIATYPE FIRST (important pentru Estuary)
        if 'mediatype' in info_data: 
            tag.setMediaType(info_data['mediatype'])
            li.setProperty('dbtype', info_data['mediatype'])
        if 'title' in info_data: 
            tag.setTitle(str(info_data['title']))
        if 'plot' in info_data: 
            tag.setPlot(str(info_data['plot']))
        
        # Durata (importanta pentru cerculet progres)
        duration = 0
        if 'duration' in info_data:
            try: 
                duration = int(info_data['duration'])
                tag.setDuration(duration)
            except: pass

        if 'year' in info_data:
            try: tag.setYear(int(info_data['year']))
            except: pass
        if 'rating' in info_data:
            try: tag.setRating(float(info_data['rating']))
            except: pass
        if 'votes' in info_data:
            try: tag.setVotes(int(info_data['votes']))
            except: pass
        if 'genre' in info_data and info_data['genre']:
            if isinstance(info_data['genre'], list):
                tag.setGenres(info_data['genre'])
            elif isinstance(info_data['genre'], str):
                tag.setGenres(info_data['genre'].split(', '))
        if 'tvshowtitle' in info_data: 
            tag.setTvShowTitle(str(info_data['tvshowtitle']))
        if 'season' in info_data:
            try: tag.setSeason(int(info_data['season']))
            except: pass
        if 'episode' in info_data:
            try: tag.setEpisode(int(info_data['episode']))
            except: pass
        if 'premiered' in info_data: 
            tag.setFirstAired(str(info_data['premiered']))
        if 'originaltitle' in info_data:
            tag.setOriginalTitle(info_data['originaltitle'])
        if 'tagline' in info_data:
            tag.setTagLine(info_data['tagline'])
        if 'mpaa' in info_data and info_data['mpaa']:
            tag.setMpaa(str(info_data['mpaa']))
        if 'studio' in info_data:
            if isinstance(info_data['studio'], list):
                tag.setStudios(info_data['studio'])
            elif isinstance(info_data['studio'], str):
                tag.setStudios([info_data['studio']])
        if 'director' in info_data:
            if isinstance(info_data['director'], list):
                tag.setDirectors(info_data['director'])
            elif isinstance(info_data['director'], str):
                tag.setDirectors([info_data['director']])
        if 'writer' in info_data:
            if isinstance(info_data['writer'], list):
                tag.setWriters(info_data['writer'])
            elif isinstance(info_data['writer'], str):
                tag.setWriters([info_data['writer']])
                
        if unique_ids: 
            default_id = 'imdb' if 'imdb' in unique_ids else 'tmdb'
            tag.setUniqueIDs(unique_ids, default_id)
            # Fortam si legacy m_strIMDBNumber pentru library items unde
            # setUniqueIDs poate fi ignorat la setResolvedUrl
            if 'imdb' in unique_ids:
                try: tag.setIMDBNumber(str(unique_ids['imdb']))
                except: pass
        if 'cast' in info_data:
            actors = []
            for a in info_data['cast']:
                if isinstance(a, dict):
                    # Convertim dictionarul in obiectul Actor cerut de Kodi
                    actors.append(xbmc.Actor(name=a.get('name', ''), role=a.get('role', ''), thumbnail=a.get('thumbnail', '')))
                else:
                    actors.append(a)
            tag.setCast(actors)

        # LOGICA WATCHED - SIMPLIFICATA
        is_fully_watched = False
        
        if isinstance(watched_info, bool): 
            is_fully_watched = watched_info
        elif isinstance(watched_info, int): 
            is_fully_watched = watched_info > 0
        elif isinstance(watched_info, dict):
            w = int(watched_info.get('watched', 0))
            t = int(watched_info.get('total', 0))
            if t > 0:
                li.setProperty('TotalEpisodes', str(t))
                li.setProperty('WatchedEpisodes', str(w))
                li.setProperty('UnWatchedEpisodes', str(max(0, t - w)))
                is_fully_watched = (w >= t)
                # Label galben bold + contor pentru seriale/sezoane incepute
                if w > 0 and not is_fully_watched:
                    li.setProperty('PercentPlayed', str(int((float(w)/float(t))*100)))
                    try:
                        cur = li.getLabel()
                        if cur and '[/' not in cur:
                            li.setLabel(f"[B][COLOR FFEFD702]{cur}[/COLOR] [COLOR FF6AFB92]({w}/{t})[/COLOR][/B]")
                    except: pass
            else:
                li.setProperty('TotalEpisodes', '0')

        # ✅ SETAM PLAYCOUNT
        if is_fully_watched: 
            tag.setPlaycount(1)
        else: 
            tag.setPlaycount(0)
            
        if 'resume_percent' in info_data and info_data['resume_percent'] > 0:
            percent = float(info_data['resume_percent'])
            if duration == 0:
                duration = 7200 if info_data.get('mediatype') == 'movie' else 2700
                try: tag.setDuration(duration)
                except: pass
            if 0 < percent < 100:
                _safe_set_prop(li, 'WatchedProgress', str(int(percent)))
            
    except Exception as e:
        log(f"[METADATA] Error: {e}", xbmc.LOGERROR)

def add_directory(name, params, folder=True, icon=None, thumb=None, fanart=None, clearlogo=None, cm=None, info=None, uids=None, watched_info=None):
    url = plugin_url(params)
    li = xbmcgui.ListItem(name)

    # ============================================================
    # FIX: Nu setam IsPlayable pentru mode=sources
    # Lasam player.py sa gestioneze redarea manual
    # ============================================================
    # ✅ FIX: Lista de moduri care sunt ACTIUNI (nu playable, nu folder)
    ACTION_MODES = [
        'sources',  # Gestionat separat de player
        'tmdb_auth', 'tmdb_logout', 'tmdb_auth_action', 'tmdb_logout_action',
        'trakt_auth', 'trakt_revoke', 'trakt_auth_action', 'trakt_revoke_action',
        'trakt_sync', 'trakt_sync_db', 'trakt_sync_action',
        'trakt_sync_smart', 'trakt_sync_smart_action', # <-- ADAUGAT AICI
        'tmdb_refresh_lists',
        'multiselect_genres',
        'clear_cache', 'clear_cache_action', 'clear_all_cache',
        'clear_search_history', 'clear_tmdb_lists_cache', 'clear_list_cache',
        'open_settings', 'settings', 'noop',
        'add_favorite', 'remove_favorite',
        'mark_watched', 'mark_unwatched', 'remove_progress',
        'tmdb_add_watchlist', 'tmdb_remove_watchlist',
        'tmdb_add_favorites', 'tmdb_remove_favorites',
        'tmdb_add_to_list', 'tmdb_remove_from_list',
        'delete_search', 'edit_search',
        'delete_tmdb_list', 'clear_tmdb_list',
        'tmdb_context_menu', 'trakt_context_menu',
        'clear_sources_context',
        'tmdb_account_info'
    ]
    
    mode = params.get('mode', '')
    if not folder and mode not in ACTION_MODES:
        _safe_set_prop(li, 'IsPlayable', 'true')
    # Pentru mode=sources, NU setam IsPlayable - plugin-ul gestioneaza singur
    # ============================================================

    art = {}
    if icon:
        art['icon'] = icon
    if thumb:
        art['thumb'] = thumb
        art['poster'] = thumb
    if fanart:
        art['fanart'] = fanart
        art['landscape'] = fanart
        
    if clearlogo:
        art['clearlogo'] = clearlogo
        art['tvshow.clearlogo'] = clearlogo
        # --- FIX SEZOANE & AF3 ---
        art['tvshow.logo'] = clearlogo
        art['logo'] = clearlogo
        art['fanart_clearlogo'] = clearlogo
        
        try:
            li.setProperty('clearlogo', clearlogo)
            li.setProperty('tvshow.clearlogo', clearlogo)
            li.setProperty('logo', clearlogo)
        except: pass
        
    if art:
        li.setArt(art)

    if info:
        set_metadata(li, info, uids, watched_info)

    # --- MODIFICARE NOUA ---
    if uids and 'tmdb' in uids:
        _safe_set_prop(li, 'tmdb_id', str(uids['tmdb']))
    # -----------------------
    
    if cm:
        try:
            li.addContextMenuItems(cm)
        except Exception as e:
            log(f"[LIST] addContextMenuItems esuat: {e}")

    try:
        xbmcplugin.addDirectoryItem(HANDLE, url, li, folder)
    except Exception as e:
        log(f"[LIST] addDirectoryItem esuat ({mode}): {e}")


def build_menu(menu_list):
    addon_path = ADDON.getAddonInfo('path')
    icons_path = os.path.join(addon_path, 'resources', 'media')

    for item in menu_list:
        mode = item.get('mode')
        action = item.get('action')
        name = item.get('name')
        icon_name = item.get('iconImage', 'DefaultFolder.png')

        icon_path = os.path.join(icons_path, icon_name)
        if not os.path.exists(icon_path):
            icon_path = icon_name

        url_params = {'mode': mode}
        if action:
            url_params['action'] = action
        if 'menu_type' in item:
            url_params['menu_type'] = item['menu_type']

        add_directory(name, url_params, icon=icon_path, thumb=icon_path, folder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def main_menu():
    build_menu(menus.root_menu())


def movies_menu():
    build_menu(menus.movie_list)


def tv_menu():
    build_menu(menus.tvshow_menu())


def get_search_history():
    """Citeste istoricul de cautare."""
    data = read_json(SEARCH_HISTORY_FILE)
    if not data or not isinstance(data, list):
        return []
    return data

def add_search_to_history(query, search_type):
    """Adauga o cautare noua la inceputul listei (Max 20)."""
    history = get_search_history()
    
    # Cream obiectul nou
    new_item = {'query': query, 'type': search_type}
    
    # Eliminam duplicatele (daca exista deja, il stergem ca sa-l punem primul)
    history = [h for h in history if not (h['query'] == query and h['type'] == search_type)]
    
    # Adaugam la inceput
    history.insert(0, new_item)
    
    # Pastram doar ultimele 20
    history = history[:20]
    
    write_json(SEARCH_HISTORY_FILE, history)

def remove_search_from_history(query, search_type):
    """Sterge o cautare specifica."""
    history = get_search_history()
    history = [h for h in history if not (h['query'] == query and h['type'] == search_type)]
    write_json(SEARCH_HISTORY_FILE, history)

def clear_search_history_action():
    """Sterge tot istoricul."""
    if xbmcvfs.exists(SEARCH_HISTORY_FILE):
        xbmcvfs.delete(SEARCH_HISTORY_FILE)
    xbmcgui.Dialog().notification("[B][COLOR FFFDBD01]Search[/COLOR][/B]", "History cleared", TMDbmovies_ICON, 2000, False)
    xbmc.executebuiltin("Container.Refresh")

def delete_search_item(params):
    """Functia apelata din meniul contextual pentru stergere."""
    query = params.get('query')
    search_type = params.get('type')
    remove_search_from_history(query, search_type)
    xbmcgui.Dialog().notification("[B][COLOR FFFDBD01]Search[/COLOR][/B]", "Removed from history", TMDbmovies_ICON, 2000, False)
    xbmc.executebuiltin("Container.Refresh")

def edit_search_item(params):
    """Functia apelata din meniul contextual pentru editare."""
    old_query = params.get('query')
    search_type = params.get('type')
    
    dialog = xbmcgui.Dialog()
    new_query = dialog.input("Edit search", defaultt=old_query, type=xbmcgui.INPUT_ALPHANUM)
    
    # Verificam daca utilizatorul a scris ceva si daca e diferit de ce era inainte
    if new_query and new_query != old_query:
        # 1. Stergem vechea intrare
        remove_search_from_history(old_query, search_type)
        
        # 2. Adaugam noua intrare (ACESTA ERA PASUL LIPSA)
        add_search_to_history(new_query, search_type)
        
        # 3. Dam Refresh la lista ca sa apara modificarea vizual
        xbmcgui.Dialog().notification("[B][COLOR FFFDBD01]Search[/COLOR][/B]", "Change saved", TMDbmovies_ICON, 2000, False)
        xbmc.executebuiltin("Container.Refresh")


def search_menu():
    SEARCH_MOVIE_ICON = os.path.join(ADDON_PATH, 'resources', 'media', 'search_movie.png')
    SEARCH_TV_ICON = os.path.join(ADDON_PATH, 'resources', 'media', 'search_tv.png')
    
    # Iconita pentru istoric (search.png)
    SEARCH_HISTORY_ICON = os.path.join(ADDON_PATH, 'resources', 'media', 'search_history.png')
    # Fallback daca nu exista search.png, folosim default
    if not os.path.exists(SEARCH_HISTORY_ICON):
        SEARCH_HISTORY_ICON = 'DefaultIconSearch.png'

    # 1. Butoanele principale de cautare
    add_directory("[B][COLOR FFFDBD01]Search Movies[/COLOR][/B]", {'mode': 'perform_search', 'type': 'movie'}, icon=SEARCH_MOVIE_ICON, thumb=SEARCH_MOVIE_ICON, folder=True)
    add_directory("[B][COLOR FFFDBD01]Search TV Shows[/COLOR][/B]", {'mode': 'perform_search', 'type': 'tv'}, icon=SEARCH_TV_ICON, thumb=SEARCH_TV_ICON, folder=True)
    
    # 2. Istoricul de cautare
    history = get_search_history()
    
    if history:
        
        for item in history:
            query = item.get('query')
            stype = item.get('type')
            
            # Formatam tipul (Movie sau TV Show)
            type_label = "Movie" if stype == 'movie' else "TV Show"
            
            # FORMATUL CERUT: History: titlu(Type) bold+inclinat
            label = f"History: [B][I][COLOR FFCA762B]{query} [/COLOR][/I][/B] ({type_label})"
            
            # Context Menu pentru Edit si Delete
            cm = [
                ('Edit Search', f"RunPlugin({PLUGIN_URL}?mode=edit_search&query={quote(query)}&type={stype})"),
                ('Delete Search', f"RunPlugin({PLUGIN_URL}?mode=delete_search&query={quote(query)}&type={stype})")
            ]
            
            # Parametrii pentru a rula din nou cautarea la click
            url_params = {'mode': 'perform_search_query', 'query': query, 'type': stype}
            
            # Adaugam cu iconita search.png
            add_directory(label, url_params, icon=SEARCH_HISTORY_ICON, thumb=SEARCH_HISTORY_ICON, cm=cm, folder=True)

        # 3. Buton Clear Historyadd_directory("------------------------------------------------", {'mode': 'noop'}, folder=False)
        add_directory("[B][COLOR FFFF0000]Clear Search History[/COLOR][/B]", {'mode': 'clear_search_history'}, icon='DefaultIconError.png', folder=False)
    
    xbmcplugin.endOfDirectory(HANDLE)


def favorites_menu():
    MOVIES_ICON = os.path.join(ADDON_PATH, 'resources', 'media', 'movies.png')
    TV_ICON = os.path.join(ADDON_PATH, 'resources', 'media', 'tv.png')

    add_directory("[B][COLOR FFFF69B4]Movies[/COLOR][/B]", {'mode': 'list_favorites', 'type': 'movie'}, icon=MOVIES_ICON, thumb=MOVIES_ICON, folder=True)
    add_directory("[B][COLOR FFFF69B4]TV Shows[/COLOR][/B]", {'mode': 'list_favorites', 'type': 'tv'}, icon=TV_ICON, thumb=TV_ICON, folder=True)
    
    xbmcplugin.endOfDirectory(HANDLE)


def settings_menu():
    from resources.lib.api import trakt_api

    session = get_tmdb_session()
    if session:
        add_directory(f"[B][COLOR FF00CED1]TMDB: {session.get('username', 'Connected')}[/COLOR][/B]", {'mode': 'tmdb_account_info'}, folder=False, icon='DefaultUser.png')
        add_directory("[COLOR red]Disconnect TMDB[/COLOR]", {'mode': 'tmdb_logout'}, folder=False, icon='DefaultIconError.png')
    else:
        add_directory("[B][COLOR FF00CED1]Connect TMDB[/COLOR][/B]", {'mode': 'tmdb_auth'}, folder=False, icon='DefaultUser.png')

    trakt_token = ADDON.getSetting('trakt_access_token')
    if trakt_token:
        user = trakt_api.get_trakt_username(trakt_token)
        ADDON.setSetting('trakt_status', f"Connected: {user}")
        add_directory(f"[B][COLOR pink]Trakt: {user}[/COLOR][/B]", {'mode': 'noop'}, folder=False, icon='DefaultUser.png')
        add_directory("[COLOR red]Disconnect Trakt[/COLOR]", {'mode': 'trakt_revoke'}, folder=False, icon='DefaultIconError.png')
        add_directory("[COLOR FF6AFB92]Smart Sync[/COLOR]", {'mode': 'trakt_sync_smart_action'}, folder=False, icon='DefaultAddonService.png')
        add_directory("[COLOR cyan]Force Full Sync[/COLOR]", {'mode': 'trakt_sync_action'}, folder=False, icon='DefaultAddonService.png')
    else:
        add_directory("[B][COLOR pink]Connect Trakt[/COLOR][/B]", {'mode': 'trakt_auth'}, folder=False, icon='DefaultUser.png')

    add_directory("Addon Settings", {'mode': 'settings'}, folder=False, icon='DefaultAddonService.png')
    add_directory("[COLOR orange]Delete All Cache[/COLOR]", {'mode': 'clear_all_cache'}, folder=False, icon='DefaultAddonNone.png')

    xbmcplugin.endOfDirectory(HANDLE)


def get_dates(days, reverse=True):
    current_date = datetime.date.today()
    if reverse:
        new_date = (current_date - datetime.timedelta(days=days)).strftime('%Y-%m-%d')
    else:
        new_date = (current_date + datetime.timedelta(days=days)).strftime('%Y-%m-%d')
    return str(current_date), new_date


def get_tmdb_movies_standard(action, page_no):
    import requests
    import datetime
    
    # Toate limbile indiene
    INDIAN_LANGS = "hi|ta|te|ml|kn|pa|bn|mr"
    
    # Baza URL
    url = f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&page={page_no}&region=US"

    if action == 'tmdb_movies_popular':
        url = f"{BASE_URL}/movie/popular?api_key={API_KEY}&language={LANG}&page={page_no}"
    elif action == 'tmdb_movies_now_playing':
        url = f"{BASE_URL}/movie/now_playing?api_key={API_KEY}&language={LANG}&page={page_no}"
    elif action == 'tmdb_movies_top_rated':
        # Dinamic: Cele mai votate/adaugate la favorite filme din ultimele 60 de zile
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        recent_past = (datetime.date.today() - datetime.timedelta(days=60)).strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}"
            f"&language=en-US&region=US"
            f"&primary_release_date.gte={recent_past}"
            f"&primary_release_date.lte={current_date}"
            f"&sort_by=vote_count.desc"
            f"&page={page_no}"
        )
        
    elif action == 'tmdb_movies_upcoming':
        tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        max_date = (datetime.date.today() + datetime.timedelta(days=120)).strftime('%Y-%m-%d')
        
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}"
            f"&language=en-US"
            f"&with_original_language=en"            # ✅ Doar limba engleza (corect)
            f"&page={page_no}"
            f"&region=US"
            f"&primary_release_date.gte={tomorrow}"
            f"&primary_release_date.lte={max_date}"  # ✅ Max 120 zile (nu filme din 2028)
            f"&sort_by=primary_release_date.asc"             # ✅ Cele mai populare primele
            f"&without_genres=99"             # ✅ Fara documentare
            f"&with_runtime.gte=60"                  # ✅ Fara scurtmetraje
            f"&popularity.gte=40"                    # ✅ Moderat - nu pierzi filme bune
            f"&with_release_type=2|3"                # ✅ Doar cinema (Limited + Wide)
            f"&include_adult=false"                  # ✅ OK
        )

    elif action == 'tmdb_movies_anticipated':
        tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        max_date = (datetime.date.today() + datetime.timedelta(days=120)).strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}"
            f"&language={LANG}"
            f"&primary_release_date.gte={tomorrow}"
            f"&primary_release_date.lte={max_date}"
            f"&sort_by=popularity.desc"
            f"&page={page_no}"
        )

    elif action == 'tmdb_movies_blockbusters':
        # LOGICA BLOCKBUSTERS: Toate timpurile, incasari gigantice, minim 500 voturi
        url = f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&page={page_no}&sort_by=revenue.desc&vote_count.gte=500"

    elif action == 'tmdb_movies_box_office':
        # LOGICA TOP BOX OFFICE: Cele mai mari incasari din ULTIMUL AN
        year_ago = (datetime.date.today() - datetime.timedelta(days=365)).strftime('%Y-%m-%d')
        url = f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&page={page_no}&primary_release_date.gte={year_ago}&sort_by=revenue.desc"
        
    elif action == 'tmdb_movies_premieres':
        current_date, previous_date = get_dates(31, reverse=True)
        url += f"&release_date.gte={previous_date}&release_date.lte={current_date}&with_release_type=1|3|2&sort_by=popularity.desc"
        
    elif action == 'tmdb_movies_latest_releases':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        # Filtram strict dupa lansarea Digitala (with_release_type=4)
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&region=US"
            f"&release_date.lte={current_date}"
            f"&with_release_type=4"
            f"&sort_by=release_date.desc"
            f"&with_runtime.gte=60&without_genres=99&vote_count.gte=5"
            f"&page={page_no}"
        )
    elif action == 'tmdb_movies_digital':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&region=US"
            f"&release_date.lte={current_date}"
            f"&with_release_type=4"
            f"&sort_by=release_date.desc"
            f"&with_runtime.gte=60&without_genres=99"
            f"&page={page_no}"
        )
    elif action == 'tmdb_movies_netflix':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        url = f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&region=US&watch_region=US&with_watch_providers=8&primary_release_date.lte={current_date}&sort_by=primary_release_date.desc&with_runtime.gte=60&without_genres=99&vote_count.gte=5&page={page_no}"
    elif action == 'tmdb_movies_amazon':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        url = f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&region=US&watch_region=US&with_watch_providers=9&primary_release_date.lte={current_date}&sort_by=primary_release_date.desc&with_runtime.gte=60&without_genres=99&vote_count.gte=5&page={page_no}"
    elif action == 'tmdb_movies_disney':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        url = f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&region=US&watch_region=US&with_watch_providers=337&primary_release_date.lte={current_date}&sort_by=primary_release_date.desc&with_runtime.gte=60&without_genres=99&vote_count.gte=5&page={page_no}"
    elif action == 'tmdb_movies_apple':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        url = f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&region=US&watch_region=US&with_watch_providers=350&primary_release_date.lte={current_date}&sort_by=primary_release_date.desc&with_runtime.gte=60&without_genres=99&vote_count.gte=5&page={page_no}"
    
    elif action == 'tmdb_movies_trending_day':
        url = f"{BASE_URL}/trending/movie/day?api_key={API_KEY}&language={LANG}&page={page_no}"
    elif action == 'tmdb_movies_trending_week':
        url = f"{BASE_URL}/trending/movie/week?api_key={API_KEY}&language={LANG}&page={page_no}"

    # =========================================================================
    # HINDI MOVIES (toate limbile indiene)
    # =========================================================================
    elif action == 'hindi_movies_trending':
        year_ago = (datetime.date.today() - datetime.timedelta(days=365)).strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}&language=en-US"
            f"&with_original_language={INDIAN_LANGS}"
            f"&primary_release_date.gte={year_ago}"
            f"&sort_by=popularity.desc"
            f"&vote_count.gte=10"
            f"&page={page_no}"
        )

    elif action == 'hindi_movies_popular':
        # Popular = Cele mai populare all-time
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}&language=en-US"
            f"&with_original_language={INDIAN_LANGS}"
            f"&sort_by=popularity.desc"
            f"&vote_count.gte=50"
            f"&page={page_no}"
        )

    elif action == 'hindi_movies_premieres':
        # Premieres = Digital releases din ultima luna
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        previous_date = (datetime.date.today() - datetime.timedelta(days=31)).strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}&language=en-US"
            f"&with_original_language={INDIAN_LANGS}"
            f"&release_date.gte={previous_date}"
            f"&release_date.lte={current_date}"
            f"&with_release_type=4|5"
            f"&sort_by=popularity.desc"
            f"&page={page_no}"
        )

    elif action == 'hindi_movies_in_theaters':
        # In Theaters = In cinematografe acum
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        previous_date = (datetime.date.today() - datetime.timedelta(days=60)).strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}&language=en-US"
            f"&with_original_language={INDIAN_LANGS}"
            f"&release_date.gte={previous_date}"
            f"&release_date.lte={current_date}"
            f"&with_release_type=3"
            f"&sort_by=popularity.desc"
            f"&page={page_no}"
        )

    elif action == 'hindi_movies_upcoming':
        # Upcoming = Filme care urmeaza, sortate CRONOLOGIC (cele mai apropiate primele)
        tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}&language=en-US"
            f"&with_original_language={INDIAN_LANGS}"
            f"&primary_release_date.gte={tomorrow}"
            f"&sort_by=primary_release_date.asc"
            f"&page={page_no}"
        )

    elif action == 'hindi_movies_anticipated':
        # Anticipated = Filme viitoare sortate dupa POPULARITATE (cele cu hype)
        tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}&language=en-US"
            f"&with_original_language={INDIAN_LANGS}"
            f"&primary_release_date.gte={tomorrow}"
            f"&sort_by=popularity.desc"
            f"&page={page_no}"
        )

    # =========================================================================
    # ROMANIAN MOVIES (Filme Romanesti)
    # =========================================================================
    elif action == 'romania_movies_latest':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}&language=ro-RO"
            f"&with_original_language=ro"
            f"&primary_release_date.lte={current_date}"
            f"&sort_by=primary_release_date.desc"
            f"&with_runtime.gte=40&vote_count.gte=2"
            f"&page={page_no}"
        )
    elif action == 'romania_movies_trending':
        year_ago = (datetime.date.today() - datetime.timedelta(days=365)).strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}&language=ro-RO"
            f"&with_original_language=ro"
            f"&primary_release_date.gte={year_ago}"
            f"&sort_by=popularity.desc"
            f"&with_runtime.gte=40&vote_count.gte=2"
            f"&page={page_no}"
        )
    elif action == 'romania_movies_popular':
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}&language=ro-RO"
            f"&with_original_language=ro"
            f"&sort_by=popularity.desc"
            f"&with_runtime.gte=40&vote_count.gte=2"
            f"&page={page_no}"
        )
    elif action == 'romania_movies_premieres':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        previous_date = (datetime.date.today() - datetime.timedelta(days=365)).strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}&language=ro-RO"
            f"&with_original_language=ro"
            f"&primary_release_date.gte={previous_date}"
            f"&primary_release_date.lte={current_date}"
            f"&with_release_type=4|5"
            f"&sort_by=primary_release_date.desc"
            f"&with_runtime.gte=40&vote_count.gte=2"
            f"&page={page_no}"
        )
    elif action == 'romania_movies_in_theaters':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        previous_date = (datetime.date.today() - datetime.timedelta(days=90)).strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/movie?api_key={API_KEY}&language=ro-RO"
            f"&with_original_language=ro"
            f"&primary_release_date.gte={previous_date}"
            f"&primary_release_date.lte={current_date}"
            f"&with_release_type=3"
            f"&sort_by=primary_release_date.desc"
            f"&with_runtime.gte=40&vote_count.gte=2"
            f"&page={page_no}"
        )

    return requests.get(url, timeout=15)


def get_tmdb_tv_standard(action, page_no):
    import requests # Lazy loading
    
    if action == 'tmdb_tv_popular':
        url = f"{BASE_URL}/tv/popular?api_key={API_KEY}&language={LANG}&page={page_no}"
    elif action == 'tmdb_tv_premieres':
        url = f"{BASE_URL}/discover/tv?api_key={API_KEY}&language={LANG}&page={page_no}&with_original_language=en&region=US"
        current_date, previous_date = get_dates(31, reverse=True)
        url += f"&sort_by=popularity.desc&first_air_date.gte={previous_date}&first_air_date.lte={current_date}"
    
    elif action == 'tmdb_tv_latest_releases':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        url = f"{BASE_URL}/discover/tv?api_key={API_KEY}&language={LANG}&region=US&first_air_date.lte={current_date}&sort_by=first_air_date.desc&without_genres=99,10763,10767&vote_count.gte=5&page={page_no}"
        
    elif action == 'tmdb_tv_netflix':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        url = f"{BASE_URL}/discover/tv?api_key={API_KEY}&language={LANG}&region=US&watch_region=US&with_watch_providers=8&first_air_date.lte={current_date}&sort_by=first_air_date.desc&without_genres=99,10763,10767&vote_count.gte=5&page={page_no}"

    elif action == 'tmdb_tv_amazon':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        url = f"{BASE_URL}/discover/tv?api_key={API_KEY}&language={LANG}&region=US&watch_region=US&with_watch_providers=9&first_air_date.lte={current_date}&sort_by=first_air_date.desc&without_genres=99,10763,10767&vote_count.gte=5&page={page_no}"

    elif action == 'tmdb_tv_disney':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        url = f"{BASE_URL}/discover/tv?api_key={API_KEY}&language={LANG}&region=US&watch_region=US&with_watch_providers=337&first_air_date.lte={current_date}&sort_by=first_air_date.desc&without_genres=99,10763,10767&vote_count.gte=5&page={page_no}"

    elif action == 'tmdb_tv_apple':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        url = f"{BASE_URL}/discover/tv?api_key={API_KEY}&language={LANG}&region=US&watch_region=US&with_watch_providers=350&first_air_date.lte={current_date}&sort_by=first_air_date.desc&without_genres=99,10763,10767&vote_count.gte=5&page={page_no}"
    
    elif action == 'tmdb_tv_airing_today':
        url = f"{BASE_URL}/tv/airing_today?api_key={API_KEY}&language={LANG}&page={page_no}"
        
    elif action == 'tmdb_tv_on_the_air':
        url = f"{BASE_URL}/tv/on_the_air?api_key={API_KEY}&language={LANG}&page={page_no}"
        
    elif action == 'tmdb_tv_top_rated':
        # Dinamic: Cele mai votate/adaugate la favorite seriale din ultimele 90 de zile
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        recent_past = (datetime.date.today() - datetime.timedelta(days=90)).strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/tv?api_key={API_KEY}"
            f"&language=en-US&region=US"
            f"&first_air_date.gte={recent_past}"
            f"&first_air_date.lte={current_date}"
            f"&sort_by=vote_count.desc"
            f"&page={page_no}"
        )
        
    elif action == 'tmdb_tv_upcoming':
        current_date, future_date = get_dates(31, reverse=False)
        url = f"{BASE_URL}/discover/tv?api_key={API_KEY}&language={LANG}&page={page_no}&with_original_language=en&region=US&sort_by=popularity.desc&first_air_date.gte={current_date}&first_air_date.lte={future_date}"
    
    elif action == 'tmdb_tv_trending_day':
        url = f"{BASE_URL}/trending/tv/day?api_key={API_KEY}&language={LANG}&page={page_no}"
        
    elif action == 'tmdb_tv_trending_week':
        url = f"{BASE_URL}/trending/tv/week?api_key={API_KEY}&language={LANG}&page={page_no}"

    # =========================================================================
    # ROMANIAN TV SHOWS (Seriale Romanesti)
    # =========================================================================
    elif action == 'romania_tv_latest':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/tv?api_key={API_KEY}&language=ro-RO"
            f"&with_original_language=ro"
            f"&first_air_date.lte={current_date}"
            f"&sort_by=first_air_date.desc"
            f"&vote_count.gte=2"
            f"&page={page_no}"
        )
    elif action == 'romania_tv_trending':
        year_ago = (datetime.date.today() - datetime.timedelta(days=365)).strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/tv?api_key={API_KEY}&language=ro-RO"
            f"&with_original_language=ro"
            f"&first_air_date.gte={year_ago}"
            f"&sort_by=popularity.desc"
            f"&vote_count.gte=2"
            f"&page={page_no}"
        )
    elif action == 'romania_tv_popular':
        url = (
            f"{BASE_URL}/discover/tv?api_key={API_KEY}&language=ro-RO"
            f"&with_original_language=ro"
            f"&sort_by=popularity.desc"
            f"&vote_count.gte=2"
            f"&page={page_no}"
        )
    elif action == 'romania_tv_premieres':
        current_date = datetime.date.today().strftime('%Y-%m-%d')
        previous_date = (datetime.date.today() - datetime.timedelta(days=730)).strftime('%Y-%m-%d')
        url = (
            f"{BASE_URL}/discover/tv?api_key={API_KEY}&language=ro-RO"
            f"&with_original_language=ro"
            f"&first_air_date.gte={previous_date}"
            f"&first_air_date.lte={current_date}"
            f"&sort_by=first_air_date.desc"
            f"&vote_count.gte=2"
            f"&page={page_no}"
        )

    return requests.get(url, timeout=15)


# =============================================================================
# TRENDING SNAPSHOT (paginare consistenta pentru rankingurile live TMDB)
# =============================================================================
_TRENDING_MOVIE_ACTIONS = {'tmdb_movies_trending_day', 'tmdb_movies_trending_week'}
_TRENDING_TV_ACTIONS = {'tmdb_tv_trending_day', 'tmdb_tv_trending_week'}
_TRENDING_SNAPSHOT_HOURS = 0.25
_TRENDING_MAX_FETCH = 10


def _trending_snapshot(action, page, content_type, page_limit):
    """Lista unica pentru trending: dedupe + filtru junk + paginare locala."""
    key = f"trend_snapshot_{content_type}_{action}_{LANG}"
    cache = MainCache()
    snap = cache.get(key)
    if not isinstance(snap, dict):
        snap = {'items': [], 'api_pages': 0, 'total_pages': 0, 'ts': int(time.time())}
    items = list(snap.get('items') or [])
    ids = {str(it.get('id')) for it in items if isinstance(it, dict) and it.get('id')}
    api_pages = int(snap.get('api_pages') or 0)
    total_pages = int(snap.get('total_pages') or 0)
    limit = int(page_limit or 20)
    need = max(1, int(page or 1)) * limit + limit
    fetch_fn = get_tmdb_movies_standard if content_type == 'movie' else get_tmdb_tv_standard
    fetched = 0
    while len(items) < need and fetched < _TRENDING_MAX_FETCH:
        if total_pages and api_pages >= total_pages:
            break
        next_page = api_pages + 1
        try:
            resp = fetch_fn(action, next_page)
            if not resp or getattr(resp, 'status_code', 0) != 200:
                break
            data = resp.json() or {}
        except Exception as e:
            log(f"[TRENDING] Fetch eroare {action} p{next_page}: {e}")
            break
        results = data.get('results') or []
        total_pages = int(data.get('total_pages') or total_pages or 0)
        api_pages = next_page
        fetched += 1
        for it in results:
            if not isinstance(it, dict):
                continue
            tid = str(it.get('id') or '')
            if not tid or tid in ids:
                continue
            if _is_tmdb_list_junk(it):
                continue
            ids.add(tid)
            items.append(it)
        if len(results) < 20:
            total_pages = api_pages
            break
    if not items:
        return None
    snap = {
        'items': items,
        'api_pages': api_pages,
        'total_pages': total_pages,
        'ts': snap.get('ts') or int(time.time()),
    }
    if fetched:
        cache.set(key, snap, expiration=_TRENDING_SNAPSHOT_HOURS)
    return snap


def build_movie_list(params):
    # --- PRIORITATE FOREGROUND ---
    window = xbmcgui.Window(10000)
    window.setProperty('tmdbmovies_loading_active', 'true')
    
    # Adaugam un mic delay daca fundalul era ocupat, sa-i dam timp sa se opreasca
    if xbmcgui.Window(10000).getProperty('tmdbmovies_warmup_busy') == 'true':
        xbmc.sleep(100)
# -----------------------------------------
    action = params.get('action')
    page = int(params.get('new_page', '1'))

    # Trakt redirection
    if action and 'trakt_movies_' in action:
        from resources.lib.api import trakt_api
        list_type = action.replace('trakt_movies_', '')
        params['list_type'] = list_type
        params['media_type'] = 'movies'
        trakt_api.trakt_discovery_list(params)
        return

    from resources.lib.core.config import PAGE_LIMIT
    is_trending = action in _TRENDING_MOVIE_ACTIONS
    snap = _trending_snapshot(action, page, 'movie', PAGE_LIMIT) if is_trending else None
    ITEMS_PER_API_PAGE = 20
    api_pages_needed = max(1, (PAGE_LIMIT + ITEMS_PER_API_PAGE - 1) // ITEMS_PER_API_PAGE)
    start_api_page = (page - 1) * api_pages_needed + 1
    if action == 'tmdb_movies_digital':
        api_pages_needed = 0

# --- FAST CACHE CHECK (RAM) ---
    cache_key = f"list_movie_{action}_{page}"
    if not is_trending:
        cached_data = get_fast_cache(cache_key)
        if cached_data:
            render_from_fast_cache(cached_data, view_type='movies')
            return
    # ---------------------------------

    # Fetch multiple API pages daca PAGE_LIMIT > 20
    all_results = []
    more_pages = False
    if snap:
        _snap_items = list(snap.get('items') or [])
        _start = (page - 1) * PAGE_LIMIT
        all_results = _snap_items[_start:_start + PAGE_LIMIT]
        more_pages = (len(_snap_items) > _start + PAGE_LIMIT) or (
            int(snap.get('api_pages') or 0) < int(snap.get('total_pages') or 0))
    else:
        for api_page in range(start_api_page, start_api_page + api_pages_needed):
            results = trakt_sync.get_tmdb_from_db(action, api_page)
            if not results:
                cache_lang = "ro-RO" if "romania_" in action else LANG
                string = f"{action}_{api_page}_{cache_lang}"
                data = cache_object(get_tmdb_movies_standard, string, [action, api_page], expiration=24)
                if data:
                    results = data.get('results', [])
            if not results:
                break
            all_results.extend(results)
            if api_page == start_api_page + api_pages_needed - 1:
                more_pages = True
            if len(results) < ITEMS_PER_API_PAGE:
                break

    if action == 'tmdb_movies_digital':
        try:
            _need = page * PAGE_LIMIT + 1
            _pool = _ensure_digital_pool(_need)
            _start = (page - 1) * PAGE_LIMIT
            all_results = _pool[_start:_start + PAGE_LIMIT + 1]
            more_pages = len(_pool) > _start + PAGE_LIMIT
        except Exception as e:
            log(f"[LIST] Digital pool esuat: {e}")

    if not all_results:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    current_items = all_results[:PAGE_LIMIT]
    has_next = len(all_results) > PAGE_LIMIT or more_pages

    try:
        current_items = [it for it in current_items if not _is_tmdb_list_junk(it)]
    except Exception:
        pass

    if action == 'tmdb_movies_digital':
        seen_ids = set()
        seen_titles = set()
        uniq = []
        for it in current_items:
            tid = str(it.get('id', '') or '')
            if tid and tid in seen_ids:
                continue
            tkey = (str(it.get('title', '') or '').strip().lower(),
                    str(it.get('release_date', '') or '')[:4])
            if tkey[0] and tkey in seen_titles:
                continue
            if tid:
                seen_ids.add(tid)
            if tkey[0]:
                seen_titles.add(tkey)
            uniq.append(it)
        current_items = uniq

# Pre-warm + procesare: prefetch populeaza RAM pool, apoi _process_movie_item citeste instant din cache
    cache_list = []
    items_to_add = []

    prefetch_metadata_parallel(current_items, 'movie')

    dig_map = {}
    if action == 'tmdb_movies_digital' and current_items:
        try:
            for _it in current_items:
                _ds = _it.get('_digital_date') or ''
                if _ds:
                    dig_map[str(_it.get('id', ''))] = _ds
            _missing = [it for it in current_items if str(it.get('id', '')) not in dig_map]
            if _missing:
                dig_map.update(_digital_dates_map(_missing))
        except Exception:
            dig_map = {}
        def _dig_key(it):
            tid = str(it.get('id', '') or '')
            ds = dig_map.get(tid, '')
            if ds:
                return (1, ds)
            return (0, str(it.get('release_date', '') or '')[:10])
        try:
            current_items.sort(key=_dig_key, reverse=True)
        except Exception:
            pass

    for item in current_items:
        try:
            processed = _process_movie_item(item, return_data=True, skip_details=True)
        except Exception as e:
            log(f"[LIST] Item film sarit la procesare: {e}")
            continue
        if processed:
            if dig_map:
                try:
                    _tid = str(item.get('id', '') or '')
                    _ds = dig_map.get(_tid, '')
                    if _ds:
                        _li = processed.get('li')
                        if _li is not None:
                            _li.setLabel(f"{_li.getLabel()} [B][COLOR FF00CED1](Digital • {_fmt_dmy(_ds)})[/COLOR][/B]")
                except Exception:
                    pass
            cache_list.append(processed)
            items_to_add.append((processed['url'], processed['li'], processed['is_folder']))

# --- FIX PAGINARE SI CACHE ---
    if has_next:
        # Cream manual item-ul de Next Page
        next_label = next_page_label(page + 1)
        next_params = {'mode': 'build_movie_list', 'action': action, 'new_page': str(page + 1)}
        next_url = plugin_url(next_params)
        
        next_li = xbmcgui.ListItem(next_label)
        style_page_nav_item(next_li, page + 1)
        
        # 1. Adaugam la afisare imediata
        items_to_add.append((next_url, next_li, True))
        
        # 2. Adaugam la Cache RAM (STRUCTURA CORECTATA PENTRU A EVITA KeyError 'li')
        cache_list.append({
            'url': next_url,
            'li': next_li,          # <--- ADAUGAT (CRITIC PENTRU CACHE)
            'is_folder': True,
            'info': {'mediatype': 'video', 'plot': next_page_plot(page + 1)}, # Minim necesar
            'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON},
            'cm_items': [],         # <--- RENUMIT DIN 'cm' IN 'cm_items'
            'resume_time': 0,
            'total_time': 0
        })

# --- BATCH ADD ---
    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))

    xbmcplugin.setContent(HANDLE, 'movies')
    
    # Pre-fetch paginile urmatoare INAINTE de endOfDirectory (maxim timp pentru thread)
    if not is_trending:
        trigger_next_page_warmup(action, page, 'movie')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    # Important: Curatam proprietatea ca sa stie fundalul ca am terminat
    window.clearProperty('tmdbmovies_loading_active')
    _set_views_apply('movies')

    
    # Save to RAM
    if not is_trending:
        set_fast_cache(cache_key, [{'label': i['li'].getLabel(), 'url': i['url'], 'is_folder': i['is_folder'], 
                                    'art': i['art'], 'info': i['info'], 'cm': i['cm_items'], 
                                    'resume_time': i['resume_time'], 'total_time': i['total_time']} for i in cache_list])


def build_tvshow_list(params):
    window = xbmcgui.Window(10000)
    window.setProperty('tmdbmovies_loading_active', 'true')
    
    # Adaugam un mic delay daca fundalul era ocupat, sa-i dam timp sa se opreasca
    if xbmcgui.Window(10000).getProperty('tmdbmovies_warmup_busy') == 'true':
        xbmc.sleep(100)
    action = params.get('action')
    page = int(params.get('new_page', '1'))

    if action and 'trakt_tv_' in action:
        from resources.lib.api import trakt_api
        list_type = action.replace('trakt_tv_', '')
        params['list_type'] = list_type
        params['media_type'] = 'shows'
        trakt_api.trakt_discovery_list(params)
        return

    from resources.lib.core.config import PAGE_LIMIT
    is_trending = action in _TRENDING_TV_ACTIONS
    snap = _trending_snapshot(action, page, 'tv', PAGE_LIMIT) if is_trending else None
    ITEMS_PER_API_PAGE = 20
    api_pages_needed = max(1, (PAGE_LIMIT + ITEMS_PER_API_PAGE - 1) // ITEMS_PER_API_PAGE)
    start_api_page = (page - 1) * api_pages_needed + 1

# --- FAST CACHE CHECK (RAM) ---
    cache_key = f"list_tv_{action}_{page}"
    if not is_trending:
        cached_data = get_fast_cache(cache_key)
        if cached_data:
            render_from_fast_cache(cached_data, view_type='tvshows')
            return
    # ---------------------------------

    # Fetch multiple API pages daca PAGE_LIMIT > 20
    all_results = []
    more_pages = False
    if snap:
        _snap_items = list(snap.get('items') or [])
        _start = (page - 1) * PAGE_LIMIT
        all_results = _snap_items[_start:_start + PAGE_LIMIT]
        more_pages = (len(_snap_items) > _start + PAGE_LIMIT) or (
            int(snap.get('api_pages') or 0) < int(snap.get('total_pages') or 0))
    else:
        for api_page in range(start_api_page, start_api_page + api_pages_needed):
            results = trakt_sync.get_tmdb_from_db(action, api_page)
            if not results:
                cache_lang = "ro-RO" if "romania_" in action else LANG
                string = f"{action}_{api_page}_{cache_lang}"
                data = cache_object(get_tmdb_tv_standard, string, [action, api_page], expiration=24)
                if data:
                    results = data.get('results', [])
            if not results:
                break
            all_results.extend(results)
            if api_page == start_api_page + api_pages_needed - 1:
                more_pages = True
            if len(results) < ITEMS_PER_API_PAGE:
                break

    if not all_results:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    current_items = all_results[:PAGE_LIMIT]
    has_next = len(all_results) > PAGE_LIMIT or more_pages

    try:
        current_items = [it for it in current_items if not _is_tmdb_list_junk(it)]
    except Exception:
        pass

# Pre-warm + procesare: prefetch populeaza RAM pool, apoi _process_tv_item citeste instant din cache
    cache_list = []
    items_to_add = []

    prefetch_metadata_parallel(current_items, 'tv')

    for item in current_items:
        try:
            processed = _process_tv_item(item, return_data=True, skip_details=True)
        except Exception as e:
            log(f"[LIST] Item serial sarit la procesare: {e}")
            continue
        if processed:
            cache_list.append(processed)
            items_to_add.append((processed['url'], processed['li'], processed['is_folder']))

# --- FIX PAGINARE SI CACHE ---
    if has_next:
        # Cream manual item-ul de Next Page
        next_label = next_page_label(page + 1)
        next_params = {'mode': 'build_tvshow_list', 'action': action, 'new_page': str(page + 1)}
        next_url = plugin_url(next_params)
        
        next_li = xbmcgui.ListItem(next_label)
        style_page_nav_item(next_li, page + 1)
        
        # 1. Adaugam la afisare
        items_to_add.append((next_url, next_li, True))
        
        # 2. Adaugam la Cache RAM (STRUCTURA CORECTATA)
        cache_list.append({
            'url': next_url,
            'li': next_li,          # <--- ADAUGAT (CRITIC)
            'is_folder': True,
            'info': {'mediatype': 'video', 'plot': next_page_plot(page + 1)},
            'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON},
            'cm_items': [],         # <--- RENUMIT
            'resume_time': 0,
            'total_time': 0
        })

# --- BATCH ADD ---
    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))

    xbmcplugin.setContent(HANDLE, 'tvshows')

    # Pre-fetch paginile urmatoare INAINTE de endOfDirectory (maxim timp pentru thread)
    if not is_trending:
        trigger_next_page_warmup(action, page, 'tv')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    # Important: Curatam proprietatea ca sa stie fundalul ca am terminat
    window.clearProperty('tmdbmovies_loading_active')
    _set_views_apply('tvshows')

    
    # Save to RAM
    if not is_trending:
        set_fast_cache(cache_key, [{'label': i['li'].getLabel(), 'url': i['url'], 'is_folder': i['is_folder'], 
                                    'art': i['art'], 'info': i['info'], 'cm': i['cm_items'], 
                                    'resume_time': 0, 'total_time': 0} for i in cache_list])

# Meniul contextual se construieste pentru FIECARE rand (la 160 de seriale sunt
# 10 setari x 160 = 1600 de citiri). getSetting() valideaza cache-ul cu
# os.path.getmtime() la fiecare apel, iar pe un profil pe SMB (sau orice
# filesystem lent) stat-ul costa ~1,5ms -> 2.4 secunde pierdute la fiecare
# constructie de lista, tocmai faza 'cm' masurata in log.
# Setarile nu se pot schimba in timpul unui build, deci le memorizam pe durata
# lui si stergem memo-ul la final (vezi _cm_memo_clear in get_next_episodes).
_CM_SET_MEMO = {}


def _cm_setting(key):
    v = _CM_SET_MEMO.get(key)
    if v is None:
        try:
            v = ADDON.getSetting(key)
        except Exception:
            v = 'false'
        _CM_SET_MEMO[key] = v
    return v


def _get_full_context_menu(tmdb_id, content_type, title='', is_in_favorites_view=False, year='', season=None, episode=None, imdb_id='', ep_name='', premiered='', ep_watched=None, progress=None):
    # ep_watched / progress: valori deja cunoscute de apelant (citite BULK).
    # Cind vin None, se citesc din DB ca inainte - semantica nu se schimba,
    # doar ca o lista de 63 de rinduri nu mai deschide 126 de conexiuni.
    cm = []
    # --- SELECT ACTION: daca randul e redirectionat catre Extended Info (setarea
    # select_ext_info), actiunea veche a selectului (Play / Browse Seasons) se muta
    # in meniul contextual, ca la POV/Redlight - nu se pierde nimic.
    if select_ext_info_params(content_type, tmdb_id, season=season, episode=episode, tv_name=title, title=title):
        if content_type == 'movie':
            _swap_params = urlencode({'mode': 'sources', 'tmdb_id': tmdb_id, 'type': 'movie', 'title': title, 'year': year})
            cm.append(('[B][COLOR FF6AFB92]Play Movie[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{_swap_params})"))
        elif content_type == 'episode' and season is not None and episode is not None:
            _swap_params = urlencode({'mode': 'sources', 'tmdb_id': tmdb_id, 'type': 'tv', 'season': str(season), 'episode': str(episode), 'title': ep_name or title, 'tv_show_title': title})
            cm.append(('[B][COLOR FF6AFB92]Play Episode[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{_swap_params})"))
        elif content_type in ('tv', 'show', 'tvshow'):
            _swap_params = urlencode({'mode': 'details', 'tmdb_id': tmdb_id, 'type': 'tv', 'title': title})
            cm.append(('[B][COLOR cyan]Browse Seasons[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{_swap_params})"))
    # ------------------------------------------------------------------
    # info_params = urlencode({'mode': 'show_info', 'type': content_type, 'tmdb_id': tmdb_id})
    # cm.append(('[B][COLOR FFFDBD01]TMDb Info[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{info_params})"))
    
    # --- ADAUGAT EXTENDED INFO (Metoda cu argumente explicite) ---
    # Folosim calea speciala pentru a fi siguri ca gaseste scriptul
    # Trimitem id si type ca argumente separate prin virgula
    # import xbmcaddon
    # my_addon_id = xbmcaddon.Addon().getAddonInfo('id')
    # script_path = f"special://home/addons/{my_addon_id}/context_extended.py"
    
    # RunScript(script, arg1, arg2...)
    # run_cmd = f"RunScript({script_path}, tmdb_id={tmdb_id}, type={content_type})"
    
    # cm.append(('[B][COLOR FF33CCFF]Extended Info[/COLOR][/B]', run_cmd))
    # -------------------------------------------------------------

    trakt_params_dict = {'mode': 'trakt_context_menu', 'tmdb_id': tmdb_id, 'type': content_type, 'title': title}
    if season: trakt_params_dict['season'] = season
    if episode: trakt_params_dict['episode'] = episode
    if _cm_setting('show_cm_trakt') != 'false':
        cm.append(('[B][COLOR pink]My Trakt[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{urlencode(trakt_params_dict)})"))

    tmdb_params_dict = {'mode': 'tmdb_context_menu', 'tmdb_id': tmdb_id, 'type': content_type, 'title': title}
    if season: tmdb_params_dict['season'] = season
    if episode: tmdb_params_dict['episode'] = episode
    if _cm_setting('show_cm_tmdb') != 'false':
        cm.append(('[B][COLOR FF00CED1]My TMDB[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{urlencode(tmdb_params_dict)})"))

    # --- INSEREAZA RANDURILE ASTEA PENTRU MDB: ---
    mdb_params_dict = {'mode': 'mdblist_context_menu', 'tmdb_id': tmdb_id, 'type': content_type, 'title': title, 'imdb_id': imdb_id}
    if season: mdb_params_dict['season'] = season
    if episode: mdb_params_dict['episode'] = episode
    if _cm_setting('show_cm_mdblist') != 'false':
        cm.append(('[B][COLOR lightskyblue]My MDBList[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{urlencode(mdb_params_dict)})"))

    # --- SIMKL: ---
    simkl_params_dict = {'mode': 'simkl_context_menu', 'tmdb_id': tmdb_id, 'type': content_type, 'title': title, 'imdb_id': imdb_id}
    if season: simkl_params_dict['season'] = season
    if episode: simkl_params_dict['episode'] = episode
    if _cm_setting('show_cm_simkl') != 'false':
        cm.append(('[B][COLOR mediumpurple]My Simkl[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{urlencode(simkl_params_dict)})"))

    # --- PUNCHPLAY: ---
    pp_params_dict = {'mode': 'punchplay_context_menu', 'tmdb_id': tmdb_id, 'type': content_type, 'title': title, 'imdb_id': imdb_id}
    if season: pp_params_dict['season'] = season
    if episode: pp_params_dict['episode'] = episode
    if _cm_setting('show_cm_punchplay') != 'false':
        cm.append(('[B][COLOR FFFF6600]My PunchPlay[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{urlencode(pp_params_dict)})"))

    # --- ALL PROVIDERS (batch pe TMDb + Trakt + MDBList — toggle in Settings) ---
    if _cm_setting('all_providers_menu') == 'true':
        allp_params_dict = {'mode': 'all_providers_context_menu', 'tmdb_id': tmdb_id, 'type': content_type, 'title': title}
        if season: allp_params_dict['season'] = season
        if episode: allp_params_dict['episode'] = episode
        if imdb_id: allp_params_dict['imdb_id'] = imdb_id
        cm.append((f'[B]{_allprov_colored("All Providers", (3, 4, 3, 3), ("trakt", "tmdb", "mdblist", "simkl"))}[/B]', f"RunPlugin({PLUGIN_URL}?{urlencode(allp_params_dict)})"))

    # --- INCEPUT MODIFICARE: MY PLAYS MENU ---
    plays_params = {
        'mode': 'show_my_plays_menu',
        'tmdb_id': tmdb_id,
        'type': content_type,
        'title': title,
        'year': year,
        'imdb_id': imdb_id  # <--- TRIMITEM IMDB ID
    }
    if season is not None: plays_params['season'] = season
    if episode is not None: plays_params['episode'] = episode
    if ep_name: plays_params['ep_name'] = ep_name
    if premiered: plays_params['premiered'] = premiered
    
    if _cm_setting('show_cm_my_plays') != 'false':
        cm.append(('[B][COLOR FFFF69B4]My Plays[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{urlencode(plays_params)})"))
    # --- SFARSIT MODIFICARE ---

    # --- Mark as Watched/Unwatched direct in root menu ---
    from resources.lib.providers.watched_provider import get_label as _prov_label, get_color as _prov_color, mark_menu_label as _mml
    _prov_lbl = _prov_label()
    _prov_clr = _prov_color()
    _w_label = f'[B][COLOR FF6AFB92]Mark Watched [COLOR {_prov_clr}]({_prov_lbl})[/COLOR][/B]'
    _uw_label = f'[B][COLOR FFE41B17]Mark Unwatched [COLOR {_prov_clr}]({_prov_lbl})[/COLOR][/B]'
    if content_type == 'movie':
        from resources.lib.providers.watched_provider import is_movie_watched as _is_mw
        _is_w = _is_mw(tmdb_id)
        _w_sp = urlencode({'mode': 'mark_watched', 'tmdb_id': tmdb_id, 'type': 'movie'})
        _uw_sp = urlencode({'mode': 'mark_unwatched', 'tmdb_id': tmdb_id, 'type': 'movie'})
        cm.append((_mml(_is_w) or (_uw_label if _is_w else _w_label), f"RunPlugin({PLUGIN_URL}?{_uw_sp if _is_w else _w_sp})"))
    elif content_type in ('tv', 'show'):
        from resources.lib.providers.watched_provider import get_watched_counts as _get_wc
        _is_w = (_get_wc(tmdb_id, 'tv') > 0)
        _w_sp = urlencode({'mode': 'mark_watched', 'tmdb_id': tmdb_id, 'type': 'tv'})
        _uw_sp = urlencode({'mode': 'mark_unwatched', 'tmdb_id': tmdb_id, 'type': 'tv'})
        cm.append((_mml(_is_w) or (_uw_label if _is_w else _w_label), f"RunPlugin({PLUGIN_URL}?{_uw_sp if _is_w else _w_sp})"))
    elif content_type == 'episode':
        if season is not None and episode is not None:
            if ep_watched is None:
                from resources.lib.providers.watched_provider import is_episode_watched as _is_epw
                _is_w = _is_epw(tmdb_id, season, episode)
            else:
                _is_w = bool(ep_watched)
            _w_sp = urlencode({'mode': 'mark_watched', 'tmdb_id': tmdb_id, 'type': 'episode', 'season': str(season), 'episode': str(episode)})
            _uw_sp = urlencode({'mode': 'mark_unwatched', 'tmdb_id': tmdb_id, 'type': 'episode', 'season': str(season), 'episode': str(episode)})
            cm.append((_mml(_is_w) or (_uw_label if _is_w else _w_label), f"RunPlugin({PLUGIN_URL}?{_uw_sp if _is_w else _w_sp})"))
    # ---------------------------------------------------------
    
    # --- MODIFICARE: DOAR PENTRU FILME (nu seriale/foldere) ---
    if content_type == 'movie':
        clear_params = urlencode({'mode': 'clear_sources_context', 'tmdb_id': tmdb_id, 'type': 'movie', 'title': title})
        cm.append(('[B][COLOR orange]Clear sources cache[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{clear_params})"))
    # ----------------------------------------------------------
    
    if is_in_favorites_view:
        rem_params = urlencode({'mode': 'remove_favorite', 'type': content_type, 'tmdb_id': tmdb_id})
        cm.append(('[B][COLOR yellow]Remove from My Favorites[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{rem_params})"))
    else:
        fav_params = urlencode({'mode': 'add_favorite', 'type': content_type, 'tmdb_id': tmdb_id, 'title': title})
        cm.append(('[B][COLOR yellow]Add to My Favorites[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{fav_params})"))

    if content_type in ('movie', 'episode'):
        if content_type == 'movie':
            scrape_params = urlencode({'mode': 'sources', 'tmdb_id': tmdb_id, 'type': 'movie', 'title': title, 'year': year, 'custom_title': '', 'custom_interactive': 'true'})
        else:
            scrape_params = urlencode({'mode': 'sources', 'tmdb_id': tmdb_id, 'type': 'tv', 'title': title, 'season': str(season), 'episode': str(episode), 'custom_title': '', 'custom_interactive': 'true'})
        cm.append(('[B]Scrape with Custom Values[/B]', f"RunPlugin({PLUGIN_URL}?{scrape_params})"))

    if progress is None:
        from resources.lib.providers import trakt_sync
        progress = trakt_sync.get_local_playback_progress(tmdb_id, content_type, season, episode)
    
    # Recunoastem procentele noi (<90) dar si formatul vechi de resume (>= 1000000)
    if progress > 0 and (progress < 90 or progress >= 1000000):
        rem_params = {'mode': 'remove_progress', 'tmdb_id': tmdb_id, 'type': content_type}
        if season: rem_params['season'] = str(season)
        if episode: rem_params['episode'] = str(episode)
        cm.append(('[B][COLOR FFFF4444]Delete Resume[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{urlencode(rem_params)})"))

    # --- PLAY WITH SOURCE SELECT: are rost doar cand auto-play este pornit
    # (altfel selectul randului deschide deja fereastra surselor). Pozitionat
    # chiar deasupra "Search Youtube". no_auto=1 ocoleste autoplay-ul. ---
    if _cm_setting('auto_play') == 'true':
        if content_type == 'movie':
            _sel_auto = urlencode({'mode': 'sources', 'tmdb_id': tmdb_id, 'type': 'movie', 'title': title, 'year': year, 'no_auto': '1'})
            cm.append(('[B][COLOR cyan]Play with source select[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{_sel_auto})"))
        elif content_type == 'episode' and season is not None and episode is not None:
            _sel_auto = urlencode({'mode': 'sources', 'tmdb_id': tmdb_id, 'type': 'tv', 'season': str(season), 'episode': str(episode), 'title': ep_name or title, 'tv_show_title': title, 'no_auto': '1'})
            cm.append(('[B][COLOR cyan]Play with source select[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{_sel_auto})"))

    yt_params_dict = {'mode': 'youtube_search', 'tmdb_id': tmdb_id, 'type': content_type, 'title': title, 'year': year}
    if season is not None: yt_params_dict['season'] = str(season)
    if episode is not None: yt_params_dict['episode'] = str(episode)
    if _cm_setting('show_cm_youtube') != 'false':
        cm.append(('[B][COLOR FFF70D1A]Search Youtube[/COLOR][/B]', f"Container.Update({plugin_url(yt_params_dict)})"))

    # Ultima optiune. Container.Update ca lista sa inlocuiasca pagina (Back revine aici).
    if content_type == 'movie' and _cm_setting('show_cm_detonate') != 'false':
        det_params_dict = {'mode': 'detonate_search', 'query': title, 'tmdb_id': tmdb_id,
                           'title': title, 'year': year}
        cm.append(('[B][COLOR FFCCCCFF]Search Detonate[/COLOR][/B]', f"Container.Update({plugin_url(det_params_dict)})"))

    return cm

def _process_movie_item(item, is_in_favorites_view=False, return_data=False, skip_details=False):
    from resources.lib.providers import watched_provider
    tmdb_id = str(item.get('id', ''))
    if not tmdb_id: return None  # Returnam None daca nu e ID valid

    title = item.get('title') or 'Unknown'
    year = str(item.get('release_date', ''))[:4]
    plot = item.get('overview', '')
    
    full_details = (get_tmdb_item_details(tmdb_id, 'movie', lightweight=True) or {}) if not skip_details else _get_cached_details(tmdb_id, 'movie')
    
    # --- MODIFICARE: EXTRAGERE IMDB ID ---
    imdb_id = full_details.get('external_ids', {}).get('imdb_id', '')
    # -------------------------------------
    
    studio = ''
    if full_details.get('production_companies'):
        studio = full_details['production_companies'][0].get('name', '')
        
    rating = full_details.get('vote_average', item.get('vote_average', 0))
    votes = full_details.get('vote_count', item.get('vote_count', 0))
    premiered = full_details.get('release_date', item.get('release_date', ''))
    
    try:
        duration = int(full_details.get('runtime') or 0) * 60
    except:
        duration = 0
    if duration <= 0: duration = 7200 # Fallback 2 ore
    
    # Acum full_details are DEJA RO in el automat!
    tagline = full_details.get('tagline', '').strip()
    genres_str = get_genres_string(item.get('genre_ids',[]))
    if not genres_str and full_details.get('genres'):
        genres_str = ", ".join([g['name'] for g in full_details['genres']])
        
    plot = full_details.get('overview') or item.get('overview') or ''
    
    try: show_motto = ADDON.getSetting('show_motto_genre') != 'false'
    except: show_motto = True
    
    plot_header = ""
    if show_motto:
        if tagline and genres_str:
            plot_header = f"[B][COLOR yellow]{tagline}[/COLOR][/B] | [B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n"
        elif tagline:
            plot_header = f"[B][COLOR yellow]{tagline}[/COLOR][/B]\n"
        elif genres_str:
            plot_header = f"[B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n"
        
    plot = plot_header + plot
    
    poster_path = full_details.get('poster_path', item.get('poster_path', ''))
    backdrop_path = full_details.get('backdrop_path', item.get('backdrop_path', ''))
    
    raw_logo = full_details.get('clearlogo', '')
    movie_logo = f"{IMG_BASE}{raw_logo}" if raw_logo and not raw_logo.startswith('http') else raw_logo

    # --- LOGICA CULOARE ROSIE FILME NELANSATE ---
    display_title = f"{title} ({year})" if year else title
    if premiered:
        try:
            p_str = str(premiered)[:10]
            parts = p_str.split('-')
            release_date = datetime.date(int(parts[0]), int(parts[1]), int(parts[2]))
            today = datetime.date.today()
            # Ora de lansare (doar azi / maine) din calendarul Trakt de filme.
            _mv_at = ''
            if 0 <= (release_date - today).days <= 1:
                try:
                    _mv_at = movie_release_air_time(tmdb_id, release_date, today)
                except:
                    _mv_at = ''
            if release_date == today:
                # Lansare AZI: nume + eticheta galben bold (la fel ca in
                # Up Next, sezon si calendare). Rozul e pentru viitor.
                _dl = f"{calendar_localized_label(0, '')} • {_mv_at}" if _mv_at else calendar_localized_label(0, '')
                date_label = f"[B][COLOR yellow]({_dl})[/COLOR][/B]"
                display_title = f"[B][COLOR yellow]{display_title}[/COLOR][/B] {date_label}"
            elif release_date > today:
                if release_date == today + datetime.timedelta(days=1):
                    _base = calendar_localized_label(1, _fmt_dmy(p_str))
                else:
                    _base = _fmt_dmy(p_str)
                _dl = f"{_base} • {_mv_at}" if _mv_at else _base
                date_label = f"[B][COLOR white]({_dl})[/COLOR][/B]"
                display_title = f"[B][COLOR FFE238EC]{display_title}[/COLOR][/B] {date_label}"
        except: pass

    # --- CALCUL RESUME ---
    from resources.lib.providers import trakt_sync
    progress_value = trakt_sync.get_local_playback_progress(tmdb_id, 'movie')
    
    resume_percent = 0
    resume_time = 0
    if progress_value >= 1000000:
        resume_time = int(progress_value - 1000000)
        resume_percent = (resume_time / duration) * 100
    elif 0 < progress_value < 90:
        resume_percent = progress_value
        resume_time = int((resume_percent / 100.0) * duration)

    poster_path = full_details.get('poster_path', item.get('poster_path', ''))
    poster = f"{IMG_BASE}{poster_path}" if poster_path else TMDbmovies_ICON
    backdrop_path = full_details.get('backdrop_path', item.get('backdrop_path', ''))
    backdrop = f"{BACKDROP_BASE}{backdrop_path}" if backdrop_path else ''

    is_watched = watched_provider.get_watched_counts(tmdb_id, 'movie') > 0
    if is_watched and '[COLOR' not in display_title:
        display_title = f'[B][COLOR FF6AFB92]{display_title}[/COLOR][/B]'

    info = {
        'mediatype': 'movie', 'title': title, 'year': year, 'plot': plot, 
        'rating': rating, 'votes': votes, 'premiered': premiered, 
        'studio': studio, 'duration': duration, 'resume_percent': resume_percent,
        'genre': genres_str,
        'playcount': 1 if is_watched else 0,
        'mpaa': full_details.get('mpaa', '')
    }
    
    # --- MODIFICARE: Trimitem imdb_id in context menu ---
    cm = _get_full_context_menu(tmdb_id, 'movie', title, is_in_favorites_view, year=year, imdb_id=imdb_id)
    # ----------------------------------------------------
    url_params = select_ext_info_params('movie', tmdb_id) or {'mode': 'sources', 'tmdb_id': tmdb_id, 'type': 'movie', 'title': title, 'year': year}
    
    li = xbmcgui.ListItem(display_title)
    
    art = {'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': backdrop}
    if movie_logo:
        art['clearlogo'] = movie_logo
    li.setArt(art)
    
    _safe_set_prop(li, 'tmdb_id', tmdb_id)
    set_metadata(li, info, unique_ids={'tmdb': tmdb_id}, watched_info=is_watched)
    
    if resume_time > 0:
        set_resume_point(li, resume_time, duration)

    if cm: li.addContextMenuItems(cm)
    
    # --- LOGICA DE RETURNARE PENTRU CACHE ---
    if return_data:
        return {
            'url': plugin_url(url_params),
            'li': li,
            'is_folder': False,
            'info': info,
            'art': {'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': backdrop, 'clearlogo': movie_logo},
            'cm_items': cm,
            'resume_time': resume_time,
            'total_time': duration,
            'label': display_title
        }

    # Adauga clearlogo=movie_logo in apelul functiei
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(url_params), li, False)


def _process_tv_item(item, is_in_favorites_view=False, return_data=False, skip_details=False):
    from resources.lib.api import trakt_api
    tmdb_id = str(item.get('id', ''))
    if not tmdb_id: return None

    title = item.get('name', item.get('title', 'Unknown'))
    year = str(item.get('first_air_date', ''))[:4]
    plot = item.get('overview', '')

    full_details = (get_tmdb_item_details(tmdb_id, 'tv', lightweight=True) or {}) if not skip_details else _get_cached_details(tmdb_id, 'tv')
    # --- FALLBACK TITLU: cand itemul n-are nume (ex: dropped din DB), luam din metadata ---
    if not title or title == 'Unknown':
        title = full_details.get('name') or 'Unknown'
    # --- MODIFICARE: EXTRAGERE IMDB ID ---
    imdb_id = full_details.get('external_ids', {}).get('imdb_id', '')
    # -------------------------------------
    studio = full_details['networks'][0].get('name', '') if full_details.get('networks') else ''
    rating = full_details.get('vote_average', item.get('vote_average', 0))
    votes = full_details.get('vote_count', item.get('vote_count', 0))
    premiered = full_details.get('first_air_date', item.get('first_air_date', ''))
    
    try:
        runtimes = full_details.get('episode_run_time')
        duration = int(runtimes[0]) * 60 if runtimes and runtimes[0] else 0
    except:
        duration = 0
    
    # 1. Datele de baza in engleza
    tagline = full_details.get('tagline', '').strip()
    genres_str = get_genres_string(item.get('genre_ids',[]))
    if not genres_str and full_details.get('genres'):
        genres_str = ", ".join([g['name'] for g in full_details['genres']])
        
    plot = full_details.get('overview') or item.get('overview') or ''
    
    try: show_motto = ADDON.getSetting('show_motto_genre') != 'false'
    except: show_motto = True
    
    plot_header = ""
    if show_motto:
        if tagline and genres_str:
            plot_header = f"[B][COLOR yellow]{tagline}[/COLOR][/B] | [B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n"
        elif tagline:
            plot_header = f"[B][COLOR yellow]{tagline}[/COLOR][/B]\n"
        elif genres_str:
            plot_header = f"[B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n"
        
    plot = plot_header + plot
        
    poster_path = full_details.get('poster_path', item.get('poster_path', ''))
    backdrop_path = full_details.get('backdrop_path', item.get('backdrop_path', ''))
    
    raw_logo = full_details.get('clearlogo', '')
    tv_logo = f"{IMG_BASE}{raw_logo}" if raw_logo and not raw_logo.startswith('http') else raw_logo

    # --- LOGICA CULOARE ROSIE SERIALE NELANSATE ---
    display_name = f"{title} ({year})" if year else title
    if premiered:
        try:
            p_str = str(premiered)[:10]
            parts = p_str.split('-')
            release_date = datetime.date(int(parts[0]), int(parts[1]), int(parts[2]))
            today = datetime.date.today()
            if release_date == today:
                _dl = calendar_localized_label(0, '')
                if 0 <= (release_date - today).days <= 1:
                    try:
                        _sa = get_episode_air_stamp(tmdb_id, 1, 1)[1]
                    except:
                        _sa = ''
                    if _sa:
                        _dl = f"{_dl} • {_sa}"
                date_label = f"[B][COLOR yellow]({_dl})[/COLOR][/B]"
                display_name = f"[B][COLOR yellow]{display_name}[/COLOR][/B] {date_label}"
            elif release_date > today:
                if release_date == today + datetime.timedelta(days=1):
                    _base = calendar_localized_label(1, _fmt_dmy(p_str))
                    try:
                        _sa = get_episode_air_stamp(tmdb_id, 1, 1)[1]
                    except:
                        _sa = ''
                    _base = f"{_base} • {_sa}" if _sa else _base
                    date_label = f"[B][COLOR white]({_base})[/COLOR][/B]"
                else:
                    date_label = f"[B][COLOR white]({_fmt_dmy(p_str)})[/COLOR][/B]"
                display_name = f"[B][COLOR FFE238EC]{display_name}[/COLOR][/B] {date_label}"
        except: pass

    poster_path = full_details.get('poster_path', item.get('poster_path', ''))
    poster = f"{IMG_BASE}{poster_path}" if poster_path else TMDbmovies_ICON
    backdrop_path = full_details.get('backdrop_path', item.get('backdrop_path', ''))
    backdrop = f"{BACKDROP_BASE}{backdrop_path}" if backdrop_path else ''

    watched_info = get_watched_status_tvshow(tmdb_id)
    
    # Asiguram-ne ca valorile sunt intotdeauna numere intregi (evitam eroarea cu NoneType)
    w_watched = int(watched_info.get('watched') or 0)
    w_total = int(watched_info.get('total') or 0)
    
    # Verificam daca serialul este vazut complet pentru bifa
    is_watched = w_watched >= w_total if w_total > 0 else False
    if is_watched and '[COLOR' not in display_name:
        display_name = f'[B][COLOR FF6AFB92]{display_name}[/COLOR][/B]'
    
    info = {
        'mediatype': 'tvshow', 'title': title, 'year': year, 'plot': plot, 
        'rating': rating, 'votes': votes, 'premiered': premiered, 
        'studio': studio, 'duration': duration, 'genre': genres_str,
        'playcount': 1 if is_watched else 0,
        'mpaa': full_details.get('mpaa', '')
    }

    # --- MODIFICARE: Trimitem parametrul year catre _get_full_context_menu ---
    cm = _get_full_context_menu(tmdb_id, 'tv', title, is_in_favorites_view, year=year, imdb_id=imdb_id)
    # -------------------------------------------------------------------------
    _sel_info = select_ext_info_params('tv', tmdb_id)
    url_params = _sel_info or {'mode': 'details', 'tmdb_id': tmdb_id, 'type': 'tv', 'title': title}
    
    li = xbmcgui.ListItem(display_name)
    
    art = {'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': backdrop}
    if tv_logo:
        art['clearlogo'] = tv_logo
        art['tvshow.clearlogo'] = tv_logo
        art['tvshow.logo'] = tv_logo
        art['logo'] = tv_logo
        art['fanart_clearlogo'] = tv_logo
    li.setArt(art)
    
    _safe_set_prop(li, 'tmdb_id', tmdb_id)
    set_metadata(li, info, unique_ids={'tmdb': tmdb_id}, watched_info=watched_info)
    
    if cm: li.addContextMenuItems(cm)
    
    # --- LOGICA DE RETURNARE PENTRU CACHE ---
    if return_data:
        return {
            'url': plugin_url(url_params),
            'li': li,
            'is_folder': not _sel_info,
            'info': info,
            'art': art,  # ACUM TRIMIT TOATE ART-URILE INCLUZAND LOGO!
            'cm_items': cm,
            'label': display_name
        }
    # ----------------------------------------

    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(url_params), li, not _sel_info)


# Optimized get_watched_status_tvshow
_TV_META_HEAL_CHECKED = set()

def get_watched_status_tvshow(tmdb_id, watched_count=None):
    """watched_count poate veni pre-citit (bulk) din lista care randeaza zeci de
    seriale, ca sa nu se deschida o conexiune per rind."""
    from resources.lib.providers import watched_provider, trakt_sync
    str_id = str(tmdb_id)
    if watched_count is None:
        watched_count = watched_provider.get_watched_counts(tmdb_id, 'tv')

    if str_id in TV_META_CACHE:
        total_eps = TV_META_CACHE[str_id]
    else:
        total_eps = trakt_sync.get_tv_meta_from_db(str_id)
        TV_META_CACHE[str_id] = total_eps

    if not total_eps and watched_count > 0:
        details = get_tmdb_item_details(str_id, 'tv')
        if details:
            total_eps = details.get('number_of_episodes', 0)
            if total_eps:
                trakt_sync.set_tv_meta_to_db(str_id, total_eps)
        else:
            total_eps = 0
        TV_META_CACHE[str_id] = total_eps

    if watched_count > (total_eps or 0) > 0 and str_id not in _TV_META_HEAL_CHECKED:
        _TV_META_HEAL_CHECKED.add(str_id)
        try:
            import xbmcgui as _xg
            _sync_active = _xg.Window(10000).getProperty('tmdbmovies_sync_active') == 'true'
        except:
            _sync_active = False
        if not _sync_active:
            try:
                fresh = get_tmdb_item_details(str_id, 'tv', lightweight=True, skip_localization=True, force=True)
                fresh_total = int((fresh or {}).get('number_of_episodes') or 0)
                if fresh_total > (total_eps or 0):
                    log(f"[TV META] Heal {str_id}: total {total_eps} -> {fresh_total} (watched={watched_count})")
                    trakt_sync.set_tv_meta_to_db(str_id, fresh_total)
                    TV_META_CACHE[str_id] = fresh_total
                    total_eps = fresh_total
            except:
                pass

    # Providerul poate declara un serial "complet" chiar daca oglinda noastra
    # de episoade o contrazice (MDBList trimite in sync/watched.shows orice
    # serial cu activitate, nu doar pe cele complet vizionate). Nu credem
    # declaratia cand avem episoade reale mai putine decat totalul - altfel
    # 1 episod din 40 primea badge "Complet" in In Progress TV Shows.
    _contradicted = bool(watched_count and total_eps and watched_count < total_eps)
    if not (total_eps and watched_count >= total_eps) and not _contradicted:
        try:
            # Setul vine citit O SINGURA DATA pe build (vezi
            # watched_provider.get_fully_watched_set). Fara el, fiecare rand deschide
            # propria conexiune SQLite prin is_fully_watched_show: pe Android,
            # 164 de randuri inseamna ~3,4s pierdute aici.
            _fws = watched_provider.get_fully_watched_set()
            if _fws is not None:
                _is_full = str_id in _fws
            else:
                _mod = watched_provider.get_source_module()
                _chk = getattr(_mod, 'is_fully_watched_show', None) if _mod else None
                _is_full = bool(_chk(str_id)) if callable(_chk) else False
            if _is_full:
                _t = total_eps or watched_count
                if not _t:
                    try:
                        fresh = get_tmdb_item_details(str_id, 'tv', lightweight=True, skip_localization=True)
                        _t = int((fresh or {}).get('number_of_episodes') or 0)
                        if _t:
                            trakt_sync.set_tv_meta_to_db(str_id, _t)
                            TV_META_CACHE[str_id] = _t
                    except:
                        pass
                if _t:
                    return {'watched': _t, 'total': _t}
        except:
            pass

    return {'watched': watched_count, 'total': total_eps}
# --------------------------------------------------------------------


# TMDB V4 AUTH -------------------

def get_tmdb_v4_token():
    """Citeste token-ul v4 al utilizatorului din fisierul local."""
    data = read_json(TMDB_V4_TOKEN_FILE)
    if data and data.get('access_token'):
        return data['access_token']
    return None

def tmdb_auth():
    """Autentificare TMDb cu QR code (v4, stil Umbrella) — singura metoda de conectare."""
    dialog = xbmcgui.Dialog()
    
    # Verificam daca avem cheia de develop in config
    if not TMDB_V4_READ_TOKEN or "PUNE_AICI" in TMDB_V4_READ_TOKEN:
        dialog.notification("Error Config", "TMDB_V4_READ_TOKEN not set in config.py!", xbmcgui.NOTIFICATION_ERROR)
        return

    headers = {
        'Authorization': f'Bearer {TMDB_V4_READ_TOKEN}',
        'Content-Type': 'application/json;charset=utf-8'
    }
    
    try:
        # 1. Cerem Request Token
        r = requests.post('https://api.themoviedb.org/4/auth/request_token', headers=headers, timeout=10)
        data = r.json()
        
        if not data.get('success'):
            dialog.notification("Error TMDb", data.get('status_message', 'Error'), xbmcgui.NOTIFICATION_ERROR)
            return
            
        request_token = data['request_token']
        
        # 2. Construim URL-ul de aprobare
        url_full = f"https://www.themoviedb.org/auth/access?request_token={request_token}"
        
        # Copiem link-ul in clipboard (daca e pe PC/Android)
        xbmc.executebuiltin(f'SetProperty(TMDbAuthLink,{url_full},home)')
        
        # --- GENERARE LINK SCURT (TinyURL) — doar pentru afisare; QR-ul are URL-ul complet ---
        try:
            r_tiny = requests.get(f'http://tinyurl.com/api-create.php?url={url_full}', timeout=5)
            if r_tiny.status_code == 200 and r_tiny.text.startswith('http'):
                url_display = r_tiny.text.strip()
            else:
                url_display = url_full  # Fallback la cel lung
        except:
            url_display = url_full
        
        # ----------------------------------------------------------------------------------------------------
        # QR CODE AUTH (stil Umbrella) — dialog custom cu QR + cod
        # doModal() pe MAIN THREAD (input garantat); polling in background
        # ----------------------------------------------------------------------------------------------------
        import threading
        from resources.lib.core.utils import make_qr
        from resources.lib.core.auth_dialog import QRProgressDialog, run_modal_main_thread

        qr_path = make_qr(url_full, 'tmdb_v4_qr.png')
        msg = (f"1. Open this link in browser:\n"
               f"[B][COLOR FF00CED1]{url_display}[/COLOR][/B]\n"
               f"2. Log in and press [B]Approve[/B]")

        pdialog = QRProgressDialog(
            'auth_qr.xml', ADDON.getAddonInfo('path'), 'Default', '1080i',
            heading='[B][COLOR FF00CED1]TMDb Authentication[/COLOR][/B]',
            qr_image=qr_path or '',
            icon=TMDB_ICON,
            addon_icon=os.path.join(ADDON.getAddonInfo('path'), 'icon.png'),
            content=msg,
        )

        log(f"[TMDB] Auth: aproba acest link (doar el conteaza): {url_full}", xbmc.LOGINFO)

        _result = {}
        _mon = xbmc.Monitor()
        expires_in = 3600  # Request token TMDb v4: valid 60 minute

        def _poll():
            start_time = time.time()
            polls = 0
            while not pdialog.iscanceled() and not _mon.abortRequested():
                elapsed = time.time() - start_time
                if elapsed > expires_in:
                    pdialog.expired = True
                    pdialog.close()
                    return
                percent = max(0, int(100 - (elapsed / expires_in * 100)))
                pdialog.update(percent, msg)
                time.sleep(5)
                try:
                    # Inainte de aprobare raspunde cu 422/41 (nu invalideaza token-ul);
                    # dupa Approve pe site, prima apelare cu succes schimba token-ul.
                    r2 = requests.post('https://api.themoviedb.org/4/auth/access_token',
                                       headers=headers,
                                       json={'request_token': request_token},
                                       timeout=15)
                    data2 = r2.json()
                    polls += 1
                    if data2.get('success'):
                        log(f"[TMDB] Access token granted after {polls} poll(s)", xbmc.LOGINFO)
                        _result['data'] = data2
                        _result['polls'] = polls
                        _result['last'] = 'approved'
                        pdialog.close()
                        return
                    _result['polls'] = polls
                    _result['last'] = f"HTTP {r2.status_code} code {data2.get('status_code')}"
                    if data2.get('status_code') != 41:
                        log(f"[TMDB] Poll {polls}: {_result['last']} {data2.get('status_message')}", xbmc.LOGWARNING)
                except Exception as e:
                    polls += 1
                    _result['polls'] = polls
                    _result['last'] = f"EXC {e!r}"
                    log(f"[TMDB] Poll {polls} exception: {e!r}", xbmc.LOGWARNING)

        threading.Thread(target=_poll, daemon=True).start()
        log(f"[TMDB] QR dialog deschis — poll la fiecare 5s", xbmc.LOGINFO)
        run_modal_main_thread(pdialog)
        pdialog.close()

        # 3. Schimbam Request Token pe Access Token (Final)
        data2 = _result.get('data')
        if data2:
            username = 'User'
            try:
                acc_headers = {'Authorization': f"Bearer {data2['access_token']}"}
                acc_r = requests.get(f"{BASE_URL}/account", headers=acc_headers, timeout=10)
                if acc_r.status_code == 200:
                    username = acc_r.json().get('username', 'User')
            except:
                pass

            write_json(TMDB_V4_TOKEN_FILE, {
                'access_token': data2['access_token'],
                'account_id': data2['account_id'],
                'username': username
            })
            ADDON.setSetting('tmdb_status', f"Connected: {username}")
            dialog.notification(provider_title('tmdb', name='TMDB'), f"Connected: [B][COLOR FFF70D1A]{username}[/COLOR][/B]", TMDB_ICON, 3000, False)
            
            # ----------------------------------------------------------------------------------------------------
            # ADAUGAT: Actualizare automata a listelor (inclusiv seriale v4)
            # ----------------------------------------------------------------------------------------------------
            t = threading.Thread(target=trakt_sync.sync_full_library, kwargs={'silent': False, 'force': True})
            t.daemon = True
            t.start()
            # ----------------------------------------------------------------------------------------------------
        elif pdialog.expired:
            dialog.notification("TMDb", "Request expired. Try again.", xbmcgui.NOTIFICATION_ERROR)
        elif not pdialog.iscanceled():
            dialog.notification("Error", "You did not approve.", xbmcgui.NOTIFICATION_ERROR)
        else:
            log(f"[TMDB] Auth dialog closed by user; polls={_result.get('polls', 0)} last={_result.get('last', 'never')}", xbmc.LOGWARNING)
            if _result.get('polls', 0) > 0:
                dialog.notification("TMDb", "No approval detected. Close ALL old TMDb tabs in browser, then approve the NEW link shown on screen.", xbmcgui.NOTIFICATION_WARNING)
            
    except Exception as e:
        log(f"[TMDB] Auth Error: {e}", xbmc.LOGERROR)
        dialog.notification("Error", "Check the log", xbmcgui.NOTIFICATION_ERROR)



# ------------------

def get_tmdb_session():
    """Returneaza datele contului TMDb autentificat cu QR (v4): account_id, access_token, username."""
    data = read_json(TMDB_V4_TOKEN_FILE)
    # Verificam intai daca data exista si este un dictionar
    if data and isinstance(data, dict):
        if data.get('access_token') and data.get('account_id'):
            return data
    return None


def get_tmdb_account_info():
    """GET /3/account (cu Bearer v4, fara session_id) — username, name, iso_639_1, iso_3166_1, avatar.
    /4/account/{id} NU are iso codes (verificat live 200: doar name+username)."""
    session = get_tmdb_session()
    if not session:
        return None
    data = tmdb_auth_request("/account", method='GET', v4=False)
    if not data or not isinstance(data, dict):
        return None
    return data


def tmdb_auth_v4():
    """Alias pentru compatibilitate — aceeasi autentificare QR ca tmdb_auth()."""
    return tmdb_auth()

def tmdb_logout():
    # --- START PROTECTIE DECONECTARE ACCIDENTALA ---
    if not xbmcgui.Dialog().yesno(provider_title('tmdb', name='Disconnect TMDb'), f"Are you sure you want to disconnect from [B][COLOR {provider_color('tmdb')}]TMDb[/COLOR][/B]?"):
        return
    # --- END PROTECTIE ---

    # Sesiune veche v3 (daca a ramas dinainte de migrarea pe QR/v4)
    old_session = read_json(TMDB_SESSION_FILE)
    if old_session and isinstance(old_session, dict) and old_session.get('session_id'):
        try:
            url = f"{BASE_URL}/authentication/session?api_key={API_KEY}"
            requests.delete(url, json={'session_id': old_session['session_id']}, timeout=10)
        except:
            pass

    if xbmcvfs.exists(TMDB_SESSION_FILE):
        xbmcvfs.delete(TMDB_SESSION_FILE)
    if xbmcvfs.exists(TMDB_V4_TOKEN_FILE):
        xbmcvfs.delete(TMDB_V4_TOKEN_FILE)
    if xbmcvfs.exists(TMDB_LISTS_CACHE_FILE):
        xbmcvfs.delete(TMDB_LISTS_CACHE_FILE)

    ADDON.setSetting('tmdb_status', "Disconnected")

    xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "User Disconnected", TMDB_ICON, 3000, False)
    xbmc.executebuiltin("Container.Refresh")

def tmdb_auth_request(path, method='GET', data=None, params=None, v4=False):
    """Cerere autentificata TMDb cu token-ul v4 al utilizatorului (Authorization: Bearer).
    v4=True  → base https://api.themoviedb.org/4
    v4=False → base https://api.themoviedb.org/3 (v3 accepta Bearer v4, fara api_key)
    """
    token = get_tmdb_v4_token()
    if not token:
        return None

    url = f"{TMDB_V4_BASE_URL if v4 else BASE_URL}{path}"

    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json;charset=utf-8'
    }

    try:
        if method == 'GET':
            r = requests.get(url, headers=headers, params=params, timeout=15)
        elif method == 'POST':
            r = requests.post(url, headers=headers, json=data, params=params, timeout=15)
        elif method == 'DELETE':
            r = requests.delete(url, headers=headers, json=data, params=params, timeout=15)
        else:
            return None

        if r.status_code in [200, 201, 204]:
            if r.status_code == 204 or not r.text:
                return {}
            return r.json()
        else:
            log(f"[TMDB] Auth request failed: {r.status_code} {r.text}", xbmc.LOGERROR)
            return None
    except Exception as e:
        log(f"[TMDB] Auth request error: {e}", xbmc.LOGERROR)
        return None


def tmdb_v4_request(endpoint, method='GET', data=None):
    """Cerere v4 cu token-ul utilizatorului (inainte folosea API read token)."""
    return tmdb_auth_request(endpoint, method=method, data=data, v4=True)


def get_tmdb_user_lists_v4():
    session = get_tmdb_session()
    if not session:
        return []
    
    account_id = session.get('account_id')
    all_lists = []
    page = 1
    
    while True:
        data = tmdb_v4_request(f"/account/{account_id}/lists?page={page}")
        
        if not data or 'results' not in data:
            break
        
        results = data.get('results', [])
        if not results:
            break
        
        all_lists.extend(results)
        
        total_pages = data.get('total_pages', 1)
        if page >= total_pages:
            break
        page += 1
    
    return all_lists


def get_tmdb_list_details_v4(list_id):
    return tmdb_v4_request(f"/list/{list_id}?page=1")


def get_tmdb_lists_cache():
    cache = read_json(TMDB_LISTS_CACHE_FILE)
    if cache and isinstance(cache, dict) and cache.get('timestamp'):
        if int(time.time()) - cache['timestamp'] < LISTS_CACHE_TTL:
            data = cache.get('data', [])
            if data and len(data) > 0:
                return data
    return None


def save_tmdb_lists_cache(data):
    cache = {
        'timestamp': int(time.time()),
        'data': data
    }
    write_json(TMDB_LISTS_CACHE_FILE, cache)


def clear_tmdb_lists_cache(params=None):
    if xbmcvfs.exists(TMDB_LISTS_CACHE_FILE):
        xbmcvfs.delete(TMDB_LISTS_CACHE_FILE)
    xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "List cache cleared", TMDB_ICON, 3000, False)
    xbmc.executebuiltin("Container.Refresh")


def get_tmdb_lists_with_details():
    session = get_tmdb_session()
    if not session:
        return []

    lists_v4 = get_tmdb_user_lists_v4()

    if not lists_v4:
        return []

    lists_with_details = []
    detail_tasks = []

    for lst in lists_v4:
        list_id = str(lst.get('id'))
        
        poster_path = lst.get('poster_path', '')
        backdrop_path = lst.get('backdrop_path', '')
        
        poster = get_list_image_url(poster_path, 'poster') or ''
        backdrop = get_list_image_url(backdrop_path, 'fanart') or ''
        
        entry = {
            'id': list_id,
            'name': lst.get('name', 'Unknown'),
            'description': lst.get('description', ''),
            'item_count': lst.get('number_of_items', lst.get('item_count', 0)),
            'poster': poster,
            'backdrop': backdrop,
            'public': lst.get('public', False),
            '_needs_detail': not poster and bool(list_id)
        }
        
        if entry['_needs_detail']:
            detail_tasks.append(entry)
        else:
            lists_with_details.append(entry)

    if detail_tasks:
        def fetch_worker(list_id):
            return list_id, get_tmdb_list_details_v4(list_id)
        
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = {executor.submit(fetch_worker, e['id']): e for e in detail_tasks}
            detail_map = {}
            for future in as_completed(futures):
                list_id, details = future.result()
                detail_map[list_id] = details
        
        for entry in detail_tasks:
            list_details = detail_map.get(entry['id'])
            if list_details and list_details.get('results'):
                first_item = list_details['results'][0]
                item_poster = first_item.get('poster_path', '')
                item_backdrop = first_item.get('backdrop_path', '')
                if item_poster:
                    entry['poster'] = get_list_image_url(item_poster, 'poster')
                if item_backdrop and not entry['backdrop']:
                    entry['backdrop'] = get_list_image_url(item_backdrop, 'fanart')
            lists_with_details.append(entry)

    return lists_with_details


def tmdb_account_info():
    """Afiseaza informatii despre contul TMDb + contorizarea listelor din mirror-ul local."""
    session = get_tmdb_session()
    if not session:
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), 'Not connected', TMDB_ICON, 3000, False)
        return

    def label(text):
        return f'[B][COLOR FF00CED1]{text}[/COLOR][/B]'

    def val(v):
        return f'[B]{v}[/B]'

    def section(text):
        return f'[B][COLOR FFFDBD01]{text}[/COLOR][/B]'

    body = []

    data = get_tmdb_account_info()
    username = (data or {}).get('username') or session.get('username') or 'Unknown'
    body.append(f'{label("Username:")} {val(username)}')
    if data:
        body.append(f'{label("Name:")} {val(data.get("name") or "N/A")}')
        body.append(f'{label("Language:")} {val(data.get("iso_639_1") or "N/A")}')
        body.append(f'{label("Country:")} {val(data.get("iso_3166_1") or "N/A")}')
        avatar = (data.get('avatar') or {}).get('gravatar') or {}
        body.append(f'{label("Avatar:")} {val("Yes" if avatar.get("hash") else "No")}')

    # --- Contorizare liste din mirror-ul local (instant, offline) ---
    try:
        from resources.lib.providers import trakt_sync
        conn = trakt_sync.get_connection()
        c = conn.cursor()
        wl_m = c.execute("SELECT COUNT(*) FROM tmdb_account_lists WHERE list_type='watchlist' AND media_type='movie'").fetchone()[0]
        wl_s = c.execute("SELECT COUNT(*) FROM tmdb_account_lists WHERE list_type='watchlist' AND media_type='tv'").fetchone()[0]
        fav_m = c.execute("SELECT COUNT(*) FROM tmdb_account_lists WHERE list_type='favorite' AND media_type='movie'").fetchone()[0]
        fav_s = c.execute("SELECT COUNT(*) FROM tmdb_account_lists WHERE list_type='favorite' AND media_type='tv'").fetchone()[0]
        lists_n = c.execute("SELECT COUNT(*) FROM tmdb_custom_lists").fetchone()[0]
        lists_items = c.execute("SELECT COALESCE(SUM(item_count), 0) FROM tmdb_custom_lists").fetchone()[0]
        rec_n = c.execute("SELECT COUNT(*) FROM tmdb_recommendations").fetchone()[0]
        conn.close()
    except Exception:
        wl_m = wl_s = fav_m = fav_s = 0
        lists_n = lists_items = rec_n = 0

    body.append('')
    body.append(section('--- My Lists ---'))
    body.append(f'  Watchlist Movies: {val(wl_m)}')
    body.append(f'  Watchlist TV Shows: {val(wl_s)}')
    body.append(f'  Favorite Movies: {val(fav_m)}')
    body.append(f'  Favorite TV Shows: {val(fav_s)}')
    if lists_n:
        body.append(f'  My Lists: {val(f"{lists_n} lists / {lists_items} items")}')
    if rec_n:
        body.append(f'  Recommendations: {val(rec_n)}')

    # --- Ratings given (live, v3 rated endpoints with Bearer) ---
    try:
        aid = session.get('account_id')
        if aid:
            def _rated_total(path):
                try:
                    res = tmdb_auth_request(path, method='GET', params={'language': 'en-US', 'page': 1, 'sort_by': 'created_at.desc'}, v4=False)
                    if isinstance(res, dict):
                        if 'total_results' in res:
                            return int(res.get('total_results') or 0)
                        if 'total_pages' in res and 'results' in res:
                            # fallback: daca API nu da total_results, numaram prima pagina + estimam
                            return len(res.get('results') or [])
                    return 0
                except:
                    return 0
            r_m = _rated_total(f"/account/{aid}/rated/movies")
            r_tv = _rated_total(f"/account/{aid}/rated/tv")
            r_ep = _rated_total(f"/account/{aid}/rated/tv/episodes")
            r_total = r_m + r_tv + r_ep
            # fallback: daca endpoint-ul episoadelor nu exista (404 -> 0), incercam si v4
            if r_total == 0 and (r_m == 0 and r_tv == 0):
                # v4 rated nu exista documentat, dar incercam pentru compatibilitate
                try:
                    res4 = tmdb_auth_request(f"/account/{aid}/rated/tv/episodes", method='GET', v4=True)
                    if isinstance(res4, dict) and 'total_results' in res4:
                        r_ep = int(res4.get('total_results') or 0)
                        r_total = r_m + r_tv + r_ep
                except:
                    pass
            body.append('')
            body.append(section('--- Ratings Given ---'))
            if r_ep:
                body.append(f'  Total: {val(r_total)} (Movies: {r_m}, TV Shows: {r_tv}, Episodes: {r_ep})')
            else:
                body.append(f'  Total: {val(r_total)} (Movies: {r_m}, TV Shows: {r_tv})')
            if r_total == 0:
                body.append(f'  [COLOR gray]No ratings yet[/COLOR]')
    except:
        pass

    text = '\n'.join(body)
    xbmcgui.Dialog().textviewer('[B][COLOR FF00CED1]TMDB ACCOUNT INFO[/COLOR][/B]', text)


def tmdb_my_lists():
    session = get_tmdb_session()
    if not session:
        add_directory("[B][COLOR FF00CED1]Connect TMDB[/COLOR][/B]", {'mode': 'tmdb_auth'}, icon='DefaultUser.png', folder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    add_directory("[B][COLOR FF00CED1]TMDB Account[/COLOR][/B]", {'mode': 'tmdb_account_info'}, icon='DefaultUser.png', thumb='DefaultUser.png', folder=False)
    try:
        from resources.lib.providers.watched_provider import tmdb_upnext_enabled
        if tmdb_upnext_enabled():
            add_directory("[B][COLOR FF00CED1]TMDb [COLOR FFFF4444]UP NEXT[/COLOR][/B]", {'mode': 'tmdb_up_next'}, icon=TMDB_ICON, thumb=TMDB_ICON, folder=True)
    except Exception:
        add_directory("[B][COLOR FF00CED1]TMDb [COLOR FFFF4444]UP NEXT[/COLOR][/B]", {'mode': 'tmdb_up_next'}, icon=TMDB_ICON, thumb=TMDB_ICON, folder=True)
    add_directory("[B][COLOR FF00CED1]TMDB [COLOR yellow]My Calendar[/COLOR][/B]", {'mode': 'tmdb_calendar_my'}, icon=TMDB_ICON, thumb=TMDB_ICON, folder=True)
    _wl_total = 0
    _fav_total = 0
    try:
        _conn = trakt_sync.get_connection()
        _c = _conn.cursor()
        _c.execute("SELECT COUNT(*) FROM tmdb_account_lists WHERE list_type='watchlist'")
        _wl_total = _c.fetchone()[0] or 0
        _c.execute("SELECT COUNT(*) FROM tmdb_account_lists WHERE list_type='favorite'")
        _fav_total = _c.fetchone()[0] or 0
        _conn.close()
    except Exception:
        pass
    add_directory("[B][COLOR FFCCCCFF]Watchlist[/COLOR][/B] [B][COLOR FFFDBD01](%d)[/COLOR][/B]" % _wl_total, {'mode': 'tmdb_watchlist_menu'}, icon=TMDB_ICON, thumb=TMDB_ICON, folder=True)
    add_directory("[B][COLOR FFCCCCFF]Favorites[/COLOR][/B] [B][COLOR FFFDBD01](%d)[/COLOR][/B]" % _fav_total, {'mode': 'tmdb_favorites_menu'}, icon=TMDB_ICON, thumb=TMDB_ICON, folder=True)
    add_directory("[B][COLOR FFCCCCFF]Recommendations[/COLOR][/B]", {'mode': 'tmdb_recommendations_menu'}, icon=TMDB_ICON, thumb=TMDB_ICON, folder=True)
    
    add_directory("[B][COLOR FF00CED1]--- My Lists ---[/COLOR][/B]", {'mode': 'noop'}, folder=False, icon='DefaultUser.png')

    # ✅ Citim listele personale din SQL
    lists = trakt_sync.get_tmdb_custom_lists_from_db()
    
    log(f"[TMDB] Found {len(lists) if lists else 0} custom lists in SQL")

    if lists:
        for lst in lists:
            list_id = str(lst.get('list_id'))
            name = lst.get('name', 'Unknown')
            count = lst.get('item_count', 0)
            description = lst.get('description', '')  # ✅ ADAUGAT
            
            # Citim poster si backdrop din SQL
            poster_path = lst.get('poster', '')
            backdrop_path = lst.get('backdrop', '')
            
            # Construim URL-urile complete
            poster = get_list_image_url(poster_path, 'poster') if poster_path else TMDB_ICON
            fanart = get_list_image_url(backdrop_path, 'fanart') if backdrop_path else ''
            
            cm = [
                ('Refresh Lists', f"RunPlugin({PLUGIN_URL}?mode=tmdb_refresh_lists)"), 
            ]

            # ✅ ADAUGAT: info cu plot (description)
            info = {
                'mediatype': 'video',
                'title': name,
                'plot': description if description else f"TMDb List: {name}\n{count} items"
            }

            add_directory(
                f"[B][COLOR FFCCCCFF]{name}[/COLOR] [B][COLOR FFFDBD01]({count})[/COLOR][/B]",
                {'mode': 'tmdb_list_items', 'list_id': list_id, 'list_name': name},
                icon=poster, thumb=poster, fanart=fanart, cm=cm, info=info, folder=True
            )
    else:
        add_directory("[COLOR gray]No personal lists or sync again[/COLOR]", {'mode': 'trakt_sync_db'}, folder=False)

    xbmcplugin.endOfDirectory(HANDLE)
    _set_views_apply('main')


def _tmdb_calendar_window():
    import datetime as _dt
    prev_days, fut_days = calendar_window_days()
    sort_asc, today_top = calendar_sort_flags()
    today = _dt.date.today()
    return {
        'prev_days': prev_days,
        'fut_days': fut_days,
        'sort_asc': sort_asc,
        'today_top': today_top,
        'today': today,
        'start': today - _dt.timedelta(days=prev_days),
        'end': today + _dt.timedelta(days=fut_days),
    }


def _tmdb_movie_release_date(details):
    if not isinstance(details, dict): return ''
    generic = str(details.get('release_date', '') or '')[:10]
    if generic: return generic
    rd = (details.get('release_dates') or {}).get('results') or []
    if not isinstance(rd, list): return ''
    for r in rd:
        try:
            if str(r.get('iso_3166_1', '')).upper() == 'US':
                return str(((r.get('release_dates') or [{}])[0] or {}).get('release_date', ''))[:10]
        except Exception:
            pass
    for r in rd:
        try:
            ds = str(((r.get('release_dates') or [{}])[0] or {}).get('release_date', ''))[:10]
            if ds: return ds
        except Exception:
            pass
    return ''


def _us_digital_date(details):
    if not isinstance(details, dict): return ''
    best = ''
    try:
        rd = (details.get('release_dates') or {}).get('results') or []
        for r in rd:
            if str(r.get('iso_3166_1', '')).upper() != 'US':
                continue
            for e in r.get('release_dates', []) or []:
                try:
                    if int(e.get('type', 0)) != 4:
                        continue
                    ds = str(e.get('release_date', ''))[:10]
                    if len(ds) == 10 and (not best or ds < best):
                        best = ds
                except Exception:
                    pass
    except Exception:
        pass
    return best


def _digital_dates_map(items, timeout=8):
    import threading as _th
    import time as _t
    out = {}
    todo = []
    for it in items or []:
        tid = str(it.get('id', '') or '')
        if not tid:
            continue
        try:
            ds = _us_digital_date(_get_cached_details(tid, 'movie') or {})
        except Exception:
            ds = ''
        if ds:
            out[tid] = ds
        else:
            todo.append(tid)
    if todo:
        deadline = _t.time() + timeout
        lock = _th.Lock()
        def _task(tid):
            try:
                get_tmdb_item_details(tid, 'movie', lightweight=True)
                ds = _us_digital_date(_get_cached_details(tid, 'movie') or {})
                if ds:
                    with lock:
                        out[tid] = ds
            except Exception:
                pass
        threads = []
        for tid in todo:
            t = _th.Thread(target=_task, args=(tid,))
            t.daemon = True
            threads.append(t)
            t.start()
        for t in threads:
            remain = deadline - _t.time()
            if remain <= 0:
                break
            t.join(timeout=remain)
    return out


_DIGITAL_JUNK_RE = re.compile(r'\b(njpw|aew|wwe|wwf|nxt|ufc|aaa|bellator|wsof|pfl|wrestle\s?kingdom|wrestlemania|royal\s?rumble|summerslam|survivor\s?series|money\s?in\s?the\s?bank|elimination\s?chamber|crown\s?jewel)\b', re.IGNORECASE)


def _is_tmdb_list_junk(it):
    try:
        g = it.get('genre_ids')
        if isinstance(g, list) and any(str(x) == '99' for x in g):
            return True
    except Exception:
        pass
    try:
        t = str(it.get('title', '') or it.get('name', '') or '')
        if t and _DIGITAL_JUNK_RE.search(t):
            return True
    except Exception:
        pass
    return False


def _digital_day_items(day_str):
    import requests
    out = []
    try:
        base = (f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&region=US"
                f"&release_date.gte={day_str}&release_date.lte={day_str}"
                f"&with_release_type=4&sort_by=release_date.desc"
                f"&with_runtime.gte=60&without_genres=99")
        page = 1
        while page <= 10:
            try:
                r = requests.get(base + f"&page={page}", timeout=15)
                if r.status_code != 200:
                    break
                res = r.json().get('results', []) or []
            except Exception:
                break
            if not res:
                break
            out.extend(res)
            if len(res) < 20:
                break
            page += 1
    except Exception:
        pass
    return out


def _ensure_digital_pool(need, chunk=14, max_days=90, deadline_s=15):
    import datetime as _dt
    import threading as _th
    import time as _t
    today = _dt.date.today()
    by_id = {}
    days_back = 0
    t_end = _t.time() + deadline_s
    while len(by_id) < need and days_back < max_days:
        days = [(today - _dt.timedelta(days=d)).strftime('%Y-%m-%d')
                for d in range(days_back, min(days_back + chunk, max_days))]
        results = {}
        lock = _th.Lock()
        def _task(ds):
            try:
                items = cache_object(_digital_day_items, f'tmdb_digital_day_{ds}_{LANG}', [ds], expiration=24) or []
            except Exception:
                items = []
            with lock:
                results[ds] = items
        threads = []
        for ds in days:
            t = _th.Thread(target=_task, args=(ds,))
            t.daemon = True
            threads.append(t)
            t.start()
        for t in threads:
            remain = t_end - _t.time()
            if remain <= 0:
                break
            t.join(timeout=remain)
        for ds in days:
            for it in results.get(ds) or []:
                try:
                    tid = str(it.get('id', '') or '')
                    if not tid:
                        continue
                    if not it.get('genre_ids'):
                        continue
                    try:
                        if _DIGITAL_JUNK_RE.search(str(it.get('title', '') or '')):
                            continue
                    except Exception:
                        pass
                    cp = dict(it)
                    cp['_digital_date'] = ds
                    prev = by_id.get(tid)
                    if prev is None or ds > prev.get('_digital_date', ''):
                        by_id[tid] = cp
                except Exception:
                    pass
        days_back += chunk
        if _t.time() >= t_end:
            break
    pool = list(by_id.values())
    try:
        pool.sort(key=lambda it: it.get('_digital_date', ''), reverse=True)
    except Exception:
        pass
    seen = set()
    out = []
    for it in pool:
        tkey = (str(it.get('title', '') or '').strip().lower(),
                str(it.get('release_date', '') or '')[:4])
        if tkey[0] and tkey in seen:
            continue
        if tkey[0]:
            seen.add(tkey)
        out.append(it)
    return out


def _prefetch_tmdb_seasons(pairs):
    """Fetch detalii sezoane in thread-uri daemon cu deadline 8s (calendar).
    Returneaza dict {(tmdb_id, season): data} pentru cele care au terminat."""
    import threading as _th
    import time as _t
    results = {}
    lock = _th.Lock()

    def task(tid, sn):
        try:
            d = get_smart_season_details(tid, sn)
            if d:
                with lock:
                    results[(tid, sn)] = d
        except Exception:
            pass

    threads = []
    for tid, sn in pairs:
        t = _th.Thread(target=task, args=(tid, sn))
        t.daemon = True
        threads.append(t)
        t.start()

    deadline = _t.time() + 8
    for t in threads:
        remain = deadline - _t.time()
        if remain > 0:
            t.join(timeout=remain)
        else:
            break
    return results


def tmdb_calendar_my():
    """My Calendar: filme + episoade din watchlist-ul TMDb cu data in fereastra.
    Data filmelor din SQL (sync v4), serialele din next_episode_to_air (cache TMDb)."""
    import datetime as _dt
    from resources.lib.core.config import calendar_localized_label
    from resources.lib.providers.watched_provider import is_episode_watched as _wp_is_epw, is_movie_watched as _wp_is_mw

    session = get_tmdb_session()
    if not session:
        add_directory("[B][COLOR FF00CED1]Connect TMDB[/COLOR][/B]", {'mode': 'tmdb_auth'}, icon='DefaultUser.png', folder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    xbmcplugin.setContent(HANDLE, 'episodes')
    wnd = _tmdb_calendar_window()

    rows = trakt_sync.get_tmdb_watchlist_for_calendar() or []
    movies = [r for r in rows if r.get('media_type') == 'movie']
    shows = [r for r in rows if r.get('media_type') == 'tv']

    entries = []

    # --- Filme: data din SQL (sync v4); fallback cached details pentru randuri vechi ---
    if movies:
        missing = []
        for r in movies:
            tid = str(r.get('tmdb_id') or '')
            if not tid or tid == 'None': continue
            dstr = str(r.get('date') or '')[:10]
            if len(dstr) < 8:
                missing.append({'id': tid, 'media_type': 'movie'})
        if missing:
            prefetch_metadata_parallel(missing, 'movie')
        for r in movies:
            tid = str(r.get('tmdb_id') or '')
            if not tid or tid == 'None': continue
            date_str = str(r.get('date') or '')[:10]
            if len(date_str) < 8:
                details = _get_cached_details(tid, 'movie') or {}
                date_str = _tmdb_movie_release_date(details)
            if not date_str: continue
            try:
                d = _dt.date.fromisoformat(date_str)
            except Exception:
                continue
            if d < wnd['start'] or d > wnd['end']:
                continue
            entries.append({
                'media_type': 'movie',
                'tmdb_id': tid,
                'show_title': r.get('title', ''),
                'season': 0,
                'episode': 0,
                'ep_title': '',
                'air_date': date_str,
                'diff': (d - wnd['today']).days,
                'poster': r.get('poster', '') or '',
                'fanart': '',
            })

    # --- Seriale: TOATE episoadele cu air_date in fereastra (paritate Trakt My Calendar,
    # care ia fiecare episod din fereastra, nu doar next_episode_to_air) ---
    # Sezoane candidate: sezonul lui next_episode_to_air + sezoane viitoare cu
    # premiera in fereastra. Detaliile sezoanelor vin din get_smart_season_details
    # (cache RAM + SQLite; prima vizita partiala, a 2-a instant).
    if shows:
        missing = []
        for r in shows:
            tid = str(r.get('tmdb_id') or '')
            if not tid or tid == 'None': continue
            if not _get_cached_details(tid, 'tv'):
                missing.append({'id': tid, 'media_type': 'tv'})
        if missing:
            prefetch_metadata_parallel(missing, 'tv')

        cand_map = {}
        for r in shows:
            tid = str(r.get('tmdb_id') or '')
            if not tid or tid == 'None': continue
            details = _get_cached_details(tid, 'tv') or {}
            if not isinstance(details, dict): continue
            nxt = details.get('next_episode_to_air') or {}
            if not isinstance(nxt, dict): nxt = {}
            cur_s = int(nxt.get('season_number', 0) or 0)
            cand = set()
            if cur_s > 0:
                cand.add(cur_s)
            # sezoane viitoare cu premiera in fereastra (acopera si serialele
            # in hiatus la care next_episode_to_air e gol dar premiera e anuntata)
            for s in (details.get('seasons') or []):
                if not isinstance(s, dict): continue
                sn = int(s.get('season_number', 0) or 0)
                if sn <= 0 or sn == cur_s: continue
                ad = str(s.get('air_date') or '')[:10]
                if len(ad) < 8: continue
                try:
                    sd = _dt.date.fromisoformat(ad)
                except Exception:
                    continue
                if wnd['start'] <= sd <= wnd['end']:
                    cand.add(sn)
            if cand:
                cand_map[tid] = {'title': r.get('title', ''), 'seasons': sorted(cand)}

        season_fetch = [(tid, sn) for tid, m in cand_map.items() for sn in m['seasons']]
        if season_fetch:
            season_data = _prefetch_tmdb_seasons(season_fetch)
            # stamp-urile (data+ora din Trakt/Simkl) se citesc O SINGURA DATA pentru
            # toate sezoanele, nu cate o interogare per episod
            try:
                _stamps = get_episode_air_stamps(
                    [(tid, sn, ep.get('episode_number'))
                     for tid, m in cand_map.items() for sn in m['seasons']
                     for ep in ((season_data.get((tid, sn)) or {}).get('episodes') or [])
                     if isinstance(ep, dict) and ep.get('episode_number')] or None)
            except Exception:
                _stamps = {}
            for tid, m in cand_map.items():
                for sn in m['seasons']:
                    details = season_data.get((tid, sn))
                    if not details or not isinstance(details, dict):
                        continue
                    for ep in (details.get('episodes') or []):
                        if not isinstance(ep, dict): continue
                        ep_num = int(ep.get('episode_number', 0) or 0)
                        air = str(ep.get('air_date') or '')[:10]
                        if not ep_num or len(air) < 8:
                            continue
                        try:
                            d = _dt.date.fromisoformat(air)
                        except Exception:
                            continue
                        # TMDb poate avea data cu o zi in urma fata de sursa de difuzare
                        # (ex. Lanterns S01E07: TMDb 27, Trakt/Simkl/MDBList 28). Fara asta
                        # calendarul ar arata "ieri" iar Browse Season "azi" pentru acelasi
                        # episod.
                        try:
                            _st = (_stamps or {}).get((str(tid), int(sn), int(ep_num)))
                        except Exception:
                            _st = None
                        d = air_effective_date(d, _st, wnd['today'])
                        air = d.isoformat()
                        if d < wnd['start'] or d > wnd['end']:
                            continue
                        ep_name = str(ep.get('name', '') or '').strip()
                        # Numele generice (Episodul N / Episode N etc.) se pastreaza
                        # si se afiseaza (paritate cu calendarul Trakt, care afiseaza
                        # 'Episode 1' asa cum vine din API — 2026-08-19)
                        entries.append({
                            'media_type': 'tv',
                            'tmdb_id': tid,
                            'show_title': m['title'],
                            'season': sn,
                            'episode': ep_num,
                            'ep_title': ep_name,
                            'ep_plot': str(ep.get('overview', '') or ''),
                            'air_date': air,
                            'diff': (d - wnd['today']).days,
                            'poster': '',
                            'fanart': '',
                        })

    if not entries:
        add_directory("[B][COLOR gray]No Calendar Events[/COLOR][/B]", {'mode': 'noop'}, folder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    _render_tmdb_calendar_entries(entries, wnd)


def _render_tmdb_calendar_entries(entries, wnd):
    import datetime as _dt
    from resources.lib.core.config import calendar_localized_label
    try:
        from resources.lib.providers.watched_provider import is_episode_watched as _wp_is_epw, is_movie_watched as _wp_is_mw, browse_command as _browse_cmd
    except ImportError:
        from resources.lib.providers.watched_provider import is_episode_watched as _wp_is_epw, is_movie_watched as _wp_is_mw
        _browse_cmd = lambda url: 'Container.Update(%s)' % url
    from resources.lib.core.cache import ram_pool_get
    from resources.lib.core.config import get_plot_language_code

    fake_items = [{'id': e['tmdb_id'], 'media_type': 'tv' if e['media_type'] == 'tv' else 'movie'} for e in entries]

    # Prefetch doar itemii lipsa din cache — evita rate-limit TMDb.
    # NON-BLOCKING (deadline 1.1s intern) + persist in background: prima vizita
    # instant, a 2-a cu tot (SQLite) — paritate cu calendarul Trakt/MDBList/Simkl.
    try:
        need = []
        for it in fake_items:
            if not _get_cached_details(str(it['id']), it['media_type']):
                need.append(it)
        if need:
            prefetch_metadata_parallel(need, 'tv' if entries[0]['media_type'] == 'tv' else 'movie')
    except Exception:
        prefetch_metadata_parallel(fake_items, 'tv' if entries[0]['media_type'] == 'tv' else 'movie')

    # Persist pool-ul prefetch in SQLite (background) — vizitele urmatoare au
    # poster/plot/fanart din cache zero-HTTP.
    try:
        import threading

        def _persist():
            try:
                cur_lang = get_plot_language_code()
                conn = trakt_sync.get_connection()
                for it in fake_items:
                    tid = str(it.get('id') or '')
                    if not tid or tid == 'None': continue
                    d = ram_pool_get(tid)
                    if not d or not isinstance(d, dict): continue
                    if d.get('_cached_lang') != cur_lang: continue
                    try:
                        trakt_sync.set_tmdb_item_details_to_db(conn.cursor(), tid, it.get('media_type') or 'tv', d)
                    except Exception:
                        pass
                try:
                    conn.commit()
                except Exception:
                    pass
                conn.close()
            except Exception:
                pass
        threading.Thread(target=_persist, daemon=True).start()
    except Exception:
        pass

    items_to_add = []
    # Orele de difuzare: prefetch o data pentru toata fereastra, apoi o singura
    # citire bulk. Doar episodele de azi / maine le folosesc in eticheta.
    _air_keys = [{'tmdb_id': e['tmdb_id'], 'season': e.get('season') or 0,
                  'episode': e.get('episode') or 0, 'air_date': e.get('air_date') or '',
                  'show_title': e.get('show_title') or ''}
                 for e in entries if e.get('media_type') == 'tv'
                 and -1 <= int(e.get('diff') or 0) <= 1]
    try:
        prefetch_air_times(_air_keys)
        _air_stamps = get_episode_air_stamps(
            [(k['tmdb_id'], int(k['season']), int(k['episode'])) for k in _air_keys]) or {}
    except Exception:
        _air_stamps = {}

    for e in entries:
        tmdb_id = e['tmdb_id']
        is_movie = e['media_type'] == 'movie'

        cached = _get_cached_details(tmdb_id, 'movie' if is_movie else 'tv') or {}
        title_key = 'title' if is_movie else 'name'
        cached_title = str(cached.get(title_key, '') or '')
        # Titlul serialelor/filmelor in calendar: EN din DB (sync v4). Cached-ul
        # (prefetch, poate fi RO/localizat) ramane doar fallback pt randuri vechi;
        # daca e non-latin (CJK), nu-l folosim — ar ramane 'Unknown Show'.
        db_title = str(e.get('show_title') or '').strip()
        if db_title:
            show_title = db_title
        elif cached_title and not _NON_LATIN_RE.search(cached_title):
            show_title = cached_title
        else:
            show_title = 'Unknown Show'
        poster = e.get('poster') or ''
        fanart = ''
        pp = cached.get('poster_path', '')
        if pp:
            poster = f"{IMG_BASE}{pp}"
        bd = cached.get('backdrop_path', '')
        if bd:
            fanart = f"{BACKDROP_BASE}{bd}"
        plot = cached.get('overview', '') or ''
        if not is_movie:
            plot = str(e.get('ep_plot') or '') or plot

        diff = e['diff']
        try:
            d = _dt.date.fromisoformat(str(e['air_date']))
            date_label = calendar_localized_label(diff, d)
        except Exception:
            date_label = str(e['air_date'])
        # Ora de difuzare (doar azi / maine) din cache-ul comun de ore.
        if -1 <= diff <= 1 and not is_movie:
            try:
                _at = _air_stamps.get((str(e['tmdb_id']), int(e.get('season') or 0), int(e.get('episode') or 0)))
                if _at and _at[1]:
                    date_label = f'{date_label} • {_at[1]}'
            except Exception:
                pass
        if diff == 0:
            date_color = 'white'
        elif diff < 0:
            date_color = 'FF00FA9A'
        else:
            date_color = 'yellow'

        # Difuzat AZI: numele serialului/filmului + eticheta, galben bold.
        # Numele episodului rmane lavanda FFCCCCFF (standardul din toate listele).
        _today = (diff == 0)
        if is_movie:
            movie_year = str(e['air_date'])[:4] if e['air_date'] else ''
            display_title = f'{show_title} ({movie_year})' if movie_year else show_title
            _tclr = 'yellow' if _today else 'FFFF4444'
            display = f'[B][COLOR {_tclr}]{display_title}[/COLOR][/B]'
        else:
            ep_label = f'S{e["season"]:02d}E{e["episode"]:02d}' if e['season'] else ''
            _tclr = 'yellow' if _today else 'FF00CED1'
            display = f'[B][COLOR {_tclr}]{show_title}[/COLOR][/B]'
            if ep_label:
                display += f' - [B][COLOR {date_color}]{ep_label}[/COLOR][/B]'
            if e.get('ep_title'):
                display += f' - [B][I][COLOR FFCCCCFF]{e["ep_title"]}[/I][/COLOR][/B]'
        if date_label:
            _dclr = 'yellow' if _today else date_color
            display += f' [COLOR {_dclr}] • [B]{date_label}[/B][/COLOR]'

        li = xbmcgui.ListItem(display)
        _safe_set_prop(li, 'cal_diff', str(diff))
        li.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': fanart})
        if is_movie:
            watched = _wp_is_mw(tmdb_id)
            info = {'mediatype': 'movie', 'title': show_title}
        else:
            watched = _wp_is_epw(tmdb_id, e['season'], e['episode'])
            ep_label = f'S{e["season"]:02d}E{e["episode"]:02d}' if e['season'] else ''
            info = {'mediatype': 'episode', 'title': e['ep_title'] or ep_label, 'tvshowtitle': show_title,
                    'season': e['season'], 'episode': e['episode']}
        if plot:
            info['plot'] = plot
        set_metadata(li, info, unique_ids={'tmdb': tmdb_id}, watched_info=watched)
        if is_movie:
            cm = _get_full_context_menu(tmdb_id, 'movie', show_title)
        else:
            cm = calendar_context_menu(_get_full_context_menu(tmdb_id, 'episode', show_title, season=e['season'], episode=e['episode']),
                                       'episode', tmdb_id, show_title, e['season'], e['episode'],
                                       base_url=PLUGIN_URL, browse_cmd=_browse_cmd, urlencode_fn=urlencode, clear_sources=True)
        if cm:
            li.addContextMenuItems(cm)
        if is_movie:
            params, is_folder = calendar_row_click_params('movie', tmdb_id, diff, show_title=show_title, sources_title=show_title)
        else:
            params, is_folder = calendar_row_click_params('episode', tmdb_id, diff, e['season'], e['episode'], show_title)
        if params:
            items_to_add.append((plugin_url(params), li, is_folder))

    items_to_add = sort_calendar_items(items_to_add, wnd['today_top'], wnd['sort_asc'])

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))
    xbmcplugin.endOfDirectory(HANDLE)
    _set_views_apply('episode_lists', 'episodes')



def tmdb_account_recommendations(params):
    content_type = params.get('type', 'movie')
    page = int(params.get('page', '1'))
    
    # 1. Incercam SQL
    results = trakt_sync.get_recommendations_from_db(content_type)
    
    # 2. Fallback: daca SQL e gol, fortam sync si reincarcam
    if not results:
        try:
            log("[TMDB] Recommendations goale in SQL, fortam sync...")
            conn = trakt_sync.get_connection()
            c = conn.cursor()
            trakt_sync._sync_tmdb_recommendations_fast(c)
            conn.commit()
            conn.close()
            
            # Reincarcam dupa sync
            results = trakt_sync.get_recommendations_from_db(content_type)
        except Exception as e:
            log(f"[TMDB] Error sync recommendations: {e}", xbmc.LOGERROR)
    
    if not results:
        add_directory("[COLOR gray]No recommendations available[/COLOR]", {'mode': 'noop'}, folder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    paginated, total_pages = paginate_list(results, page, PAGE_LIMIT)
    
    for item in paginated:
        if content_type == 'movie': 
            _process_movie_item(item)
        else: 
            _process_tv_item(item)
    
    if page < total_pages:
        add_directory(
            next_page_label(page + 1), 
            {'mode': 'tmdb_account_recommendations', 'type': content_type, 'page': str(page+1)}, 
            icon=NEXT_PAGE_ICON, thumb=NEXT_PAGE_ICON,
            info={'mediatype': 'video', 'plot': next_page_plot(page + 1)}, folder=True
        )
    
    xbmcplugin.setContent(HANDLE, 'movies' if content_type == 'movie' else 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE)
    _set_views_apply('movies' if content_type == 'movie' else 'tvshows')



def fetch_tmdb_list_items_all(list_id):
    all_items = []
    page = 1
    while True:
        url = f"{BASE_URL}/list/{list_id}?api_key={API_KEY}&language={LANG}&page={page}"
        try:
            r = requests.get(url, timeout=10)
            if r.status_code != 200:
                break
            data = r.json()
            items = data.get('items', [])
            if not items:
                break
            all_items.extend(items)
            if len(items) < 20: 
                break
            page += 1
            if page > 100: 
                break
        except Exception as e:
            log(f"[TMDB] Error fetching list items for {list_id}: {e}", xbmc.LOGERROR)
            break
    return all_items


def tmdb_list_items(params):
    list_id = params.get('list_id')
    list_name = params.get('list_name', '')
    page = int(params.get('page', '1'))

    # --- FAST CACHE CHECK (RAM) ---
    from resources.lib.core.utils import sort_personal_list, personal_lists_sort_az
    sort_suffix = 'az' if personal_lists_sort_az() else 'orig'
    cache_key = f"tmdb_custom_list_{list_id}_{page}_{sort_suffix}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='movies')
        return
    # ------------------------------

    items_raw = trakt_sync.get_tmdb_custom_list_items_from_db(list_id)
    if not items_raw:
        xbmcplugin.endOfDirectory(HANDLE); return

    items_raw = sort_personal_list(items_raw)
    paginated, total = paginate_list(items_raw, page, PAGE_LIMIT)
    
    # REPARAT NameError: folosim variabila m_type determinata corect
    if paginated:
        m_type = paginated[0].get('media_type', 'movie')
        prefetch_metadata_parallel(paginated, m_type)

    for item in paginated:
        if item.get('media_type') == 'movie': _process_movie_item(item)
        else: _process_tv_item(item)

    if page < total:
        add_directory(next_page_label(page + 1), {'mode': 'tmdb_list_items', 'list_id': list_id, 'list_name': list_name, 'page': str(page+1)}, icon=NEXT_PAGE_ICON, thumb=NEXT_PAGE_ICON, info={'mediatype': 'video', 'plot': next_page_plot(page + 1)}, folder=True)
    xbmcplugin.setContent(HANDLE, 'movies'); xbmcplugin.endOfDirectory(HANDLE)
    _set_views_apply('movies')


def clear_list_cache(params):
    list_id = params.get('list_id')
    cache = MainCache()
    cache.delete(f"tmdb_list_full_{list_id}") 
    xbmcgui.Dialog().notification("[B][COLOR FF00CED1]TMDb [COLOR FFCCCCFF]Movies[/COLOR][/B]", "List Cache Cleared!", TMDbmovies_ICON, 3000, False)
    xbmc.executebuiltin("Container.Refresh")


def get_tmdb_account_list(endpoint, page_no, session):
    token = get_tmdb_v4_token()
    if not token:
        return None
    url = f"{TMDB_V4_BASE_URL}/account/{session['account_id']}/{endpoint}"
    headers = {'Authorization': f'Bearer {token}'}
    return requests.get(url, headers=headers, params={'language': LANG, 'page': page_no, 'sort_by': 'created_at.desc'}, timeout=10)


def tmdb_watchlist(params):
    content_type = params.get('type')
    page = int(params.get('page', '1'))

    # --- 1. FAST CACHE CHECK (RAM) ---
    from resources.lib.core.utils import sort_personal_list, personal_lists_sort_az
    sort_suffix = 'az' if personal_lists_sort_az() else 'orig'
    cache_key = f"tmdb_watchlist_{content_type}_{page}_{sort_suffix}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='movies' if content_type == 'movie' else 'tvshows')
        return
    # ---------------------------------

    results_raw = trakt_sync.get_tmdb_account_list_from_db('watchlist', content_type)
    
    if not results_raw:
        session = get_tmdb_session()
        if not session: 
            xbmcplugin.endOfDirectory(HANDLE)
            return

        endpoint = f"{'movie' if content_type == 'movie' else 'tv'}/watchlist"
        string = f"tmdb_watchlist_{content_type}_{page}"
        data = cache_object(get_tmdb_account_list, string, [endpoint, page, session], expiration=1) 
        if data: 
            results = data.get('results', [])
            conn = trakt_sync.get_connection()
            trakt_sync._sync_tmdb_account_list_single(conn.cursor(), 'watchlist', content_type, results)
            conn.commit()
            conn.close()
        else:
            results = []
    else:
        results = results_raw

    if not results:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    results = sort_personal_list(results)
    paginated, total = paginate_list(results, page, PAGE_LIMIT)
    prefetch_metadata_parallel(paginated, content_type)
    
    # --- 2. BATCH RENDERING & CACHE PREP ---
    items_to_add = []
    cache_list = []
    
    for item in paginated:
        if content_type == 'movie': 
            processed = _process_movie_item(item, return_data=True)
        else: 
            processed = _process_tv_item(item, return_data=True)
            
        if processed:
            items_to_add.append((processed['url'], processed['li'], processed['is_folder']))
            cache_list.append(processed)

    if page < total:
        # Adaugam butonul Next Page manual pentru Batch/Cache
        next_label = next_page_label(page + 1)
        next_params = {'mode': 'tmdb_watchlist', 'type': content_type, 'page': str(page+1)}
        next_url = plugin_url(next_params)
        next_li = xbmcgui.ListItem(next_label)
        style_page_nav_item(next_li, page + 1)
        items_to_add.append((next_url, next_li, True))
        cache_list.append({'label': next_label, 'url': next_url, 'is_folder': True, 'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON}, 'info': {'mediatype': 'video', 'plot': next_page_plot(page + 1)}, 'cm_items': []})

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))

    xbmcplugin.setContent(HANDLE, 'movies' if content_type == 'movie' else 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('movies' if content_type == 'movie' else 'tvshows')

    
    # Salvam in RAM
    set_fast_cache(cache_key, [{'label': i['li'].getLabel() if 'li' in i else i['label'], 'url': i['url'], 'is_folder': i['is_folder'], 'art': i['art'], 'info': i['info'], 'cm': i['cm_items'], 'resume_time': i.get('resume_time', 0), 'total_time': i.get('total_time', 0)} for i in cache_list])


def tmdb_favorites(params):
    content_type = params.get('type')
    page = int(params.get('page', '1'))

    # --- FAST CACHE CHECK (RAM) ---
    from resources.lib.core.utils import sort_personal_list, personal_lists_sort_az
    sort_suffix = 'az' if personal_lists_sort_az() else 'orig'
    cache_key = f"tmdb_favorites_{content_type}_{page}_{sort_suffix}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='movies' if content_type == 'movie' else 'tvshows')
        return
    # ------------------------------

    results_raw = trakt_sync.get_tmdb_account_list_from_db('favorite', content_type)
    
    if not results_raw:
        session = get_tmdb_session()
        if not session: 
            xbmcplugin.endOfDirectory(HANDLE)
            return

        endpoint = f"{'movie' if content_type == 'movie' else 'tv'}/favorites"
        string = f"tmdb_favorites_{content_type}_{page}"
        data = cache_object(get_tmdb_account_list, string, [endpoint, page, session], expiration=1) 
        if data: 
            results = data.get('results', [])
            conn = trakt_sync.get_connection()
            trakt_sync._sync_tmdb_account_list_single(conn.cursor(), 'favorite', content_type, results)
            conn.commit()
            conn.close()
        else:
            results = []
    else:
        results = results_raw

    if not results:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    results = sort_personal_list(results)
    paginated, total = paginate_list(results, page, PAGE_LIMIT)
    prefetch_metadata_parallel(paginated, content_type)
    
    for item in paginated:
        if content_type == 'movie': _process_movie_item(item)
        else: _process_tv_item(item)

    if page < total:
        add_directory(next_page_label(page + 1), {'mode': 'tmdb_favorites', 'type': content_type, 'page': str(page+1)}, icon=NEXT_PAGE_ICON, thumb=NEXT_PAGE_ICON, info={'mediatype': 'video', 'plot': next_page_plot(page + 1)}, folder=True)
    xbmcplugin.setContent(HANDLE, 'movies' if content_type == 'movie' else 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE)
    _set_views_apply('movies' if content_type == 'movie' else 'tvshows')



def add_to_tmdb_watchlist(content_type, tmdb_id, notify=True):
    session = get_tmdb_session()
    if not session:
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "Not connected", xbmcgui.NOTIFICATION_WARNING)
        return False
    m_type = 'tv' if content_type in ('tv', 'tvshow', 'episode', 'season', 'show') else 'movie'
    # v4 NU are POST pentru watchlist (404). Endpoint-ul corect e v3:
    # POST /3/account/{account_id}/watchlist — hex account_id v4 functioneaza cu Bearer (verificat live 201).
    result = tmdb_auth_request(f"/account/{session['account_id']}/watchlist", method='POST',
                               data={'media_type': m_type, 'media_id': int(tmdb_id), 'watchlist': True}, v4=False)
    if result and result.get('success', True):
        details = get_tmdb_item_details(str(tmdb_id), content_type) or {}
        d_title = details.get('title') or details.get('name', 'Unknown')
        d_year = str(details.get('release_date') or details.get('first_air_date', ''))[:4]
        d_poster = details.get('poster_path', '')
        d_overview = details.get('overview', '')
        if notify:
            xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'),
                                          f"[B][COLOR yellow]{d_title}[/COLOR][/B] added to [B][COLOR FF00CED1]Watchlist[/COLOR][/B]",
                                          TMDB_ICON, 3000, False)
        
        # --- FIX BUFFERING: SQL INSTANT ---
        try:
            # 1. Update SQL Instant
            conn = trakt_sync.get_connection()
            c = conn.cursor()
            c.execute("INSERT OR REPLACE INTO tmdb_account_lists VALUES (?,?,?,?,?,?,?,?,?,?)", 
                      ('watchlist', m_type, str(tmdb_id), d_title, d_year, d_poster, str(time.time()), d_overview, '', ''))
            conn.commit()
            conn.close()
        except: pass

        # 2. Refresh UI Imediat (ca sa dispara rotita)
        from resources.lib.core.cache import clear_all_fast_cache
        clear_all_fast_cache()
        xbmc.executebuiltin("Container.Refresh")
        
        # 3. Up Next TMDB: serialul adaugat in watchlist → apare instant in lista
        #    (S1E1 daca e neinceput, altfel urmatorul episod nevizionat)
        if m_type == 'tv':
            try:
                from resources.lib.providers.trakt_sync import refresh_next_episode_tmdb
                refresh_next_episode_tmdb(str(tmdb_id))
            except Exception:
                pass
        
        return True
        # -------------------------------------------------
    return False

def remove_from_tmdb_watchlist(content_type, tmdb_id, notify=True):
    session = get_tmdb_session()
    if not session: return False
    m_type = 'tv' if content_type in ('tv', 'tvshow', 'episode', 'season', 'show') else 'movie'
    result = tmdb_auth_request(f"/account/{session['account_id']}/watchlist", method='POST',
                               data={'media_type': m_type, 'media_id': int(tmdb_id), 'watchlist': False}, v4=False)
    if result and result.get('success', True):
        details = get_tmdb_item_details(str(tmdb_id), content_type) or {}
        d_title = details.get('title') or details.get('name', 'Unknown')
        if notify:
            xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'),
                                          f"[B][COLOR yellow]{d_title}[/COLOR][/B] removed from [B][COLOR FF00CED1]Watchlist[/COLOR][/B]",
                                          TMDB_ICON, 3000, False)
        
        # --- FIX BUFFERING: SQL INSTANT ---
        try:
            conn = trakt_sync.get_connection()
            c = conn.cursor()
            c.execute("DELETE FROM tmdb_account_lists WHERE list_type=? AND media_type=? AND tmdb_id=?", 
                      ('watchlist', m_type, str(tmdb_id)))
            conn.commit()
            conn.close()
        except: pass
        
        from resources.lib.core.cache import clear_all_fast_cache
        clear_all_fast_cache()
        xbmc.executebuiltin("Container.Refresh")
        
        # 3. Up Next TMDB: serialul scos din watchlist → dispara instant din lista
        #    (refresh_next_episode_tmdb sterge randul daca nu mai e nici in
        #    watchlist, nici in pool-ul providerului activ)
        if m_type == 'tv':
            try:
                from resources.lib.providers.trakt_sync import refresh_next_episode_tmdb
                refresh_next_episode_tmdb(str(tmdb_id))
            except Exception:
                pass
        
        return True
        # -------------------------------------------------
    return False


def add_to_tmdb_favorites(content_type, tmdb_id, notify=True):
    session = get_tmdb_session()
    if not session:
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "Not connected", TMDB_ICON, 3000, False)
        return False

    m_type = 'tv' if content_type in ('tv', 'tvshow', 'episode', 'season', 'show') else 'movie'
    # v4 NU are POST pentru favorites (404). Endpoint-ul corect e v3:
    # POST /3/account/{account_id}/favorite — hex account_id v4 functioneaza cu Bearer (verificat live 201).
    result = tmdb_auth_request(f"/account/{session['account_id']}/favorite", method='POST',
                               data={'media_type': m_type, 'media_id': int(tmdb_id), 'favorite': True}, v4=False)

    if result and result.get('success', True):
        details = get_tmdb_item_details(str(tmdb_id), content_type) or {}
        d_title = details.get('title') or details.get('name', 'Unknown')
        d_year = str(details.get('release_date') or details.get('first_air_date', ''))[:4]
        d_poster = details.get('poster_path', '')
        d_overview = details.get('overview', '')
        if notify:
            xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'),
                                          f"[B][COLOR yellow]{d_title}[/COLOR][/B] added to [B][COLOR FF00CED1]Favorites[/COLOR][/B]",
                                          TMDB_ICON, 3000, False)
        
        # --- FIX BUFFERING: SQL INSTANT ---
        try:
            conn = trakt_sync.get_connection()
            c = conn.cursor()
            c.execute("INSERT OR REPLACE INTO tmdb_account_lists VALUES (?,?,?,?,?,?,?,?,?,?)", 
                      ('favorite', m_type, str(tmdb_id), d_title, d_year, d_poster, str(time.time()), d_overview, '', ''))
            conn.commit()
            conn.close()
        except: pass

        from resources.lib.core.cache import clear_all_fast_cache
        clear_all_fast_cache()
        xbmc.executebuiltin("Container.Refresh")
        
        return True
        # -------------------------------------------------
    return False


def remove_from_tmdb_favorites(content_type, tmdb_id, notify=True):
    session = get_tmdb_session()
    if not session:
        return False

    m_type = 'tv' if content_type in ('tv', 'tvshow', 'episode', 'season', 'show') else 'movie'
    result = tmdb_auth_request(f"/account/{session['account_id']}/favorite", method='POST',
                               data={'media_type': m_type, 'media_id': int(tmdb_id), 'favorite': False}, v4=False)

    if result and result.get('success', True):
        details = get_tmdb_item_details(str(tmdb_id), content_type) or {}
        d_title = details.get('title') or details.get('name', 'Unknown')
        if notify:
            xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'),
                                          f"[B][COLOR yellow]{d_title}[/COLOR][/B] removed from [B][COLOR FF00CED1]Favorites[/COLOR][/B]",
                                          TMDB_ICON, 3000, False)
        
        # --- FIX BUFFERING: SQL INSTANT ---
        try:
            conn = trakt_sync.get_connection()
            c = conn.cursor()
            c.execute("DELETE FROM tmdb_account_lists WHERE list_type=? AND media_type=? AND tmdb_id=?", 
                      ('favorite', m_type, str(tmdb_id)))
            conn.commit()
            conn.close()
        except: pass

        from resources.lib.core.cache import clear_all_fast_cache
        clear_all_fast_cache()
        xbmc.executebuiltin("Container.Refresh")
        
        return True
        # -------------------------------------------------
    return False


def add_to_tmdb_list(list_id, tmdb_id, content_type='movie'):
    session = get_tmdb_session()
    if not session: 
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "Not connected", TMDB_ICON, 3000, False)
        return False

    success = False
    media_type_normalized = 'tv' if content_type in ['tv', 'tvshow', 'episode', 'season', 'show'] else 'movie'
    
    # --- API V4 (singura metoda — suporta si seriale, si filme) ---
    resp = tmdb_auth_request(f"/list/{list_id}/items", method='POST',
                             data={"items": [{"media_type": media_type_normalized, "media_id": int(tmdb_id)}]}, v4=True)
    
    if resp and resp.get('success'):
        # Notificare cu numele listei (colorat TMDb + bold)
        list_name = 'List'
        d_title = ''
        try:
            conn_l = trakt_sync.get_connection()
            c_l = conn_l.cursor()
            c_l.execute("SELECT name FROM tmdb_custom_lists WHERE list_id=?", (str(list_id),))
            row_l = c_l.fetchone()
            if row_l: list_name = row_l[0]
            conn_l.close()
        except: pass
        try:
            details = get_tmdb_item_details(str(tmdb_id), media_type_normalized) or {}
            d_title = details.get('title') or details.get('name', 'Unknown')
        except: pass
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'),
                                      f"[B][COLOR yellow]{d_title}[/COLOR][/B] added to [B][COLOR FF00CED1]{list_name}[/COLOR][/B]",
                                      TMDB_ICON, 3000, False)
        success = True
    else:
        log(f"[TMDB] V4 Add failed: {resp}")

    if success:
        try:
            details = get_tmdb_item_details(str(tmdb_id), media_type_normalized) or {}
            d_title = details.get('title') or details.get('name', 'Unknown')
            d_year = str(details.get('release_date') or details.get('first_air_date', ''))[:4]
            d_poster = details.get('poster_path', '')
            d_backdrop = details.get('backdrop_path', '') # Definit corect aici
            d_overview = details.get('overview', '')
            
            conn = trakt_sync.get_connection()
            c = conn.cursor()
            # 1. Verificam daca item-ul exista deja (contorul nu se incrementeaza la duplicate)
            c.execute("SELECT sort_index FROM tmdb_custom_list_items WHERE list_id=? AND tmdb_id=?", 
                      (str(list_id), str(tmdb_id)))
            row_dup = c.fetchone()
            is_duplicate = row_dup is not None
            
            # 2. Inseram item-ul in baza locala - sort_index = min-1 ca sa fie primul (newest first)
            if is_duplicate:
                new_idx = row_dup[0]
            else:
                c.execute("SELECT MIN(sort_index) FROM tmdb_custom_list_items WHERE list_id=?", (str(list_id),))
                row_min = c.fetchone()
                new_idx = (row_min[0] - 1) if row_min and row_min[0] is not None else 0
            c.execute("INSERT OR REPLACE INTO tmdb_custom_list_items VALUES (?,?,?,?,?,?,?,?)", 
                      (str(list_id), str(tmdb_id), media_type_normalized, d_title, d_year, d_poster, d_overview, new_idx))
            
            # 3. Actualizam contorul doar daca e item nou (nu duplicat)
            if is_duplicate:
                c.execute("UPDATE tmdb_custom_lists SET poster = ?, backdrop = ? WHERE list_id=?", 
                          (d_poster, d_backdrop, str(list_id)))
            else:
                c.execute("UPDATE tmdb_custom_lists SET item_count = item_count + 1, poster = ?, backdrop = ? WHERE list_id=?", 
                          (d_poster, d_backdrop, str(list_id)))
            conn.commit()
            conn.close()
        except Exception as e:
            log(f"[TMDB] Error updating local SQL on add: {e}")

        # 3. Curatam cache-ul RAM si dam refresh o singura data, la final
        from resources.lib.core.cache import clear_all_fast_cache
        clear_all_fast_cache()
        xbmc.executebuiltin("Container.Refresh")
        return True
    
    return False


def remove_from_tmdb_list(list_id, tmdb_id, content_type='movie'):
    session = get_tmdb_session()
    if not session: return False

    success = False
    m_type = 'tv' if content_type in ['tv', 'tvshow', 'episode', 'season', 'show'] else 'movie'

    def try_delete(media_t):
        resp = tmdb_auth_request(f"/list/{list_id}/items", method='DELETE',
                                 data={"items": [{"media_type": media_t, "media_id": int(tmdb_id)}]}, v4=True)
        if not resp:
            return False
        if resp.get('success'):
            results = resp.get('results') or []
            if results:
                return bool(results[0].get('success'))
            return True
        return False

    success = try_delete(m_type)
    success_type = m_type
    
    if not success:
        other_type = 'movie' if m_type == 'tv' else 'tv'
        success = try_delete(other_type)
        if success: success_type = other_type

    if success:
        # 1. Stergere locala SQL + ACTUALIZARE POSTER LISTA
        try:
            from resources.lib.providers import trakt_sync
            conn = trakt_sync.get_connection()
            c = conn.cursor()
            
            # A. Stergem item-ul
            c.execute("DELETE FROM tmdb_custom_list_items WHERE list_id=? AND tmdb_id=?", 
                      (str(list_id), str(tmdb_id)))
            
            # B. Luam posterul primului element RAMAS pentru coperta listei
            c.execute("SELECT poster FROM tmdb_custom_list_items WHERE list_id=? ORDER BY sort_index ASC LIMIT 1", 
                      (str(list_id),))
            row = c.fetchone()
            
            # C. Numaram cate au mai ramas
            c.execute("SELECT COUNT(*) FROM tmdb_custom_list_items WHERE list_id=?", 
                      (str(list_id),))
            new_count = c.fetchone()[0]
            
            # D. Actualizam lista: count + poster nou
            if row and new_count > 0:
                c.execute("UPDATE tmdb_custom_lists SET item_count=?, poster=? WHERE list_id=?", 
                          (new_count, row[0] or '', str(list_id)))
            else:
                # The list is empty - resetam tot
                c.execute("UPDATE tmdb_custom_lists SET item_count=0, poster='', backdrop='' WHERE list_id=?", 
                          (str(list_id),))
            
            conn.commit()
            conn.close()
        except Exception as e:
            log(f"[TMDB] SQL Remove Error: {e}")

        # 2. Invalidare Smart Sync
        try:
            from resources.lib.core.config import LAST_SYNC_FILE
            sync_data = read_json(LAST_SYNC_FILE) or {}
            if 'lists' in sync_data:
                del sync_data['lists']
                write_json(LAST_SYNC_FILE, sync_data)
        except: pass

        from resources.lib.core.cache import clear_all_fast_cache
        clear_all_fast_cache()

        list_name = 'list'
        try:
            conn_n = trakt_sync.get_connection()
            c_n = conn_n.cursor()
            c_n.execute("SELECT name FROM tmdb_custom_lists WHERE list_id=?", (str(list_id),))
            row_n = c_n.fetchone()
            if row_n: list_name = row_n[0]
            conn_n.close()
        except: pass
        try:
            # Folosim tipul care a sters CU SUCCES (fallback-ul poate fi alt tip decat m_type)
            details = get_tmdb_item_details(str(tmdb_id), success_type) or {}
            d_title = details.get('title') or details.get('name', 'Unknown')
        except:
            d_title = ''
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'),
                                      f"[B][COLOR yellow]{d_title}[/COLOR][/B] removed from [B][COLOR FF00CED1]{list_name}[/COLOR][/B]",
                                      TMDB_ICON, 3000, False)
        xbmc.executebuiltin("Container.Refresh")
        return True
    
    return False


def is_in_tmdb_watchlist(tmdb_id, content_type):
    return trakt_sync.is_in_tmdb_account_list('watchlist', content_type, tmdb_id)


def is_in_tmdb_favorites(tmdb_id, content_type):
    return trakt_sync.is_in_tmdb_account_list('favorite', content_type, tmdb_id)


def get_tmdb_user_lists():
    session = get_tmdb_session()
    if not session:
        return []
    return get_tmdb_user_lists_v4()


def show_tmdb_context_menu(tmdb_id, content_type, title='', season=None, episode=None):
    session = get_tmdb_session()
    if not session:
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "Not connected", xbmcgui.NOTIFICATION_WARNING)
        return

    options = []
    
    in_watchlist = is_in_tmdb_watchlist(tmdb_id, content_type)
    if in_watchlist:
        options.append(('Remove from [B][COLOR FF00CED1]Watchlist[/COLOR][/B]', 'remove_watchlist'))
    else:
        options.append(('Add to [B][COLOR FF00CED1]Watchlist[/COLOR][/B]', 'add_watchlist'))

    in_favorites = is_in_tmdb_favorites(tmdb_id, content_type)
    if in_favorites:
        options.append(('Remove from [B][COLOR FF00CED1]Favorites[/COLOR][/B]', 'remove_favorites'))
    else:
        options.append(('Add to [B][COLOR FF00CED1]Favorites[/COLOR][/B]', 'add_favorites'))

    options.append(('Add to [B][COLOR FF00CED1]My Lists[/COLOR][/B]', 'add_to_list'))
    options.append(('Remove from [B][COLOR FF00CED1]My Lists[/COLOR][/B]', 'remove_from_list'))

    if str(content_type).lower() != 'season':
        options.append(('Rate on ' + provider_title('tmdb'), 'rate_item'))
        options.append(('Remove rating on ' + provider_title('tmdb'), 'remove_rating'))

    dialog = xbmcgui.Dialog()
    display_options = [opt[0] for opt in options]
    ret = dialog.contextmenu(display_options)

    if ret < 0:
        return

    action = options[ret][1]

    if action == 'add_watchlist':
        if add_to_tmdb_watchlist(content_type, tmdb_id):
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'remove_watchlist':
        if remove_from_tmdb_watchlist(content_type, tmdb_id):
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'add_favorites':
        if add_to_tmdb_favorites(content_type, tmdb_id):
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'remove_favorites':
        if remove_from_tmdb_favorites(content_type, tmdb_id):
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'add_to_list':
        show_tmdb_add_to_list_dialog(tmdb_id, content_type)
    elif action == 'remove_from_list':
        show_tmdb_remove_from_list_dialog(tmdb_id, content_type)
    elif action == 'rate_item':
        if rate_tmdb_item(tmdb_id, content_type, season, episode, title):
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'remove_rating':
        if remove_tmdb_rating(tmdb_id, content_type, season, episode):
            xbmc.executebuiltin("Container.Refresh")


def show_mdblist_context_menu(tmdb_id, imdb_id, content_type, title='', season=None, episode=None):
    import xbmcgui
    import xbmc
    import os
    from resources.lib.core.config import ADDON
    from resources.lib.core.config import provider_icon as _prov_icon
    MDB_ICON = _prov_icon('mdblist')
    
    from resources.lib.providers import mdblist
    if not mdblist.is_authenticated():
        xbmcgui.Dialog().notification(provider_title('mdblist'), "Add your " + provider_title('mdblist') + " API Key in Settings!", MDB_ICON, 3000, False)
        return

    if not title:
        try:
            from resources.lib.providers.trakt_sync import get_tmdb_item_details_from_db
            details = get_tmdb_item_details_from_db(tmdb_id, 'tv' if str(content_type).lower() not in ('movie', 'movies') else 'movie') or {}
            title = details.get('title') or details.get('name', 'Title')
        except:
            title = 'Title'

    # Add/Remove din mirrorul local (paritate Simkl/TMDB): fara retea si fara busy
    # dialog, meniul se randeaza instant. Mirrorul se actualizeaza la sync si la
    # fiecare add/remove facut din addon; o modificare pe site apare la sync-ul urmator.
    try:
        from resources.lib.providers.mdblist_sync import is_in_watchlist
        in_watchlist = is_in_watchlist(tmdb_id)
    except Exception:
        in_watchlist = False

    options = []
    if in_watchlist:
        options.append(('Remove from [B][COLOR lightskyblue]Watchlist[/COLOR][/B]', 'mdblist_watchlist_remove'))
    else:
        options.append(('Add to [B][COLOR lightskyblue]Watchlist[/COLOR][/B]', 'mdblist_watchlist_add'))

    from resources.lib.providers.mdblist_sync import is_in_collection
    _in_collection = is_in_collection(tmdb_id)
    if _in_collection:
        options.append(('Remove from [B][COLOR lightskyblue]Favorites[/COLOR][/B]', 'mdblist_remove_collection'))
    else:
        options.append(('Add to [B][COLOR lightskyblue]Favorites[/COLOR][/B]', 'mdblist_add_collection'))

    if str(content_type).lower() not in ('movie', 'movies'):
        _mdb_dropped = True
    else:
        _mdb_dropped = False

    options.append(('Add to [B][COLOR lightskyblue]My Lists[/COLOR][/B]', 'mdblist_add_to_list'))
    options.append(('Remove from [B][COLOR lightskyblue]My Lists[/COLOR][/B]', 'mdblist_remove_from_list'))

    if _mdb_dropped:
        from resources.lib.providers.mdblist_sync import is_dropped
        if is_dropped(tmdb_id):
            options.append(('Restore [B][COLOR FF6AFB92]Dropped Show[/COLOR][/B]', 'mdblist_unmark_dropped'))
        else:
            options.append(('[B][COLOR FFE41B17]Drop Show[/COLOR][/B]', 'mdblist_mark_dropped'))

    if content_type != 'season':
        options.append(('Rate on ' + provider_title('mdblist'), 'mdblist_rating'))
        options.append(('Remove rating on ' + provider_title('mdblist'), 'mdblist_remove_rating'))
    # --- Mark Watched/Unwatched (Dinamic, pe serverul MDBList — cross-provider) ---
    from resources.lib.providers.mdblist_sync import is_movie_watched as _mdb_is_mw, is_episode_watched as _mdb_is_ep, get_watched_episodes_count as _mdb_cnt, get_watched_season_episodes_count as _mdb_season_cnt
    if str(content_type).lower() in ('movie', 'movies'):
        _mdb_is_w = _mdb_is_mw(tmdb_id)
    elif content_type in ('tv', 'show'):
        _mdb_is_w = _mdb_cnt(tmdb_id) > 0
    elif content_type == 'episode' and season is not None and episode is not None:
        _mdb_is_w = _mdb_is_ep(tmdb_id, season, episode)
    elif content_type == 'season' and season is not None:
        _mdb_is_w = is_season_fully_watched(tmdb_id, season, _mdb_season_cnt)
    else:
        _mdb_is_w = False
    if _mdb_is_w:
        options.append(('[B][COLOR FFE41B17]Mark Unwatched [COLOR lightskyblue](MDB)[/COLOR][/B]', 'mdblist_mark_unwatched'))
    else:
        options.append(('[B][COLOR FF6AFB92]Mark Watched [COLOR lightskyblue](MDB)[/COLOR][/B]', 'mdblist_mark_watched'))

    dialog = xbmcgui.Dialog()
    ret = dialog.contextmenu([opt[0] for opt in options])

    if ret < 0:
        return

    action = options[ret][1]
    
    from resources.lib.providers.mdblist_api import MDBListAPI
    _mdb_api = MDBListAPI()
    
    if action == 'mdblist_watchlist_add':
        if mdblist.watchlist_add(imdb_id=imdb_id, tmdb_id=tmdb_id, mediatype=content_type, title=title):
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'mdblist_watchlist_remove':
        if mdblist.watchlist_remove(imdb_id=imdb_id, tmdb_id=tmdb_id, mediatype=content_type, title=title):
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'mdblist_add_to_list':
        show_mdblist_add_to_list_dialog(tmdb_id, imdb_id, content_type, title)
    elif action == 'mdblist_remove_from_list':
        show_mdblist_remove_from_list_dialog(tmdb_id, imdb_id, content_type, title)
    elif action == 'mdblist_rating':
        from resources.lib.providers.mdblist_api import prompt_mdblist_rating
        prompt_mdblist_rating(tmdb_id, content_type, season, episode, title)
    elif action == 'mdblist_remove_rating':
        from resources.lib.providers.mdblist_api import MDBListAPI
        if MDBListAPI().remove_rating(content_type, tmdb_id, season, episode) is not None:
            xbmcgui.Dialog().notification(provider_title('mdblist'), "Rating removed", MDB_ICON, 3000, False)
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'mdblist_mark_watched':
        from resources.lib.providers.mdblist_sync import mark_as_watched_internal as _mdb_mark
        _mdb_mark(tmdb_id, content_type, season, episode, sync_mdblist=True, refresh_ui=True)
    elif action == 'mdblist_mark_unwatched':
        from resources.lib.providers.mdblist_sync import mark_as_unwatched_internal as _mdb_unmark
        _mdb_unmark(tmdb_id, content_type, season, episode, sync_mdblist=True, refresh_ui=True)
    elif action == 'mdblist_mark_dropped':
        if _mdb_api.mark_dropped(tmdb_id):
            from resources.lib.providers.mdblist_sync import drop_add_local
            drop_add_local(tmdb_id, title)
            xbmcgui.Dialog().notification(provider_title('mdblist'), f"[B][COLOR yellow]{title}[/COLOR][/B] — [B][COLOR FFE41B17]Drop Show[/COLOR][/B]", MDB_ICON, 3000, False)
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'mdblist_unmark_dropped':
        if _mdb_api.unmark_dropped(tmdb_id):
            from resources.lib.providers.mdblist_sync import drop_remove_local, clear_cached
            drop_remove_local(tmdb_id)
            clear_cached('dropped')
            xbmcgui.Dialog().notification(provider_title('mdblist'), f"[B][COLOR yellow]{title}[/COLOR][/B] — Restore [B][COLOR FF6AFB92]Dropped Show[/COLOR][/B]", MDB_ICON, 3000, False)
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'mdblist_add_collection':
        _mdb_api.add_to_collection(content_type, tmdb_id)
        from resources.lib.providers.mdblist_sync import get_connection as _mdb_conn, clear_cached as _mdb_clear_cache
        _mc = _mdb_conn()
        _mc.execute("INSERT OR REPLACE INTO mdblist_collection (tmdb_id, media_type, collected_at) VALUES (?,?,datetime('now'))", (str(tmdb_id), content_type))
        _mc.commit()
        _mc.close()
        _mdb_clear_cache('collection')
        xbmcgui.Dialog().notification(provider_title('mdblist'), f"[B][COLOR yellow]{title}[/COLOR][/B] added to [B][COLOR lightskyblue]Favorites[/COLOR][/B]", MDB_ICON, 3000, False)
        xbmc.executebuiltin("Container.Refresh")
    elif action == 'mdblist_remove_collection':
        _mdb_api.remove_from_collection(content_type, tmdb_id)
        from resources.lib.providers.mdblist_sync import get_connection as _mdb_conn, clear_cached as _mdb_clear_cache
        _mc = _mdb_conn()
        _mc.execute("DELETE FROM mdblist_collection WHERE tmdb_id=?", (str(tmdb_id),))
        _mc.commit()
        _mc.close()
        _mdb_clear_cache('collection')
        xbmcgui.Dialog().notification(provider_title('mdblist'), f"[B][COLOR yellow]{title}[/COLOR][/B] removed from [B][COLOR lightskyblue]Favorites[/COLOR][/B]", MDB_ICON, 3000, False)
        xbmc.executebuiltin("Container.Refresh")


def show_simkl_context_menu(tmdb_id, imdb_id, content_type, title='', season=None, episode=None):
    import xbmcgui
    import xbmc
    import os
    from resources.lib.core.config import ADDON
    from resources.lib.core.config import provider_icon as _prov_icon
    SIMKL_ICON = _prov_icon('simkl')

    from resources.lib.providers import simkl
    if not simkl.is_authenticated():
        xbmcgui.Dialog().notification(provider_title('simkl'), "Connect " + provider_title('simkl') + " in Settings!", SIMKL_ICON, 3000, False)
        return

    if not title:
        try:
            from resources.lib.providers.trakt_sync import get_tmdb_item_details_from_db
            details = get_tmdb_item_details_from_db(tmdb_id, 'tv' if str(content_type).lower() not in ('movie', 'movies') else 'movie') or {}
            title = details.get('title') or details.get('name', 'Title')
        except:
            title = 'Title'

    options = []

    # Watchlist (5 statusuri Simkl)
    _is_movie = str(content_type).lower() in ('movie', 'movies')
    from resources.lib.providers.simkl_sync import get_watchlist_local
    _wl = get_watchlist_local()
    _wl_entry = None
    for _w in _wl:
        if str(_w.get('tmdb_id', '')) == str(tmdb_id):
            _wl_entry = _w
            break
    if _wl_entry:
        _st = _wl_entry.get('status', 'watching')
        _st_lbl = {'plantowatch': 'Plan to Watch', 'watching': 'Watching',
                   'completed': 'Completed', 'hold': 'On Hold', 'dropped': 'Dropped'}.get(_st, _st)
        options.append(('Remove from [B][COLOR mediumpurple]%s[/COLOR][/B]' % _st_lbl, 'simkl_watchlist_remove'))
    else:
        if _is_movie:
            _add_opts = [('plantowatch', 'Plan to Watch'), ('completed', 'Completed')]
        else:
            _add_opts = [('plantowatch', 'Plan to Watch'), ('watching', 'Watching'),
                         ('completed', 'Completed'), ('hold', 'On Hold')]
        for _st_id, _st_lbl in _add_opts:
            options.append(('Add to [B][COLOR mediumpurple]%s[/COLOR][/B]' % _st_lbl,
                            'simkl_watchlist_add_' + _st_id))

    # Dropped (filme + seriale)
    _drop_lbl = 'Drop Movie' if _is_movie else 'Drop Show'
    _restore_lbl = 'Restore Dropped Movie' if _is_movie else 'Restore Dropped Show'
    from resources.lib.providers.simkl_sync import is_dropped
    if is_dropped(tmdb_id):
        options.append(('[B][COLOR FF6AFB92]%s[/COLOR][/B]' % _restore_lbl, 'simkl_unmark_dropped'))
    else:
        options.append(('[B][COLOR FFE41B17]%s[/COLOR][/B]' % _drop_lbl, 'simkl_mark_dropped'))

    _is_ep = season is not None and episode is not None and str(content_type).lower() not in ('movie', 'movies')
    if content_type != 'season' and not _is_ep:
        options.append(('Rate on ' + provider_title('simkl'), 'simkl_rating'))
        options.append(('Remove rating on ' + provider_title('simkl'), 'simkl_remove_rating'))

    # Mark Watched/Unwatched (Dinamic, pe serverul Simkl — cross-provider)
    from resources.lib.providers.simkl_sync import is_movie_watched as _sk_is_mw, is_episode_watched as _sk_is_ep, get_watched_episodes_count as _sk_cnt, get_watched_season_episodes_count as _sk_season_cnt
    if str(content_type).lower() in ('movie', 'movies'):
        _sk_is_w = _sk_is_mw(tmdb_id)
    elif content_type in ('tv', 'show'):
        _sk_is_w = _sk_cnt(tmdb_id) > 0
    elif content_type == 'episode' and season is not None and episode is not None:
        _sk_is_w = _sk_is_ep(tmdb_id, season, episode)
    elif content_type == 'season' and season is not None:
        _sk_is_w = is_season_fully_watched(tmdb_id, season, _sk_season_cnt)
    else:
        _sk_is_w = False
    if _sk_is_w:
        options.append(('[B][COLOR FFE41B17]Mark Unwatched [COLOR mediumpurple](Simkl)[/COLOR][/B]', 'simkl_mark_unwatched'))
    else:
        options.append(('[B][COLOR FF6AFB92]Mark Watched [COLOR mediumpurple](Simkl)[/COLOR][/B]', 'simkl_mark_watched'))

    dialog = xbmcgui.Dialog()
    ret = dialog.contextmenu([opt[0] for opt in options])

    if ret < 0:
        return

    action = options[ret][1]

    if action == 'simkl_watchlist_add_watching':
        if simkl.watchlist_add(tmdb_id=tmdb_id, mediatype=content_type, status='watching', title=title):
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'simkl_watchlist_add_plantowatch':
        if simkl.watchlist_add(tmdb_id=tmdb_id, mediatype=content_type, status='plantowatch', title=title):
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'simkl_watchlist_add_completed':
        if simkl.watchlist_add(tmdb_id=tmdb_id, mediatype=content_type, status='completed', title=title):
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'simkl_watchlist_add_hold':
        if simkl.watchlist_add(tmdb_id=tmdb_id, mediatype=content_type, status='hold', title=title):
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'simkl_watchlist_remove':
        if simkl.watchlist_remove(tmdb_id=tmdb_id, mediatype=content_type, title=title):
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'simkl_rating':
        from resources.lib.providers.simkl_api import prompt_simkl_rating
        prompt_simkl_rating(tmdb_id, content_type, season, episode, title)
    elif action == 'simkl_remove_rating':
        from resources.lib.providers.simkl_api import SIMKLAPI
        if SIMKLAPI().remove_rating(content_type, tmdb_id, season, episode) is not None:
            xbmcgui.Dialog().notification(provider_title('simkl'), "Rating removed", SIMKL_ICON, 3000, False)
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'simkl_mark_watched':
        from resources.lib.providers.simkl_sync import mark_as_watched_internal as _sk_mark
        _sk_mark(tmdb_id, content_type, season, episode, sync_simkl=True, refresh_ui=True)
    elif action == 'simkl_mark_unwatched':
        from resources.lib.providers.simkl_sync import mark_as_unwatched_internal as _sk_unmark
        _sk_unmark(tmdb_id, content_type, season, episode, sync_simkl=True, refresh_ui=True)
    elif action == 'simkl_mark_dropped':
        from resources.lib.providers.simkl_sync import drop_show as _sk_drop
        _mt = 'movie' if str(content_type).lower() in ('movie', 'movies') else 'show'
        if _sk_drop(tmdb_id, title, _mt):
            xbmcgui.Dialog().notification(provider_title('simkl'), f"[B][COLOR yellow]{title}[/COLOR][/B] — [B][COLOR FFE41B17]Drop Show[/COLOR][/B]", SIMKL_ICON, 3000, False)
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'simkl_unmark_dropped':
        from resources.lib.providers.simkl_sync import restore_show as _sk_restore
        _mt = 'movie' if str(content_type).lower() in ('movie', 'movies') else 'show'
        if _sk_restore(tmdb_id, _mt):
            xbmcgui.Dialog().notification(provider_title('simkl'), f"[B][COLOR yellow]{title}[/COLOR][/B] — Restore [B][COLOR FF6AFB92]Dropped Show[/COLOR][/B]", SIMKL_ICON, 3000, False)
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")


def show_punchplay_context_menu(tmdb_id, imdb_id, content_type, title='', season=None, episode=None):
    import xbmcgui
    import xbmc
    import os
    from resources.lib.core.config import ADDON, PUNCHPLAY_COLOR

    PUNCHPLAY_ICON = provider_icon('punchplay')

    from resources.lib.providers import punchplay
    if not punchplay.is_authenticated():
        xbmcgui.Dialog().notification(f"[B][COLOR {PUNCHPLAY_COLOR}]PunchPlay[/COLOR][/B]", f"Connect [B][COLOR {PUNCHPLAY_COLOR}]PunchPlay[/COLOR][/B] in Settings!", PUNCHPLAY_ICON, 3000, False)
        return

    if not title:
        try:
            from resources.lib.providers.trakt_sync import get_tmdb_item_details_from_db
            details = get_tmdb_item_details_from_db(tmdb_id, 'tv' if str(content_type).lower() not in ('movie', 'movies') else 'movie') or {}
            title = details.get('title') or details.get('name', 'Title')
        except:
            title = 'Title'

    options = []

    _is_movie = str(content_type).lower() in ('movie', 'movies')
    from resources.lib.providers.punchplay_sync import get_watchlist_local
    _wl = get_watchlist_local()
    _wl_entry = None
    for _w in _wl:
        if str(_w.get('tmdb_id', '')) == str(tmdb_id):
            _wl_entry = _w
            break
    if _wl_entry:
        options.append((f'Remove from [B][COLOR {PUNCHPLAY_COLOR}]Watchlist[/COLOR][/B]', 'punchplay_watchlist_remove'))
    else:
        options.append((f'Add to [B][COLOR {PUNCHPLAY_COLOR}]Watchlist[/COLOR][/B]', 'punchplay_watchlist_add'))

    if _is_movie or str(content_type).lower() in ('tv', 'tvshow', 'show', 'shows', 'series', 'episode', 'season'):
        from resources.lib.providers.punchplay_sync import is_favourite as _pp_is_fav
        try:
            _fav = _pp_is_fav(tmdb_id)
        except:
            _fav = False
        if _fav:
            options.append((f'Remove from [B][COLOR {PUNCHPLAY_COLOR}]Favourites[/COLOR][/B]', 'punchplay_favourite_remove'))
        else:
            options.append((f'Add to [B][COLOR {PUNCHPLAY_COLOR}]Favourites[/COLOR][/B]', 'punchplay_favourite_add'))

    if _is_movie or str(content_type).lower() in ('tv', 'tvshow', 'show', 'shows', 'series', 'episode', 'season'):
        from resources.lib.providers.punchplay_sync import is_in_collection as _pp_is_coll
        try:
            _coll = _pp_is_coll(tmdb_id)
        except:
            _coll = False
        if _coll:
            options.append((f'Remove from [B][COLOR {PUNCHPLAY_COLOR}]Collection[/COLOR][/B]', 'punchplay_collection_remove'))
        else:
            options.append((f'Add to [B][COLOR {PUNCHPLAY_COLOR}]Collection[/COLOR][/B]', 'punchplay_collection_add'))

    options.append((f'Add to [B][COLOR {PUNCHPLAY_COLOR}]My Lists[/COLOR][/B]', 'punchplay_add_to_list'))
    options.append((f'Remove from [B][COLOR {PUNCHPLAY_COLOR}]My Lists[/COLOR][/B]', 'punchplay_remove_from_list'))

    _drop_lbl = 'Drop Movie' if _is_movie else 'Drop Show'
    _restore_lbl = 'Restore Dropped Movie' if _is_movie else 'Restore Dropped Show'
    from resources.lib.providers.punchplay_sync import is_dropped
    if is_dropped(tmdb_id):
        options.append(('[B][COLOR FF6AFB92]%s[/COLOR][/B]' % _restore_lbl, 'punchplay_unmark_dropped'))
    else:
        options.append(('[B][COLOR FFE41B17]%s[/COLOR][/B]' % _drop_lbl, 'punchplay_mark_dropped'))

    _is_ep = season is not None and episode is not None and str(content_type).lower() not in ('movie', 'movies')
    if content_type != 'season':
        options.append((f'Rate on [B][COLOR {PUNCHPLAY_COLOR}]PunchPlay[/COLOR][/B]', 'punchplay_rating'))
        options.append((f'Remove rating on [B][COLOR {PUNCHPLAY_COLOR}]PunchPlay[/COLOR][/B]', 'punchplay_remove_rating'))

    from resources.lib.providers.punchplay_sync import is_movie_watched as _pp_is_mw, is_episode_watched as _pp_is_ep, get_watched_episodes_count as _pp_cnt, get_watched_season_episodes_count as _pp_season_cnt
    if str(content_type).lower() in ('movie', 'movies'):
        _pp_is_w = _pp_is_mw(tmdb_id)
    elif content_type in ('tv', 'show'):
        _pp_is_w = _pp_cnt(tmdb_id) > 0
    elif content_type == 'episode' and season is not None and episode is not None:
        _pp_is_w = _pp_is_ep(tmdb_id, season, episode)
    elif content_type == 'season' and season is not None:
        _pp_is_w = is_season_fully_watched(tmdb_id, season, _pp_season_cnt)
    else:
        _pp_is_w = False
    if _pp_is_w:
        options.append((f'[B][COLOR FFE41B17]Mark Unwatched [COLOR {PUNCHPLAY_COLOR}](PunchPlay)[/COLOR][/B]', 'punchplay_mark_unwatched'))
    else:
        options.append((f'[B][COLOR FF6AFB92]Mark Watched [COLOR {PUNCHPLAY_COLOR}](PunchPlay)[/COLOR][/B]', 'punchplay_mark_watched'))

    dialog = xbmcgui.Dialog()
    ret = dialog.contextmenu([opt[0] for opt in options])

    if ret < 0:
        return

    action = options[ret][1]

    if action == 'punchplay_watchlist_add':
        if punchplay.watchlist_add(tmdb_id=tmdb_id, mediatype=content_type, title=title):
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'punchplay_watchlist_remove':
        if punchplay.watchlist_remove(tmdb_id=tmdb_id, mediatype=content_type, title=title):
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'punchplay_rating':
        from resources.lib.providers.punchplay_api import prompt_punchplay_rating
        prompt_punchplay_rating(tmdb_id, content_type, season, episode, title)
    elif action == 'punchplay_remove_rating':
        from resources.lib.providers.punchplay_api import PunchplayAPI
        if PunchplayAPI().remove_rating(content_type, tmdb_id, season, episode) is not None:
            xbmcgui.Dialog().notification(f"[B][COLOR {PUNCHPLAY_COLOR}]PunchPlay[/COLOR][/B]", "Rating removed", PUNCHPLAY_ICON, 3000, False)
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'punchplay_mark_watched':
        from resources.lib.providers.punchplay_sync import mark_as_watched_internal as _pp_mark
        _pp_mark(tmdb_id, content_type, season, episode, sync_punchplay=True, refresh_ui=True)
    elif action == 'punchplay_mark_unwatched':
        from resources.lib.providers.punchplay_sync import mark_as_unwatched_internal as _pp_unmark
        _pp_unmark(tmdb_id, content_type, season, episode, sync_punchplay=True, refresh_ui=True)
    elif action == 'punchplay_mark_dropped':
        from resources.lib.providers.punchplay_sync import drop_show as _pp_drop
        _mt = 'movie' if str(content_type).lower() in ('movie', 'movies') else 'show'
        if _pp_drop(tmdb_id, title, _mt):
            xbmcgui.Dialog().notification(f"[B][COLOR {PUNCHPLAY_COLOR}]PunchPlay[/COLOR][/B]", f"[B][COLOR yellow]{title}[/COLOR][/B] — [B][COLOR FFE41B17]Drop Show[/COLOR][/B]", PUNCHPLAY_ICON, 3000, False)
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'punchplay_unmark_dropped':
        from resources.lib.providers.punchplay_sync import restore_show as _pp_restore
        _mt = 'movie' if str(content_type).lower() in ('movie', 'movies') else 'show'
        if _pp_restore(tmdb_id, _mt):
            xbmcgui.Dialog().notification(f"[B][COLOR {PUNCHPLAY_COLOR}]PunchPlay[/COLOR][/B]", f"[B][COLOR yellow]{title}[/COLOR][/B] — Restore [B][COLOR FF6AFB92]Dropped Show[/COLOR][/B]", PUNCHPLAY_ICON, 3000, False)
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'punchplay_favourite_add':
        if punchplay.favourite_add(tmdb_id=tmdb_id, mediatype=content_type, title=title):
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'punchplay_favourite_remove':
        if punchplay.favourite_remove(tmdb_id=tmdb_id, mediatype=content_type, title=title):
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'punchplay_collection_add':
        if punchplay.collection_add(tmdb_id=tmdb_id, mediatype=content_type, title=title):
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'punchplay_collection_remove':
        if punchplay.collection_remove(tmdb_id=tmdb_id, mediatype=content_type, title=title):
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'punchplay_add_to_list':
        show_punchplay_add_to_list_dialog(tmdb_id, content_type, title)
    elif action == 'punchplay_remove_from_list':
        show_punchplay_remove_from_list_dialog(tmdb_id, content_type, title)


def _punchplay_ordinary_lists():
    rows = []
    try:
        from resources.lib.providers.punchplay_api import PunchplayAPI
        api = PunchplayAPI()
        if not api.is_authenticated():
            return rows
        cursor = None
        for _ in range(10):
            data = api.get_lists(cursor=cursor, limit=100) or {}
            for lst in data.get('items') or []:
                if not isinstance(lst, dict) or lst.get('isWatchlist') or lst.get('isDynamicList'):
                    continue
                try:
                    lid = int(lst.get('id') or 0)
                except:
                    continue
                if lid:
                    rows.append({'id': lid, 'name': lst.get('name') or f'List {lid}',
                                 'item_count': int(lst.get('itemCount') or 0)})
            cursor = data.get('nextCursor')
            if not cursor:
                break
    except:
        pass
    return rows


def _punchplay_lists_with_posters(tmdb_id=None):
    rows = []
    try:
        from resources.lib.providers.punchplay_api import PunchplayAPI
        from resources.lib.core.config import IMG_BASE
        api = PunchplayAPI()
        for lst in _punchplay_ordinary_lists():
            poster = ''
            has_item = False
            try:
                items = None
                try:
                    _d = api.get_list(lst['id']) or {}
                    items = _d.get('items') or None
                except:
                    items = None
                if not items:
                    try:
                        _p = api.get_list_items(lst['id'], offset=0, limit=200) or {}
                        items = _p.get('items') or []
                    except:
                        items = []
                for it in items or []:
                    if not isinstance(it, dict):
                        continue
                    try:
                        if tmdb_id is not None and int(it.get('tmdbId') or 0) == int(tmdb_id):
                            has_item = True
                    except:
                        pass
                if items:
                    _stamped = [it for it in items if isinstance(it, dict) and (it.get('addedAt') or it.get('added_at'))]
                    if _stamped:
                        _last = max(_stamped, key=lambda it: str(it.get('addedAt') or it.get('added_at')))
                    else:
                        _last = items[0]
                    _pp = _last.get('posterPath') if isinstance(_last, dict) else ''
                    if _pp:
                        poster = _pp if str(_pp).startswith('http') else IMG_BASE + str(_pp)
            except:
                pass
            try:
                n_items = len(items or [])
            except:
                n_items = 0
            rows.append({'id': lst['id'], 'name': lst['name'], 'item_count': max(lst['item_count'], n_items),
                         'poster': poster, 'has_item': has_item})
    except:
        pass
    try:
        from resources.lib.core.utils import sort_personal_list
        rows = sort_personal_list(rows) or rows
    except:
        pass
    return rows


def _punchplay_list_kind(content_type):
    return 'movie' if str(content_type).lower() in ('movie', 'movies') else 'show'


def show_punchplay_add_to_list_dialog(tmdb_id, content_type, title=''):
    from resources.lib.core.config import PUNCHPLAY_COLOR
    PUNCHPLAY_ICON = provider_icon('punchplay')
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        lists = _punchplay_lists_with_posters()
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel,true)')
    if not lists:
        xbmcgui.Dialog().notification(f"[B][COLOR {PUNCHPLAY_COLOR}]PunchPlay[/COLOR][/B]",
                                       'You have no lists (create one on the site first)', PUNCHPLAY_ICON, 3000, False)
        return
    display_items = []
    for lst in lists:
        li = xbmcgui.ListItem(f"[B][COLOR {PUNCHPLAY_COLOR}]{lst['name']}[/COLOR][/B]")
        li.setLabel2(f"[B][COLOR yellow]{lst['item_count']}[/COLOR][/B] items")
        poster = lst['poster'] or PUNCHPLAY_ICON
        li.setArt({'thumb': poster, 'icon': poster, 'poster': poster})
        display_items.append(li)
    idx = xbmcgui.Dialog().select(provider_title('punchplay') + ': Add to List', display_items, useDetails=True)
    if idx is None or idx < 0 or idx >= len(lists):
        return
    try:
        from resources.lib.providers.punchplay_api import PunchplayAPI
        res = PunchplayAPI().add_list_item(lists[idx]['id'], _punchplay_list_kind(content_type), tmdb_id, title=title or '')
        if res is not None:
            try:
                from resources.lib.providers.punchplay import invalidate_list_cache
                invalidate_list_cache(lists[idx]['id'])
            except:
                pass
            xbmcgui.Dialog().notification(f"[B][COLOR {PUNCHPLAY_COLOR}]PunchPlay[/COLOR][/B]",
                                           f'[B][COLOR lime]{title or tmdb_id}[/COLOR][/B] added to [B][COLOR yellow]{lists[idx]["name"]}[/COLOR][/B]',
                                           PUNCHPLAY_ICON, 3000, False)
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmc.log(f'[PUNCHPLAY] add to list error: {e}', xbmc.LOGERROR)


def show_punchplay_remove_from_list_dialog(tmdb_id, content_type, title=''):
    from resources.lib.core.config import PUNCHPLAY_COLOR
    PUNCHPLAY_ICON = provider_icon('punchplay')
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        lists = [l for l in _punchplay_lists_with_posters(tmdb_id) if l['has_item']]
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel,true)')
    if not lists:
        xbmcgui.Dialog().notification(f"[B][COLOR {PUNCHPLAY_COLOR}]PunchPlay[/COLOR][/B]",
                                       'Not in any list', PUNCHPLAY_ICON, 3000, False)
        return
    display_items = []
    for lst in lists:
        li = xbmcgui.ListItem(f"[B][COLOR {PUNCHPLAY_COLOR}]{lst['name']}[/COLOR][/B]")
        li.setLabel2(f"[B][COLOR yellow]{lst['item_count']}[/COLOR][/B] items")
        poster = lst['poster'] or PUNCHPLAY_ICON
        li.setArt({'thumb': poster, 'icon': poster, 'poster': poster})
        display_items.append(li)
    idx = xbmcgui.Dialog().select('Remove from List', display_items, useDetails=True)
    if idx is None or idx < 0 or idx >= len(lists):
        return
    try:
        from resources.lib.providers.punchplay_api import PunchplayAPI
        api = PunchplayAPI()
        item_id = None
        try:
            _d = api.get_list(lists[idx]['id']) or {}
            for it in _d.get('items') or []:
                if not isinstance(it, dict):
                    continue
                try:
                    if int(it.get('tmdbId') or 0) == int(tmdb_id):
                        item_id = it.get('id')
                        break
                except:
                    continue
        except:
            pass
        if item_id is None:
            offset = 0
            for _ in range(5):
                data = api.get_list_items(lists[idx]['id'], offset=offset, limit=200) or {}
                items = data.get('items') or []
                if not items:
                    break
                for it in items:
                    if not isinstance(it, dict):
                        continue
                    try:
                        if int(it.get('tmdbId') or 0) == int(tmdb_id):
                            item_id = it.get('id')
                            break
                    except:
                        continue
                if item_id is not None:
                    break
                offset += len(items)
                if data.get('nextOffset') is None:
                    break
        if item_id is None:
            xbmcgui.Dialog().notification(f"[B][COLOR {PUNCHPLAY_COLOR}]PunchPlay[/COLOR][/B]",
                                           f'[B][COLOR yellow]{title or tmdb_id}[/COLOR][/B] is not in [B]{lists[idx]["name"]}[/B]',
                                           PUNCHPLAY_ICON, 3000, False)
            return
        if api.remove_list_item(lists[idx]['id'], item_id) is not None:
            try:
                from resources.lib.providers.punchplay import invalidate_list_cache
                invalidate_list_cache(lists[idx]['id'])
            except:
                pass
            xbmcgui.Dialog().notification(f"[B][COLOR {PUNCHPLAY_COLOR}]PunchPlay[/COLOR][/B]",
                                           f'[B][COLOR lime]{title or tmdb_id}[/COLOR][/B] removed from [B][COLOR yellow]{lists[idx]["name"]}[/COLOR][/B]',
                                           PUNCHPLAY_ICON, 3000, False)
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmc.log(f'[PUNCHPLAY] remove from list error: {e}', xbmc.LOGERROR)


_ALL_PROV_COLORS = ('pink', 'lightskyblue', 'FF00CED1')  # legacy (3 culori)

_PROVIDER_COLORS = {
    'trakt': 'pink',
    'mdblist': 'lightskyblue',
    'tmdb': 'FF00CED1',
    'simkl': 'mediumpurple',
    'punchplay': 'FFFF6600',
}

_PROVIDER_LABELS = {
    'trakt': provider_title('trakt'),
    'mdblist': provider_title('mdblist'),
    'tmdb': provider_title('tmdb'),
    'simkl': provider_title('simkl'),
    'punchplay': provider_title('punchplay'),
}


def _allprov_colored(word, splits, provs=None):
    """Coloreaza un cuvant in segmente, unul per provider (Trakt, MDBList, TMDb, Simkl).
    ex: Watchlist -> Wat(pink) chl(lightskyblue) is(FF00CED1) t(mediumpurple).
    provs: lista de provideri per segment (optional; default = secventa legacy)."""
    out = ''
    pos = 0
    if provs:
        for i, l in enumerate(splits):
            out += '[COLOR %s]%s[/COLOR]' % (_PROVIDER_COLORS.get(provs[i], 'white'), word[pos:pos + l])
            pos += l
    else:
        n = len(_ALL_PROV_COLORS)
        for i, l in enumerate(splits):
            out += '[COLOR %s]%s[/COLOR]' % (_ALL_PROV_COLORS[i % n], word[pos:pos + l])
            pos += l
    return out


_ALL_PROV_ORDER = ('trakt', 'mdblist', 'tmdb', 'simkl', 'punchplay')  # aceeasi ordine ca _PROVIDER_COLORS

def _allprov_names(which):
    """Numele providerilor in ordinea culorilor din cuvant (Trakt, MDBList, TMDb),
    indiferent de ordinea in care au fost executate actiunile."""
    ordered = [w for w in _ALL_PROV_ORDER if w in which] + [w for w in which if w not in _ALL_PROV_ORDER]
    return ' + '.join(_PROVIDER_LABELS.get(w, w) for w in ordered)


def _trakt_rating_payload(tmdb_id, content_type, season, episode, rating=None):
    """Payload Trakt /sync/ratings (sau /remove) pentru movie/show/season/episode."""
    def _add_rating(obj):
        if rating: obj['rating'] = rating
        return obj
    if content_type == 'movie':
        return {'movies': [_add_rating({'ids': {'tmdb': int(tmdb_id)}})]}
    if content_type == 'season' and season is not None:
        return {'shows': [{'ids': {'tmdb': int(tmdb_id)},
                           'seasons': [_add_rating({'number': int(season)})]}]}
    # 'tv' + season + episode = EPISOD: URL-urile de playback trimit type='tv'
    # (nu 'episode'), deci fara normalizare asta ar rata SHOW-ul parinte pe Trakt.
    if content_type in ('tv', 'episode', 'show', 'shows', 'series') and season is not None and episode is not None:
        return {'shows': [{'ids': {'tmdb': int(tmdb_id)},
                           'seasons': [{'number': int(season),
                                        'episodes': [_add_rating({'number': int(episode)})]}]}]}
    return {'shows': [_add_rating({'ids': {'tmdb': int(tmdb_id)}})]}


_POSTWATCH_ICONS = {
    'trakt': 'trakt.png',
    'tmdb': 'tmdb.png',
    'mdblist': 'mdblist.png',
    'simkl': 'simkl.png',
    'punchplay': 'punchplay.png',
}

_POSTWATCH_LABELS = {
    'trakt': 'TRAKT',
    'mdblist': 'MDBLIST',
    'tmdb': 'TMDB',
    'simkl': 'SIMKL',
    'punchplay': 'PUNCHPLAY',
}


def _connected_rating_providers():
    connected = []
    try:
        from resources.lib.api import trakt_api
        if trakt_api.get_trakt_token():
            connected.append('trakt')
    except Exception:
        pass
    try:
        from resources.lib.providers import mdblist
        if mdblist.is_authenticated():
            connected.append('mdblist')
    except Exception:
        pass
    try:
        if get_tmdb_session():
            connected.append('tmdb')
    except Exception:
        pass
    try:
        from resources.lib.providers import simkl
        if simkl.is_authenticated():
            connected.append('simkl')
    except Exception:
        pass
    try:
        from resources.lib.providers import punchplay
        if punchplay.is_authenticated():
            connected.append('punchplay')
    except Exception:
        pass
    return connected


def rate_on_providers(tmdb_id, content_type, season, episode, val, providers):
    done = []
    try:
        if 'trakt' in providers:
            from resources.lib.api import trakt_api
            if val > 0:
                payload = _trakt_rating_payload(tmdb_id, content_type, season, episode, val)
                if trakt_api.trakt_api_request('/sync/ratings', method='POST', data=payload) is not None:
                    done.append('trakt')
            else:
                payload = _trakt_rating_payload(tmdb_id, content_type, season, episode)
                if trakt_api.trakt_api_request('/sync/ratings/remove', method='POST', data=payload) is not None:
                    done.append('trakt')
    except Exception:
        pass
    try:
        if 'mdblist' in providers:
            from resources.lib.providers.mdblist_api import MDBListAPI
            api = MDBListAPI()
            if val > 0:
                if api.rate_item(content_type, tmdb_id, val, season, episode) is not None:
                    done.append('mdblist')
            else:
                if api.remove_rating(content_type, tmdb_id, season, episode) is not None:
                    done.append('mdblist')
    except Exception:
        pass
    try:
        _simkl_locked = (season is not None or episode is not None) and str(content_type).lower() not in ('movie', 'movies')
        if 'simkl' in providers and not _simkl_locked:
            from resources.lib.providers.simkl_api import SIMKLAPI
            api = SIMKLAPI()
            if val > 0:
                if api.rate_item(content_type, tmdb_id, val, season, episode) is not None:
                    done.append('simkl')
            else:
                if api.remove_rating(content_type, tmdb_id, season, episode) is not None:
                    done.append('simkl')
    except Exception:
        pass
    try:
        if 'punchplay' in providers:
            from resources.lib.providers.punchplay_api import PunchplayAPI
            api = PunchplayAPI()
            if val > 0:
                if api.rate_item(content_type, tmdb_id, val, season, episode) is not None:
                    done.append('punchplay')
            else:
                if api.remove_rating(content_type, tmdb_id, season, episode) is not None:
                    done.append('punchplay')
    except Exception:
        pass
    try:
        # Guard TMDb: ratingul de SHOW scoate serialul din watchlist -> skip.
        # 'tv' + season + episode = EPISOD (playback-ul trimite type='tv') -> permis.
        _ct = str(content_type).lower()
        if 'tmdb' in providers and not (_ct in ('tv', 'show', 'shows', 'series') and not (season and episode)):
            if val > 0:
                if rate_tmdb_item_silent(tmdb_id, content_type, val, season, episode):
                    done.append('tmdb')
            else:
                if season is not None and episode is not None:
                    res = tmdb_auth_request(f"/tv/{tmdb_id}/season/{season}/episode/{episode}/rating",
                                            method='DELETE', v4=False)
                    if res is not None:
                        done.append('tmdb')
                elif _ct == 'season' and season is not None:
                    res = tmdb_auth_request(f"/tv/{tmdb_id}/season/{season}/rating",
                                            method='DELETE', v4=False)
                    if res is not None:
                        done.append('tmdb')
                elif delete_tmdb_rating(tmdb_id, content_type, notify=False):
                    done.append('tmdb')
    except Exception:
        pass
    return done


def prompt_postwatch_rating(tmdb_id, content_type, season=None, episode=None, title=''):
    try:
        mode = ADDON.getSetting('rating_postwatch_mode') or '0'
    except Exception:
        mode = '0'
    if mode not in ('1', '2'):
        from resources.lib.providers.watched_provider import is_mdblist, is_simkl, is_punchplay
        if is_mdblist():
            from resources.lib.providers.mdblist_api import prompt_mdblist_rating
            prompt_mdblist_rating(tmdb_id, content_type, season, episode, title)
        elif is_simkl():
            if season is None and episode is None:
                from resources.lib.providers.simkl_api import prompt_simkl_rating
                prompt_simkl_rating(tmdb_id, content_type, season, episode, title)
        elif is_punchplay():
            from resources.lib.providers.punchplay_api import prompt_punchplay_rating
            prompt_punchplay_rating(tmdb_id, content_type, season, episode, title)
        else:
            from resources.lib.api import trakt_api
            trakt_api._prompt_trakt_rating(tmdb_id, content_type, season, episode, title)
        return
    connected = _connected_rating_providers()
    if mode == '1':
        targets = list(connected)
    else:
        toggles = {
            'trakt': 'rating_postwatch_trakt',
            'mdblist': 'rating_postwatch_mdblist',
            'simkl': 'rating_postwatch_simkl',
            'tmdb': 'rating_postwatch_tmdb',
            'punchplay': 'rating_postwatch_punchplay',
        }
        targets = []
        for prov in connected:
            try:
                if ADDON.getSetting(toggles[prov]) == 'true':
                    targets.append(prov)
            except Exception:
                pass
    if season is not None and episode is not None and str(content_type).lower() not in ('movie', 'movies'):
        targets = [p for p in targets if p != 'simkl']
    if not targets:
        return
    if len(targets) == 1:
        from resources.lib.api import trakt_api
        trakt_api._prompt_trakt_rating(tmdb_id, content_type, season, episode, title, service=targets[0])
        return
    import os as _os
    from resources.lib.api.trakt_api import show_rating_window
    ordered = [p for p in _ALL_PROV_ORDER if p in targets]
    _media_dir = _os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media')
    if mode == '1':
        _title = 'RATE ON ALL PROVIDERS'
    else:
        _title = 'RATE ON ' + ' + '.join(_POSTWATCH_LABELS[p] for p in ordered)
    val = show_rating_window(tmdb_id, content_type, season, episode, title or '',
                             _os.path.join(_media_dir, _POSTWATCH_ICONS[ordered[0]]),
                             _title,
                             extra_icons=[_os.path.join(_media_dir, _POSTWATCH_ICONS[p]) for p in ordered[1:4]])
    if val <= 0:
        return
    done = rate_on_providers(tmdb_id, content_type, season, episode, val, targets)
    if done:
        msg = f'Rated [B][COLOR yellow]{val}/10[/COLOR][/B] on {_allprov_names(done)}'
    else:
        msg = 'No provider accepted the rating'
    xbmcgui.Dialog().notification('[B][COLOR yellow]All Providers[/COLOR][/B]', msg, TMDbmovies_ICON, 5000, False)


def show_all_providers_context_menu(tmdb_id, imdb_id, content_type, title='', season=None, episode=None):
    """Meniu 'All Providers': o singura actiune aplicata pe toti providerii conectati
    (TMDb + Trakt + MDBList). Watchlist/Favorite/Rate pe 3 culori (3 provideri),
    Watched/Unwatched pe 2 (Trakt + MDBList)."""
    connected = []
    try:
        from resources.lib.api import trakt_api
        if trakt_api.get_trakt_token():
            connected.append('trakt')
    except Exception:
        pass
    try:
        from resources.lib.providers import mdblist
        if mdblist.is_authenticated():
            connected.append('mdblist')
    except Exception:
        pass
    try:
        if get_tmdb_session():
            connected.append('tmdb')
    except Exception:
        pass
    try:
        from resources.lib.providers import simkl
        if simkl.is_authenticated():
            connected.append('simkl')
    except Exception:
        pass
    try:
        from resources.lib.providers import punchplay
        if punchplay.is_authenticated():
            connected.append('punchplay')
    except Exception:
        pass

    if not connected:
        xbmcgui.Dialog().notification('[B][COLOR yellow]All Providers[/COLOR][/B]',
                                       'No provider connected (Trakt / MDBList / TMDb / Simkl)',
                                       xbmcgui.NOTIFICATION_WARNING)
        return

    wl = _allprov_colored('Watchlist', (2, 2, 2, 2, 1), ('trakt', 'mdblist', 'tmdb', 'simkl', 'punchplay'))
    fav = _allprov_colored('Favorite', (2, 2, 2, 1, 1), ('trakt', 'mdblist', 'tmdb', 'simkl', 'punchplay'))
    wch = _allprov_colored('Watched', (2, 2, 1, 1, 1), ('trakt', 'mdblist', 'tmdb', 'simkl', 'punchplay'))
    uwch = _allprov_colored('Unwatched', (2, 2, 2, 2, 1), ('trakt', 'mdblist', 'tmdb', 'simkl', 'punchplay'))
    _no_simkl_rate = str(content_type).lower() not in ('movie', 'movies') and (season is not None or episode is not None)
    if _no_simkl_rate:
        rate = _allprov_colored('Rate it', (2, 2, 3), ('trakt', 'tmdb', 'mdblist'))
        rmrate = _allprov_colored('rating', (1, 1, 4), ('trakt', 'tmdb', 'mdblist'))
    else:
        rate = _allprov_colored('Rate it', (2, 1, 1, 2, 1), ('trakt', 'tmdb', 'mdblist', 'simkl', 'punchplay'))
        rmrate = _allprov_colored('rating', (1, 1, 1, 2, 1), ('trakt', 'tmdb', 'mdblist', 'simkl', 'punchplay'))

    options = [
        (f'[B]Add to {wl}[/B]', 'wl_add'),
        (f'[B]Remove from {wl}[/B]', 'wl_remove'),
        (f'[B]Add to {fav}[/B]', 'fav_add'),
        (f'[B]Remove from {fav}[/B]', 'fav_remove'),
        (f'[B]Mark {wch}[/B]', 'watched'),
        (f'[B]Mark {uwch}[/B]', 'unwatched'),
    ]
    if content_type != 'season':
        options.append((f'[B]{rate}[/B]', 'rate'))
        options.append((f'[B]Remove {rmrate}[/B]', 'rate_remove'))

    dialog = xbmcgui.Dialog()
    ret = dialog.contextmenu([opt[0] for opt in options])
    if ret < 0:
        return
    action = options[ret][1]

    done = []

    if action in ('wl_add', 'wl_remove'):
        try:
            if 'tmdb' in connected:
                fn = add_to_tmdb_watchlist if action == 'wl_add' else remove_from_tmdb_watchlist
                if fn(content_type, tmdb_id, notify=False):
                    done.append('tmdb')
        except Exception:
            pass
        try:
            if 'trakt' in connected:
                from resources.lib.api import trakt_api
                fn = trakt_api.add_to_trakt_watchlist if action == 'wl_add' else trakt_api.remove_from_trakt_watchlist
                if fn(tmdb_id, content_type, notify=False):
                    done.append('trakt')
        except Exception:
            pass
        try:
            if 'mdblist' in connected:
                from resources.lib.providers import mdblist
                fn = mdblist.watchlist_add if action == 'wl_add' else mdblist.watchlist_remove
                if fn(imdb_id=imdb_id, tmdb_id=tmdb_id, mediatype=content_type, title=title, notify=False):
                    done.append('mdblist')
        except Exception:
            pass
        try:
            if 'simkl' in connected:
                from resources.lib.providers import simkl
                # Simkl n-are watchlist generic — totul merge in Plan to Watch
                if action == 'wl_add':
                    if simkl.watchlist_add(tmdb_id=tmdb_id, mediatype=content_type, status='plantowatch', title=title, notify=False):
                        done.append('simkl')
                else:
                    if simkl.watchlist_remove(tmdb_id=tmdb_id, mediatype=content_type, title=title, notify=False):
                        done.append('simkl')
        except Exception:
            pass
        try:
            if 'punchplay' in connected:
                from resources.lib.providers import punchplay
                if action == 'wl_add':
                    if punchplay.watchlist_add(tmdb_id=tmdb_id, mediatype=content_type, title=title, notify=False):
                        done.append('punchplay')
                else:
                    if punchplay.watchlist_remove(tmdb_id=tmdb_id, mediatype=content_type, title=title, notify=False):
                        done.append('punchplay')
        except Exception:
            pass
        verb = 'added to' if action == 'wl_add' else 'removed from'
        if done:
            xbmcgui.Dialog().notification('[B][COLOR yellow]All Providers[/COLOR][/B]',
                                           f'[B][COLOR orange]{title or "Item"}[/COLOR][/B] {verb} [B]{wl}[/B] on {_allprov_names(done)}',
                                           TMDbmovies_ICON, 5000, False)

    elif action in ('fav_add', 'fav_remove'):
        try:
            if 'tmdb' in connected:
                fn = add_to_tmdb_favorites if action == 'fav_add' else remove_from_tmdb_favorites
                if fn(content_type, tmdb_id, notify=False):
                    done.append('tmdb')
        except Exception:
            pass
        try:
            if 'trakt' in connected:
                from resources.lib.api import trakt_api
                fn = trakt_api.add_to_trakt_favorites if action == 'fav_add' else trakt_api.remove_from_trakt_favorites
                if fn(tmdb_id, content_type, notify=False):
                    done.append('trakt')
        except Exception:
            pass
        try:
            if 'mdblist' in connected:
                from resources.lib.providers.mdblist_api import MDBListAPI
                api = MDBListAPI()
                from resources.lib.providers.mdblist_sync import get_connection, clear_cached
                if action == 'fav_add':
                    if api.add_to_collection(content_type, tmdb_id) is not None:
                        conn = get_connection()
                        conn.execute("INSERT OR REPLACE INTO mdblist_collection (tmdb_id, media_type, collected_at) VALUES (?,?,datetime('now'))", (str(tmdb_id), content_type))
                        conn.commit()
                        conn.close()
                        clear_cached('collection')
                        done.append('mdblist')
                else:
                    if api.remove_from_collection(content_type, tmdb_id) is not None:
                        conn = get_connection()
                        conn.execute("DELETE FROM mdblist_collection WHERE tmdb_id=?", (str(tmdb_id),))
                        conn.commit()
                        conn.close()
                        clear_cached('collection')
                        done.append('mdblist')
        except Exception:
            pass
        try:
            if 'punchplay' in connected:
                from resources.lib.providers import punchplay
                if action == 'fav_add':
                    if punchplay.favourite_add(tmdb_id=tmdb_id, mediatype=content_type, title=title, notify=False):
                        done.append('punchplay')
                else:
                    if punchplay.favourite_remove(tmdb_id=tmdb_id, mediatype=content_type, title=title, notify=False):
                        done.append('punchplay')
        except Exception:
            pass
        verb = 'added to' if action == 'fav_add' else 'removed from'
        if done:
            xbmcgui.Dialog().notification('[B][COLOR yellow]All Providers[/COLOR][/B]',
                                           f'[B][COLOR orange]{title or "Item"}[/COLOR][/B] {verb} [B]{fav}[/B] on {_allprov_names(done)}',
                                           TMDbmovies_ICON, 5000, False)

    elif action in ('watched', 'unwatched'):
        from resources.lib.providers.watched_provider import mark_watched_on_providers as _w_mark, mark_unwatched_on_providers as _w_unmark
        if action == 'watched':
            done = _w_mark(tmdb_id, content_type, season, episode, providers=connected, notify=False, sync_provider=True, do_refresh=False)
        else:
            done = _w_unmark(tmdb_id, content_type, season, episode, providers=connected, notify=False, sync_provider=True, do_refresh=False)
        if done:
            lbl = f'[B]Mark {wch}[/B]' if action == 'watched' else f'[B]Mark {uwch}[/B]'
            xbmcgui.Dialog().notification('[B][COLOR yellow]All Providers[/COLOR][/B]',
                                           f'{lbl} on {_allprov_names(done)}',
                                           TMDbmovies_ICON, 5000, False)

    elif action in ('rate', 'rate_remove'):
        rate_targets = [p for p in connected if p != 'simkl'] if _no_simkl_rate else list(connected)
        if action == 'rate':
            import os as _os
            from resources.lib.api.trakt_api import show_rating_window
            _media_dir = _os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media')
            _rate_icons = [_os.path.join(_media_dir, 'tmdb.png'),
                           _os.path.join(_media_dir, 'mdblist.png')]
            if 'simkl' in rate_targets:
                _rate_icons.append(_os.path.join(_media_dir, 'simkl.png'))
            if 'punchplay' in rate_targets:
                _rate_icons.append(_os.path.join(_media_dir, 'punchplay.png'))
            val = show_rating_window(tmdb_id, content_type, season, episode, title or '',
                                     _os.path.join(_media_dir, 'trakt.png'),
                                     'RATE ON ALL PROVIDERS',
                                     extra_icons=_rate_icons)
            if val <= 0:
                return
        else:
            val = 0
        done = rate_on_providers(tmdb_id, content_type, season, episode, val, rate_targets)
        if done:
            msg = f'Rated [B][COLOR yellow]{val}/10[/COLOR][/B] on {_allprov_names(done)}' if val > 0 else f'Rating removed from {_allprov_names(done)}'
        else:
            msg = 'No provider accepted the rating'
        xbmcgui.Dialog().notification('[B][COLOR yellow]All Providers[/COLOR][/B]', msg, TMDbmovies_ICON, 5000, False)

    if done:
        xbmc.executebuiltin("Container.Refresh")


def show_mdblist_add_to_list_dialog(tmdb_id, imdb_id, content_type, title=''):
    import xbmcgui
    import xbmc
    import os
    from resources.lib.core.config import ADDON
    from resources.lib.core.config import provider_icon as _prov_icon
    MDB_ICON = _prov_icon('mdblist')

    if not title:
        try:
            from resources.lib.providers.trakt_sync import get_tmdb_item_details_from_db
            details = get_tmdb_item_details_from_db(tmdb_id, 'tv' if str(content_type).lower() not in ('movie', 'movies') else 'movie') or {}
            title = details.get('title') or details.get('name', 'Title')
        except:
            title = 'Title'
    
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        from resources.lib.providers import mdblist
        all_lists = mdblist.fetch_user_lists()
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel,true)')
    
    if not all_lists:
        xbmcgui.Dialog().notification(provider_title('mdblist'), "You have no personal lists on the site.", MDB_ICON, 3000, False)
        return

    # --- FILTRARE LISTE STATICE ---
    static_lists = []
    for lst in all_lists:
        if lst.get('dynamic') is True or lst.get('is_dynamic') is True or lst.get('type') == 'dynamic':
            continue
        static_lists.append(lst)

    if not static_lists:
        xbmcgui.Dialog().notification(provider_title('mdblist'), "You have no STATIC lists to add to.", MDB_ICON, 3000, False)
        return

    display_items = []
    for lst in static_lists:
        name = lst.get('name', 'Unknown')
        count = lst.get('items', 0)
        display_items.append(f"[B][COLOR lightskyblue]{name}[/COLOR][/B] ({count} iteme)")

    dialog = xbmcgui.Dialog()
    ret = dialog.select("Add to " + provider_title('mdblist') + " List", display_items)

    if ret >= 0:
        selected_list = static_lists[ret]
        list_id = selected_list.get('id')
        if mdblist.list_add(list_id, imdb_id=imdb_id, tmdb_id=tmdb_id, mediatype=content_type):
            xbmcgui.Dialog().notification(provider_title('mdblist'), f"[B][COLOR yellow]{title}[/COLOR][/B] added to [B][COLOR FF6AFB92]{selected_list.get('name')}[/COLOR][/B]", MDB_ICON, 3000, False)
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")


def show_mdblist_remove_from_list_dialog(tmdb_id, imdb_id, content_type, title=''):
    import xbmcgui
    import xbmc
    import os
    from resources.lib.core.config import ADDON
    from resources.lib.core.config import provider_icon as _prov_icon
    MDB_ICON = _prov_icon('mdblist')

    if not title:
        try:
            from resources.lib.providers.trakt_sync import get_tmdb_item_details_from_db
            details = get_tmdb_item_details_from_db(tmdb_id, 'tv' if str(content_type).lower() not in ('movie', 'movies') else 'movie') or {}
            title = details.get('title') or details.get('name', 'Title')
        except:
            title = 'Title'
    
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        from resources.lib.providers import mdblist
        user_lists = mdblist.fetch_user_lists()

        if not user_lists:
            xbmcgui.Dialog().notification(provider_title('mdblist'), "You have no personal lists on the site.", MDB_ICON, 3000, False)
            return

        # --- FILTRARE LISTE STATICE ---
        static_lists = []
        for lst in user_lists:
            if lst.get('dynamic') is True or lst.get('is_dynamic') is True or lst.get('type') == 'dynamic':
                continue
            static_lists.append(lst)

        lists_with_item = []

        def check_worker(lst):
            list_id = lst.get('id')
            items, _ = mdblist.fetch_list_items(list_id, page=1, limit=1000)
            found = False
            if items:
                for item in items:
                    item_tmdb = str(item.get('tmdbid') or item.get('tmdb_id') or item.get('show_tmdbid') or item.get('id', ''))
                    if item_tmdb == str(tmdb_id):
                        found = True
                        break
            return lst if found else None

        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(check_worker, lst) for lst in static_lists]
            for future in as_completed(futures):
                result = future.result()
                if result:
                    lists_with_item.append(result)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel,true)')
    
    if not lists_with_item:
        xbmcgui.Dialog().notification(provider_title('mdblist'), "Title is NOT in any personal STATIC list.", MDB_ICON, 3000, False)
        return

    display_items = []
    for lst in lists_with_item:
        name = lst.get('name', 'Unknown')
        display_items.append(f"[B][COLOR lightskyblue]{name}[/COLOR][/B]")

    dialog = xbmcgui.Dialog()
    ret = dialog.select("Remove from " + provider_title('mdblist') + " List", display_items)

    if ret >= 0:
        selected_list = lists_with_item[ret]
        list_id = selected_list.get('id')
        if mdblist.list_remove(list_id, imdb_id=imdb_id, tmdb_id=tmdb_id, mediatype=content_type):
            xbmcgui.Dialog().notification(provider_title('mdblist'), f"[B][COLOR yellow]{title}[/COLOR][/B] removed from [B][COLOR FF6AFB92]{selected_list.get('name')}[/COLOR][/B]", MDB_ICON, 3000, False)
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh")


def show_tmdb_add_to_list_dialog(tmdb_id, content_type):
    lists = trakt_sync.get_tmdb_custom_lists_from_db() 
    if not lists:
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "You have no lists", TMDB_ICON, 3000, False)
        return

    display_items = []
    for lst in lists:
        styled_name = f"[B][COLOR FF00CED1]{lst.get('name', 'Unknown')}[/COLOR][/B]"
        li = xbmcgui.ListItem(styled_name)
        li.setLabel2(f"[B][COLOR yellow]{lst.get('item_count', 0)}[/COLOR][/B] items")
        poster = get_list_image_url(lst.get('poster', ''), 'poster') or TMDB_ICON
        li.setArt({'thumb': poster, 'icon': poster, 'poster': poster})
        display_items.append(li)

    ret = xbmcgui.Dialog().select(provider_title('tmdb', name='TMDB') + ": Add to List", display_items, useDetails=True)
    if ret >= 0:
        add_to_tmdb_list(lists[ret]['list_id'], tmdb_id, content_type)


def show_tmdb_remove_from_list_dialog(tmdb_id, content_type):
    lists = trakt_sync.get_tmdb_custom_lists_from_db() 
    if not lists:
        return

    lists_with_item = []
    for lst in lists:
        list_id = lst.get('list_id')
        if trakt_sync.is_in_tmdb_custom_list(list_id, tmdb_id):
            lists_with_item.append(lst)

    if not lists_with_item:
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "Not in any list", TMDB_ICON, 3000, False)
        return

    display_items = []
    for lst in lists_with_item:
        raw_name = lst.get('name', 'Unknown')
        styled_name = f"[B][COLOR FF00CED1]{raw_name}[/COLOR][/B]"
        li = xbmcgui.ListItem(styled_name)
        li.setLabel2(f"[B][COLOR yellow]{lst.get('item_count', 0)}[/COLOR][/B] items")
        
        # ✅ FIX: Construire corecta URL imagini
        poster_path = lst.get('poster', '')
        backdrop_path = lst.get('backdrop', '')
        
        poster = get_list_image_url(lst.get('poster', ''), 'poster') or TMDB_ICON
        li.setArt({'thumb': poster, 'icon': poster, 'poster': poster})
        
        display_items.append(li)

    dialog = xbmcgui.Dialog()
    ret = dialog.select("Remove from List", display_items, useDetails=True)

    if ret >= 0:
        selected_list = lists_with_item[ret]
        remove_from_tmdb_list(selected_list['list_id'], tmdb_id, content_type)


def add_favorite(params):
    favs = read_json(FAVORITES_FILE)
    if not favs:
        favs = {'movie': [], 'tv': []}

    c_type = params.get('type')
    tmdb_id = params.get('tmdb_id')
    title = params.get('title', '')

    if c_type not in favs:
        favs[c_type] = []

    for f in favs[c_type]:
        if str(f.get('tmdb_id')) == str(tmdb_id):
            if not title:
                title = f.get('title', '')
            xbmcgui.Dialog().notification("[B][COLOR FFFF69B4]Favorites[/COLOR][/B]", f"[B][COLOR yellow]{title}[/COLOR][/B] — already in favorites", TMDbmovies_ICON, 2000, False)
            return

    new_item = {
        'tmdb_id': tmdb_id,
        'title': title,
        'added': time.strftime('%d-%m-%Y %H:%M:%S')
    }

    favs[c_type].insert(0, new_item)
    write_json(FAVORITES_FILE, favs)
    
    # Curatam RAM-ul pentru ca lista sa se updateze imediat cand intram in ea
    from resources.lib.core.cache import clear_all_fast_cache
    clear_all_fast_cache()
    
    xbmcgui.Dialog().notification("[B][COLOR FFFF69B4]Favorites[/COLOR][/B]", f"Added: [B][COLOR yellow]{title}[/COLOR][/B]", TMDbmovies_ICON, 2000, False)


def remove_favorite(params):
    favs = read_json(FAVORITES_FILE)
    if not favs:
        return

    c_type = params.get('type')
    tmdb_id = params.get('tmdb_id')

    if c_type not in favs:
        return

    initial_len = len(favs[c_type])
    removed_title = ''
    for f in favs[c_type]:
        if str(f.get('tmdb_id')) == str(tmdb_id):
            removed_title = f.get('title', '')
            break
    favs[c_type] = [f for f in favs[c_type] if str(f.get('tmdb_id')) != str(tmdb_id)]

    if len(favs[c_type]) < initial_len:
        write_json(FAVORITES_FILE, favs)
        
        # Curatam RAM-ul
        from resources.lib.core.cache import clear_all_fast_cache
        clear_all_fast_cache()
        
        xbmcgui.Dialog().notification("[B][COLOR FFFF69B4]Favorites[/COLOR][/B]", f"Removed: [B][COLOR yellow]{removed_title}[/COLOR][/B]", TMDbmovies_ICON, 3000, False)
        xbmc.executebuiltin("Container.Refresh")


def list_favorites(content_type):
    favs = read_json(FAVORITES_FILE)
    
    if not favs or not isinstance(favs, dict):
        favs = {'movie': [], 'tv': []}
    
    items = favs.get(content_type, [])
    local_items = [f for f in items if f.get('added')]

    if not local_items:
        xbmcgui.Dialog().notification("[B][COLOR FFFF69B4]Favorites[/COLOR][/B]", "The list is empty", TMDbmovies_ICON, 3000, False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # --- 1. FAST CACHE CHECK (RAM) ---
    # Includem si numarul de elemente in cheie pentru a invalida cache-ul cand se adauga/sterge ceva
    cache_key = f"local_favs_{content_type}_{len(local_items)}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='movies' if content_type == 'movie' else 'tvshows')
        return
    # ---------------------------------

    # 2. PREFETCHING PARALEL PENTRU VITEZA MAXIMA
    # Construim o lista fake compatibila cu prefetcher-ul
    fake_items_for_prefetch = [{'id': fav.get('tmdb_id'), 'media_type': content_type} for fav in local_items if fav.get('tmdb_id')]
    prefetch_metadata_parallel(fake_items_for_prefetch, content_type)

    # 3. PROCESARE SI BATCH ADD
    items_to_add = []
    cache_list = []
    
    for fav in local_items:
        tmdb_id = fav.get('tmdb_id')
        if not tmdb_id:
            continue

        endpoint = 'movie' if content_type == 'movie' else 'tv'
        
        # Citim direct din DB (Acum e instant datorita prefetcherului care a umplut DB-ul)
        data = trakt_sync.get_tmdb_item_details_from_db(tmdb_id, endpoint)
        
        # Fallback de siguranta
        if not data:
            url = f"{BASE_URL}/{endpoint}/{tmdb_id}?api_key={API_KEY}&language={LANG}"
            data = get_json(url)
            if data:
                conn = trakt_sync.get_connection()
                trakt_sync.set_tmdb_item_details_to_db(conn.cursor(), tmdb_id, endpoint, data)
                conn.commit()
                conn.close()

        if data:
            if content_type == 'movie':
                processed = _process_movie_item(data, is_in_favorites_view=True, return_data=True)
            else:
                processed = _process_tv_item(data, is_in_favorites_view=True, return_data=True)
                
            if processed:
                items_to_add.append((processed['url'], processed['li'], processed['is_folder']))
                cache_list.append(processed)

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))

    xbmcplugin.setContent(HANDLE, 'movies' if content_type == 'movie' else 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('movies' if content_type == 'movie' else 'tvshows')

    
    # 4. SALVAM IN RAM PENTRU URMATOAREA DATA
    set_fast_cache(cache_key, [{
        'label': i['li'].getLabel() if 'li' in i else i['label'], 
        'url': i['url'], 
        'is_folder': i['is_folder'], 
        'art': i['art'], 
        'info': i['info'], 
        'cm': i['cm_items'], 
        'resume_time': i.get('resume_time', 0), 
        'total_time': i.get('total_time', 0)
    } for i in cache_list])

def show_details(tmdb_id, content_type):
    from resources.lib.core.cache import _ensure_ram_cache_ver
    _ensure_ram_cache_ver()
    
    xbmcplugin.setContent(HANDLE, 'seasons')

    # Folosim Creierul Central care stie de limba RO/EN si se vindeca singur!
    data = get_tmdb_item_details(tmdb_id, 'tv')

    if not data:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    poster = f"{IMG_BASE}{data.get('poster_path', '')}" if data.get('poster_path') else ''
    backdrop = f"{BACKDROP_BASE}{data.get('backdrop_path', '')}" if data.get('backdrop_path') else ''
    tv_title = data.get('name', '')
    
    main_show_plot = data.get('overview', '')
    
    studio = ''
    if data.get('networks'):
        studio = data['networks'][0].get('name', '')
        
    show_mpaa = data.get('mpaa', '')
    raw_logo = data.get('clearlogo', '')
    show_logo = f"{IMG_BASE}{raw_logo}" if raw_logo and not raw_logo.startswith('http') else raw_logo
    show_rating = float(data.get('vote_average', 0.0))
    show_votes = int(data.get('vote_count', 0))

    from resources.lib.providers import watched_provider
    import datetime
    today = datetime.date.today()

    show_specials = ADDON.getSetting('show_specials') == 'true'
    if ADDON.getSetting('flatten_single_season') == 'true':
        _flat = [s for s in data.get('seasons', []) if (s.get('season_number', 0) or 0) != 0 or show_specials]
        _flat = [s for s in _flat if int(s.get('episode_count') or 0) > 0]
        if len(_flat) == 1:
            list_episodes(tmdb_id, str(int(_flat[0].get('season_number', 0) or 0)), tv_title)
            return
    for s in data.get('seasons', []):
        s_num = s['season_number']
        if s_num == 0 and not show_specials:
            continue

        name = "Specials" if s_num == 0 else f"Season {s_num}"
        ep_count = s.get('episode_count', 0)
        
        # s_poster primeste automat posterul RO din creierul central!
        s_poster = f"{IMG_BASE}{s.get('poster_path', '')}" if s.get('poster_path') else poster
        
        premiered = s.get('air_date', '')

        display_name = name
        if premiered:
            try:
                parts = str(premiered).split('-')
                if datetime.date(int(parts[0]), int(parts[1]), int(parts[2])) > today:
                    display_name = f"[B][COLOR FFE238EC]{name}[/COLOR] ({_fmt_dmy(premiered)}[/B])"
            except: pass

        # Plot-ul sezonului vine deja tradus daca setarea e pe RO
        season_plot = s.get('overview', '')
        if not season_plot:
            season_plot = main_show_plot

        watched_count = watched_provider.get_watched_counts(tmdb_id, 'season', s_num)
        watched_info = {'watched': watched_count, 'total': ep_count}
        
        s_rating = float(s.get('vote_average') or show_rating)

        info = {
            'mediatype': 'season',
            'title': name,
            'plot': season_plot,
            'tvshowtitle': tv_title,
            'season': s_num,
            'premiered': premiered,
            'studio': studio,
            'mpaa': show_mpaa,
            'rating': s_rating,
            'votes': show_votes
        }

        # --- NOU: Adaugam Meniul Contextual (Mark Watched/Unwatched) pentru Sezoane ---
        cm =[]
        is_fully_watched = (watched_count >= ep_count) if ep_count > 0 else False
        info['playcount'] = 1 if is_fully_watched else 0
        # Label galben bold + contor pentru sezoane incepute
        if watched_count > 0 and not is_fully_watched:
            if '[/' not in display_name:
                display_name = f"[B][COLOR FFEFD702]{display_name}[/COLOR] [COLOR FF6AFB92]({watched_count}/{ep_count})[/COLOR][/B]"
        elif is_fully_watched and '[COLOR' not in display_name:
            display_name = f'[B][COLOR FF6AFB92]{display_name}[/COLOR][/B]'
        
        watched_params = urlencode({'mode': 'mark_watched', 'tmdb_id': tmdb_id, 'type': 'season', 'season': s_num})
        unwatched_params = urlencode({'mode': 'mark_unwatched', 'tmdb_id': tmdb_id, 'type': 'season', 'season': s_num})

        from resources.lib.providers.watched_provider import get_label as _prov_label, get_color as _prov_color, mark_menu_label as _mml
        _prov_lbl = _prov_label()
        _prov_clr = _prov_color()
        _mw_multi = _mml(is_fully_watched)
        if is_fully_watched:
            cm.append((_mw_multi or f'[B][COLOR FFE41B17]Mark Unwatched [COLOR {_prov_clr}]({_prov_lbl})[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{unwatched_params})"))
        else:
            cm.append((_mw_multi or f'[B][COLOR FF6AFB92]Mark Watched [COLOR {_prov_clr}]({_prov_lbl})[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{watched_params})"))
            
        if ADDON.getSetting('show_cm_trakt') != 'false':
            trakt_params = urlencode({'mode': 'trakt_context_menu', 'tmdb_id': tmdb_id, 'type': 'season', 'title': name, 'season': s_num})
            cm.append(('[B][COLOR pink]My Trakt[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{trakt_params})"))
        if ADDON.getSetting('show_cm_tmdb') != 'false':
            tmdb_params = urlencode({'mode': 'tmdb_context_menu', 'tmdb_id': tmdb_id, 'type': 'season', 'title': name, 'season': s_num})
            cm.append(('[B][COLOR FF00CED1]My TMDB[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{tmdb_params})"))
        if ADDON.getSetting('show_cm_mdblist') != 'false':
            mdb_params = urlencode({'mode': 'mdblist_context_menu', 'tmdb_id': tmdb_id, 'type': 'season', 'title': name, 'season': s_num})
            cm.append(('[B][COLOR lightskyblue]My MDBList[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{mdb_params})"))
        if ADDON.getSetting('show_cm_simkl') != 'false':
            simkl_params = urlencode({'mode': 'simkl_context_menu', 'tmdb_id': tmdb_id, 'type': 'season', 'title': name, 'season': s_num})
            cm.append(('[B][COLOR mediumpurple]My Simkl[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{simkl_params})"))
        if ADDON.getSetting('show_cm_punchplay') != 'false':
            pp_params = urlencode({'mode': 'punchplay_context_menu', 'tmdb_id': tmdb_id, 'type': 'season', 'title': name, 'season': s_num})
            cm.append(('[B][COLOR FFFF6600]My PunchPlay[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{pp_params})"))
        # --- ALL PROVIDERS (batch — toggle in Settings) ---
        if ADDON.getSetting('all_providers_menu') == 'true':
            allp_params = urlencode({'mode': 'all_providers_context_menu', 'tmdb_id': tmdb_id, 'type': 'season', 'title': name, 'season': s_num})
            cm.append((f'[B]{_allprov_colored("All Providers", (3, 4, 3, 3), ("trakt", "tmdb", "mdblist", "simkl"))}[/B]', f"RunPlugin({PLUGIN_URL}?{allp_params})"))
        # -----------------------------------------------------------------------------

        # Trebuie sa trimitem si uids={'tmdb': tmdb_id} pentru ca AF3 sa lege Logo-ul de serial!
        add_directory(
            display_name,
            {'mode': 'episodes', 'tmdb_id': tmdb_id, 'season': str(s_num), 'tv_show_title': tv_title},
            thumb=s_poster, fanart=backdrop, clearlogo=show_logo, info=info, 
            uids={'tmdb': str(tmdb_id)}, watched_info=watched_info, cm=cm, folder=True
        )

    xbmcplugin.endOfDirectory(HANDLE)
    _set_views_apply('seasons')


    # Pre-fetch first 2 season details in background for instant episode loading
    import threading
    first_seasons = [s['season_number'] for s in data.get('seasons', []) if s['season_number'] in (1, 2)]
    for sn in first_seasons:
        t = threading.Thread(target=get_smart_season_details, args=(tmdb_id, sn), daemon=True)
        t.start()


_EPGROUP_TTL_HOURS = 168

def get_episode_numbering_map(tmdb_id):
    try:
        tid = str(tmdb_id or '').strip()
        if not tid:
            return {}
        from resources.lib.core.cache import MainCache
        _ck = f'epgroups_map_{tid}'
        try:
            _cached = MainCache().get(_ck)
            if _cached is not None:
                return {tuple(map(int, k.split(':'))): tuple(v) for k, v in _cached.items()}
        except: pass
        mapping = {}
        try:
            from resources.lib.core.utils import get_json
            data = get_json(f"{BASE_URL}/tv/{tid}/episode_groups?api_key={API_KEY}") or {}
            for grp in data.get('results', []) or []:
                gid = grp.get('id')
                if not gid:
                    continue
                det = get_json(f"{BASE_URL}/tv/episode_group/{gid}?api_key={API_KEY}") or {}
                for g in det.get('groups', []) or []:
                    try: gs = int(g.get('order'))
                    except: continue
                    for ep in g.get('episodes', []) or []:
                        try:
                            es = int(ep.get('season_number')); ee = int(ep.get('episode_number'))
                            eo = int(ep.get('order')) + 1
                        except: continue
                        if (gs, eo) != (es, ee):
                            mapping[(es, ee)] = (gs, eo)
        except: pass
        try:
            MainCache().set(_ck, {f"{k[0]}:{k[1]}": list(v) for k, v in mapping.items()}, expiration=_EPGROUP_TTL_HOURS)
        except: pass
        return mapping
    except:
        return {}

# Sezoane care NU exista pe TMDb (ex. sezon anuntat, dar fara episoade/metadata).
# TMDb raspunde 404, iar fara cache negativ retinem la fiecare constructie de lista
# - 15 warning-uri identice intr-o singura sesiune, pentru acelasi serial.
_SEASON_404 = {}
_SEASON_404_TTL = 3600


def _season_404_seen(tmdb_id, season_num):
    try:
        import time as _t
        k = (str(tmdb_id), int(season_num))
        ts = _SEASON_404.get(k)
        if ts and (_t.time() - ts) < _SEASON_404_TTL:
            return True
    except Exception:
        pass
    return False


def _season_404_mark(tmdb_id, season_num):
    try:
        import time as _t
        _SEASON_404[(str(tmdb_id), int(season_num))] = _t.time()
    except Exception:
        pass


def get_smart_season_details(tmdb_id, season_num, db_only=False):
    from resources.lib.providers import trakt_sync
    from resources.lib.core.cache import ram_cache_get_season, ram_cache_set_season
    from resources.lib.core.config import ADDON, SESSION, get_headers, BASE_URL, API_KEY, get_plot_language_code, get_plot_img_lang, LANG_TO_TMDB
    current_lang = get_plot_language_code()

    # Memo per proces (cheia include versiunea cache-ului RAM, deci invalidarea
    # e respectata): al doilea apel din aceeasi randare nu mai re-parseaza JSON-ul.
    try:
        _mkey = (str(tmdb_id), int(season_num), current_lang,
                 xbmcgui.Window(10000).getProperty('tmdbmovies_ram_cache_version'))
    except:
        _mkey = None
    _memo = _season_memo_get(_mkey)
    if _memo is not None:
        return _memo

    # Check RAM cache first (instant) — validam limba: cache-ul EN (prefetch) nu poate
    # umple lista cu nume englezesti cand plot_language e RO
    ram_data = ram_cache_get_season(tmdb_id, season_num)
    if ram_data:
        if ram_data.get('_cached_lang') == current_lang:
            _season_memo_set(_mkey, ram_data)
            return ram_data
        ram_data = None

    data = trakt_sync.get_tmdb_season_details_from_db(tmdb_id, season_num)
    
    if data:
        cached_lang = data.get('_cached_lang', 'en')
        if cached_lang == current_lang:
            ram_cache_set_season(tmdb_id, season_num, data)
            _season_memo_set(_mkey, data)
            return data
            
    if _season_404_seen(tmdb_id, season_num):
        return None

    if db_only:
        # Idem: fara retea in bucla de randare. Sezonul lipsa din RAM/SQLite
        # lasa randul fara durata/rating/still pina la urmatoarea randare, dar
        # NU mai tine lista in asteptare (warm-up-ul il aduce in cache intre timp).
        return None

    url_en = f"{BASE_URL}/tv/{tmdb_id}/season/{season_num}?api_key={API_KEY}&language=en-US"
    
    for _attempt in range(3):
        try:
            res_en = SESSION.get(url_en, headers=get_headers(), timeout=5)
            if res_en.status_code == 429 and _attempt < 2:
                xbmc.sleep(1000 * (_attempt + 1))
                continue
            if res_en.status_code != 200:
                if res_en.status_code == 404:
                    # sezon inexistent pe TMDb -> cache negativ (nu mai repetam)
                    _season_404_mark(tmdb_id, season_num)
                log(f"[SEASON] tv/{tmdb_id}/season/{season_num}: HTTP {res_en.status_code}", xbmc.LOGWARNING)
                return None
            data = res_en.json()
            data['_cached_lang'] = 'en'
            
            if current_lang != 'en':
                tmdb_lang = LANG_TO_TMDB.get(current_lang, 'en-US')
                url_target = f"{BASE_URL}/tv/{tmdb_id}/season/{season_num}?api_key={API_KEY}&language={tmdb_lang}&append_to_response=images&include_image_language={get_plot_img_lang()}"
                res_target = SESSION.get(url_target, headers=get_headers(), timeout=5)
                
                if res_target.status_code == 200:
                    data_target = res_target.json()
                    if data_target.get('overview'): data['overview'] = data_target['overview']
                    
                    target_posters = data_target.get('images', {}).get('posters',[])
                    if target_posters: data['poster_path'] = target_posters[0].get('file_path')
                        
                    target_eps = {ep['episode_number']: ep for ep in data_target.get('episodes',[])}
                    for ep in data.get('episodes',[]):
                        ep_num = ep['episode_number']
                        if ep_num in target_eps:
                            target_ep = target_eps[ep_num]
                            if target_ep.get('overview', '').strip(): ep['overview'] = target_ep['overview']
                            target_name = target_ep.get('name', '').strip()
                            if target_name and not re.match(r'^[A-Za-z\u00c0-\u024f]+\s+\d+$', target_name):
                                ep['name'] = target_name
                            if target_ep.get('still_path'): ep['still_path'] = target_ep['still_path']
                    data['_cached_lang'] = current_lang

            conn = trakt_sync.get_connection()
            try:
                trakt_sync.set_tmdb_season_details_to_db(conn.cursor(), tmdb_id, season_num, data)
                conn.commit()
            finally:
                conn.close()
            ram_cache_set_season(tmdb_id, season_num, data)
            return data
        except Exception as e:
            log(f"[SEASON] tv/{tmdb_id}/season/{season_num} fetch error: {e}", xbmc.LOGWARNING)
            xbmc.sleep(500 * (_attempt + 1))
    return None

def list_episodes(tmdb_id, season_num, tv_show_title):
    from resources.lib.core.cache import _ensure_ram_cache_ver
    _ensure_ram_cache_ver()
    from resources.lib.providers import trakt_sync
    from resources.lib.api import trakt_api
    from resources.lib.providers import watched_provider
    xbmcplugin.setContent(HANDLE, 'episodes')

    data = get_smart_season_details(tmdb_id, season_num)

    if not data:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    poster = f"{IMG_BASE}{data.get('poster_path', '')}" if data.get('poster_path') else ''
    
    # --- MODIFICARE: Obtinem IMDb ID al SERIALULUI (Parent) ---
    # Incercam sa luam detaliile serialului din DB sau API pentru a gasi IMDb ID
    show_imdb_id = ''
    show_details = trakt_sync.get_tmdb_item_details_from_db(tmdb_id, 'tv')
    if show_details:
        show_imdb_id = show_details.get('external_ids', {}).get('imdb_id', '')
    
    show_mpaa = show_details.get('mpaa', '') if show_details else ''
    show_logo = show_details.get('clearlogo', '') if show_details else ''
    
    if not show_imdb_id:
         # Fallback API rapid doar pentru external_ids daca nu e in DB
         try:
             ext_url = f"{BASE_URL}/tv/{tmdb_id}/external_ids?api_key={API_KEY}"
             ext_data = requests.get(ext_url, timeout=3).json()
             show_imdb_id = ext_data.get('imdb_id', '')
         except: pass
    # -----------------------------------------------------------

    from resources.lib.api import trakt_api
    import datetime
    today = datetime.date.today()
    try:
        hide_unaired = ADDON.getSetting('hide_unaired_episodes') == 'true'
    except:
        hide_unaired = False

    show_status = show_details.get('status', '') if show_details else ''
    total_seasons = show_details.get('number_of_seasons', 0) if show_details else 0
    total_eps_in_season = len(data.get('episodes',[])) if data else 0

    # Batch fetch all progress for this season (1 query instead of per-episode)
    progress_map = trakt_sync.get_local_playback_progress_batch(tmdb_id, 'tv', season_num)
    try:
        # Numai episoadele care pot AFISA o ora (azi sau viitoare, cu o zi de
        # marja pentru un possible air_date gresit din TMDb). Cerutarea pentru
        # episoadele deja difuzate era retea degeaba si incetinea sezonul.
        def _ask_air(ep):
            ad = ep.get('air_date') or ''
            try:
                _p = str(ad).split('T')[0].split('-')
                return (datetime.date(int(_p[0]), int(_p[1]), int(_p[2])) - today).days >= -2
            except:
                return False
        prefetch_air_times([{'tmdb_id': str(tmdb_id), 'season': int(season_num),
                             'episode': int(ep.get('episode_number') or 0),
                             'air_date': ep.get('air_date') or ''}
                            for ep in data.get('episodes', []) if _ask_air(ep)])
    except:
        pass

    for ep in data.get('episodes', []):
        ep_num = ep['episode_number']
        original_ep_name = ep.get('name', '') or f'Episode {int(ep_num)}'
        
        # --- LOGICA NATIVA PREMIERE / FINALE PENTRU SKIN (Fara text vizibil) ---
        api_ep_type = ep.get('episode_type', '')
        ep_type = api_ep_type
        
        if int(ep_num) == 1:
            ep_type = 'series_premiere' if int(season_num) == 1 else 'season_premiere'
        elif total_eps_in_season > 0 and int(ep_num) == total_eps_in_season:
            if show_status in ['Ended', 'Canceled'] and int(season_num) == total_seasons:
                ep_type = 'series_finale'
            else:
                ep_type = 'season_finale'
        elif api_ep_type == 'mid_season':
            ep_type = 'mid_season_finale'
        # -----------------------------------------------------------------------
        
        name = f"{season_num}x{int(ep_num):02d} {original_ep_name}"
        
        # --- LOGICA CULOARE ROSIE EPISOD (INJECTATA) ---
        display_label = name
        ep_air_date = ep.get('air_date', '')
        if hide_unaired:
            try:
                _parts = str(ep_air_date).split('-')
                _ad = datetime.date(int(_parts[0]), int(_parts[1]), int(_parts[2]))
                if _ad > today:
                    continue
            except:
                continue
        if ep_air_date:
            try:
                parts = str(ep_air_date).split('-')
                _ep_d = datetime.date(int(parts[0]), int(parts[1]), int(parts[2]))
                try:
                    _ep_stamp = get_episode_air_stamp(tmdb_id, season_num, ep_num)
                except:
                    _ep_stamp = None
                _ep_at = _ep_stamp[1] if _ep_stamp else ''
                _ep_d = air_effective_date(_ep_d, _ep_stamp, today)
                if _ep_d >= today:
                    # "doar azi si maine" primesc cuvantul + data; restul=data.
                    if _ep_d == today:
                        _ep_day = calendar_localized_label(0, '')
                    elif _ep_d == today + datetime.timedelta(days=1):
                        _ep_day = calendar_localized_label(1, _ep_d.isoformat())
                    else:
                        _ep_day = _fmt_dmy(ep_air_date)
                    _ep_when = f"{_ep_day} • {_ep_at}" if _ep_at else _ep_day
                    # Rozul FFE238EC = "nu s-a difuzat inca", deci doar pentru
                    # viitor. Azi: numele episodului rmane lavanda (FFCCCCFF,
                    # standardul din toate listele), doar eticheta devine
                    # galben bold.
                    if _ep_d > today:
                        display_label = f"[B][COLOR FFE238EC]{season_num}x{int(ep_num):02d} {original_ep_name}[/COLOR] ({_ep_when})[/B]"
                    else:
                        display_label = f"[B]{season_num}x{int(ep_num):02d} [COLOR FFCCCCFF]{original_ep_name}[/COLOR][/B] [B][COLOR yellow]({_ep_when})[/COLOR][/B]"
            except: pass
        # -----------------------------------------------
        
        progress_value = progress_map.get(ep_num, 0)
        resume_percent = 0
        resume_seconds = 0
        
        if progress_value >= 1000000:
            resume_seconds = int(progress_value - 1000000)
        elif progress_value > 0 and progress_value < 90:
            resume_percent = progress_value

# Imaginile si plotul sunt deja localizate automat de Dual-Fetch-ul de mai sus!
        # --- LOGICA NOUA IMAGINI EPISOD (Standard Modern) ---
        ep_still = ep.get('still_path', '')
        
        # Poster-ul vertical
        season_poster_path = data.get('poster_path', '') if data else ''
        if not season_poster_path and show_details: season_poster_path = show_details.get('poster_path', '')
        base_poster = f"{IMG_BASE}{season_poster_path}" if season_poster_path else ''
        
        # Fanart-ul serialului
        show_fanart_path = show_details.get('backdrop_path', '') if show_details else ''
        base_fanart = f"{BACKDROP_BASE}{show_fanart_path}" if show_fanart_path else base_poster
        
        try:
            art_pref = ADDON.getSetting('episodes_art')
        except:
            art_pref = '0'

        # 0 = Thumb + Fanart (Hibrid)
        # 1 = Thumb + Thumb
        # 2 = Poster + Fanart

        has_still = bool(ep_still)
        
        if art_pref == '3':
            # Poster + Thumb
            ep_icon = base_poster
            final_fanart = f"{IMG_BASE}{ep_still}" if has_still else base_fanart
        elif art_pref == '2':
            # Poster + Fanart
            ep_icon = base_poster
            final_fanart = base_fanart
        elif art_pref == '1':
            # Thumb + Thumb
            ep_icon = f"{IMG_BASE}{ep_still}" if has_still else base_poster
            final_fanart = f"{IMG_BASE}{ep_still}" if has_still else base_fanart
        else:
            # 0: Thumb + Fanart (Hibrid / Default)
            ep_icon = f"{IMG_BASE}{ep_still}" if has_still else base_poster
            final_fanart = base_fanart
        # ----------------------------------

        is_watched = watched_provider.is_episode_watched(tmdb_id, season_num, ep_num)
        
        try:
            duration = int(ep.get('runtime') or 0) * 60
        except:
            duration = 0
            
        # Daca episodul nu are durata pe TMDb, luam de la serial sau punem 45 min default
        if duration <= 0:
            try:
                runtimes = show_details.get('episode_run_time', []) if show_details else []
                duration = int(runtimes[0]) * 60 if runtimes and runtimes[0] else 2700
            except:
                duration = 2700

        if resume_seconds > 0 and duration > 0:
            resume_percent = (resume_seconds / duration) * 100

        ep_plot = ep.get('overview', '')

        info = {
            'mediatype': 'episode',
            'title': original_ep_name,
            'resume_percent': resume_percent,
            'plot': ep_plot,
            'rating': ep.get('vote_average', 0),
            'premiered': ep_air_date,
            'season': int(season_num),
            'episode': int(ep_num),
            'tvshowtitle': tv_show_title,
            'duration': duration,
            'votes': ep.get('vote_count', 0),
            'mpaa': show_mpaa
        }
        
        cm = _get_full_context_menu(
            tmdb_id, 'episode', tv_show_title,
            season=season_num, episode=ep_num, imdb_id=show_imdb_id,
            ep_name=original_ep_name, premiered=ep_air_date
        )

        clear_ep_params = urlencode({'mode': 'clear_sources_context', 'tmdb_id': tmdb_id, 'type': 'tv', 'season': str(season_num), 'episode': str(ep_num), 'title': f"{tv_show_title} S{season_num}E{ep_num}"})
        cm.append(('[B][COLOR orange]Clear sources cache[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?{clear_ep_params})"))
        
        url_params = select_ext_info_params('episode', tmdb_id, season_num, ep_num, tv_show_title, ep.get('name', '')) or {'mode': 'sources', 'tmdb_id': tmdb_id, 'type': 'tv', 'season': str(season_num), 'episode': str(ep_num), 'title': ep.get('name', ''), 'tv_show_title': tv_show_title}
        
        if resume_percent > 0 and resume_percent < 90 and duration > 0:
            resume_seconds = int((resume_percent / 100.0) * duration)
        
        url = plugin_url(url_params)
        
        li = xbmcgui.ListItem(display_label)
        
        try: skin_compat = ADDON.getSetting('skin_type')
        except: skin_compat = '0'
        
        # AF3 ascunde thumb-ul daca e identic cu posterul → la modurile Poster (2/3)
        # thumb/landscape devin still-ul episodului (thumb != poster)
        if art_pref in ('2', '3'):
            thumb_art = f"{IMG_BASE}{ep_still}" if has_still else ''
            landscape_art = thumb_art or ep_icon
        else:
            thumb_art = ep_icon
            landscape_art = ep_icon

        art = {
            'thumb': thumb_art,
            'icon': ep_icon, 
            'landscape': landscape_art,
            'tvshow.landscape': landscape_art,
            'tvshow.poster': base_poster, 
            'season.poster': base_poster, 
            'fanart': final_fanart
        }
        
        if skin_compat == '1':
            art['poster'] = base_poster  # AF3 (Afiseaza Poster Vertical 2:3)
        else:
            art['poster'] = ep_icon      # Estuary (Forteaza Thumbnail 16:9)
            
        if show_logo:
            art['clearlogo'] = f"{IMG_BASE}{show_logo}" if not show_logo.startswith('http') else show_logo
            art['tvshow.clearlogo'] = f"{IMG_BASE}{show_logo}" if not show_logo.startswith('http') else show_logo
        li.setArt(art)
        
        _safe_set_prop(li, 'tmdb_id', tmdb_id)
        if ep_type:
            _safe_set_prop(li, 'episode_type', ep_type)
        set_metadata(li, info, unique_ids={'tmdb': tmdb_id, 'imdb': show_imdb_id}, watched_info=is_watched)
        set_resume_point(li, resume_seconds, duration)
        
        if cm: li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)
    _set_views_apply('episodes')



def show_info_dialog(params):
    tmdb_id = params.get('tmdb_id')
    content_type = params.get('type')

    # Folosim direct creierul central care ne aduce din prima tot (inclusiv RO)
    data = get_tmdb_item_details(tmdb_id, content_type)
    if not data:
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "Load error", xbmcgui.NOTIFICATION_ERROR)
        return

    title = data.get('title') or data.get('name', 'Unknown')
    li = xbmcgui.ListItem(title)

    plot = data.get('overview', '')
    tagline_text = data.get('tagline', '').strip()
    genres_str = ", ".join([g['name'] for g in data.get('genres',[])])
    
    try:
        from resources.lib.core.config import ADDON
        show_motto = ADDON.getSetting('show_motto_genre') != 'false'
    except: show_motto = True
    
    plot_header = ""
    if show_motto:
        if tagline_text and genres_str:
            plot_header = f"[B][COLOR yellow]{tagline_text}[/COLOR][/B] | [B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n"
        elif tagline_text:
            plot_header = f"[B][COLOR yellow]{tagline_text}[/COLOR][/B]\n"
        elif genres_str:
            plot_header = f"[B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n"
        
    plot = plot_header + plot
        
    poster_path = data.get('poster_path', '')
    backdrop_path = data.get('backdrop_path', '')

    cast = []
    for p in data.get('credits', {}).get('cast', [])[:20]:
        if not p.get('name'):
            continue
        thumb = f"{IMG_BASE}{p['profile_path']}" if p.get('profile_path') else ''
        cast.append(xbmc.Actor(p['name'], p.get('character', ''), p.get('order', 0), thumb))

    # --- INCEPUT MODIFICARE: Logica Trailer (V5 - FINAL FIX & DEEP SCAN) ---
    trailer_url = ''
    found_video = None
    priority_types = ['Trailer', 'Teaser'] # Prioritate: Trailer, apoi Teaser

    # 1. Verificare initiala (in datele deja descarcate prin append_to_response)
    videos = data.get('videos', {}).get('results', [])
    for vid_type in priority_types:
        for v in videos:
            if v.get('site') == 'YouTube' and v.get('type') == vid_type:
                found_video = v
                break
        if found_video: break
    
    # 2. FALLBACK: Deep Search Iterativ (Daca nu am gasit nimic in lista standard)
    if not found_video:
        log(f"[TMDB-INFO] Trailer missing. Starting Deep Search for ID: {tmdb_id}")
        
        original_lang = data.get('original_language') or 'en'
        lang_code = original_lang.split('-')[0].split('_')[0]
        
        # Adaugam limba originala prima in lista
        try_locales = []
        if lang_code == 'hi':
            try_locales.extend(['hi-IN', 'ta-IN', 'te-IN', 'ml-IN', 'kn-IN', 'pa-IN'])
        elif lang_code == 'ta':
            try_locales.extend(['ta-IN', 'hi-IN', 'te-IN', 'ml-IN', 'kn-IN', 'en-US'])
        elif lang_code == 'te':
            try_locales.extend(['te-IN', 'hi-IN', 'ta-IN', 'ml-IN', 'kn-IN', 'en-US'])
        else:
            try_locales = ['en-US', 'ta-IN', 'te-IN', 'hi-IN', 'ml-IN', 'kn-IN', 'pa-IN', 'xx']
        
        safe_include = f"{lang_code},en,null,xx,hi,ta,te,ml,kn,bn,gu,mr,ur,or,as,es,fr,de,it,ro"
        
        for locale in try_locales:
            # Construim URL-ul manual pentru a forta regiunea
            vid_url = f"{BASE_URL}/{content_type}/{tmdb_id}/videos?api_key={API_KEY}&language={locale}&include_video_language={safe_include}"
            
            try:
                # log(f"[TMDB-INFO] Trying locale: {locale} ...") # Decomenteaza pentru debug
                r_vid = requests.get(vid_url, timeout=2) 
                if r_vid.status_code == 200:
                    data_vid = r_vid.json()
                    temp_res = data_vid.get('results', [])
                    
                    if temp_res:
                        # Cautam Trailer sau Teaser in rezultatele regionale
                        for vid_type in priority_types:
                            for v in temp_res:
                                if v.get('site') == 'YouTube' and v.get('type') == vid_type:
                                    found_video = v
                                    log(f"[TMDB-INFO] SUCCESS! Found {vid_type} in locale: {locale}")
                                    break
                            if found_video: break
                        
                        # Daca am gasit un video valid, ne oprim din cautat in alte regiuni
                        if found_video: break
                        
                        # Daca e lista dar nu e trailer, luam primul ca backup (dar continuam cautarea poate gasim trailer in alta parte)
                        # Daca vrei sa fii agresiv si sa te opresti la orice video, decomenteaza linia de mai jos:
                        # if temp_res: found_video = temp_res[0]; break 

            except Exception as e:
                log(f"[TMDB-INFO] Error checking {locale}: {e}", xbmc.LOGWARNING)

    # 3. Fallback final: Daca tot nu am gasit Trailer/Teaser, luam orice video disponibil din lista initiala
    if not found_video and videos:
        for v in videos:
            if v.get('site') == 'YouTube':
                found_video = v
                break

    # 4. Fallback Google YouTube API: daca TMDb nu are niciun trailer, cautam
    #    pe YouTube direct (inclusiv upload-uri neoficiale), ca la Extended Info.
    if not found_video and title:
        try:
            from resources.lib.context.context_trailer import search_youtube_api
            _yt_title = data.get('title') or data.get('name') or title
            _yt_year = (data.get('release_date') or data.get('first_air_date') or '')[:4] or None
            _yt_id = search_youtube_api(_yt_title, _yt_year)
            if _yt_id:
                log(f"[TMDB-INFO] Found trailer via Google YouTube API: {_yt_id}")
                found_video = {'key': _yt_id, 'site': 'YouTube', 'type': 'Trailer'}
        except Exception as e:
            log(f"[TMDB-INFO] Google YouTube API fallback error: {e}", xbmc.LOGWARNING)

    # Construire URL Final (folosind setarea trailer_player)
    if found_video or _imdb_trailer_mode():
        from resources.lib.core.config import get_trailer_url as _gtu
        _yr = (data.get('release_date') or data.get('first_air_date') or '')[:4]
        _tst = (data.get('production_companies') or []) or (data.get('networks') or [])
        _tst = _tst[0].get('name') if _tst and isinstance(_tst, list) and _tst[0].get('name') else ''
        # Plotul merge FARA antet (motto+gen ajung prin tagline + genre), ca
        # tmdbm.trailers sa nu afiseze motto-ul de doua ori in OSD. Nu trimitem
        # plot=None: tmdbm.trailers si-ar lua singur overview-ul in ENGLEZA si
        # am pierde traducerea RO obtinuta mai sus.
        _plot_clean = plot
        if show_motto and plot_header and plot.startswith(plot_header):
            _plot_clean = plot[len(plot_header):]
        # Tagline pentru OSD: FARA [B]! Randul TagLine din OSD pierde [/B]-ul
        # final (il afiseaza literal) cand stringul se termina cu [/COLOR][/B].
        # Format simplu, doar culori - genul e inclus in string ca sa apara
        # pe acelasi rand cu motto-ul (parametrul genre= alimenteaza doar
        # linia de sub titlul clipului, nu randul din OSD).
        _gnames = ", ".join([g['name'] for g in data.get('genres', []) if g.get('name')]) or None
        _tag_param = None
        if show_motto:
            if tagline_text and _gnames:
                _tag_param = f"[COLOR yellow]{tagline_text}[/COLOR]   |   [COLOR FF00CED1]{_gnames}[/COLOR]"
            elif tagline_text:
                _tag_param = f"[COLOR yellow]{tagline_text}[/COLOR]"
            elif _gnames:
                _tag_param = f"[COLOR FF00CED1]{_gnames}[/COLOR]"
        _video_key = found_video.get('key') if found_video else ''
        trailer_url = _gtu(_video_key, tmdb_id=tmdb_id,
                           dbtype=content_type, title=title, year=_yr,
                           plot=_plot_clean or None, studio=_tst or None,
                           tagline=_tag_param,
                           genre=_gnames,
                           imdb_id=(data.get('external_ids') or {}).get('imdb_id', ''))
        log(f"[TMDB-INFO] trailer builder v4 plot={len(_plot_clean or '')}c tagline_param={bool(_tag_param)} genre_param={bool(_gnames)}")
    # --- SFARSIT MODIFICARE ---


    try:
        tag = li.getVideoInfoTag()
        tag.setMediaType('movie' if content_type == 'movie' else 'tvshow')
        tag.setTitle(title)
        # Motto+genuri stau in antetul din plot, echilibrat: acelasi string
        # ajunge bold atit in subtitlul din TMDb Info, cit si in OSD-ul
        # trailerului (care copiaza info tag-ul acestui dialog).
        tag.setPlot(plot) # <--- AICI ERA BUG-UL (era data.get('overview'))

        if data.get('vote_average'):
            tag.setRating(float(data['vote_average']))
        if data.get('vote_count'):
            tag.setVotes(int(data['vote_count']))

        date_str = data.get('release_date') or data.get('first_air_date')
        if date_str:
            tag.setPremiered(date_str)
            try:
                tag.setYear(int(date_str[:4]))
            except:
                pass

        # --- 1. SETARE GENURI SI TAGLINE ---
        genres_str = ""
        colored_genres_list = []
        genres_list = []
        if data.get('genres'):
            genres_list = [g['name'] for g in data['genres']]
            colored_genres_list = [f"[B][COLOR cyan]{g}[/COLOR][/B]" for g in genres_list]
            genres_str = " • ".join(colored_genres_list)

        raw_tagline = data.get('tagline')
        tagline = raw_tagline.strip() if raw_tagline else ""

        # --- 2. TRUCURI PENTRU SKIN-UL KODI ---
        if content_type == 'movie':
            if colored_genres_list:
                tag.setGenres(colored_genres_list)
            # Fara TagLine la filme: Estuary il arata in subtitlu cu [I] (fara
            # bold), iar OSD-ul il inveleste in [B]...[/B]; un singur string cu
            # [B] nu poate fi curat in ambele. Antetul din plot le arata bold
            # pe amindoua.
        else:
            # PACALIM KODI LA SERIALE! 
            # Pentru ca ignora Tagline-ul, il unim cu Genul (pe care stim ca il afiseaza sub titlu)
            final_tv_string = ""
            if tagline and genres_str:
                final_tv_string = f"[B][COLOR yellow]{tagline}[/COLOR]   |   {genres_str}"
            elif tagline:
                final_tv_string = f"[B][COLOR yellow]{tagline}[/COLOR]"
            elif genres_str:
                final_tv_string = genres_str
                
            if final_tv_string:
                # Trimitem totul ca un singur "Gen"
                tag.setGenres([final_tv_string])

        try:
            _dtl = tag.getTagLine() if hasattr(tag, 'getTagLine') else ''
        except:
            _dtl = ''
        log(f"[TMDB-INFO] dialog tags v2 tagline_B={'[B' in str(_dtl)}")

        # --- FIX STATUS: Folosim "Studios" pentru a afisa Statusul in dreapta ---
        # Estuary afiseaza lista de Studiouri (Networks) sub Rating/An.
        studios_list = []
        
        # 1. Calculam Statusul si aplicam CULORI DINAMICE
        if content_type in ['tv', 'tvshow'] and 'status' in data:
            st = data['status']
            status_text = ""
            
            if st == 'Returning Series': 
                status_text = "[COLOR cyan]Status: [B]Continuing[/COLOR][/B]" 
            elif st == 'Ended': 
                status_text = "[COLOR orange]Status: [B]Ended[/COLOR][/B]"
            elif st == 'Canceled': 
                status_text = "[COLOR FFFF4444]Status: [B]Canceled[/COLOR][/B]"
            elif st == 'In Production': 
                status_text = "[B][COLOR yellow]Status: In Production[/COLOR][/B]"
            else:
                # Pentru orice alt status necunoscut
                status_text = f"[B][COLOR cyan]Status: {st}[/COLOR][/B]"
            
            # Adaugam statusul ca PRIMUL element in lista de studiouri
            if status_text:
                studios_list.append(status_text)

        # 2. Adaugam Studiourile reale
        if data.get('production_companies'):
            studios_list.extend([c.get('name') for c in data['production_companies']])
        elif data.get('networks'):
            studios_list.extend([n.get('name') for n in data['networks']])

        # 3. Setam lista combinata
        if studios_list:
            tag.setStudios(studios_list)
        
        # 4. Tara de origine
        country_names = []
        if content_type in ['movie', 'tv', 'tvshow']:
            pcs = data.get('production_countries', [])
            for c in pcs:
                if c.get('name') and c['name'] not in country_names:
                    country_names.append(c['name'])
            origins = data.get('origin_country', [])
            for o in origins:
                if o and o not in country_names:
                    country_names.append(o)
        if country_names:
            tag.setCountries(country_names[:3])
        # ------------------------------------------------------------------------
        
        if cast:
            tag.setCast(cast)

        dirs = [p['name'] for p in data.get('credits', {}).get('crew', []) if p.get('job') == 'Director']
        if dirs:
            tag.setDirectors(dirs)

        writers = [p['name'] for p in data.get('credits', {}).get('crew', []) if p.get('job') in ['Screenplay', 'Writer']]
        if writers:
            tag.setWriters(writers)

        if trailer_url:
            tag.setTrailer(trailer_url)

        try:
            if data.get('runtime'):
                tag.setDuration(int(data.get('runtime')) * 60)
        except:
            pass

        ext_ids = data.get('external_ids', {})
        unique_ids = {'tmdb': str(tmdb_id)}
        if ext_ids.get('imdb_id'):
            unique_ids['imdb'] = ext_ids['imdb_id']
        if ext_ids.get('tvdb_id'):
            unique_ids['tvdb'] = str(ext_ids['tvdb_id'])
        tag.setUniqueIDs(unique_ids)
        
        

    except Exception as e:
        log(f"[TMDB-INFO] Tag Error: {e}", xbmc.LOGERROR)

    art = {}
    if poster_path: # <--- Folosim variabila localizata, nu data.get('poster_path')
        art['poster'] = f"{IMG_BASE}{poster_path}"
        art['thumb'] = f"{IMG_BASE}{poster_path}"
        art['icon'] = f"{IMG_BASE}{poster_path}"
    if backdrop_path:
        art['fanart'] = f"{BACKDROP_BASE}{backdrop_path}"
    li.setArt(art)

    xbmcgui.Dialog().info(li)


def show_global_info(params):
    """
    Handler robust pentru meniul contextual global (Filme, Seriale, Sezoane, Episoade).
    """
    log(f"[GLOBAL-INFO] Params: {params}")

    tmdb_id = params.get('tmdb_id')
    imdb_id = params.get('imdb_id')
    tvdb_id = params.get('tvdb_id')
    
    # Tipuri posibile: movie, tv, season, episode
    content_type = params.get('type', 'movie')
    
    title = params.get('title', '')
    year = params.get('year', '')
    
    # IMPORTANT: Citim season si episode din params
    season = params.get('season')
    episode = params.get('episode')
    
    # Convertim la int daca exista
    if season:
        try:
            season = int(season)
        except:
            season = None
    if episode:
        try:
            episode = int(episode)
        except:
            episode = None

    log(f"[GLOBAL-INFO] Parsed: type={content_type}, tmdb_id={tmdb_id}, season={season}, episode={episode}")

    # Validare ID
    if tmdb_id and (not str(tmdb_id).isdigit() or str(tmdb_id) == '0'): 
        tmdb_id = None
    if imdb_id and not str(imdb_id).startswith('tt'): 
        imdb_id = None

    # 1. Gasirea ID-ului Principal (Film sau Serial)
    found_id = tmdb_id
    
    # Determinam media type pentru cautare
    if content_type in ['tv', 'season', 'episode']:
        found_media = 'tv'
    else:
        found_media = 'movie'

    # Daca nu avem TMDb ID, il cautam
    if not found_id:
        # A. Cautare prin External IDs
        if imdb_id:
            url = f"{BASE_URL}/find/{imdb_id}?api_key={API_KEY}&external_source=imdb_id"
            data = get_json(url)
            if data:
                if data.get('movie_results') and found_media == 'movie':
                    found_id = data['movie_results'][0]['id']
                elif data.get('tv_results'):
                    found_id = data['tv_results'][0]['id']
                    found_media = 'tv'
                elif data.get('tv_episode_results'):
                    found_id = data['tv_episode_results'][0]['show_id']
                    found_media = 'tv'
        
        # B. Cautare prin TVDb
        if not found_id and tvdb_id and str(tvdb_id).isdigit():
            url = f"{BASE_URL}/find/{tvdb_id}?api_key={API_KEY}&external_source=tvdb_id"
            data = get_json(url)
            if data:
                if data.get('tv_results'):
                    found_id = data['tv_results'][0]['id']
                    found_media = 'tv'
                elif data.get('tv_episode_results'):
                    found_id = data['tv_episode_results'][0]['show_id']
                    found_media = 'tv'

        # C. Cautare prin Titlu (Fallback)
        if not found_id and title:
            clean_title = title.split('(')[0].strip()
            url = f"{BASE_URL}/search/{found_media}?api_key={API_KEY}&query={quote(clean_title)}"
            
            if year and str(year).isdigit() and found_media == 'movie':
                url += f"&primary_release_year={year}"
                    
            data = get_json(url)
            if data.get('results'):
                found_id = data['results'][0]['id']
                log(f"[GLOBAL-INFO] Found parent ID by title: {found_id}")

    # 2. Afisare Info bazat pe tipul cerut
    if found_id:
        log(f"[GLOBAL-INFO] Showing info: type={content_type}, id={found_id}, season={season}, episode={episode}")
        
        # Logica de decizie bazata pe TYPE primit SAU prezenta season/episode
        if content_type == 'episode' or (season is not None and episode is not None and episode > 0):
            # Afisam info pentru EPISOD
            if season is not None and episode is not None:
                log(f"[GLOBAL-INFO] -> Episode info dialog")
                show_specific_info_dialog(str(found_id), 'episode', season=season, episode=episode)
            else:
                # Fallback la serial daca nu avem season/episode valid
                show_info_dialog({'tmdb_id': str(found_id), 'type': 'tv'})
                
        elif content_type == 'season' or (season is not None and season >= 0 and (episode is None or episode <= 0)):
            # Afisam info pentru SEZON
            if season is not None:
                log(f"[GLOBAL-INFO] -> Season info dialog")
                show_specific_info_dialog(str(found_id), 'season', season=season)
            else:
                # Fallback la serial
                show_info_dialog({'tmdb_id': str(found_id), 'type': 'tv'})
                
        else:
            # Info standard (Film sau Serial intreg)
            log(f"[GLOBAL-INFO] -> Standard info dialog for {found_media}")
            show_info_dialog({'tmdb_id': str(found_id), 'type': found_media})
    else:
        import xbmcgui
        xbmcgui.Dialog().notification("TMDb Info", "Could not identify title", xbmcgui.NOTIFICATION_WARNING, 3000)


def show_specific_info_dialog(tmdb_id, specific_type, season=1, episode=1):
    import xbmcgui
    
    show_data = None
    try:
        show_url = f"{BASE_URL}/tv/{tmdb_id}?api_key={API_KEY}&language={LANG}&include_video_language={VIDEO_LANGS}&append_to_response=videos"
        show_data = get_json(show_url)
    except:
        pass
    
    if specific_type == 'season':
        url_en = f"{BASE_URL}/tv/{tmdb_id}/season/{season}?api_key={API_KEY}&language=en-US&include_video_language={VIDEO_LANGS}&append_to_response=images,credits,videos"
    else:
        url_en = f"{BASE_URL}/tv/{tmdb_id}/season/{season}/episode/{episode}?api_key={API_KEY}&language=en-US&include_video_language={VIDEO_LANGS}&append_to_response=images,credits,videos"
        
    data = get_json(url_en)
    
    try:
        from resources.lib.core.config import ADDON, get_plot_language_code, get_plot_img_lang, LANG_TO_TMDB
        lang_code = get_plot_language_code()
        if lang_code != 'en' and data and data.get('success') != False:
            tmdb_lang = LANG_TO_TMDB.get(lang_code, 'en-US')
            url_target = url_en.replace('language=en-US', f'language={tmdb_lang}') + f"&include_image_language={get_plot_img_lang()}"
            data_target = get_json(url_target)
            
            if data_target:
                if data_target.get('overview'): 
                    data['overview'] = data_target['overview']
                
                if specific_type == 'episode' and data_target.get('name'):
                    target_name = data_target['name'].strip()
                    if not re.match(r'^[A-Za-z\u00c0-\u024f]+\s+\d+$', target_name):
                        data['name'] = target_name
                
                imgs = data_target.get('images', {})
                target_posters = imgs.get('posters', []) or imgs.get('stills', [])
                if target_posters:
                    data['poster_path'] = target_posters[0].get('file_path')
                    data['still_path'] = target_posters[0].get('file_path')
                elif data_target.get('poster_path'):
                    data['poster_path'] = data_target.get('poster_path')
                elif data_target.get('still_path'):
                    data['still_path'] = data_target.get('still_path')
                    
                if show_data and not data.get('overview'):
                    show_loc_url = f"{BASE_URL}/tv/{tmdb_id}?api_key={API_KEY}&language={tmdb_lang}"
                    show_loc = get_json(show_loc_url)
                    if show_loc and show_loc.get('overview'):
                        show_data['overview'] = show_loc['overview']
    except Exception as e:
        log(f"[SPECIFIC-INFO] Error localization: {e}")

    if not data or data.get('success') == False:
        log(f"[SPECIFIC-INFO] Season/Episode not found (S{season}E{episode}), falling back to TV show info")
        if show_data:
            show_info_dialog({'tmdb_id': str(tmdb_id), 'type': 'tv'})
            return
        else:
            xbmcgui.Dialog().notification("TMDb Info", "Season/Episode does not exist", xbmcgui.NOTIFICATION_WARNING)
            return

    # Metadata mapping
    title = data.get('name', 'Unknown')
    overview = data.get('overview', '')
    
    # Fallback Plot de la Serial
    if not overview and show_data:
        overview = show_data.get('overview', '')

    poster_path = data.get('poster_path') or data.get('still_path')
    
    # Construim ListItem. Estuary (VideoInfoSubLabelVar) afiseaza sub titlul
    # serialului: la SEZON -> ListItem.Label, la EPISOD -> "Sx: ListItem.Title".
    # Culori: verde "TMDb Info" din CM (FF6AFB92) pentru sezon si pentru
    # prefix-ul "1x01" al episodului; turcoaz (FF00CED1) pentru titlu.
    _acc = 'FF6AFB92'
    if specific_type == 'season':
        _disp = f"[B][COLOR {_acc}]{title}[/COLOR][/B]"
    elif specific_type == 'episode':
        _se_n = season if season is not None else (data.get('season_number') or 0)
        _ep_n = episode if episode is not None else (data.get('episode_number') or 0)
        _disp = f"[B][COLOR {_acc}]{_se_n}x{_ep_n:02d}[/COLOR][/B]: [B][COLOR FF00CED1]{title}[/COLOR][/B]"
    else:
        _disp = title
    li = xbmcgui.ListItem(_disp if specific_type == 'season' else title)
    tag = li.getVideoInfoTag()
    
    tag.setTitle(_disp if specific_type == 'episode' else title)
    tag.setPlot(overview)
    tag.setMediaType(specific_type) 
    
    if 'air_date' in data and data['air_date']:
        tag.setPremiered(data['air_date'])
        try: tag.setYear(int(data['air_date'][:4]))
        except: pass
        
    if 'vote_average' in data: tag.setRating(float(data['vote_average']))
    # La EPISOD NU setam Season/Episode pe tag: Estuary isi construieste
    # propriul prefix "1x01:" simplu (alb) din ele si ar aparea DUBLU langa
    # prefix-ul nostru colorat. Sezonul le pastreaza (afisarea lui foloseste
    # ListItem.Label, nu aceste numere).
    if specific_type != 'episode':
        if 'season_number' in data: tag.setSeason(int(data['season_number']))
        if 'episode_number' in data: tag.setEpisode(int(data['episode_number']))
    
    # Setam TVShowTitle
    if show_data:
        tag.setTvShowTitle(show_data.get('name', ''))
    
    # --- LOGICA TRAILER ---
    trailer_url = ''
    priority_types = ['Trailer', 'Teaser']
    _show_title = show_data.get('name') if show_data else title
    _dbtype = specific_type if specific_type in ('movie', 'tv', 'season', 'episode') else 'tv'

    # 1. Cautam trailer in datele sezonului/episodului. Transmitem contextul de
    #    sezon catre tmdbm.trailers, ca fallback-ul lui sa aleaga trailerul corect
    #    al sezonului (nu al serialului) cand lista de aici nu-l are.
    videos = data.get('videos', {}).get('results', [])
    _tst2 = ((show_data.get('production_companies') or []) if show_data else []) or ((show_data.get('networks') or []) if show_data else [])
    _tst2 = _tst2[0].get('name') if _tst2 and isinstance(_tst2, list) and _tst2[0].get('name') else ''
    _sht = ((show_data.get('tagline') or '').strip() if show_data else '')
    _sht = f"[COLOR yellow]{_sht}[/COLOR]" if _sht else None
    _shg = ", ".join([g['name'] for g in ((show_data.get('genres') or []) if show_data else []) if g.get('name')]) or None
    # Antet "motto | gen" inglobat in plot (acelasi tipar ca la filme/Extended Info).
    # NU transmitem tagline separat: tmdbm.trailers l-ar afisa pe un rand propriu in OSD.
    _plot_hdr = ''
    if _sht and _shg:
        _plot_hdr = f"[B]{_sht}[/B] | [B][COLOR FF00CED1]{_shg}[/COLOR][/B]\n"
    elif _sht:
        _plot_hdr = f"[B]{_sht}[/B]\n"
    elif _shg:
        _plot_hdr = f"[B][COLOR FF00CED1]{_shg}[/COLOR][/B]\n"
    _plot_full = _plot_hdr + (overview or '')
    if _imdb_trailer_mode():
        from resources.lib.core.config import get_trailer_url as _gtu
        trailer_url = _gtu('', tmdb_id=tmdb_id,
                          dbtype=_dbtype, title=_show_title, year='',
                          season=season if specific_type == 'season' else None,
                          plot=_plot_full or None, studio=_tst2 or None,
                          genre=_shg,
                          imdb_id=(show_data.get('external_ids') or {}).get('imdb_id', '')
                          if show_data else '')

    for vid_type in priority_types:
        for v in videos:
            if v.get('site') == 'YouTube' and v.get('type') == vid_type:
                from resources.lib.core.config import get_trailer_url as _gtu
                trailer_url = _gtu(v.get('key'), tmdb_id=tmdb_id,
                                  dbtype=_dbtype, title=_show_title, year='',
                                  season=season if specific_type == 'season' else None,
                                  plot=_plot_full or None, studio=_tst2 or None,
                                  genre=_shg)
                break
        if trailer_url:
            break
    
    # 2. FALLBACK: Daca nu am gasit, cautam la nivel de serial
    if not trailer_url and show_data:
        show_videos = show_data.get('videos', {}).get('results', [])
        for vid_type in priority_types:
            for v in show_videos:
                if v.get('site') == 'YouTube' and v.get('type') == vid_type:
                    from resources.lib.core.config import get_trailer_url as _gtu
                    trailer_url = _gtu(v.get('key'), tmdb_id=tmdb_id,
                                      dbtype=_dbtype, title=_show_title, year='',
                                      season=season if specific_type == 'season' else None,
                                      plot=_plot_full or None, studio=_tst2 or None,
                                      genre=_shg)
                    break
            if trailer_url:
                break
        log(f"[TMDB-INFO] trailer builder v2 season plot={bool(overview)} tagline_param=False genre_param=True")
    
    if trailer_url:
        tag.setTrailer(trailer_url)

    # Cast
    cast = []
    source_cast = data.get('guest_stars', []) + data.get('credits', {}).get('cast', [])
    for p in source_cast[:15]:
        if not p.get('name'):
            continue
        thumb = f"{IMG_BASE}{p['profile_path']}" if p.get('profile_path') else ''
        cast.append(xbmc.Actor(p['name'], p.get('character', ''), p.get('order', 0), thumb))
    if cast:
        tag.setCast(cast)

    # Imagini
    art = {}
    if poster_path:
        full_poster = f"{IMG_BASE}{poster_path}"
        art['poster'] = full_poster
        art['thumb'] = full_poster
        art['icon'] = full_poster
        
    if show_data:
        if show_data.get('backdrop_path'):
            art['fanart'] = f"{BACKDROP_BASE}{show_data['backdrop_path']}"
        if not art.get('poster') and show_data.get('poster_path'):
            art['poster'] = f"{IMG_BASE}{show_data['poster_path']}"

    li.setArt(art)
    xbmcgui.Dialog().info(li)


def perform_search(params):
    """Cere input si afiseaza rezultatele - REFRESH SAFE folosind cache!"""
    search_type = params.get('type', 'multi')
    query = params.get('query')
    page = int(params.get('page', '1')) # <--- ADAUGAT: Preluam pagina
    
    # 1. Daca avem query in URL (redirect) - afisam direct
    if query:
        from urllib.parse import unquote
        build_search_result(search_type, unquote(query), page) # <--- Trimitem pagina
        return
    
    # 2. Verificam cache-ul pentru Container.Refresh
    cache_key = f'tmdb_search_{search_type}'
    cached_query = xbmcgui.Window(10000).getProperty(cache_key)
    
    # Detectam daca suntem deja pe pagina de rezultate (refresh)
    container_path = xbmc.getInfoLabel('Container.FolderPath')
    is_refresh = cached_query and 'perform_search' in container_path
    
    if is_refresh:
        # E un refresh - folosim query-ul din cache
        build_search_result(search_type, cached_query, page) # <--- Trimitem pagina
        return
    
    # 3. Cautare noua - cerem input
    dialog = xbmcgui.Dialog()
    new_query = dialog.input("Search...", type=xbmcgui.INPUT_ALPHANUM)
    
    if new_query:
        add_search_to_history(new_query, search_type)
        # Salvam in cache pentru refresh-uri viitoare
        xbmcgui.Window(10000).setProperty(cache_key, new_query)
        # Afisam rezultatele direct
        build_search_result(search_type, new_query, 1) # <--- Aici e pagina 1 (cautare noua)
    else:
        # Cancel
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def perform_search_query(params):
    """Executa direct o cautare din istoric."""
    search_type = params.get('type', 'multi')
    query = params.get('query', '')
    page = int(params.get('page', '1')) # <--- ADAUGAT: Preluam pagina
    
    if query:
        from urllib.parse import unquote
        query = unquote(query)
        add_search_to_history(query, search_type)
        # Salvam in cache pentru refresh
        xbmcgui.Window(10000).setProperty(f'tmdb_search_{search_type}', query)
        build_search_result(search_type, query, page) # <--- Trimitem pagina
    else:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)

def get_tmdb_search_results(query, search_type, page, year=None):
    url = f"{BASE_URL}/search/{search_type}?api_key={API_KEY}&language={LANG}&query={quote(query)}&page={page}"
    if year:
        # Filtru server-side: fara el, titluri generice ('Captain') nu au
        # deloc filmul indian in primele 20 rezultate (doar Captain Marvel etc.)
        url += f"&year={year}"
    return requests.get(url, timeout=10)


# --- COD EXISTENT ---
def build_search_result(search_type, query, page=1): # Adaugat parametrul page
    # --- FAST CACHE CHECK (RAM) ---
    cache_key = f"search_{search_type}_{query}_{page}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='movies' if search_type == 'movie' else 'tvshows')
        return
    # ------------------------------
    data = cache_object(get_tmdb_search_results, f"search_{search_type}_{query}_{page}", [query, search_type, page], expiration=1)

    if not data:
        xbmcplugin.endOfDirectory(HANDLE); return

    results = data.get('results', [])
    prefetch_metadata_parallel(results, search_type) # Threading metadata
    
    items_to_add = []
    cache_list = []

    for item in results:
        processed = _process_movie_item(item, return_data=True) if search_type == 'movie' else _process_tv_item(item, return_data=True)
        if processed:
            items_to_add.append((processed['url'], processed['li'], processed['is_folder']))
            cache_list.append(processed)

    # Paginare pentru cautare
    total_pages = data.get('total_pages', 1)
    if page < total_pages:
        next_label = next_page_label(page + 1)
        next_params = {'mode': 'perform_search', 'type': search_type, 'query': query, 'page': str(page+1)}
        next_url = plugin_url(next_params)
        next_li = xbmcgui.ListItem(next_label)
        style_page_nav_item(next_li, page + 1)
        items_to_add.append((next_url, next_li, True))
        cache_list.append({'label': next_label, 'url': next_url, 'is_folder': True, 'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON}, 'info': {'mediatype': 'video', 'plot': next_page_plot(page + 1)}, 'cm_items': []})

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))

    xbmcplugin.setContent(HANDLE, 'movies' if search_type == 'movie' else 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('movies' if search_type == 'movie' else 'tvshows')

    
    # Save to RAM
    set_fast_cache(cache_key, [{'label': i['li'].getLabel() if 'li' in i else i['label'], 'url': i['url'], 'is_folder': i['is_folder'], 'art': i['art'], 'info': i['info'], 'cm': i['cm_items'], 'resume_time': i.get('resume_time', 0), 'total_time': i.get('total_time', 0)} for i in cache_list])


# --- COD EXISTENT ---
def list_recommendations(params):
    tmdb_id = params.get('tmdb_id')
    menu_type = params.get('menu_type', 'movie')
    page = int(params.get('page', '1'))

    # --- FAST CACHE CHECK (RAM) ---
    cache_key = f"recomm_{tmdb_id}_{page}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='movies' if menu_type == 'movie' else 'tvshows')
        return
    # ------------------------------

    endpoint = 'movie' if menu_type == 'movie' else 'tv'
    url = f"{BASE_URL}/{endpoint}/{tmdb_id}/recommendations?api_key={API_KEY}&language={LANG}&page={page}"
    data = get_json(url)
    
    if not data:
        xbmcplugin.endOfDirectory(HANDLE); return

    results = data.get('results', [])
    prefetch_metadata_parallel(results, menu_type)

    items_to_add = []
    cache_list = []
    
    for item in results:
        processed = _process_movie_item(item, return_data=True) if menu_type == 'movie' else _process_tv_item(item, return_data=True)
        if processed:
            items_to_add.append((processed['url'], processed['li'], processed['is_folder']))
            cache_list.append(processed)

    # Next Page logic...
    total_pages = min(data.get('total_pages', 1), 500)
    if page < total_pages:
        next_label = next_page_label(page + 1)
        next_params = {'mode': 'list_recommendations', 'tmdb_id': tmdb_id, 'menu_type': menu_type, 'page': str(page+1)}
        next_url = plugin_url(next_params)
        next_li = xbmcgui.ListItem(next_label)
        style_page_nav_item(next_li, page + 1)
        items_to_add.append((next_url, next_li, True))
        cache_list.append({'label': next_label, 'url': next_url, 'is_folder': True, 'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON}, 'info': {'mediatype': 'video', 'plot': next_page_plot(page + 1)}, 'cm_items': []})

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))

    xbmcplugin.setContent(HANDLE, 'movies' if menu_type == 'movie' else 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('movies' if menu_type == 'movie' else 'tvshows')

    set_fast_cache(cache_key, [{'label': i['li'].getLabel() if 'li' in i else i['label'], 'url': i['url'], 'is_folder': i['is_folder'], 'art': i['art'], 'info': i['info'], 'cm': i['cm_items'], 'resume_time': 0, 'total_time': 0} for i in cache_list])


def build_actors_list(params):
    action = params.get('action', 'popular')
    page = int(params.get('page', '1'))

    from resources.lib.core.config import PAGE_LIMIT
    ITEMS_PER_API_PAGE = 20
    api_pages_needed = max(1, (PAGE_LIMIT + ITEMS_PER_API_PAGE - 1) // ITEMS_PER_API_PAGE)
    start_api_page = (page - 1) * api_pages_needed + 1

    cache_key = f"actors_{action}_{page}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='main')
        return

    all_results = []
    more_pages = False
    for api_page in range(start_api_page, start_api_page + api_pages_needed):
        url = f"{BASE_URL}/person/popular?api_key={API_KEY}&language={LANG}&page={api_page}"
        data = get_json(url)
        if not data:
            break
        results = data.get('results', [])
        all_results.extend(results)
        if api_page == start_api_page + api_pages_needed - 1:
            if (data.get('total_pages', 0) or 0) > api_page:
                more_pages = True
        if len(results) < ITEMS_PER_API_PAGE:
            break

    if not all_results:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    current_items = all_results[:PAGE_LIMIT]
    has_next = len(all_results) > PAGE_LIMIT or more_pages

    items_to_add = []
    cache_list = []

    if page == 1:
        search_url = plugin_url({'mode': 'perform_actor_search'})
        search_li = xbmcgui.ListItem('[B][COLOR FFFDBD01]Search Actors[/COLOR][/B]')
        search_icon = os.path.join(ADDON_PATH, 'resources', 'media', 'search.png')
        search_li.setArt({'icon': search_icon, 'thumb': search_icon})
        items_to_add.append((search_url, search_li, True))
        cache_list.append({'label': '[B][COLOR FFFDBD01]Search Actors[/COLOR][/B]', 'url': search_url, 'is_folder': True, 'art': {'icon': search_icon}, 'info': {}, 'cm': []})

    for actor in current_items:
        actor_id = actor.get('id')
        name = actor.get('name', 'Unknown')
        profile = actor.get('profile_path', '')
        thumb = f"{IMG_BASE}{profile}" if profile else ''

        li = xbmcgui.ListItem(label=name)
        art = {'icon': thumb, 'thumb': thumb}
        if thumb:
            art['poster'] = thumb
        li.setArt(art)

        known_for = actor.get('known_for', [])
        if known_for:
            titles = []
            for kf in known_for[:2]:
                kf_type = kf.get('media_type', '')
                kf_title = kf.get('title') or kf.get('name', '')
                if kf_title:
                    titles.append(kf_title)
            if titles:
                try:
                    li.getVideoInfoTag().setPlot(', '.join(titles))
                except:
                    pass

        actor_url = plugin_url({'mode': 'actor_dialog', 'actor_id': str(actor_id)})
        items_to_add.append((actor_url, li, False))
        cache_list.append({'label': name, 'url': actor_url, 'is_folder': False, 'art': {'icon': thumb, 'thumb': thumb}, 'info': {}, 'cm': []})

    if has_next:
        next_label = next_page_label(page + 1)
        next_params = {'mode': 'build_actors_list', 'action': action, 'page': str(page + 1)}
        next_url = plugin_url(next_params)
        next_li = xbmcgui.ListItem(next_label)
        style_page_nav_item(next_li, page + 1)
        items_to_add.append((next_url, next_li, True))
        cache_list.append({'label': next_label, 'url': next_url, 'is_folder': True, 'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON}, 'info': {'mediatype': 'video', 'plot': next_page_plot(page + 1)}, 'cm': []})

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('main', 'files')

    set_fast_cache(cache_key, cache_list)


def perform_actor_search(params):
    query = params.get('query')
    page = int(params.get('page', '1'))

    if query:
        build_actor_search_result(query, page)
        return

    cache_key = 'tmdb_actor_search'
    cached_query = xbmcgui.Window(10000).getProperty(cache_key)
    container_path = xbmc.getInfoLabel('Container.FolderPath')
    is_refresh = cached_query and 'perform_actor_search' in container_path

    if is_refresh:
        build_actor_search_result(cached_query, page)
        return

    new_query = xbmcgui.Dialog().input('Search Actor', type=xbmcgui.INPUT_ALPHANUM)
    if new_query:
        xbmcgui.Window(10000).setProperty(cache_key, new_query)
        build_actor_search_result(new_query, 1)
    else:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def build_actor_search_result(query, page=1):
    cache_key = f"actor_search_{query}_{page}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='main')
        return

    url = f"{BASE_URL}/search/person?api_key={API_KEY}&language={LANG}&query={quote(query)}&page={page}"
    data = get_json(url)
    if not data:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    results = data.get('results', [])
    items_to_add = []
    cache_list = []

    for actor in results:
        actor_id = actor.get('id')
        name = actor.get('name', 'Unknown')
        profile = actor.get('profile_path', '')
        thumb = f"{IMG_BASE}{profile}" if profile else ''

        li = xbmcgui.ListItem(label=name)
        art = {'icon': thumb, 'thumb': thumb}
        if thumb:
            art['poster'] = thumb
        li.setArt(art)

        known_for = actor.get('known_for', [])
        if known_for:
            titles = []
            for kf in known_for[:2]:
                kf_title = kf.get('title') or kf.get('name', '')
                if kf_title:
                    titles.append(kf_title)
            if titles:
                try:
                    li.getVideoInfoTag().setPlot(', '.join(titles))
                except:
                    pass

        actor_url = plugin_url({'mode': 'actor_dialog', 'actor_id': str(actor_id)})
        items_to_add.append((actor_url, li, False))
        cache_list.append({'label': name, 'url': actor_url, 'is_folder': False, 'art': {'icon': thumb, 'thumb': thumb}, 'info': {}, 'cm': []})

    total_pages = min(data.get('total_pages', 1), 500)
    if page < total_pages:
        next_label = next_page_label(page + 1)
        next_params = {'mode': 'perform_actor_search', 'query': query, 'page': str(page + 1)}
        next_url = plugin_url(next_params)
        next_li = xbmcgui.ListItem(next_label)
        style_page_nav_item(next_li, page + 1)
        items_to_add.append((next_url, next_li, True))
        cache_list.append({'label': next_label, 'url': next_url, 'is_folder': True, 'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON}, 'info': {'mediatype': 'video', 'plot': next_page_plot(page + 1)}, 'cm': []})

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('main', 'files')

    set_fast_cache(cache_key, cache_list)


def tmdb_edit_list(params):
    list_id = params.get('list_id')
    xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "Feature in development", TMDB_ICON, 3000, False)


def create_tmdb_list():
    session = get_tmdb_session()
    if not session:
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "Not connected", xbmcgui.NOTIFICATION_WARNING)
        return None

    dialog = xbmcgui.Dialog()
    list_name = dialog.input("List name", type=xbmcgui.INPUT_ALPHANUM)
    if not list_name:
        return None

    description = dialog.input("Description (optional)", type=xbmcgui.INPUT_ALPHANUM)

    # v4 NU are create-list (404) — v3: POST /3/list (verificat live 201, raspuns cu 'list_id')
    result = tmdb_auth_request("/list", method='POST',
                               data={'name': list_name, 'description': description,
                                     'iso_639_1': (LANG or 'en')[:2], 'iso_3166_1': 'US'}, v4=False)

    list_id = (result or {}).get('list_id')
    if result and list_id:
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), f"List created: [B][COLOR yellow]{list_name}[/COLOR][/B]", TMDB_ICON, 3000, False)
        trakt_sync.sync_tmdb_only(silent=True) 
        xbmc.executebuiltin("Container.Refresh")
        return list_id
    else:
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "Error creating list", xbmcgui.NOTIFICATION_ERROR)
    return None


def delete_tmdb_list(list_id):
    session = get_tmdb_session()
    if not session:
        return False

    dialog = xbmcgui.Dialog()
    if not dialog.yesno("Confirm", "Are you sure you want to delete this list?"):
        return False

    list_name = ''
    try:
        conn_l = trakt_sync.get_connection()
        c_l = conn_l.cursor()
        c_l.execute("SELECT name FROM tmdb_custom_lists WHERE list_id=?", (str(list_id),))
        row_l = c_l.fetchone()
        conn_l.close()
        if row_l and row_l[0]:
            list_name = row_l[0]
    except: pass

    # v4 NU are delete-list (404) — v3: DELETE /3/list/{id} (verificat live 200)
    result = tmdb_auth_request(f"/list/{list_id}", method='DELETE', v4=False)

    if result is not None:
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), f"List deleted: [B][COLOR FF00CED1]{list_name}[/COLOR][/B]", TMDB_ICON, 3000, False)
        trakt_sync.sync_tmdb_only(silent=True) 
        xbmc.executebuiltin("Container.Refresh")
        return True

    xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "Delete error", xbmcgui.NOTIFICATION_ERROR)
    return False


def clear_tmdb_list(list_id):
    session = get_tmdb_session()
    if not session:
        return False

    dialog = xbmcgui.Dialog()
    if not dialog.yesno("Confirm", "Are you sure you want to clear this list?"):
        return False

    list_name = ''
    try:
        conn_l = trakt_sync.get_connection()
        c_l = conn_l.cursor()
        c_l.execute("SELECT name FROM tmdb_custom_lists WHERE list_id=?", (str(list_id),))
        row_l = c_l.fetchone()
        conn_l.close()
        if row_l and row_l[0]:
            list_name = row_l[0]
    except: pass

    # v3 accepta Bearer v4 — endpointul /clear nu exista in v4
    result = tmdb_auth_request(f"/list/{list_id}/clear", method='POST', params={'confirm': 'true'}, v4=False)

    if result is not None:
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), f"List cleared: [B][COLOR FF00CED1]{list_name}[/COLOR][/B]", TMDB_ICON, 3000, False)
        trakt_sync.sync_tmdb_only(silent=True) 
        xbmc.executebuiltin("Container.Refresh")
        return True

    return False


def rate_tmdb_item_silent(tmdb_id, content_type, rating_value, season=None, episode=None):
    session = get_tmdb_session()
    if not session: return False

    if content_type == 'season' and not episode:
        # TMDb NU are endpoint de rating pentru sezon (verificat live: 404).
        # Aici s-ar rata SHOW-ul parinte -> TMDb il scoate din watchlist.
        xbmcgui.Dialog().notification(provider_title('tmdb'),
                                       'TMDb has no season rating - skipped (would rate the show and remove it from watchlist)',
                                       TMDB_ICON, 4000, False)
        return False

    if content_type == 'episode' or (season and episode):
        # v3 + Bearer (accepta token v4)
        result = tmdb_auth_request(f"/tv/{tmdb_id}/season/{season}/episode/{episode}/rating", method='POST',
                                   data={'value': float(rating_value)}, v4=False)
    else:
        # v4 NU are rating (404) — v3: POST /3/{movie|tv}/{id}/rating (verificat live 201)
        endpoint = 'movie' if content_type == 'movie' else 'tv'
        result = tmdb_auth_request(f"/{endpoint}/{tmdb_id}/rating", method='POST',
                                   data={'value': float(rating_value)}, v4=False)

    if result is not None:
        try:
            # Mirror-ul local se sterge DOAR la movie/show (serverul scoate itemul
            # din watchlist la rating de movie/show, dar pastreaza la episod — entry 104).
            if not (season and episode):
                from resources.lib.providers import trakt_sync
                conn = trakt_sync.get_connection()
                conn.execute("DELETE FROM tmdb_account_lists WHERE tmdb_id=? AND list_type='watchlist'", (str(tmdb_id),))
                conn.commit()
                conn.close()
                from resources.lib.core.cache import clear_all_fast_cache
                clear_all_fast_cache()
        except: pass
        return True
    return False

def rate_tmdb_item(tmdb_id, content_type, season=None, episode=None, title=''):
    session = get_tmdb_session()
    if not session:
        xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "Not connected", xbmcgui.NOTIFICATION_WARNING)
        return False
    
    from resources.lib.api import trakt_api
    trakt_api._prompt_trakt_rating(tmdb_id, content_type, season, episode, title, service='tmdb')


def prompt_add_rating_picker(tmdb_id, content_type, season=None, episode=None, title=''):
    """Un singur context 'Add Rating' — picker cu providerii conectati (Trakt/MDBList/TMDb)."""
    import os
    from resources.lib.core.config import ADDON_PATH

    options = []

    from resources.lib.api import trakt_api
    try:
        if trakt_api.get_trakt_token():
            options.append(('Add [B][COLOR pink]Rating (Trakt)[/COLOR][/B]', 'trakt'))
    except Exception:
        pass

    try:
        from resources.lib.providers.mdblist_api import MDBListAPI
        if MDBListAPI().is_authenticated():
            options.append(('Add [B][COLOR lightskyblue]Rating (MDBList)[/COLOR][/B]', 'mdblist'))
    except Exception:
        pass

    try:
        if get_tmdb_session():
            options.append(('Add [B][COLOR FF00CED1]Rating (TMDb)[/COLOR][/B]', 'tmdb'))
    except Exception:
        pass

    if not options:
        xbmcgui.Dialog().notification('[B][COLOR FFCCCCFF]Add Rating[/COLOR][/B]',
                                       'No provider connected (Trakt / MDBList / TMDb)',
                                       xbmcgui.NOTIFICATION_ERROR, 3000, False)
        return

    dialog = xbmcgui.Dialog()
    ret = dialog.contextmenu([opt[0] for opt in options])
    if ret < 0:
        return
    action = options[ret][1]

    if action == 'trakt':
        trakt_api.rate_trakt_item(tmdb_id, content_type, season, episode, title)
    elif action == 'mdblist':
        from resources.lib.providers.mdblist_api import prompt_mdblist_rating
        prompt_mdblist_rating(tmdb_id, content_type, season, episode, title)
    elif action == 'tmdb':
        rate_tmdb_item(tmdb_id, content_type, season, episode, title)


def delete_tmdb_rating(tmdb_id, content_type, notify=True):
    session = get_tmdb_session()
    if not session:
        return False

    # v4 NU are rating (404) — v3: DELETE /3/{movie|tv}/{id}/rating
    endpoint = 'movie' if content_type == 'movie' else 'tv'
    result = tmdb_auth_request(f"/{endpoint}/{tmdb_id}/rating", method='DELETE', v4=False)

    if result is not None:
        if notify:
            xbmcgui.Dialog().notification(provider_title('tmdb', name='TMDB'), "Rating deleted", TMDB_ICON, 3000, False)
        return True

    return False


def remove_tmdb_rating(tmdb_id, content_type, season=None, episode=None, notify=True):
    if content_type == 'episode' or (season is not None and episode is not None):
        res = tmdb_auth_request(f"/tv/{tmdb_id}/season/{season}/episode/{episode}/rating", method='DELETE', v4=False)
    elif str(content_type).lower() == 'season' and season is not None:
        res = tmdb_auth_request(f"/tv/{tmdb_id}/season/{season}/rating", method='DELETE', v4=False)
    else:
        return delete_tmdb_rating(tmdb_id, content_type, notify=notify)
    if res is not None:
        if notify:
            xbmcgui.Dialog().notification(provider_title('tmdb'), "Rating removed", TMDB_ICON, 3000, False)
        return True
    return False


def get_similar_items(tmdb_id, content_type, page=1):
    endpoint = 'movie' if content_type == 'movie' else 'tv'
    url = f"{BASE_URL}/{endpoint}/{tmdb_id}/similar?api_key={API_KEY}&language={LANG}&page={page}"
    return get_json(url)


def get_recommendations_items(tmdb_id, content_type, page=1):
    endpoint = 'movie' if content_type == 'movie' else 'tv'
    url = f"{BASE_URL}/{endpoint}/{tmdb_id}/recommendations?api_key={API_KEY}&language={LANG}&page={page}"
    return get_json(url)


def refresh_container():
    xbmc.executebuiltin("Container.Refresh")


def go_back():
    xbmc.executebuiltin("Action(Back)")


def _ensure_clearlogo(data):
    """Normalizeaza clearlogo din images.logos daca lipseste cheia top-level
    (ex: date puse in RAM pool de prefetch_metadata_parallel, care nu extrag logo-ul)."""
    if not data or data.get('clearlogo'):
        return data
    try:
        for img in data.get('images', {}).get('logos', []):
            if img.get('file_path', '').lower().endswith('.png'):
                data['clearlogo'] = img['file_path']
                break
    except:
        pass
    return data


def _get_cached_details(tmdb_id, content_type):
    """Cache-only lookup — zero API calls. Respecta _cached_lang."""
    str_id = str(tmdb_id)
    from resources.lib.core.config import get_plot_language_code
    current_lang = get_plot_language_code()
    from resources.lib.core.cache import ram_pool_get
    pool_data = ram_pool_get(str_id)
    if pool_data and pool_data.get('_cached_lang') == current_lang:
        return _ensure_clearlogo(pool_data)
    from resources.lib.providers import trakt_sync
    data = trakt_sync.get_tmdb_item_details_from_db(str_id, content_type)
    if data and data.get('_cached_lang') == current_lang:
        return _ensure_clearlogo(data)
    return {}


def _extract_mpaa(data, content_type):
    """Extrage MPAA (TV-MA/R/PG-13 etc.) din content_ratings (tv) sau release_dates (movie)."""
    try:
        mpaa = ''
        if content_type == 'tv' and 'content_ratings' in data:
            for r in data['content_ratings'].get('results', []):
                if r.get('iso_3166_1') == 'US':
                    mpaa = r.get('rating', '')
                    break
        elif content_type == 'movie' and 'release_dates' in data:
            for r in data['release_dates'].get('results', []):
                if r.get('iso_3166_1') == 'US':
                    for rd in r.get('release_dates', []):
                        if rd.get('certification'):
                            mpaa = rd.get('certification')
                            break
                    if mpaa: break
        if mpaa:
            data['mpaa'] = mpaa
    except:
        pass


def get_tmdb_item_details(tmdb_id, content_type, lightweight=False, skip_localization=False, force=False,
                          db_only=False):
    """Fetch detalii TMDB. lightweight=True omite credits/videos (lista). skip_localization=True sare al 2-lea GET RO. force=True sare citirea din cache-uri (doar API + write-through). db_only=True se opreste dupa cache-uri (RAM + SQLite), fara nicio cerere TMDb."""
    endpoint = 'movie' if content_type == 'movie' else 'tv'
    str_id = str(tmdb_id)

    from resources.lib.core.config import get_plot_language_code
    current_lang = 'en' if skip_localization else get_plot_language_code()

    from resources.lib.core.cache import ram_cache_get_tvshow, ram_cache_set_tvshow, ram_pool_get, ram_pool_set
    from resources.lib.core.config import ADDON, SESSION, get_headers, get_plot_img_lang, LANG_TO_TMDB
    from resources.lib.providers import trakt_sync
    data = None
    if not force:
        # 1. Check global RAM pool — skip if language doesn't match
        pool_data = ram_pool_get(str_id)
        if pool_data and pool_data.get('_cached_lang') == current_lang:
            if lightweight or not pool_data.get('_lightweight'):
                return _ensure_clearlogo(pool_data)

        # 2. Check Window Properties RAM cache — skip if language doesn't match
        ram_data = ram_cache_get_tvshow(str_id)
        if ram_data and ram_data.get('_cached_lang') == current_lang:
            if lightweight or not ram_data.get('_lightweight'):
                ram_pool_set(str_id, ram_data)
                return _ensure_clearlogo(ram_data)

        data = trakt_sync.get_tmdb_item_details_from_db(str_id, content_type)

        if data:
            cached_lang = data.get('_cached_lang', 'en')
            if cached_lang == current_lang:
                if lightweight or not data.get('_lightweight'):
                    ram_pool_set(str_id, data)
                    ram_cache_set_tvshow(str_id, data)
                    return _ensure_clearlogo(data)

    if db_only:
        # Bucla de randare a listei NU are voie sa iasa in retea. Pe o cutie
        # lenta, un singur serial necache-uit transforma build-ul de ~1.5s in
        # 10-14s (cazul din logul de pe Android: `randuri=14012`), iar un build
        # intins peste fereastra de refresh a generat cursele de la stop.
        # Randul se construieste din ce avem; cache-urile se umplu deja in
        # fundal (warm-up-ul cu 10 threaduri + pasul de la 85%), iar ele
        # supravietuiesc marcarii, deci urmatoarea randare le are.
        return None

    append = "external_ids,images,content_ratings,release_dates" if lightweight else "credits,videos,external_ids,images,content_ratings,release_dates"
    url_en = f"{BASE_URL}/{endpoint}/{tmdb_id}?api_key={API_KEY}&language=en-US&append_to_response={append}&include_image_language=en,null,xx"
    
    try:
        res_en = None
        for _attempt in range(3):
            res_en = SESSION.get(url_en, headers=get_headers(), timeout=5)
            if res_en.status_code == 429 and _attempt < 2:
                xbmc.sleep(1000 * (_attempt + 1))
                continue
            break
        if res_en is None or res_en.status_code != 200:
            xbmc.log(f"[TMDB] details non-200 for tv/{tmdb_id}: status={getattr(res_en, 'status_code', None)}", xbmc.LOGWARNING)
            return None
        data = res_en.json()
        
        data['_cached_lang'] = 'en'
        data['_lightweight'] = lightweight
        
        _extract_mpaa(data, content_type)
        
        en_logos = [img for img in data.get('images', {}).get('logos', []) if img.get('file_path', '').lower().endswith('.png')]
        if en_logos:
            data['clearlogo'] = en_logos[0]['file_path']
        
        if not skip_localization and current_lang != 'en':
            tmdb_lang = LANG_TO_TMDB.get(current_lang, 'en-US')
            url_target = f"{BASE_URL}/{endpoint}/{tmdb_id}?api_key={API_KEY}&language={tmdb_lang}&append_to_response=images&include_image_language={get_plot_img_lang()}"
            res_target = None
            for _attempt2 in range(3):
                res_target = SESSION.get(url_target, headers=get_headers(), timeout=5)
                if res_target.status_code == 429 and _attempt2 < 2:
                    xbmc.sleep(1000 * (_attempt2 + 1))
                    continue
                break
            
            if res_target.status_code == 200:
                data_target = res_target.json()
                
                if data_target.get('overview'):
                    data['overview'] = data_target['overview']
                if data_target.get('tagline'):
                    data['tagline'] = data_target['tagline']
                
                target_imgs = data_target.get('images', {})
                
                target_logos = [l for l in target_imgs.get('logos', []) if l.get('file_path', '').lower().endswith('.png')]
                if target_logos: 
                    data['clearlogo'] = target_logos[0]['file_path']
                
                target_posters = target_imgs.get('posters', [])
                if target_posters:
                    data['poster_path'] = target_posters[0]['file_path']
                    
                target_backdrops = target_imgs.get('backdrops', [])
                if target_backdrops:
                    data['backdrop_path'] = target_backdrops[0]['file_path']
                    
                data['_cached_lang'] = current_lang
        
        _ensure_clearlogo(data)
        ram_pool_set(str_id, data)
        ram_cache_set_tvshow(tmdb_id, data)
        try:
            existing = trakt_sync.get_tmdb_item_details_from_db(str_id, content_type)
            should_store = True
            merge_release_dates = False
            if existing and existing.get('_cached_lang') not in ('en', None) and data.get('_cached_lang') == 'en' and skip_localization:
                should_store = False
            elif existing and existing.get('_cached_lang') == data.get('_cached_lang'):
                if not lightweight and existing.get('_lightweight'):
                    should_store = True
                elif lightweight and not existing.get('_lightweight'):
                    # Randul existent e "full" (credits/videos) si NU are release_dates.
                    # Nu il suprascriem cu payload-ul lightweight (am pierde titlurile
                    # localizate si overview-ul din randul full), dar completam DOAR
                    # campul lipsa - altfel datele de lansare traiesc doar in pool-ul
                    # RAM si calendarul se goleste la restartul lui Kodi.
                    if not existing.get('release_dates') and data.get('release_dates'):
                        existing['release_dates'] = data['release_dates']
                        merge_release_dates = True
                    should_store = False
            if should_store or merge_release_dates:
                conn = trakt_sync.get_connection()
                trakt_sync.set_tmdb_item_details_to_db(conn.cursor(), tmdb_id, content_type,
                                                       existing if merge_release_dates else data)
                conn.commit()
                conn.close()
        except:
            pass
        return data
    except Exception as e:
        xbmc.log(f"[TMDB] Fetch Error: {e}", xbmc.LOGERROR)
        return None

def check_tmdb_connection():
    try:
        url = f"{BASE_URL}/configuration?api_key={API_KEY}"
        r = requests.get(url, timeout=5)
        return r.status_code == 200
    except:
        return False


def get_watched_status_movie(tmdb_id):
    from resources.lib.providers import watched_provider
    return watched_provider.get_watched_counts(tmdb_id, 'movie') > 0


def get_watched_status_season(tmdb_id, season_num):
    from resources.lib.providers import watched_provider

    watched_count = watched_provider.get_watched_counts(tmdb_id, 'season', season_num)

    try:
        data = trakt_sync.get_tmdb_season_details_from_db(tmdb_id, season_num)
        if not data: 
            url = f"{BASE_URL}/tv/{tmdb_id}/season/{season_num}?api_key={API_KEY}&language={LANG}"
            data = get_json(url)
            if data: 
                conn = trakt_sync.get_connection()
                trakt_sync.set_tmdb_season_details_to_db(conn.cursor(), tmdb_id, season_num, data)
                conn.commit()
                conn.close()

        total_eps = len(data.get('episodes', [])) if data else 0
    except:
        total_eps = 0

    return {'watched': watched_count, 'total': total_eps}


def export_local_favorites():
    favs = read_json(FAVORITES_FILE)
    if not favs:
        xbmcgui.Dialog().notification("[B][COLOR FFFF69B4]Favorites[/COLOR][/B]", "No favorites to export", TMDbmovies_ICON, 2000, False)
        return

    dialog = xbmcgui.Dialog()
    path = dialog.browseSingle(3, "Choose export location", 'files', '.json')

    if path:
        export_file = os.path.join(path, 'tmdbmovies_favorites_backup.json')
        write_json(export_file, favs)
        xbmcgui.Dialog().notification("[B][COLOR FFFF69B4]Favorites[/COLOR][/B]", "Export complete!", TMDbmovies_ICON, 2000, False)


def import_local_favorites():
    dialog = xbmcgui.Dialog()
    path = dialog.browseSingle(1, "Select import file", 'files', '.json')

    if path:
        try:
            imported = read_json(path)
            if imported:
                current = read_json(FAVORITES_FILE) or {'movie': [], 'tv': []}

                for c_type in ['movie', 'tv']:
                    existing_ids = {str(f.get('tmdb_id')) for f in current.get(c_type, [])}
                    for item in imported.get(c_type, []):
                        if str(item.get('tmdb_id')) not in existing_ids:
                            current[c_type].append(item)

                write_json(FAVORITES_FILE, current)
                xbmcgui.Dialog().notification("[B][COLOR FFFF69B4]Favorites[/COLOR][/B]", "Import complete!", TMDbmovies_ICON, 2000, False)
                xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            log(f"[IMPORT] Error: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("[B][COLOR FFFF69B4]Favorites[/COLOR][/B]", "Import error", TMDbmovies_ICON, 2000, False)


def debug_info():
    session = get_tmdb_session()
    from resources.lib.api import trakt_api
    trakt_token = trakt_api.get_trakt_token()

    info = []
    info.append(f"TMDB Connected: {'Yes' if session else 'No'}")
    if session:
        info.append(f"TMDB User: {session.get('username', 'N/A')}")

    info.append(f"Trakt Connected: {'Yes' if trakt_token else 'No'}")
    if trakt_token:
        info.append(f"Trakt User: {trakt_api.get_trakt_username()}")

    info.append(f"Language: {LANG}")
    info.append(f"Cache DB: {os.path.exists(os.path.join(ADDON.getAddonInfo('profile'), 'maincache.db'))}")
    info.append(f"Sync DB: {os.path.exists(trakt_sync.DB_PATH)}")

    dialog = xbmcgui.Dialog()
    dialog.textviewer("Debug Info", "\n".join(info))


def test_api_connection():
    results = []

    try:
        r = requests.get(f"{BASE_URL}/configuration?api_key={API_KEY}", timeout=5)
        results.append(f"TMDB API: {'OK' if r.status_code == 200 else 'FAIL'}")
    except:
        results.append("TMDB API: FAIL (timeout)")

    try:
        from resources.lib.api import trakt_api
        headers = trakt_api.get_trakt_headers()
        r = requests.get(f"{trakt_api.TRAKT_API_URL}/movies/trending", headers=headers, timeout=5)
        results.append(f"Trakt API: {'OK' if r.status_code == 200 else 'FAIL'}")
    except:
        results.append("Trakt API: FAIL (timeout)")

    xbmcgui.Dialog().ok("API Test", "\n".join(results))

# =============================================================================
# FUNCTII IN PROGRESS (Corectate)
# =============================================================================

def in_progress_movies(params):
    """Afiseaza filmele cu resume point + PLOT + METADATA COMPLETE."""
    from resources.lib.providers import trakt_sync
    from resources.lib.core.config import PAGE_LIMIT
    from resources.lib.core.utils import skip_ext_info_in_progress as _skip_ip
    
    try: icon = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media', 'player.png')
    except: icon = 'DefaultIcon.png'
    
    page = int(params.get('page', '1'))
    all_results = trakt_sync.get_in_progress_movies_from_db()
    
    if not all_results:
        from resources.lib.providers.watched_provider import _get_provider_raw
        _prov = _get_provider_raw()
        if _prov == 'mdblist':
            add_directory("[COLOR cyan]No movies started. Sync MDBList.[/COLOR]", {'mode': 'mdblist_sync'}, folder=False, icon='DefaultIconInfo.png')
        elif _prov == 'simkl':
            add_directory("[COLOR cyan]No movies started. Sync Simkl.[/COLOR]", {'mode': 'simkl_sync'}, folder=False, icon='DefaultIconInfo.png')
        elif _prov == 'punchplay':
            add_directory("[COLOR cyan]No movies started. Sync PunchPlay.[/COLOR]", {'mode': 'punchplay_sync'}, folder=False, icon='DefaultIconInfo.png')
        elif _prov == 'local':
            add_directory("[COLOR cyan]No movies started yet - play something or mark a movie as watched (Kodi Local).[/COLOR]", {'mode': 'main'}, folder=False, icon='DefaultIconInfo.png')
        else:
            add_directory("[COLOR cyan]No movies started. Sync Trakt.[/COLOR]", {'mode': 'trakt_sync_db'}, folder=False, icon='DefaultIconInfo.png')
        xbmcplugin.endOfDirectory(HANDLE)
        return
    
    results, total_pages = paginate_list(all_results, page, PAGE_LIMIT)
        
    for item in results:
        tmdb_id = str(item.get('id') or item.get('tmdb_id', ''))
        if not tmdb_id: continue

        title = item.get('title', 'Unknown')
        year = str(item.get('year', ''))
        
        details = get_tmdb_item_details(tmdb_id, 'movie')
        
        # FIX "()": randurile vechi scrise de sync cu title/year gol -> fallback pe detaliile TMDb
        if details:
            if not title or title == 'Unknown':
                title = details.get('title') or title
            if not year:
                try:
                    year = str(details.get('release_date') or '')[:4]
                except:
                    year = ''
        
        plot = item.get('overview', '')
        poster_path_api = ''
        backdrop_path_api = ''
        imdb_id = ''
        rating, votes, premiered, studio, duration = 0, 0, '', '', 0
        movie_mpaa = ''
        movie_logo = ''
        cast = []

        tagline = ''
        genres_str = ''
        if details:
            imdb_id = details.get('external_ids', {}).get('imdb_id', '')
            plot = details.get('overview', plot)
            tagline = details.get('tagline', '').strip()
            genres_str = ", ".join([g['name'] for g in details.get('genres',[])])
            poster_path_api = details.get('poster_path', '')
            rating = details.get('vote_average', 0.0)
            votes = details.get('vote_count', 0)
            premiered = details.get('release_date', '')
            
            raw_logo = details.get('clearlogo', '')
            movie_logo = f"{IMG_BASE}{raw_logo}" if raw_logo and not raw_logo.startswith('http') else raw_logo
            movie_mpaa = details.get('mpaa', '')
            
            if details.get('production_companies'):
                studio = [c['name'] for c in details['production_companies']]
                
            for p in details.get('credits', {}).get('cast', [])[:15]:
                if p.get('name'):
                    thumb = f"{IMG_BASE}{p['profile_path']}" if p.get('profile_path') else ''
                    cast.append({"name": p['name'], "role": p.get('character', ''), "thumbnail": thumb})
                    
            try:
                duration = int(details.get('runtime') or 0) * 60
            except:
                pass

        # <<-- MODIFICARE CHEIE: Interpretarea valorii din DB -->>
        progress_raw = float(item.get('progress', 0))
        resume_seconds = 0
        progress_percent = 0

        if progress_raw >= 1000000:
            # Este numarul magic, deci avem secunde exacte
            resume_seconds = int(progress_raw - 1000000)
            if duration > 0:
                progress_percent = (resume_seconds / duration) * 100
        elif 0 < progress_raw < 90:
            # Este un procentaj standard (ex: de la Trakt)
            progress_percent = progress_raw
            if duration > 0:
                resume_seconds = int((progress_percent / 100.0) * duration)
        # <<---------------------------------------------------->>

        poster = f"{IMG_BASE}{poster_path_api}" if poster_path_api else ''
        backdrop = f"{BACKDROP_BASE}{backdrop_path_api}" if backdrop_path_api else ''
        
        try: show_motto = ADDON.getSetting('show_motto_genre') != 'false'
        except: show_motto = True
        
        display_plot = f"[B][COLOR orange]Progress: {int(progress_percent)}%[/COLOR][/B]\n"
        if show_motto:
            if tagline and genres_str:
                display_plot += f"[B][COLOR yellow]{tagline}[/COLOR][/B] | [B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n"
            elif tagline:
                display_plot += f"[B][COLOR yellow]{tagline}[/COLOR][/B]\n"
            elif genres_str:
                display_plot += f"[B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n"
            
        display_plot += plot

        info = {
            'mediatype': 'movie', 'title': title, 'year': year, 'plot': display_plot,
            'resume_percent': progress_percent, 'rating': rating, 'votes': votes,
            'premiered': premiered, 'studio': studio, 'duration': duration,
            'mpaa': movie_mpaa, 'cast': cast, 'genre': genres_str
        }
        
        cm = _get_full_context_menu(tmdb_id, 'movie', title, imdb_id=imdb_id, year=year)
        from resources.lib.providers.watched_provider import get_label as _prov_label, get_color as _prov_color, mark_menu_label as _mml
        cm.append((_mml(False) or f'[B][COLOR FF6AFB92]Mark Watched [COLOR {_prov_color()}]({_prov_label()})[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?mode=mark_watched&tmdb_id={tmdb_id}&type=movie)"))

        if _skip_ip():
            url_params = None
        else:
            url_params = select_ext_info_params('movie', tmdb_id)
        url_params = url_params or {'mode': 'sources', 'tmdb_id': tmdb_id, 'type': 'movie', 'title': title, 'year': year}
        
        from resources.lib.providers.watched_provider import get_watched_counts as _get_wc
        is_watched_this = _get_wc(tmdb_id, 'movie') > 0
        display_title_ip = f"{title} ({year})"
        if is_watched_this:
            display_title_ip = f'[B][COLOR FF6AFB92]{display_title_ip}[/COLOR][/B]'

        url = plugin_url(url_params)
        li = xbmcgui.ListItem(display_title_ip)
        
        art_dict = {'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': backdrop}
        if movie_logo:
            art_dict['clearlogo'] = movie_logo
        li.setArt(art_dict)
        
        set_metadata(li, info, unique_ids={'tmdb': tmdb_id, 'imdb': imdb_id}, watched_info=False)
        
        set_resume_point(li, resume_seconds, duration)
        
        if cm:
            li.addContextMenuItems(cm)
        
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    
    if page < total_pages:
        add_directory(
            next_page_label(page + 1),
            {'mode': 'in_progress_movies', 'page': str(page + 1)},
            icon=NEXT_PAGE_ICON, thumb=NEXT_PAGE_ICON,
            info={'mediatype': 'video', 'plot': next_page_plot(page + 1)}, folder=True
        )
        
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)
    _set_views_apply('movies')



def in_progress_tvshows(params):
    """Afiseaza TOATE serialele in progres. Sursa unificata cu Up Next pentru sincronizare 100%."""
    from resources.lib.providers import trakt_sync
    from concurrent.futures import ThreadPoolExecutor
    import datetime

    # === CITIM SETAREA INAINTE DE CACHE ===
    try: show_future = ADDON.getSetting('upnext_show_future') == 'true'
    except: show_future = False
    try: hide_unaired = ADDON.getSetting('hide_unaired_episodes') == 'true'
    except: hide_unaired = False

    from resources.lib.providers.watched_provider import _get_provider_raw as _get_prov
    use_mdblist = _get_prov() == 'mdblist'
    use_simkl = _get_prov() == 'simkl'
    use_punchplay = _get_prov() == 'punchplay'
    use_local = _get_prov() == 'local'

    from resources.lib.core.utils import skip_ext_info_in_progress as _skip_ip

    # === 1. FAST CACHE CHECK (RAM) ===
    # Bump LABEL_VERSION cand se modifica formatul label-urilor (e.g. culoare TBA)
    # 8: randurile difuzate azi primesc si ele eticheta (Astazi) + token
    LABEL_VERSION = "8"
    try:
        _air_time_on = ADDON.getSetting('show_air_time') == 'true'
    except:
        _air_time_on = False
    cache_key = f"in_progress_tvshows_all_future_{use_mdblist}_{use_simkl}_{use_punchplay}_{use_local}_{show_future}_{hide_unaired}_{LABEL_VERSION}_{int(_air_time_on)}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='tvshows')
        log(f"[IN PROGRESS] din fast cache: {len(cached_data)} randuri (instant)")
        return
    # Alt proces construieste deja lista -> asteptam cache-ul lui (anti-race)
    cached_data = _list_build_wait(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='tvshows')
        log(f"[IN PROGRESS] din fast cache: {len(cached_data)} randuri (build preluat de alt proces)")
        return
    # ==================================

    try: icon = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media', 'in_progress_tvshow.png')
    except: icon = 'DefaultIcon.png'

    # Sursa de adevar este acum EXACT aceeasi ca la Up Next (provider-aware)
    if use_local:
        from resources.lib.providers.local_sync import get_in_progress_tvshows_from_db as _loc_ip
        raw_items = _loc_ip()
    elif use_mdblist:
        from resources.lib.providers.mdblist_sync import get_in_progress_tvshows_from_db as _mdb_ip
        raw_items = _mdb_ip()
    elif use_simkl:
        from resources.lib.providers.simkl_sync import get_in_progress_tvshows_from_db as _sk_ip
        raw_items = _sk_ip()
    elif use_punchplay:
        from resources.lib.providers.punchplay_sync import get_in_progress_tvshows_from_db as _pp_ip
        raw_items = _pp_ip()
    else:
        raw_items = trakt_sync.get_next_episodes_from_db()

    if not raw_items:
        if use_local:
            add_directory("[COLOR cyan]No TV shows in progress. Mark episodes watched (Kodi Local).[/COLOR]",
                          {'mode': 'main'}, folder=False, icon='DefaultIconInfo.png')
        elif use_mdblist:
            add_directory("[COLOR cyan]No TV shows in progress. Sync MDBList.[/COLOR]",
                          {'mode': 'mdblist_sync'}, folder=False, icon='DefaultIconInfo.png')
        elif use_simkl:
            add_directory("[COLOR cyan]No TV shows in progress. Sync Simkl.[/COLOR]",
                          {'mode': 'simkl_sync'}, folder=False, icon='DefaultIconInfo.png')
        elif use_punchplay:
            add_directory("[COLOR cyan]No TV shows in progress. Sync PunchPlay.[/COLOR]",
                          {'mode': 'punchplay_sync'}, folder=False, icon='DefaultIconInfo.png')
        else:
            add_directory("[COLOR cyan]No TV shows in progress. Sync Trakt.[/COLOR]",
                          {'mode': 'trakt_sync_db'}, folder=False, icon='DefaultIconInfo.png')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    today = datetime.date.today()
    max_future_date = today + datetime.timedelta(days=7)

    # 2. FILTRARE STRICTA
    valid_shows = []
    for item in raw_items:
        tmdb_id = str(item['tmdb_id'])

        if 'watched_count' in item and item.get('watched_count') is not None:
            try:
                if int(item.get('watched_count') or 0) == 0:
                    continue
            except:
                pass

        # Aplicam regula 7 zile / TBA
        if not show_future:
            air_date_str = item.get('air_date', '')
            if not air_date_str:
                # Nu are data de difuzare sau e TBA -> Ascundem
                continue
            try:
                parts = str(air_date_str).split('T')[0].split('-')
                air_date = datetime.date(int(parts[0]), int(parts[1]), int(parts[2]))
                if air_date > max_future_date:
                    # Apare peste mai mult de 7 zile -> Ascundem
                    continue 
            except:
                # Esec parsare data (probabil TBA) -> Ascundem
                continue

        if hide_unaired:
            air_date_str = item.get('air_date', '')
            if not air_date_str:
                continue
            try:
                parts = str(air_date_str).split('T')[0].split('-')
                air_date = datetime.date(int(parts[0]), int(parts[1]), int(parts[2]))
                if air_date > today:
                    continue
            except:
                continue
                
        valid_shows.append(item)

    if not valid_shows:
        add_directory("[COLOR cyan]All current shows are completed or appear in the future.[/COLOR]",
                      {'mode': 'noop'}, folder=False, icon='DefaultIconInfo.png')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # 3. PREFETCH METADATA
    _t_start = time.time()
    prefetch_metadata_parallel([{'id': str(i['tmdb_id']), 'media_type': 'tv'} for i in valid_shows], 'tv')
    # Asteptare LIMITATA (150ms) pentru orele de difuzare: pe conexiuni rapide
    # eticheta "Airing today at HH:MM" e gata si intra in randarea curenta; pe
    # cele lente continuam fara ea, iar apply_air_times_to_cache_items o aplica la
    # randare (list_render.py). Un prefetch plin costa ~440ms la 62 de seriale.
    try:
        import threading as _thr_air_b
        _air_b = _thr_air_b.Thread(target=prefetch_air_times, args=(valid_shows,), daemon=True)
        _air_b.start()
        _air_b.join(0.15)
    except:
        pass
    _t_warm = time.time()

    # Orele de difuzare: o singura conexiune sqlite pentru toata lista.
    try:
        _ip_at_map = get_episode_air_stamps(
            [(str(x['tmdb_id']), int(x.get('season') or 0), int(x.get('episode') or 0)) for x in valid_shows])
    except:
        _ip_at_map = None

    items_to_add = []
    cache_list = []

    try: show_motto = ADDON.getSetting('show_motto_genre') != 'false'
    except: show_motto = True

    # 4. CONSTRUIRE LISTA UI
    for item in valid_shows:
        tmdb_id = str(item['tmdb_id'])
        
        details = get_tmdb_item_details(tmdb_id, 'tv', lightweight=True)
        if not details:
            continue

        # Calculam rapid episoadele din SQL / TMDB
        watched_info_db = get_watched_status_tvshow(tmdb_id)
        curr_watched = int(watched_info_db.get('watched', 0))
        curr_total = int(watched_info_db.get('total', 0))
        
        if curr_total == 0:
            curr_total = details.get('number_of_episodes', 0)
            if curr_total > 0:
                trakt_sync.set_tv_meta_to_db(tmdb_id, curr_total)

        # --- Extragem datele ---
        # Numele serialului: NON-localizat (din DB Trakt/MDBList API), nu din TMDb.
        # Doar numele episoadelor sunt localizate (via get_smart_season_details).
        name       = item.get('show_title') or details.get('name', 'Unknown')
        year       = str(details.get('first_air_date', ''))[:4]
        plot       = details.get('overview', '')
        imdb_id    = details.get('external_ids', {}).get('imdb_id', '')
        tagline    = details.get('tagline', '').strip()
        genres_str = ", ".join([g['name'] for g in details.get('genres', [])])
        poster_path = details.get('poster_path', '')
        poster      = f"{IMG_BASE}{poster_path}" if poster_path else ''
        backdrop    = f"{BACKDROP_BASE}{details.get('backdrop_path', '')}" if details.get('backdrop_path') else ''
        raw_logo    = details.get('clearlogo', '')
        clearlogo   = f"{IMG_BASE}{raw_logo}" if raw_logo and not raw_logo.startswith('http') else raw_logo

        cast = []
        for p in details.get('credits', {}).get('cast', [])[:15]:
            if p.get('name'):
                thumb = f"{IMG_BASE}{p['profile_path']}" if p.get('profile_path') else ''
                cast.append({"name": p['name'], "role": p.get('character', ''), "thumbnail": thumb})

        duration = 0
        try:
            runtimes = details.get('episode_run_time', [])
            if runtimes and runtimes[0]: duration = int(runtimes[0]) * 60
        except: pass

        # --- Progress display ---
        display_total = str(curr_total) if curr_total > 0 else "?"
        progress_pct  = int((curr_watched / curr_total) * 100) if curr_total > 0 else 0
        if progress_pct > 100: progress_pct = 100

        display_plot = f"[B][COLOR orange]Watched: {curr_watched}/{display_total} ({progress_pct}%)[/COLOR][/B]\n"
        if show_motto:
            if tagline and genres_str:
                display_plot += f"[B][COLOR yellow]{tagline}[/COLOR][/B] | [B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n"
            elif tagline:
                display_plot += f"[B][COLOR yellow]{tagline}[/COLOR][/B]\n"
            elif genres_str:
                display_plot += f"[B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n"
        display_plot += plot

        info = {
            'mediatype'  : 'tvshow',
            'title'      : name,
            'year'       : year,
            'plot'       : display_plot,
            'tvshowtitle': name,
            'rating'     : details.get('vote_average', 0.0),
            'votes'      : details.get('vote_count', 0),
            'premiered'  : details.get('first_air_date', ''),
            'studio'     : details.get('networks', [{}])[0].get('name', '') if details.get('networks') else '',
            'duration'   : duration,
            'mpaa'       : details.get('mpaa', ''),
            'cast'       : cast,
            'genre'      : genres_str,
        }
        art = {
            'icon'  : poster, 'thumb' : poster, 'poster' : poster,
            'fanart': backdrop,
        }
        if clearlogo: art['clearlogo'] = clearlogo

        watched_info_dict = {'watched': curr_watched, 'total': curr_total}
        cm  = _get_full_context_menu(tmdb_id, 'tv', name, year=year, imdb_id=imdb_id)
        _sel_info = None if _skip_ip() else select_ext_info_params('tv', tmdb_id)
        url_params = _sel_info or {'mode': 'details', 'tmdb_id': tmdb_id, 'type': 'tv', 'title': name}
        url = plugin_url(url_params)

        air_date_str = item.get('air_date', '')
        is_tba = not air_date_str

        if is_tba:
            label = f"[B][COLOR FFFF4444]{name} (TBA)[/COLOR][/B]"
            _ip_name = None
        else:
            _ip_name = f"{name} ({year})" if year else name
            if curr_total > 0 and curr_watched >= curr_total:
                label = f"{_ip_name} [B][COLOR lime](Complet)[/COLOR][/B]"
            elif curr_watched > 0:
                label = f"[B][COLOR FFEFD702]{_ip_name}[/COLOR] [COLOR FF6AFB92]({curr_watched}/{display_total})[/COLOR][/B]"
            else:
                label = f"{_ip_name} [B][COLOR FF6AFB92]({curr_watched}/{display_total})[/COLOR][/B]"
        label_cache = label
        air_key = None
        try:
            _ip_key = (str(tmdb_id), int(item.get('season') or 0), int(item.get('episode') or 0))
            _ip_stamp = _ip_at_map.get(_ip_key) if _ip_at_map is not None else None
            if _ip_stamp is None:
                try:
                    _ip_stamp = get_episode_air_stamp(tmdb_id, item.get('season'), item.get('episode'))
                except:
                    _ip_stamp = None
            _ip_at = _ip_stamp[1] if _ip_stamp else ''
            _ip_ad = str(item.get('air_date', '')).split('T')[0]
            _ip_parts = _ip_ad.split('-')
            _ip_d = datetime.date(int(_ip_parts[0]), int(_ip_parts[1]), int(_ip_parts[2]))
            _ip_d = air_effective_date(_ip_d, _ip_stamp, datetime.date.today())
            if _ip_d >= datetime.date.today():
                _ip_diff = (_ip_d - datetime.date.today()).days
                if _ip_diff == 0:
                    _ip_when = calendar_localized_label(0, '')
                elif _ip_diff == 1:
                    _ip_when = calendar_localized_label(1, _ip_d.isoformat())
                else:
                    _ip_when = _fmt_dmy(_ip_ad)
                # Data se afiseaza mereu; ora doar cind o stim. In cache ramane
                # tokenul, deci ora se completeaza la randare (live + fast cache)
                # fara sa fie nevoie de re-prefetch sau de re-salvare a listei.
                if _ip_diff == 0 and _ip_name:
                    # Azi: numele serialului + eticheta, galben bold. Rebuild
                    # din nume (nu infasurarea labelului, care isi are deja
                    # inchiderea /B si ar lasa un [/B] vizibil).
                    _cnt = ' [B][COLOR FF6AFB92](%d/%s)[/COLOR][/B]' % (curr_watched, display_total)
                    if curr_total > 0 and curr_watched >= curr_total:
                        _cnt = ' [B][COLOR lime](Complet)[/COLOR][/B]'
                    label_cache = f"[B][COLOR yellow]{_ip_name}[/COLOR][/B]{_cnt} [B][COLOR yellow]({_ip_when}{AIR_TIME_TOKEN})[/COLOR][/B]"
                else:
                    label_cache = f"{label} [COLOR yellow]({_ip_when}{AIR_TIME_TOKEN})[/COLOR]"
                label = apply_air_time(label_cache, _ip_at)
                air_key = _ip_key
        except:
            label_cache = label

        li = xbmcgui.ListItem(label)
        li.setArt(art)
        set_metadata(li, info, unique_ids={'tmdb': tmdb_id, 'imdb': imdb_id}, watched_info=watched_info_dict)
        if cm: li.addContextMenuItems(cm)

        items_to_add.append((url, li, not _sel_info))
        cache_list.append({
            'label'      : label_cache,
            'air_key'    : air_key,
            'url'        : url,
            'is_folder'  : not _sel_info,
            'art'        : art,
            'info'       : info,
            'cm'         : cm,
            'resume_time': 0,
            'total_time' : 0,
            'properties' : {
                'TotalEpisodes': str(watched_info_dict['total']) if watched_info_dict['total'] > 0 else '0',
                'WatchedEpisodes': str(watched_info_dict['watched']),
                'UnWatchedEpisodes': str(max(0, watched_info_dict['total'] - watched_info_dict['watched'])) if watched_info_dict['total'] > 0 else '',
                'PercentPlayed': str(int((float(watched_info_dict['watched'])/float(watched_info_dict['total']))*100)) if (watched_info_dict['total'] > 0 and 0 < watched_info_dict['watched'] < watched_info_dict['total']) else '',
            }
        })

    _t_build = time.time()
    log(f"[IN PROGRESS] rebuild {int((_t_build - _t_start) * 1000)}ms "
        f"(prefetch+warm={int((_t_warm - _t_start) * 1000)}, randuri={int((_t_build - _t_warm) * 1000)}, "
        f"items={len(valid_shows)}, randuri_finale={len(cache_list)})")

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))
    
    xbmcplugin.setContent(HANDLE, 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('tvshows')


    set_fast_cache(cache_key, cache_list)
    _list_build_clear(cache_key)


def in_progress_episodes(params):
    """Afiseaza episoadele cu PLOT si METADATA COMPLETE (fara paginare)."""
    from resources.lib.providers import trakt_sync
    from concurrent.futures import ThreadPoolExecutor
    
    from resources.lib.providers.watched_provider import _get_provider_raw as _get_prov
    use_mdblist = _get_prov() == 'mdblist'
    use_simkl = _get_prov() == 'simkl'
    use_punchplay = _get_prov() == 'punchplay'
    use_local = _get_prov() == 'local'
    from resources.lib.core.utils import skip_ext_info_in_progress as _skip_ip

    cache_key = f"in_progress_episodes_all_{use_mdblist}_{use_simkl}_{use_punchplay}_{use_local}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='episode_lists')
        return
    
    try: icon = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media', 'player.png')
    except: icon = 'DefaultIcon.png'
    
    all_results = trakt_sync.get_in_progress_episodes_from_db()
    
    if not all_results:
        if use_mdblist:
            add_directory("[COLOR cyan]No episodes paused midway. Sync MDBList.[/COLOR]", {'mode': 'mdblist_sync'}, folder=False, icon='DefaultIconInfo.png')
        elif use_simkl:
            add_directory("[COLOR cyan]No episodes paused midway. Sync Simkl.[/COLOR]", {'mode': 'simkl_sync'}, folder=False, icon='DefaultIconInfo.png')
        elif use_punchplay:
            add_directory("[COLOR cyan]No episodes paused midway. Sync PunchPlay.[/COLOR]", {'mode': 'punchplay_sync'}, folder=False, icon='DefaultIconInfo.png')
        elif use_local:
            add_directory("[COLOR cyan]No episodes paused midway yet - play something or mark an episode as watched (Kodi Local).[/COLOR]", {'mode': 'main'}, folder=False, icon='DefaultIconInfo.png')
        else:
            add_directory("[COLOR cyan]No episodes paused midway. Sync Trakt.[/COLOR]", {'mode': 'trakt_sync_db'}, folder=False, icon='DefaultIconInfo.png')
        xbmcplugin.endOfDirectory(HANDLE)
        return
    
    # 1. Trage detaliile serialelor in paralel
    prefetch_metadata_parallel(all_results, 'tv')
    
    # 2. Season prefetch (session dedicata + timeout scurt, inchisa la final)
    import threading, requests
    from resources.lib.core.config import BASE_URL, API_KEY, get_headers, get_plot_language, get_plot_language_code
    from resources.lib.core.cache import ram_cache_set_season

    ip_lang = get_plot_language_code()
    ip_tmdb_lang = get_plot_language()
    in_progress_session = requests.Session()
    def _prefetch_in_progress_season_worker(it):
        if xbmc.Monitor().abortRequested(): return
        try:
            t_id = str(it.get('id') or it.get('tmdb_id', ''))
            s_num = int(it.get('season', 0))
            if not t_id or not s_num: return
            url = f"{BASE_URL}/tv/{t_id}/season/{s_num}?api_key={API_KEY}&language={ip_tmdb_lang}"
            res = in_progress_session.get(url, headers=get_headers(), timeout=0.25)
            if res.status_code == 200:
                data = res.json()
                data['_cached_lang'] = ip_lang
                ram_cache_set_season(t_id, s_num, data)
        except:
            pass

    for itm in all_results:
        t = threading.Thread(target=_prefetch_in_progress_season_worker, args=(itm,))
        t.daemon = True
        t.start()

    items_to_add = []
    cache_list = []

    for item in all_results:
        tmdb_id = str(item.get('id') or item.get('tmdb_id', ''))
        if not tmdb_id: continue

        season = int(item.get('season', 0))
        episode = int(item.get('episode', 0))
        
        ep_plot = ''
        rating, votes, premiered, duration = 0.0, 0, '', 0
        
        show_details = get_tmdb_item_details(tmdb_id, 'tv')
        show_name = show_details.get('name', 'Unknown Show') if show_details else 'Unknown Show'
        
        show_imdb_id = ''
        show_mpaa = ''
        show_logo = ''
        studio = ''
        
        if show_details:
            show_mpaa = show_details.get('mpaa', '')
            raw_logo = show_details.get('clearlogo', '')
            show_logo = f"{IMG_BASE}{raw_logo}" if raw_logo and not raw_logo.startswith('http') else raw_logo
            if show_details.get('networks'): studio = [n['name'] for n in show_details['networks']]
            show_imdb_id = show_details.get('external_ids', {}).get('imdb_id', '')

        db_title = item.get('title') or item.get('name', f'Episode {episode}')
        ep_name = db_title.split(' - ')[-1].strip() if ' - ' in db_title else db_title
        
        season_data = get_smart_season_details(tmdb_id, season)
        
        ep_still = ''
        ep_type = ''
        if season_data:
            total_eps_in_season = len(season_data.get('episodes',[]))
            show_status = show_details.get('status', '') if show_details else ''
            total_seasons = show_details.get('number_of_seasons', 0) if show_details else 0
            
            for ep in season_data.get('episodes',[]):
                if ep.get('episode_number') == episode:
                    if ep.get('overview'): ep_plot = ep.get('overview')
                    if ep.get('still_path'): ep_still = ep.get('still_path')
                    if ep.get('name'): ep_name = ep.get('name')
                    rating = float(ep.get('vote_average', 0))
                    votes = int(ep.get('vote_count', 0))
                    premiered = ep.get('air_date', '')
                    try:
                        duration = int(ep.get('runtime') or 0) * 60
                    except:
                        duration = 0
                        
                    if duration <= 0:
                        try:
                            runtimes = show_details.get('episode_run_time', []) if show_details else []
                            duration = int(runtimes[0]) * 60 if runtimes and runtimes[0] else 2700
                        except:
                            duration = 2700
                    
                    api_ep_type = ep.get('episode_type', '')
                    ep_type = api_ep_type
                    if episode == 1:
                        ep_type = 'series_premiere' if season == 1 else 'season_premiere'
                    elif total_eps_in_season > 0 and episode == total_eps_in_season:
                        if show_status in ['Ended', 'Canceled'] and season == total_seasons:
                            ep_type = 'series_finale'
                        else:
                            ep_type = 'season_finale'
                    elif api_ep_type == 'mid_season':
                        ep_type = 'mid_season_finale'
                        
                    break
        
        progress_raw = float(item.get('progress', 0))
        resume_seconds = 0
        progress_percent = 0

        if progress_raw >= 1000000:
            resume_seconds = int(progress_raw - 1000000)
            if duration > 0:
                progress_percent = (resume_seconds / duration) * 100
        elif 0 < progress_raw < 90:
            progress_percent = progress_raw
            if duration > 0:
                resume_seconds = int((progress_percent / 100.0) * duration)
            
        try: art_pref = ADDON.getSetting('episodes_art')
        except: art_pref = '0'

        season_poster_path = season_data.get('poster_path', '') if season_data else ''
        if not season_poster_path and show_details: season_poster_path = show_details.get('poster_path', '')
        base_poster = f"{IMG_BASE}{season_poster_path}" if season_poster_path else ''
        
        show_fanart_path = show_details.get('backdrop_path', '') if show_details else ''
        base_fanart = f"{BACKDROP_BASE}{show_fanart_path}" if show_fanart_path else base_poster

        has_still = bool(ep_still)
        if art_pref == '3':
            ep_icon = base_poster
            final_fanart = f"{IMG_BASE}{ep_still}" if has_still else base_fanart
        elif art_pref == '2':
            ep_icon = base_poster
            final_fanart = base_fanart
        elif art_pref == '1':
            ep_icon = f"{IMG_BASE}{ep_still}" if has_still else base_poster
            final_fanart = f"{IMG_BASE}{ep_still}" if has_still else base_fanart
        else:
            ep_icon = f"{IMG_BASE}{ep_still}" if has_still else base_poster
            final_fanart = base_fanart
        
        show_watched_info = get_watched_status_tvshow(tmdb_id)
        unwatched_count = 0
        if show_watched_info['total'] > 0:
            unwatched_count = max(0, show_watched_info['total'] - show_watched_info['watched'])

        try: skin_compat = ADDON.getSetting('skin_type')
        except: skin_compat = '0'

        from resources.lib.providers.watched_provider import is_mdblist as _is_mdb_provider
        _show_clr = 'lightskyblue' if _is_mdb_provider() else 'FF00CED1'
        display_label = f"[B][COLOR {_show_clr}]{show_name}[/COLOR][/B] - [B][COLOR FFCCCCCC]S{season:02d}E{episode:02d}[/COLOR][/B] - [B][COLOR FFCCCCFF][I]{ep_name}[/I][/COLOR][/B]"
        
        if skin_compat == '0' and unwatched_count > 0:
            display_label += f" [COLOR orange] ({unwatched_count})[/COLOR]"

        display_plot = f"[B][COLOR orange]Progress: {int(progress_percent)}%[/COLOR][/B]\n{ep_plot}"

        info = {
            'mediatype': 'episode', 'title': ep_name,
            'plot': display_plot,
            'tvshowtitle': show_name, 'season': season, 'episode': episode,
            'resume_percent': progress_percent, 'rating': rating, 'votes': votes, 'premiered': premiered,
            'duration': duration, 'studio': studio, 'mpaa': show_mpaa
        }
        
        try:
            from resources.lib.providers.watched_provider import get_label as _prov_label, get_color as _prov_color, mark_menu_label as _mml, browse_command as _browse_cmd
        except ImportError:
            from resources.lib.providers.watched_provider import get_label as _prov_label, get_color as _prov_color, mark_menu_label as _mml
            _browse_cmd = lambda url: 'Container.Update(%s)' % url
        _prov_lbl = _prov_label()
        _prov_clr = _prov_color()
        cm = [
            (_mml(False) or f'[B][COLOR FF6AFB92]Mark Watched [COLOR {_prov_clr}]({_prov_lbl})[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?mode=mark_watched&tmdb_id={tmdb_id}&type=episode&season={season}&episode={episode})"),
            ('[B]Scrape with Custom Values[/B]', f"RunPlugin({PLUGIN_URL}?mode=sources&tmdb_id={tmdb_id}&type=tv&title={quote_plus(show_name)}&season={season}&episode={episode}&custom_interactive=true)"),
            ('[B][COLOR FFFF4444]Delete Resume[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?mode=remove_progress&tmdb_id={tmdb_id}&type=episode&season={season}&episode={episode}&tv_show_title={quote_plus(show_name)})")
        ]
        # Are rost doar cu auto-play pornit (altfel selectul randului deschide
        # deja fereastra surselor); no_auto=1 ocoleste autoplay-ul.
        if ADDON.getSetting('auto_play') == 'true':
            cm.append(('[B][COLOR cyan]Play with source select[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?mode=sources&tmdb_id={tmdb_id}&type=tv&season={season}&episode={episode}&title={quote_plus(ep_name)}&tv_show_title={quote_plus(show_name)}&no_auto=1)"))
        # --- SELECT ACTION: rindul e redirectionat catre Extended Info -> Play in CM ---
        if select_ext_info_params('episode', tmdb_id, season, episode, show_name, ep_name):
            cm.insert(0, ('[B][COLOR FF6AFB92]Play Episode[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?mode=sources&tmdb_id={tmdb_id}&type=tv&season={season}&episode={episode}&title={quote_plus(ep_name)}&tv_show_title={quote_plus(show_name)})"))
        # -------------------------------------------------------------------------
        if ADDON.getSetting('show_cm_my_plays') != 'false':
            cm.insert(1, ('[B][COLOR FFFF69B4]My Plays[/COLOR][/B]', f"RunPlugin({PLUGIN_URL}?mode=show_my_plays_menu&tmdb_id={tmdb_id}&type=episode&title={quote_plus(show_name)}&ep_name={quote_plus(ep_name)}&season={season}&episode={episode}&imdb_id={show_imdb_id}&premiered={premiered})"))
        
        cm = calendar_context_menu(cm, 'episode', tmdb_id, show_name, season=season, episode=episode,
                                   base_url=PLUGIN_URL, browse_cmd=_browse_cmd, urlencode_fn=urlencode,
                                   clear_sources=True)
        
        if _skip_ip():
            url_params = None
        else:
            url_params = select_ext_info_params('episode', tmdb_id, season, episode, show_name, ep_name)
        url_params = url_params or {'mode': 'sources', 'tmdb_id': tmdb_id, 'type': 'tv', 'season': str(season), 'episode': str(episode), 'title': ep_name, 'tv_show_title': show_name}
        
        url = plugin_url(url_params)
        
        li = xbmcgui.ListItem(display_label)
        
        try: skin_compat = ADDON.getSetting('skin_type')
        except: skin_compat = '0'
        
        # AF3 ascunde thumb-ul daca e identic cu posterul → la modurile Poster (2/3)
        # thumb/landscape devin still-ul episodului (thumb != poster)
        if art_pref in ('2', '3'):
            thumb_art = f"{IMG_BASE}{ep_still}" if has_still else ''
            landscape_art = thumb_art or ep_icon
        else:
            thumb_art = ep_icon
            landscape_art = ep_icon

        art_dict = {
            'thumb': thumb_art,
            'icon': ep_icon, 
            'landscape': landscape_art,
            'tvshow.landscape': landscape_art,
            'tvshow.poster': base_poster, 
            'season.poster': base_poster, 
            'fanart': final_fanart
        }
        
        if skin_compat == '1':
            art_dict['poster'] = base_poster
        else:
            art_dict['poster'] = ep_icon
            
        if show_logo: art_dict['clearlogo'] = show_logo
        li.setArt(art_dict)
        
        _safe_set_prop(li, 'tmdb_id', tmdb_id)
        if ep_type:
            _safe_set_prop(li, 'episode_type', ep_type)
            
        set_metadata(li, info, unique_ids={'tmdb': str(tmdb_id), 'imdb': show_imdb_id}, watched_info=show_watched_info)
        set_resume_point(li, resume_seconds, duration)
        
        if cm: li.addContextMenuItems(cm)
        
        items_to_add.append((url, li, False))
        
        cache_list.append({
            'label': display_label,
            'url': url,
            'is_folder': False,
            'art': art_dict,
            'info': info,
            'cm': cm,
            'resume_time': resume_seconds,
            'total_time': duration,
            'properties': {
                'episode_type': ep_type,
                'TotalEpisodes': str(show_watched_info['total']) if show_watched_info['total'] > 0 else '0',
                'WatchedEpisodes': str(show_watched_info['watched']),
                'UnWatchedEpisodes': str(max(0, show_watched_info['total'] - show_watched_info['watched'])) if show_watched_info['total'] > 0 else '',
                'PercentPlayed': str(int((float(show_watched_info['watched'])/float(show_watched_info['total']))*100)) if (show_watched_info['total'] > 0 and 0 < show_watched_info['watched'] < show_watched_info['total']) else '',
            }
        })
        
    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))
        
    xbmcplugin.setContent(HANDLE, 'episodes')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('episode_lists', 'episodes')

    
    set_fast_cache(cache_key, cache_list)
    try:
        in_progress_session.close()
    except:
        pass


def get_next_episodes(params=None, cache_only=False, warm_only=False):
    """Afiseaza Next Episodes (Up Next) cu sortare avansata si filtrare 'dropped'.
    Sursa e dinamica: providerul de watched status decide (MDBList → mdblist_next_episodes,
    altfel → trakt_next_episodes).

    cache_only=True: construieste lista si o salveaza in fast cache, fara sa
    creeze ListItem-uri si fara sa atinga Kodi (nici addDirectoryItems, nici
    endOfDirectory). Folosit de threadul de avansare, ca randarea de la intoarcerea
    din player sa fie un simplu cache-hit de ~300ms in loc de ~1800ms.

    warm_only=True: se opreste dupa incalzirea cache-urilor (metadate + sezoane +
    watched + total episoade), fara bucla de randare si fara scriere in cache.
    Folosit la 85% din player, cu ~35s inainte de stop.
    """
    import datetime
    from resources.lib.providers import trakt_sync

    if warm_only:
        # Log la INTRARE, nu la final: daca functia se opreste mai jos (cache
        # disponibil, lista goala, exceptie), vedem ca a pornit dar n-a terminat.
        log(f"[UP NEXT] warm-only: pornit (use_tmdb={bool(params and params.get('use_tmdb') == 'true')})")

    # 1. OBTINEREA DATELOR BRUTE DIN BAZA DE DATE LOCALA (sursa dinamica pe provider)
    try:
        from resources.lib.providers.watched_provider import _get_provider_raw as _get_prov, browse_command as _browse_cmd
    except ImportError:
        from resources.lib.providers.watched_provider import _get_provider_raw as _get_prov
        _browse_cmd = lambda url: 'Container.Update(%s)' % url
    use_tmdb = bool(params and params.get('use_tmdb') == 'true')
    use_local = not use_tmdb and _get_prov() == 'local'
    use_mdblist = not use_tmdb and _get_prov() == 'mdblist'
    use_simkl = not use_tmdb and _get_prov() == 'simkl'
    use_punchplay = not use_tmdb and _get_prov() == 'punchplay'
    # Amintirea "ce lista Up Next e pe ecran" se scrie DOAR la o randare reala.
    #
    # threadul de avansare (la stop) nu poate citi Container.FolderPath (in
    # timpul redarii e gol), deci are nevoie de amintirea ultimei liste randate.
    #
    # Dar build-urile de FUNDAL (cache_only / warm_only: pre-randarea de la stop,
    # incalzirea de la 85%, ciclurile de dupa sync) nu randeaza nimic pe ecran si
    # totusi rescriau amintirea cu varianta pe care o construiau ELE - iar
    # ultimul build din ciclu e mereu "cealalta" varianta. Efectul, masurat pe
    # log (19:34, mansh/MDBList): userul era in ?mode=mdblist_upnext (varianta
    # provider), iar amintirea zicea "tmdb" pentru ca warm-up-ul de la 85%
    # construise tmdb. Safety pass-ul din player a validat atunci stampul listei
    # tmdb, a re-randat prea devreme si a servit cache-ul VECHI al listei
    # vizibile, iar re-randarea care ar fi reparat-o a fost suprimate.
    if not cache_only and not warm_only:
        try:
            from resources.lib.core.list_render import remember_upnext_view
            remember_upnext_view('tmdb' if use_tmdb else 'provider')
        except Exception:
            pass
    show_color = 'FF00CED1' if use_tmdb else provider_color('local' if use_local else ('mdblist' if use_mdblist else ('simkl' if use_simkl else ('punchplay' if use_punchplay else 'trakt'))))
    # Momentul CITIRII randurilor din DB. Stampul de "build terminat" scris la
    # final trebuie sa fie acesta, nu momentul scrierii: un build pornit inainte
    # de marcaj poate termina dupa el si ar scrie lista veche cu stamp proaspat
    # (log real: build pornit 22:42:12.8, marcaj 22:42:21.4, scriere 22:42:28.6).
    _t_rows = time.time()
    if use_tmdb:
        raw_items = trakt_sync.get_tmdb_next_episodes_from_db()
    elif use_local:
        from resources.lib.providers.local_sync import get_next_episodes_from_db as _loc_next
        raw_items = _loc_next()
        for _it in raw_items:
            _it.setdefault('overview', '')
            _it.setdefault('poster', '')
    elif use_mdblist:
        from resources.lib.providers.mdblist_sync import get_next_episodes_from_db as _mdb_next
        raw_items = _mdb_next()
        for _it in raw_items:
            _it.setdefault('overview', '')
            _it.setdefault('poster', '')
    elif use_simkl:
        from resources.lib.providers.simkl_sync import get_next_episodes_from_db as _sk_next
        raw_items = _sk_next()
        for _it in raw_items:
            _it.setdefault('overview', '')
            _it.setdefault('poster', '')
    elif use_punchplay:
        from resources.lib.providers.punchplay_sync import get_next_episodes_from_db as _pp_next
        raw_items = _pp_next()
        for _it in raw_items:
            _it.setdefault('overview', '')
            _it.setdefault('poster', '')
    else:
        raw_items = trakt_sync.get_next_episodes_from_db()

    # 3. FILTRAREA SERIALELOR ABANDONATE (DROPPED/HIDDEN) - LOGICA NOUA
    #    (mdblist exclude deja mdblist_dropped in interogarea sa; simkl_next_episodes
    #    contine doar seriale cu status 'watching', deci dropped sunt excluse implicit)
    #    TMDB Up Next: tabela de dropped a providerului ACTIV (trakt_hidden_shows /
    #    mdblist_dropped / simkl_dropped) — sectiunea 1 se comporta ca Trakt,
    #    iar serialele neincepute dropped nu apar la coada.
    if use_tmdb:
        try:
            from resources.lib.providers.watched_provider import _get_provider_raw as _get_prov_raw
            _prov = _get_prov_raw()
            _drop_tbl = {'trakt': 'trakt_hidden_shows', 'mdblist': 'mdblist_dropped', 'simkl': 'simkl_dropped', 'punchplay': 'punchplay_dropped'}.get(_prov)
            if _drop_tbl:
                from resources.lib.providers.watched_provider import get_source_module as _get_src_mod
                _conn = _get_src_mod().get_connection()
                _c = _conn.cursor()
                _c.execute("SELECT tmdb_id FROM %s" % _drop_tbl)
                _hidden = {str(row['tmdb_id']) for row in _c.fetchall()}
                _conn.close()
                if _hidden:
                    _init_cnt = len(raw_items)
                    raw_items = [item for item in raw_items if str(item.get('tmdb_id')) not in _hidden]
                    _removed = _init_cnt - len(raw_items)
                    if _removed > 0:
                        log(f"[UP NEXT] TMDB Up Next filtered out {_removed} dropped/hidden shows ({_prov}).")
        except Exception as e:
            log(f"[UP NEXT] TMDB Up Next error filtering dropped: {e}", xbmc.LOGERROR)
    elif not use_mdblist and not use_simkl and not use_punchplay:
        try:
            conn = trakt_sync.get_connection()
            c = conn.cursor()
            c.execute("SELECT tmdb_id FROM trakt_hidden_shows")
            hidden_tmdb_ids = {row['tmdb_id'] for row in c.fetchall()}
            conn.close()
            
            if hidden_tmdb_ids:
                initial_count = len(raw_items)
                raw_items = [item for item in raw_items if str(item.get('tmdb_id')) not in hidden_tmdb_ids]
                removed_count = initial_count - len(raw_items)
                if removed_count > 0:
                    log(f"[UP NEXT] Filtered out {removed_count} dropped/hidden shows.")
        except Exception as e:
            log(f"[UP NEXT] Error filtering hidden shows: {e}", xbmc.LOGERROR)
    
    # Filtru neincepute: original TMDb exact (restaurat) + extensie Trakt/MDBList/Simkl
    unstarted_items = []
    if use_tmdb:
        try:
            show_unstarted = ADDON.getSetting('tmdb_upnext_show_unstarted') == 'true'
        except:
            show_unstarted = True
        if show_unstarted:
            unstarted_items = [it for it in raw_items if int(it.get('watched_count') or 0) == 0]
            raw_items = [it for it in raw_items if int(it.get('watched_count') or 0) > 0]
        else:
            raw_items = [it for it in raw_items if int(it.get('watched_count') or 0) > 0]
    else:
        try:
            show_unstarted = ADDON.getSetting('tmdb_upnext_show_unstarted') == 'true'
        except:
            show_unstarted = True
        def _is_unstarted(it):
            if 'watched_count' not in it or it.get('watched_count') is None:
                return False
            try:
                return int(it.get('watched_count') or 0) == 0
            except:
                return False
        if show_unstarted:
            unstarted_items = [it for it in raw_items if _is_unstarted(it)]
            raw_items = [it for it in raw_items if not _is_unstarted(it)]
        else:
            raw_items = [it for it in raw_items if not _is_unstarted(it)]
    
    today = datetime.date.today()
    max_future_date = today + datetime.timedelta(days=7)

    # 2. CITIREA SETARILOR DIN settings.xml
    try:
        show_future = ADDON.getSetting('upnext_show_future') == 'true'
    except:
        show_future = False
    from resources.lib.core.utils import skip_ext_info_upnext as _skip_un

    # 4. SEPARAREA EPISOADELOR PE CATEGORII
    available_now = []
    upcoming_soon = []
    later = []
    tba = []

    for item in raw_items:
        air_date_str = item.get('air_date', '')
        
        if not air_date_str:
            if show_future: 
                tba.append(item)
            continue
            
        try:
            parts = str(air_date_str).split('T')[0].split('-')
            air_date = datetime.date(int(parts[0]), int(parts[1]), int(parts[2]))
        except:
            if show_future: 
                tba.append(item)
            continue
        
        # Aplicam filtrele de data, inclusiv cel de 7 zile
        if air_date <= today:
            available_now.append(item)
        elif today < air_date <= max_future_date:
            upcoming_soon.append(item)
        else: # Mai mult de 7 zile in viitor
            if show_future: 
                later.append(item)
            
    # 5. SORTAREA INTELIGENTA (REPARATA SI MAI ROBUSTA)
    # Helper pentru a asigura un timestamp valid la sortare
    def get_last_watched_ts(x):
        lw = x.get('last_watched_at')
        if not lw: 
            return 1
            
        try:
            d_str = str(lw).replace('Z', '').split('.')[0]
            date_part, time_part = d_str.split('T')
            y, m, d = map(int, date_part.split('-'))
            H, M, S = map(int, time_part.split(':'))
            return datetime.datetime(y, m, d, H, M, S).timestamp()
        except:
            try:
                d_str = str(lw).split('T')[0]
                y, m, d = map(int, d_str.split('-'))
                return datetime.datetime(y, m, d, 0, 0, 0).timestamp()
            except:
                return 1

    # A. Disponibile acum: sortate descrescator dupa ultima vizionare EXACTA
    available_now.sort(key=get_last_watched_ts, reverse=True)
    
    # B. Urmatoarele 7 zile: sortate cronologic (cel mai apropiat primul)
    upcoming_soon.sort(key=lambda x: x.get('air_date', ''))
    
    # C. Celelalte liste (daca sunt active)
    if show_future:
        # Peste 7 zile: sortate cronologic dupa data lansarii
        later.sort(key=lambda x: x.get('air_date', ''))
        # TBA: sortate alfabetic dupa numele serialului
        tba.sort(key=lambda x: x.get('show_title', ''))
        # Combinam listele strict in aceasta ordine
        items = available_now + upcoming_soon + later + tba
    else:
        # Daca setarea e OFF, ignoram complet later si tba
        items = available_now + upcoming_soon

    # D. Serialele neincepute (TMDB Up Next) la COADA listei, sortate dupa data
    #    difuzarii primului episod (cele fara data la final)
    if unstarted_items:
        unstarted_items.sort(key=lambda x: (x.get('air_date') or '9999'))
        items = items + unstarted_items

    # 6. CONSTRUIREA LISTEI FINALE
    if not items:
        if cache_only:
            return
        if use_tmdb:
            add_directory("[COLOR gray]No new episodes (Run 'Refresh TMDb Lists')[/COLOR]", {'mode': 'tmdb_refresh_lists'}, folder=False)
        elif use_mdblist:
            add_directory("[COLOR gray]No new episodes (Run 'MDBList Sync')[/COLOR]", {'mode': 'mdblist_sync'}, folder=False)
        elif use_simkl:
            add_directory("[COLOR gray]No new episodes (Run 'Simkl Sync')[/COLOR]", {'mode': 'simkl_sync'}, folder=False)
        elif use_punchplay:
            add_directory("[COLOR gray]No new episodes (Run 'PunchPlay Sync')[/COLOR]", {'mode': 'punchplay_sync'}, folder=False)
        elif use_local:
            add_directory("[COLOR cyan]No new episodes yet - mark a show as watched (right-click > Mark Watched), or sync your Kodi library.[/COLOR]", {'mode': 'main'}, folder=False, icon='DefaultIconInfo.png')
        else:
            add_directory("[COLOR gray]No new episodes (Run 'Trakt Sync')[/COLOR]", {'mode': 'trakt_sync_db'}, folder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Fast cache check (LABEL_VERSION e in list_render, sursa unica a cheii)
    cache_key = next_episodes_cache_key(params, use_tmdb=use_tmdb, use_mdblist=use_mdblist,
                                        use_simkl=use_simkl, use_punchplay=use_punchplay,
                                        use_local=use_local)
    # warm_only nu se opreste pe cache: daca exista o lista in cache, returnul
    # timpuriu ar face warm-ul sa nu incalzeasca nimic (exact cand e nevoie).
    #
    # CARPE DE CORECTITUDINE: dupa un marcaj, lista e servita intentionat "veche"
    # (stale-while-revalidate) ca sa nu ramana containerul negru. Dar daca
    # pre-randarea nu reuseste sa o rescrie (thread pierdut, device lent, erroare),
    # lista ar ramane veche la nesfarsit. Deci dupa UP_NEXT_STALE_MAX_S ignoram
    # cache-ul si construim din DB - corect, cu build de ~8s in schimb.
    _stale = False
    try:
        from resources.lib.core.cache import upnext_stale_since as _read_ss
        _ss = _read_ss()
        _stale = _ss > 0 and (time.time() - _ss) > UP_NEXT_STALE_MAX_S
    except Exception:
        _stale = False
    if _stale:
        try:
            log(f"[UP NEXT] cache ignorat: lista e veche de {int(time.time() - _ss)}s, reconstruiesc")
        except Exception:
            pass
        # Inchidem fereastra stale-while-revalidate: golirile de lista trebuie sa
        # revina la normal, altfel clear_list_fast_cache() ar ramane blocat.
        try:
            xbmcgui.Window(10000).clearProperty('tmdbmovies.upnext_stale_since')
        except Exception:
            pass
        cached_data = None
    else:
        cached_data = None if (cache_only or warm_only) else get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='episode_lists')
        log(f"[UP NEXT] din fast cache: {len(cached_data)} randuri (instant, "
            f"varianta {'tmdb' if use_tmdb else 'provider'})")
        return

    # Alt proces construieste deja ACEASTA lista (widget-ul din skin + containerul
    # + refresh-urile pornesc in paralel si randeau 3-5s fiecare in acelasi timp
    # -> pagina goala / crash). Asteptam putin cache-ul lui in loc sa re-construim.
    #
    # EXCEPTIE warm_only: incalzirea NU participa la lock. Daca aici ar astepta,
    # s-ar bloca pana termina randarea in curs, deci nu ar incalzi nimic — chiar
    # inversul scopului ei. Incalzirea e idempotenta si nu scrie lista in cache,
    # deci poate rula linistit alaturi de o randare.
    cached_data = None if warm_only else _list_build_wait(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='episode_lists')
        log(f"[UP NEXT] din fast cache: {len(cached_data)} randuri (build preluat "
            f"de alt proces, varianta {'tmdb' if use_tmdb else 'provider'})")
        return

    _t_start = time.time()
    # Prefetch-ul ramane pentru viteza (Trage detaliile serialelor in paralel)
    prefetch_metadata_parallel(items, 'tv')
    _t_prefetch = time.time()

    # Incalzire cache-uri show+season in paralel, cu deadline: prima intrare
    # cu cache gol facea zeci de HTTP secventiale in bucla de mai jos (~15s).
    from concurrent.futures import ThreadPoolExecutor, as_completed
    def _warm_up_next_worker(it):
        try:
            if xbmc.Monitor().abortRequested():
                return
            get_tmdb_item_details(str(it['tmdb_id']), 'tv', lightweight=True)
        except:
            pass
        try:
            if xbmc.Monitor().abortRequested():
                return
            get_smart_season_details(str(it['tmdb_id']), it['season'])
        except:
            pass
    # Bugetul de asteptare al warm-up-ului. 10s la `warm_only` (pasul de la 85%,
    # in timpul redarii: nimeni nu asteapta lista acum, umplem cache-urile cit
    # incap pentru randarea de dupa stop). 3s cind lista se construieste ACUM,
    # pentru user sau pentru pre-randarea de la marcaj: dincolo de buget nu mai
    # asteptam - cele 10 threaduri rup oricum in fundal si umplu cache-urile
    # (supravietuiesc marcarii), iar bucla de mai jos nu mai iese in retea.
    _warm_budget = 10.0 if warm_only else 3.0
    _warm_ex = ThreadPoolExecutor(max_workers=10)
    try:
        _warm_futs = [_warm_ex.submit(_warm_up_next_worker, it) for it in items]
        for _f in as_completed(_warm_futs, timeout=_warm_budget):
            pass
    except:
        pass
    try:
        _warm_ex.shutdown(wait=False)
    except:
        pass
    try:
        # Orele de difuzare vin din Trakt/Simkl (0.5-2s cu buget de retea) si NU
        # sunt necesare ca lista sa fie afisata: apply_air_times_to_cache_items le
        # aplica la randare, iar randarea de dupa stop nu o mai astepta. De aceea
        # umplerea cache-ului merge in fundal, nu in calea critica a randarii.
        import threading as _thr_air
        _thr_air.Thread(target=prefetch_air_times, args=(list(items),), daemon=True).start()
    except:
        pass
    _t_warm = time.time()

    # Pre-citiri BULK: o singura conexiune sqlite pentru toata lista (inainte se
    # deschideau 4-5 conexiuni per rind, cu PRAGMA-uri de fiecare data).
    _keys = []
    for _x in items:
        try:
            _keys.append((str(_x['tmdb_id']), int(_x.get('season') or 0), int(_x.get('episode') or 0)))
        except:
            continue
    try:
        _at_map = get_episode_air_stamps(_keys)
    except:
        _at_map = None
    try:
        _prog_map = trakt_sync.get_local_playback_progress_map(_keys)
    except:
        _prog_map = None
    # Watched counts + total episoade: tot bulk (inainte: 2-3 conexiuni per rind).
    try:
        from resources.lib.providers import watched_provider as _wp
        _wc_map = _wp.get_watched_counts_map([str(x['tmdb_id']) for x in items])
    except:
        _wc_map = None
    try:
        _tv_meta_map = trakt_sync.get_tv_meta_map([str(x['tmdb_id']) for x in items])
    except:
        _tv_meta_map = None
    if _tv_meta_map:
        try:
            for _mk, _mv in _tv_meta_map.items():
                if _mv:
                    TV_META_CACHE[str(_mk)] = _mv
        except:
            pass

    # Detaliile serialelor: BULK, o singura conexiune SQLite. Inainte fiecare
    # rind deschidea propria conexiune (+ 4 PRAGMA) si isi decomprima propriul
    # blob - la 48 de rinduri, citeva secunde doar in deschideri de conexiune.
    # Pre-incalzim pool-ul RAM cu EXACT rindurile din DB; `get_tmdb_item_details`
    # din bucla face apoi un dict-hit, cu aceeasi filtrare pe limba ca inainte.
    try:
        _det_bulk = trakt_sync.get_tmdb_item_details_bulk(
            [str(x['tmdb_id']) for x in items], 'tv') or {}
    except Exception:
        _det_bulk = {}
    if _det_bulk:
        try:
            from resources.lib.core.cache import ram_pool_set, ram_cache_set_tvshow
            for _dk, _dv in _det_bulk.items():
                if isinstance(_dv, dict) and _dv:
                    ram_pool_set(_dk, _dv)
                    ram_cache_set_tvshow(_dk, _dv)
        except Exception:
            pass

    # Sezoanele lipsa din RAM/db se citesc acum BULK, cu o singura interogare
    # pentru toata lista, in loc de cate una per rand (2,5s pe Android). Doar
    # randurile care raman fara nimic in cache coboara pe calea cu retea.
    _season_bulk = {}
    try:
        _season_bulk = trakt_sync.get_tmdb_season_details_bulk(
            [(str(_x['tmdb_id']), int(_x.get('season') or 0)) for _x in items]) or {}
    except Exception:
        _season_bulk = {}

    # WARM_ONLY: am incalzit cache-urile (metadate, sezoane, watched, total episoade)
    # si ne oprim AICI, inainte de bucla de randare. Apelat la 85% din player, cu
    # ~35s inainte de stop: pe Android bucla de randare costa ~16s pentru 164 de
    # randuri, dar prefetch+warm doar ~4s, deci la intoarcere lista se construieste
    # mult mai repede. Cache-urile supravietuiesc marcarii (clear_list_fast_cache
    # atinge doar lista, nu metadatele).
    if warm_only:
        log(f"[UP NEXT] warm-only: {len(items)} randuri, cache-uri incalzite "
            f"({int((time.time() - _t_start) * 1000)}ms, fara randare)")
        try:
            _list_build_clear(cache_key)
        except Exception:
            pass
        return

    items_to_add = []
    cache_list = []

    # Setari citite O SINGURA DATA per build. Inainte erau 4-6 citiri native pe
    # rind (`skin_type` de doua ori, `episodes_art`, limba, skip_upnext,
    # select_ext_info de doua ori) - ~300 de traversari JNI per build pe Android,
    # pentru valori care nu se pot schimba in mijlocul construirii listei.
    try:
        art_pref = ADDON.getSetting('episodes_art')
    except Exception:
        art_pref = '0'
    try:
        skin_compat = ADDON.getSetting('skin_type')
    except Exception:
        skin_compat = '0'
    try:
        from resources.lib.core.config import get_plot_language_code as _gplc
        _plot_lang = _gplc()
    except Exception:
        _plot_lang = 'en'
    try:
        from resources.lib.core.cache import ram_cache_get_season as _ram_season
    except Exception:
        _ram_season = None
    try:
        _skip_un_round = bool(_skip_un())
    except Exception:
        _skip_un_round = False
    # Cheile deja vizionate: BULK, o singura conexiune. Meniul contextual al
    # fiecarui rind intreba asta din DB (`is_episode_watched`) - pe Windows 18ms
    # per rind, adica 88% din build (`faze=meniu=1135` din `randuri=1282`).
    # None = citirea a esuat -> meniul cade pe citirea per rind, ca inainte.
    try:
        from resources.lib.providers.watched_provider import get_watched_episode_keys_bulk as _wk_bulk
        _watched_keys = _wk_bulk([(str(_x['tmdb_id']), int(_x.get('season') or 0), int(_x.get('episode') or 0))
                                  for _x in items])
    except Exception:
        _watched_keys = None
    # Cronometre pe faze (dict-ul ajunge in logul `rebuild`): daca lista se simte
    # iar lent, urmatorul log spune exact ce faza maninca timpul.
    _ph = {}

    for it in items:
        tmdb_id = it['tmdb_id']
        _t_ph = time.time()
        
        # Serial neinceput (UP NEXT watchlist neinceput, toti providerii): watched_count==0 -> rosu
        try:
            is_unstarted = int(it.get('watched_count') or 0) == 0 if 'watched_count' in it else False
        except:
            is_unstarted = False
        
        # --- INCEPUT NOU: CALCUL EPISOADE RAMASE (AF3 / ESTUARY) ---
        if _wc_map is not None:
            show_watched_info = get_watched_status_tvshow(tmdb_id, watched_count=_wc_map.get(str(tmdb_id), 0))
        else:
            show_watched_info = get_watched_status_tvshow(tmdb_id)
        unwatched_count = 0
        if show_watched_info['total'] > 0:
            unwatched_count = max(0, show_watched_info['total'] - show_watched_info['watched'])
        # --- SFARSIT NOU ---
        _ph['watched'] = _ph.get('watched', 0.0) + (time.time() - _t_ph) * 1000.0
        _t_ph = time.time()
        
        # 1. Extragem datele complete si garantat RO/EN (Aici se intampla magia Clearlogo!)
        show_details = get_tmdb_item_details(tmdb_id, 'tv', lightweight=True, db_only=True)
        if not show_watched_info.get('total') and show_details and show_details.get('number_of_episodes'):
            try:
                _healed_total = int(show_details['number_of_episodes'])
                if _healed_total > 0:
                    trakt_sync.set_tv_meta_to_db(str(tmdb_id), _healed_total)
                    TV_META_CACHE[str(tmdb_id)] = _healed_total
                    show_watched_info = {'watched': show_watched_info.get('watched', 0), 'total': _healed_total}
                    unwatched_count = max(0, _healed_total - show_watched_info['watched'])
            except:
                pass
        imdb_id = show_details.get('external_ids', {}).get('imdb_id', '') if show_details else ''
        
        # 2. Extragem absolut tot ce vrea Kodi (Clearlogo, MPAA, Studio)
        raw_logo = show_details.get('clearlogo', '') if show_details else ''
        show_logo = f"{IMG_BASE}{raw_logo}" if raw_logo and not raw_logo.startswith('http') else raw_logo
        
        show_mpaa = show_details.get('mpaa', '') if show_details else ''
        studio = ''
        if show_details and show_details.get('networks'):
            studio = show_details['networks'][0].get('name', '')
        _ph['detalii'] = _ph.get('detalii', 0.0) + (time.time() - _t_ph) * 1000.0
        _t_ph = time.time()

        # 3. Metadate implicite episod (de la Trakt)
        ep_plot = it['overview']
        ep_still = ''
        rating = 0.0
        votes = 0
        duration = 0
        
        # 4. Gasim episodul in baza noastra TMDb pentru a lua Durata, Stelutele (Rating) si Voturile!
        #    Cache first (RAM → SQLite) + API fallback
        season_data = _ram_season(tmdb_id, it['season']) if _ram_season else None
        if season_data:
            if season_data.get('_cached_lang') != _plot_lang:
                season_data = None
        if not season_data:
            season_data = _season_bulk.get((str(tmdb_id), int(it.get('season') or 0)))
            if season_data:
                if season_data.get('_cached_lang') != _plot_lang:
                    season_data = None
        if not season_data:
            season_data = get_smart_season_details(tmdb_id, it['season'], db_only=True)
        if not season_data and not it.get('overview'):
            # Sezonul lipseste din cache, iar randul nu are overview de la provider:
            # citim plotul de rezerva din baza locala AICI, pentru ca fallback-ul de
            # mai jos sta sub `if season_data:` si nu s-ar mai executa (randul ar
            # ramine fara descriere pina la urmatoarea randare). Doar SQLite, fara retea.
            try:
                ep_plot = trakt_sync.get_tmdb_next_overview(tmdb_id, it['season'], it['episode']) or ep_plot
            except:
                pass
        ep_type = ''
        if season_data:
            total_eps_in_season = len(season_data.get('episodes',[]))
            show_status = show_details.get('status', '') if show_details else ''
            total_seasons = show_details.get('number_of_seasons', 0) if show_details else 0
            
            for ep in season_data.get('episodes',[]):
                if ep.get('episode_number') == it['episode']:
                    if ep.get('overview'): ep_plot = ep.get('overview')
                    if ep.get('still_path'): ep_still = ep.get('still_path')
                    ep_name_localized = ep.get('name', '').strip()
                    if ep_name_localized and not re.match(r'^[A-Za-z\u00c0-\u024f]+\s+\d+$', ep_name_localized):
                        it['ep_title'] = ep_name_localized
                    rating = ep.get('vote_average', 0.0)
                    votes = ep.get('vote_count', 0)
                    try:
                        duration = int(ep.get('runtime') or 0) * 60
                    except:
                        duration = 0
                        
                    if duration <= 0:
                        try:
                            runtimes = show_details.get('episode_run_time', []) if show_details else []
                            duration = int(runtimes[0]) * 60 if runtimes and runtimes[0] else 2700
                        except:
                            duration = 2700
                    
                    api_ep_type = ep.get('episode_type', '')
                    ep_type = api_ep_type
                    if it['episode'] == 1:
                        ep_type = 'series_premiere' if it['season'] == 1 else 'season_premiere'
                    elif total_eps_in_season > 0 and it['episode'] == total_eps_in_season:
                        if show_status in['Ended', 'Canceled'] and it['season'] == total_seasons:
                            ep_type = 'series_finale'
                        else:
                            ep_type = 'season_finale'
                    elif api_ep_type == 'mid_season':
                        ep_type = 'mid_season_finale'
                    break

            if not ep_plot:
                try:
                    ep_plot = trakt_sync.get_tmdb_next_overview(tmdb_id, it['season'], it['episode']) or ep_plot
                except:
                    pass

            # Determinam premiere/finale si pentru episoade nepublicate inca (ex: saptamana viitoare)
            if not ep_type and it['episode'] is not None:
                if it['episode'] == 1:
                    ep_type = 'series_premiere' if it['season'] == 1 else 'season_premiere'
                elif total_eps_in_season > 0 and it['episode'] == total_eps_in_season:
                    if show_status in['Ended', 'Canceled'] and it['season'] == total_seasons:
                        ep_type = 'series_finale'
                    else:
                        ep_type = 'season_finale'
                    
        _ph['sezon'] = _ph.get('sezon', 0.0) + (time.time() - _t_ph) * 1000.0
        _t_ph = time.time()

        # --- LOGICA NOUA IMAGINI UP NEXT (Standard Modern) ---
        season_poster_path = ''
        if season_data: season_poster_path = season_data.get('poster_path', '')
        if not season_poster_path and show_details: season_poster_path = show_details.get('poster_path', '')
        base_poster = f"{IMG_BASE}{season_poster_path}" if season_poster_path else (it.get('poster') or TRAKT_ICON)
        
        show_fanart_path = show_details.get('backdrop_path', '') if show_details else ''
        base_fanart = f"{BACKDROP_BASE}{show_fanart_path}" if show_fanart_path else base_poster

        has_still = bool(ep_still)
        
        if art_pref == '3':
            # Poster + Thumb
            ep_icon = base_poster
            final_fanart = f"{IMG_BASE}{ep_still}" if has_still else base_fanart
        elif art_pref == '2':
            # Poster + Fanart
            ep_icon = base_poster
            final_fanart = base_fanart
        elif art_pref == '1':
            # Thumb + Thumb
            ep_icon = f"{IMG_BASE}{ep_still}" if has_still else base_poster
            final_fanart = f"{IMG_BASE}{ep_still}" if has_still else base_fanart
        else:
            # 0: Thumb + Fanart (Hibrid)
            ep_icon = f"{IMG_BASE}{ep_still}" if has_still else base_poster
            final_fanart = base_fanart
        # ----------------------------------
        
        # Progresul si starea "vazut" sunt deja cunoscute (BULK): le dam meniului,
        # ca sa nu mai deschida el 2 conexiuni SQLite per rind.
        _prog_for_cm = None
        _watched_for_cm = None
        try:
            _cm_key = (str(tmdb_id), int(it['season'] or 0), int(it['episode'] or 0))
            if _prog_map is not None:
                _prog_for_cm = _prog_map.get(_cm_key, 0)
            if _watched_keys is not None:
                _watched_for_cm = _cm_key in _watched_keys
        except Exception:
            _prog_for_cm = None
            _watched_for_cm = None

        # --- START MODIFICARE: CALCUL RESUME PENTRU UP NEXT ---
        if _prog_for_cm is not None:
            progress_value = _prog_for_cm
        else:
            progress_value = trakt_sync.get_local_playback_progress(tmdb_id, 'tv', it['season'], it['episode'])
        resume_percent = 0
        resume_seconds = 0
        
        if progress_value >= 1000000:
            resume_seconds = int(progress_value - 1000000)
            if duration > 0:
                resume_percent = (resume_seconds / duration) * 100
        elif 0 < progress_value < 90:
            resume_percent = progress_value
            if duration > 0:
                resume_seconds = int((resume_percent / 100.0) * duration)
        # --- SFARSIT MODIFICARE ---

        # 5. Dam dictionarului info absolut tot (Acum Kodi stie durata si stelutele)
        info = {
            'mediatype': 'episode', 
            'title': it['ep_title'], 
            'tvshowtitle': it['show_title'], 
            'season': it['season'], 
            'episode': it['episode'], 
            'plot': ep_plot, 
            'premiered': it['air_date'],
            'rating': rating,
            'votes': votes,
            'duration': duration,
            'mpaa': show_mpaa,
            'studio': studio,
            'resume_percent': resume_percent # <--- ADAUGAT AICI PENTRU CERCULET
        }
        
        badge = ""
        if skin_compat == '0':
            if ep_type in['series_premiere', 'season_premiere']:
                badge = "[COLOR FF00FA9A] • Season Premiere[/COLOR]"
            elif ep_type in ['series_finale', 'season_finale']:
                badge = "[COLOR FFFF4444] • Season Finale[/COLOR]"
            elif ep_type == 'mid_season_finale':
                badge = "[COLOR FFFF4444] • Mid-Season Finale[/COLOR]"
                
        label = f"[B][COLOR {show_color}]{it['show_title']}[/COLOR][/B] - [B][COLOR FFCCCCCC]S{it['season']:02d}E{it['episode']:02d}[/COLOR][/B] - [B][COLOR FFCCCCFF][I]{it['ep_title']}{badge}[/I][/COLOR][/B]"
        if is_unstarted:
            label = f"[B][COLOR FFFF4444]{it['show_title']}[/COLOR] - [B][COLOR yellow]S{it['season']:02d}E{it['episode']:02d}[/COLOR][/B] - [B][COLOR FFCCCCFF][I]{it['ep_title']}{badge}[/I][/COLOR][/B]"

        # Logica de afisare a datei pentru episoadele viitoare
        # <<-- MODIFICARE AICI PENTRU CULOARE -->>
        is_upcoming = False
        _at = ''
        _akey = (str(tmdb_id), int(it['season'] or 0), int(it['episode'] or 0))
        _stamp = None
        if _at_map is not None:
            _stamp = _at_map.get(_akey)
        else:
            try:
                _stamp = get_episode_air_stamp(tmdb_id, it['season'], it['episode'])
            except:
                _stamp = None
        if _stamp:
            _at = _stamp[1]
        if it['air_date']:
            try:
                parts = str(it['air_date']).split('T')[0].split('-')
                air_date_obj = datetime.date(int(parts[0]), int(parts[1]), int(parts[2]))
                air_date_obj = air_effective_date(air_date_obj, _stamp, today)
                if air_date_obj >= today:
                    is_upcoming = True
                    days_until = (air_date_obj - today).days
                    if days_until == 0:
                        zile_str = calendar_localized_label(0, '')
                    elif days_until == 1:
                        zile_str = calendar_localized_label(1, air_date_obj.isoformat())
                    elif 1 < days_until <= 7:
                        zile_str = f"In {days_until} zile" if _plot_lang == 'ro' else f"In {days_until} days"
                    else:
                        zile_str = _fmt_dmy(it['air_date'])
                    # In fast cache salvam TOKENUL, nu ora: lista se poate salva
                    # imediat (deschiderile urmatoare = instant), iar orele apar la
                    # randare pe masura ce cache-ul de ore se umple.
                    # Rozul FFFF69B4 = "nu s-a difuzat inca", deci doar pentru
                    # viitor. Pentru azi: numele si eticheta sunt galben bold
                    # (semnalul "azi"), in toate listele.
                    if days_until == 0:
                        label = f"[B][COLOR yellow]{it['show_title']}[/COLOR][/B] - [B][COLOR FFCCCCCC]S{it['season']:02d}E{it['episode']:02d}[/COLOR][/B] - [B][COLOR FFCCCCFF][I]{it['ep_title']}{badge}[/I][/COLOR][/B]  [B][COLOR yellow]({zile_str}{AIR_TIME_TOKEN})[/COLOR][/B]"
                    else:
                        label = f"[B][COLOR FFFF69B4]{it['show_title']}[/COLOR] [COLOR yellow]- S{it['season']:02d}E{it['episode']:02d}[/COLOR] - [I][COLOR FFCCCCFF]{it['ep_title']}[/COLOR][/I]  [COLOR yellow]({zile_str}{AIR_TIME_TOKEN})[/COLOR]{badge}[/B]"
            except: 
                pass
        elif show_future: # TBA (fara data)
             label = f"[B][COLOR FFFF69B4]{it['show_title']}[/COLOR] [COLOR {('yellow' if is_unstarted else 'FFFF4444')}]- S{it['season']:02d}E{it['episode']:02d}[/COLOR] - [I][COLOR FFCCCCFF]{it['ep_title']}[/COLOR][/I]  [COLOR {('yellow' if is_unstarted else 'FFFF4444')}](TBA)[/COLOR]{badge}[/B]"
             
        # --- NOU: AFISARE ESTUARY NUMAR EPISOADE RAMASE ---
        if skin_compat == '0' and unwatched_count > 0:
            label += f" [COLOR orange] ({unwatched_count})[/COLOR]"
        # --------------------------------------------------

        # Randarea LIVE primeste ora reala; in cache ramane tokenul (air_key).
        label_live = apply_air_time(label, _at)
        air_key = (str(tmdb_id), int(it['season']), int(it['episode'])) if AIR_TIME_TOKEN in label else None
        _ph['eticheta'] = _ph.get('eticheta', 0.0) + (time.time() - _t_ph) * 1000.0
        _t_ph = time.time()

        if _skip_un_round:
            url_params = None
        else:
            url_params = select_ext_info_params('episode', tmdb_id, it['season'], it['episode'], it['show_title'], it['ep_title'])
        url_params = url_params or {'mode': 'sources', 'tmdb_id': tmdb_id, 'type': 'tv', 'season': str(it['season']), 'episode': str(it['episode']), 'title': it['ep_title'], 'tv_show_title': it['show_title']}

        cm = _get_full_context_menu(
            tmdb_id, 
            'episode',             
            it['show_title'], 
            imdb_id=imdb_id,
            season=it['season'],   
            episode=it['episode'],
            ep_watched=_watched_for_cm,
            progress=_prog_for_cm
        )
        
        # --- Browse Show / Browse Season / Clear sources cache (helper comun) ---
        cm = calendar_context_menu(cm, 'episode', tmdb_id, it['show_title'], season=it['season'], episode=it['episode'],
                                   base_url=PLUGIN_URL, browse_cmd=_browse_cmd, urlencode_fn=urlencode,
                                   clear_sources=True)
        _ph['meniu'] = _ph.get('meniu', 0.0) + (time.time() - _t_ph) * 1000.0
        _t_ph = time.time()
        
        url = plugin_url(url_params)
        li = None if cache_only else xbmcgui.ListItem(label_live)

        # AF3 ascunde thumb-ul daca e identic cu posterul → la modurile Poster (2/3)
        # thumb/landscape devin still-ul episodului (thumb != poster)
        if art_pref in ('2', '3'):
            thumb_art = f"{IMG_BASE}{ep_still}" if has_still else ''
            landscape_art = thumb_art or ep_icon
        else:
            thumb_art = ep_icon
            landscape_art = ep_icon

        art = {
            'thumb': thumb_art,
            'icon': ep_icon, 
            'landscape': landscape_art,
            'tvshow.landscape': landscape_art,
            'tvshow.poster': base_poster, 
            'season.poster': base_poster, 
            'fanart': final_fanart
        }
        
        if skin_compat == '1':
            art['poster'] = base_poster
        else:
            art['poster'] = ep_icon
            
        if show_logo:
            art['clearlogo'] = show_logo
            art['tvshow.clearlogo'] = show_logo
            art['tvshow.logo'] = show_logo
            art['logo'] = show_logo
            art['fanart_clearlogo'] = show_logo
        if not cache_only:
            li.setArt(art)
            _safe_set_prop(li, 'tmdb_id', str(tmdb_id))
            if ep_type:
                _safe_set_prop(li, 'episode_type', ep_type)
            # Modificat watched_info pentru a seta proprietatile AF3
            set_metadata(li, info, unique_ids={'tmdb': str(tmdb_id), 'imdb': imdb_id}, watched_info=show_watched_info)

            # --- ADAUGAT: Setam manual cercul de progres pentru Kodi ---
            set_resume_point(li, resume_seconds, duration)

            if cm: li.addContextMenuItems(cm)
            items_to_add.append((url, li, False))
        cache_list.append({
            'label': label, 'air_key': air_key, 'url': url, 'is_folder': False,
            'info': info, 'art': art, 'cm': cm,
            'resume_time': resume_seconds, 'total_time': duration,
            'unique_ids': {'tmdb': str(tmdb_id), 'imdb': imdb_id},
            'properties': {
                'episode_type': ep_type,
                'TotalEpisodes': str(show_watched_info['total']) if show_watched_info['total'] > 0 else '0',
                'WatchedEpisodes': str(show_watched_info['watched']),
                'UnWatchedEpisodes': str(max(0, show_watched_info['total'] - show_watched_info['watched'])) if show_watched_info['total'] > 0 else '',
                'PercentPlayed': str(int((float(show_watched_info['watched'])/float(show_watched_info['total']))*100)) if (show_watched_info['total'] > 0 and 0 < show_watched_info['watched'] < show_watched_info['total']) else '',
            }
        })
        _ph['rest'] = _ph.get('rest', 0.0) + (time.time() - _t_ph) * 1000.0

    # === AICI SE TERMINA BUCLA FOR ===

    # Timpi pe faze: daca Up Next se simte iar lent, kodi.log spune exact unde.
    _t_build = time.time()
    try:
        global _LAST_NEXT_BUILD_MS
        _LAST_NEXT_BUILD_MS = (_t_build - _t_start) * 1000.0
    except Exception:
        pass
    try:
        _ph_txt = ', '.join(f"{_k}={int(_v)}" for _k, _v in
                            sorted((_ph or {}).items(), key=lambda _kv: -_kv[1]))
    except Exception:
        _ph_txt = ''
    log(f"[UP NEXT] rebuild {int((_t_build - _t_start) * 1000)}ms "
        f"(varianta {'tmdb' if use_tmdb else 'provider'}, "
        f"prefetch={int((_t_prefetch - _t_start) * 1000)}, warm={int((_t_warm - _t_prefetch) * 1000)}, "
        f"randuri={int((_t_build - _t_warm) * 1000)}, items={len(items)}, randuri_finale={len(cache_list)}"
        + (f", faze={_ph_txt}" if _ph_txt else '') + ")")

    if not cache_only:
        if items_to_add:
            xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))

        xbmcplugin.setContent(HANDLE, 'episodes')
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
        _set_views_apply('episode_lists', 'episodes')

    # Nu salva liste goale in fast cache: o randare din fereastra de sync/update
    # (tabela in rebuild, DB locked, exceptie de citire) ar ramine servita din RAM
    # pina la urmatorul clear — exact scenariul "Up Next gol dupa update".
    if cache_list:
        set_fast_cache(cache_key, cache_list)
        # Stamp de "build terminat": safety pass-ul din player astepta pina acum
        # doar terminarea threadului de pre-randare, care poate sa si renunte -
        # deci putea stinge `upnext_stale_since` cu cache-ul inca vechi.
        try:
            mark_upnext_cache_built('tmdb' if use_tmdb else 'provider', _t_rows)
        except Exception:
            pass
        # CANARY (doar log, zero schimbare de comportament): randul Up Next al
        # providerului e scris de un daemon care porneste la marcaj. Daca el a
        # rescris randul DUPA ce build-ul asta a citit din DB, cache-ul de fata
        # e vechi, desi stampul de build e nou (la 19:34, mansh/MDBList, ambele
        # asteptari min_ts au atins plafonul de 3.0s - semn ca randul nu fusese
        # inca commit-uit). Daca linia apare pe device, urmatorul pas e o singura
        # re-citire, nu suprimarea stampului (vezi AGENTS.md 209).
        try:
            from resources.lib.providers.watched_provider import _upnext_row_updated_stamp as _row_stamp
            _rs = _row_stamp()
            if _rs and _rs > _t_rows:
                log(f"[UP NEXT] ATENTIE: randurile citite la {_t_rows:.2f} sint mai vechi "
                    f"decit ultima rescriere a unui rand Up Next ({_rs:.2f}) - cache "
                    f"posibil vechi (varianta {'tmdb' if use_tmdb else 'provider'})")
        except Exception:
            pass
        if cache_only:
            log(f"[UP NEXT] pre-randare in cache: {len(cache_list)} randuri (fara GUI)")
    # Lock-ul se elibereaza DUPA scrierea cache-ului: procesele care asteapta
    # (widget/container) il gasesc gata si randeaza instant.
    _list_build_clear(cache_key)
    # Memo-ul setarilor a fost valabil doar pentru acest build: daca utilizatorul
    # schimba un comutator de meniu contextual, urmatoarea constructie trebuie sa
    # citeasca valoarea noua.
    _CM_SET_MEMO.clear()
    try:
        season_session.close()
    except:
        pass


# FOR SEREN
def get_trakt_client_id():
    """Extrage Trakt client_id fara a genera erori in log daca addon-urile lipsesc."""
    import os
    import re
    import xbmc
    
    # Folosim xbmcvfs pentru a verifica daca un folder de addon exista, e mai sigur
    def addon_exists(addon_id):
        addon_path = f"special://home/addons/{addon_id}"
        return xbmcvfs.exists(addon_path)

    search_map = {
        'plugin.video.seren': [
            'resources/lib/modules/globals.py',
            'resources/lib/modules/trakt/trakt_api.py',
            'resources/lib/common/tools.py',
        ],
        'script.trakt': [
            'resources/lib/trakt/api.py',
            'resources/lib/traktapi.py',
        ],
        'plugin.video.themoviedb.helper': [
            'resources/tmdbhelper/lib/api/trakt/api.py',
            'resources/lib/trakt/api.py',
        ],
    }
    
    for addon_id, paths in search_map.items():
        if not addon_exists(addon_id):
            continue  # Sarim peste daca addon-ul nu e instalat
        
        try:
            import xbmcaddon
            addon_instance = xbmcaddon.Addon(addon_id)
            base = addon_instance.getAddonInfo('path')
        except:
            continue

        for rp in paths:
            fp = os.path.join(base, *rp.split('/'))
            if not os.path.isfile(fp): continue
            try:
                with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
                    txt = f.read()
                for m in re.finditer(r'["\']([a-f0-9]{64})["\']', txt):
                    xbmc.log(f"[TMDb Movies] Trakt client_id found in {addon_id}", xbmc.LOGINFO)
                    return m.group(1)
            except: continue
    
    # Fallback scan (doar daca Seren exista)
    if addon_exists('plugin.video.seren'):
        try:
            import xbmcaddon
            seren_addon = xbmcaddon.Addon('plugin.video.seren')
            base = seren_addon.getAddonInfo('path')
            for root, _, files in os.walk(base):
                for fn in files:
                    if not fn.endswith('.py'): continue
                    fp = os.path.join(root, fn)
                    try:
                        with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
                            txt = f.read()
                        if 'client' not in txt.lower(): continue
                        for m in re.finditer(r'["\']([a-f0-9]{64})["\']', txt):
                            xbmc.log(f"[TMDb Movies] Trakt client_id found via fallback in {fp}", xbmc.LOGINFO)
                            return m.group(1)
                    except: continue
        except: pass
    
    return None


def get_trakt_id(imdb_id, tmdb_id, media_type='movie'):
    """Converteste IMDb/TMDb ID → Trakt ID, fara erori in log."""
    import requests
    import xbmc
    
    client_id = get_trakt_client_id()
    if not client_id:
        # AICI AM SCOS LINIA CARE GENERA EROAREA IN LOG!
        return None
    
    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': client_id
    }
    
    trakt_type = 'movie' if media_type == 'movie' else 'show'
    
    if imdb_id and str(imdb_id).startswith('tt'):
        try:
            r = requests.get(
                f"https://api.trakt.tv/search/imdb/{imdb_id}?type={trakt_type}",
                headers=headers, timeout=5
            )
            if r.ok and r.json():
                tid = r.json()[0][trakt_type]['ids']['trakt']
                return tid
        except: pass
    
    if tmdb_id:
        try:
            r = requests.get(
                f"https://api.trakt.tv/search/tmdb/{tmdb_id}?type={trakt_type}",
                headers=headers, timeout=5
            )
            if r.ok and r.json():
                tid = r.json()[0][trakt_type]['ids']['trakt']
                return tid
        except: pass
    
    return None

    
# =============================================================================
# MENU: MY PLAYS (Custom Player Launcher) - CU SUPORT SETARI
# =============================================================================
# =============================================================================
# BACKGROUND WARM-UP & PREFETCH ENGINE (V7 - GHOST MODE)
# =============================================================================

def process_single_list_warmup(action, content_type, page=1):
    """Proceseaza o lista in fundal cu intrerupere fortata (Zero Hang)."""
    monitor = xbmc.Monitor()
    window = xbmcgui.Window(10000)
    cache_key = f"list_{content_type}_{action}_{page}"
    
    if monitor.abortRequested() or window.getProperty('tmdbmovies_loading_active') == 'true' or get_fast_cache(cache_key):
        return

    results = None
    try:
        results = trakt_sync.get_tmdb_from_db(action, page)
        
        if not results:
            if monitor.abortRequested() or window.getProperty('tmdbmovies_loading_active') == 'true':
                return
            string = f"{action}_{page}_{LANG}"
            data = cache_object(get_tmdb_movies_standard if content_type == 'movie' else get_tmdb_tv_standard, 
                                string, [action, page], expiration=1)
            if data: results = data.get('results', [])
    except: pass
    
    if not results or monitor.abortRequested() or window.getProperty('tmdbmovies_loading_active') == 'true':
        return

    cache_list = []
    items_to_process = results[:15] 
    
    for item in items_to_process:
        if monitor.abortRequested() or window.getProperty('tmdbmovies_loading_active') == 'true':
            return
        
        try:
            if content_type == 'movie':
                processed = _process_movie_item(item, return_data=True)
            else:
                processed = _process_tv_item(item, return_data=True)
            
            if processed:
                cache_list.append({
                    'label': processed['label'], 'url': processed['url'], 
                    'is_folder': processed['is_folder'], 'art': processed['art'], 
                    'info': processed['info'], 'cm': processed['cm_items'], 
                    'resume_time': processed['resume_time'], 'total_time': processed['total_time']
                })
        except: continue

    if len(cache_list) > 0 and not (monitor.abortRequested() or window.getProperty('tmdbmovies_loading_active') == 'true'):
        mode_str = 'build_movie_list' if content_type == 'movie' else 'build_tvshow_list'
        next_label = next_page_label(page + 1)
        next_params = {'mode': mode_str, 'action': action, 'new_page': str(page + 1)}
        next_url = plugin_url(next_params)
        
        cache_list.append({
            'label': next_label, 'url': next_url, 'is_folder': True,
            'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON},
            'info': {'mediatype': 'video', 'plot': 'Next Page'},
            'cm': [], 'resume_time': 0, 'total_time': 0, 'li': None
        })
        set_fast_cache(cache_key, cache_list)

def run_background_warmup(content_type):
    """Lanseaza warmup-ul intr-un invoker Kodi separat (nu blocheaza plugin-ul)."""
    window = xbmcgui.Window(10000)
    if window.getProperty('tmdbmovies_warmup_busy') == 'true' or \
       window.getProperty('tmdbmovies_loading_active') == 'true':
        return
    import urllib.parse
    xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.tmdbmovies/?mode=background_warmup&type={content_type})')


def run_background_warmup_sync(content_type):
    """Executa warmup-ul sincron (intr-un invoker separat)."""
    import time
    window = xbmcgui.Window(10000)
    if window.getProperty('tmdbmovies_warmup_busy') == 'true':
        return
    window.setProperty('tmdbmovies_warmup_busy', 'true')
    monitor = xbmc.Monitor()
    
    try:
        if content_type == 'movie':
            actions = [
                'tmdb_movies_trending_day', 'tmdb_movies_trending_week', 
                'tmdb_movies_popular', 'tmdb_movies_top_rated',
                'tmdb_movies_premieres', 'tmdb_movies_latest_releases',
                'tmdb_movies_digital',
                'tmdb_movies_netflix',  'tmdb_movies_amazon',
                'tmdb_movies_disney', 'tmdb_movies_apple', 
                'tmdb_movies_box_office', 'tmdb_movies_now_playing',
                'tmdb_movies_upcoming', 'tmdb_movies_anticipated', 
                'tmdb_movies_blockbusters',
                'hindi_movies_trending', 'hindi_movies_popular', 
                'hindi_movies_premieres', 'hindi_movies_in_theaters', 
                'hindi_movies_upcoming', 'hindi_movies_anticipated',
                'trakt_movies_trending', 'trakt_movies_popular',
                'trakt_movies_anticipated', 'trakt_movies_boxoffice'
            ]
            delay = 0.3
        else:
            actions = [
                'tmdb_tv_trending_day', 'tmdb_tv_trending_week', 
                'tmdb_tv_popular', 'tmdb_tv_top_rated',
                'tmdb_tv_premieres', 'tmdb_tv_airing_today', 
                'tmdb_tv_on_the_air', 'tmdb_tv_upcoming',
                'trakt_tv_trending', 'trakt_tv_popular', 'trakt_tv_anticipated',
                'tmdb_tv_latest_releases', 'tmdb_tv_netflix',
                'tmdb_tv_amazon', 'tmdb_tv_disney', 'tmdb_tv_apple'
            ]
            delay = 0.7

        # Grace de start: userul ABIA a navigat (meniul care a declansat
        # warmup-ul a setat tmdbmovies_last_nav_ts). Asteptam sa se aseze —
        # daca navigheaza altundeva in cele 6s, warmup-ul moare inainte sa
        # apuce sa ocupe slotul de script.
        if monitor.waitForAbort(6.0): return

        for act in actions:
            if monitor.abortRequested() or window.getProperty('tmdbmovies_loading_active') == 'true':
                log("[WARMUP] User activity detected. Killing background task for stability.")
                break
            # Userul a navigat intre timp? Warmup-ul ocupa slotul de script
            # (RLI serializaeaza invocarile) si toate click-urile asteapta la
            # coada pina termina — moare imediat la orice navigare noua.
            try:
                _last_nav = float(window.getProperty('tmdbmovies_last_nav_ts') or 0)
                if _last_nav and (time.time() - _last_nav) < 4.0:
                    log("[WARMUP] Recent navigation detected. Killing background task.")
                    break
            except Exception:
                pass

            process_single_list_warmup(act, content_type, 1)

            if monitor.waitForAbort(delay): break
    finally:
        window.clearProperty('tmdbmovies_warmup_busy')

def trigger_next_page_warmup(action, current_page, content_type):
    """Pre-fetch 1-2 pagini inline (lista e deja randata, delay invizibil). Fara thread."""
    import time
    from resources.lib.core.cache import cache_object
    from resources.lib.providers.trakt_sync import get_tmdb_from_db
    
    deadline = time.time() + 0.5
    for i in range(1, 3):
        if time.time() > deadline: break
        if get_tmdb_from_db(action, current_page + i):
            continue
        try:
            if content_type == 'movie':
                cache_object(get_tmdb_movies_standard, f"{action}_{current_page + i}_{LANG}", [action, current_page + i], expiration=24)
            else:
                cache_object(get_tmdb_tv_standard, f"{action}_{current_page + i}_{LANG}", [action, current_page + i], expiration=24)
        except:
            break
    

def navigator_genres(params):
    menu_type = params.get('menu_type', 'movie')
    icons_path = os.path.join(ADDON_PATH, 'resources', 'media')
    genre_icon = os.path.join(icons_path, 'genres.png')

    if menu_type == 'movie':
        genre_list = menus.MOVIE_GENRES
    else:
        genre_list = menus.TV_GENRES

    add_directory('[B]Multiselect[/B]',
                 {'mode': 'multiselect_genres', 'media_type': menu_type},
                 icon=os.path.join(icons_path, 'item_next.png'), folder=False)

    for genre in genre_list:
        add_directory(genre['name'],
                     {'mode': 'list_by_genre', 'media_type': menu_type, 'genre_id': str(genre['id'])},
                     icon=genre_icon, folder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    _set_views_apply('main')


def multiselect_genres(params):
    menu_type = params.get('media_type', 'movie')

    if menu_type == 'movie':
        genre_list = menus.MOVIE_GENRES
    else:
        genre_list = menus.TV_GENRES

    dialog = xbmcgui.Dialog()
    items = [genre['name'] for genre in genre_list]
    selected = dialog.multiselect('Select Genres', items)

    if selected is None or selected == []:
        return

    genre_ids = ','.join([str(genre_list[i]['id']) for i in selected])
    url_params = {'mode': 'list_by_genre', 'media_type': menu_type, 'genre_id': genre_ids}
    url = plugin_url(url_params)
    xbmc.executebuiltin('Container.Update(%s)' % url)


def navigator_years(params):
    menu_type = params.get('menu_type', 'movie')
    import datetime
    current_year = datetime.datetime.now().year
    icons_path = os.path.join(ADDON_PATH, 'resources', 'media')
    cal_icon = os.path.join(icons_path, 'calender.png')

    for year in range(current_year, 1999, -1):
        add_directory(str(year),
                     {'mode': 'list_by_year', 'media_type': menu_type, 'year': str(year)},
                     icon=cal_icon, folder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    _set_views_apply('main')


def list_by_genre(params):
    media_type = params.get('media_type', 'movie')
    genre_id = params.get('genre_id')
    page = int(params.get('page', '1'))

    if not genre_id:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    cache_key = f"genre_{media_type}_{genre_id}_{page}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='movies' if media_type == 'movie' else 'tvshows')
        return

    if media_type == 'movie':
        url = f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&with_genres={genre_id}&page={page}&sort_by=popularity.desc&vote_count.gte=10"
    else:
        url = f"{BASE_URL}/discover/tv?api_key={API_KEY}&language={LANG}&with_genres={genre_id}&page={page}&sort_by=popularity.desc&vote_count.gte=10"

    data = get_json(url)
    if not data or not data.get('results'):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    results = data['results']
    prefetch_metadata_parallel(results, media_type)

    items_to_add = []
    cache_list = []

    for item in results:
        processed = _process_movie_item(item, return_data=True) if media_type == 'movie' else _process_tv_item(item, return_data=True)
        if processed:
            items_to_add.append((processed['url'], processed['li'], processed['is_folder']))
            cache_list.append(processed)

    total_pages = data.get('total_pages', 1)
    if page < total_pages:
        next_label = next_page_label(page + 1)
        next_params = {'mode': 'list_by_genre', 'media_type': media_type, 'genre_id': genre_id, 'page': str(page+1)}
        next_url = plugin_url(next_params)
        next_li = xbmcgui.ListItem(next_label)
        style_page_nav_item(next_li, page + 1)
        items_to_add.append((next_url, next_li, True))
        cache_list.append({'label': next_label, 'url': next_url, 'is_folder': True, 'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON}, 'info': {'mediatype': 'video', 'plot': next_page_plot(page + 1)}, 'cm_items': []})

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))

    xbmcplugin.setContent(HANDLE, 'movies' if media_type == 'movie' else 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('movies' if media_type == 'movie' else 'tvshows')

    set_fast_cache(cache_key, [{'label': i['li'].getLabel() if 'li' in i else i['label'], 'url': i['url'], 'is_folder': i['is_folder'], 'art': i['art'], 'info': i['info'], 'cm': i['cm_items'], 'resume_time': i.get('resume_time', 0), 'total_time': i.get('total_time', 0)} for i in cache_list])


def list_by_year(params):
    media_type = params.get('media_type', 'movie')
    year = params.get('year')
    page = int(params.get('page', '1'))

    if not year:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    cache_key = f"year_{media_type}_{year}_{page}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='movies' if media_type == 'movie' else 'tvshows')
        return

    if media_type == 'movie':
        url = f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&primary_release_year={year}&page={page}&sort_by=popularity.desc&vote_count.gte=10"
    else:
        url = f"{BASE_URL}/discover/tv?api_key={API_KEY}&language={LANG}&first_air_date_year={year}&page={page}&sort_by=popularity.desc&vote_count.gte=10"

    data = get_json(url)
    if not data or not data.get('results'):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    results = data['results']
    prefetch_metadata_parallel(results, media_type)

    items_to_add = []
    cache_list = []

    for item in results:
        processed = _process_movie_item(item, return_data=True) if media_type == 'movie' else _process_tv_item(item, return_data=True)
        if processed:
            items_to_add.append((processed['url'], processed['li'], processed['is_folder']))
            cache_list.append(processed)

    total_pages = data.get('total_pages', 1)
    if page < total_pages:
        next_label = next_page_label(page + 1)
        next_params = {'mode': 'list_by_year', 'media_type': media_type, 'year': year, 'page': str(page+1)}
        next_url = plugin_url(next_params)
        next_li = xbmcgui.ListItem(next_label)
        style_page_nav_item(next_li, page + 1)
        items_to_add.append((next_url, next_li, True))
        cache_list.append({'label': next_label, 'url': next_url, 'is_folder': True, 'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON}, 'info': {'mediatype': 'video', 'plot': next_page_plot(page + 1)}, 'cm_items': []})

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))

    xbmcplugin.setContent(HANDLE, 'movies' if media_type == 'movie' else 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('movies' if media_type == 'movie' else 'tvshows')

    set_fast_cache(cache_key, [{'label': i['li'].getLabel() if 'li' in i else i['label'], 'url': i['url'], 'is_folder': i['is_folder'], 'art': i['art'], 'info': i['info'], 'cm': i['cm_items'], 'resume_time': i.get('resume_time', 0), 'total_time': i.get('total_time', 0)} for i in cache_list])


def navigator_providers(params):
    menu_type = params.get('menu_type', 'movie')
    icons_path = os.path.join(ADDON_PATH, 'resources', 'media')
    fallback_icon = os.path.join(icons_path, f'{menu_type}.png')

    url = f"{BASE_URL}/watch/providers/{menu_type}?api_key={API_KEY}&language={LANG}&watch_region=US"
    data = get_json(url)

    if not data or not data.get('results'):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for provider in data['results']:
        thumb = None
        if provider.get('logo_path'):
            thumb = f"https://image.tmdb.org/t/p/original{provider['logo_path']}"
        add_directory(provider['provider_name'],
                     {'mode': 'list_by_provider', 'media_type': menu_type, 'provider_id': str(provider['provider_id'])},
                     icon=thumb or fallback_icon, thumb=thumb, folder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    _set_views_apply('main')


def list_by_provider(params):
    media_type = params.get('media_type', 'movie')
    provider_id = params.get('provider_id')
    page = int(params.get('page', '1'))

    if not provider_id:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    cache_key = f"provider_{media_type}_{provider_id}_{page}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='movies' if media_type == 'movie' else 'tvshows')
        return

    if media_type == 'movie':
        url = f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&region=US&watch_region=US&with_watch_providers={provider_id}&page={page}&sort_by=popularity.desc&vote_count.gte=10"
    else:
        url = f"{BASE_URL}/discover/tv?api_key={API_KEY}&language={LANG}&region=US&watch_region=US&with_watch_providers={provider_id}&page={page}&sort_by=popularity.desc&vote_count.gte=10"

    data = get_json(url)
    if not data or not data.get('results'):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    results = data['results']
    prefetch_metadata_parallel(results, media_type)

    items_to_add = []
    cache_list = []

    for item in results:
        processed = _process_movie_item(item, return_data=True) if media_type == 'movie' else _process_tv_item(item, return_data=True)
        if processed:
            items_to_add.append((processed['url'], processed['li'], processed['is_folder']))
            cache_list.append(processed)

    total_pages = data.get('total_pages', 1)
    if page < total_pages:
        next_label = next_page_label(page + 1)
        next_params = {'mode': 'list_by_provider', 'media_type': media_type, 'provider_id': provider_id, 'page': str(page+1)}
        next_url = plugin_url(next_params)
        next_li = xbmcgui.ListItem(next_label)
        style_page_nav_item(next_li, page + 1)
        items_to_add.append((next_url, next_li, True))
        cache_list.append({'label': next_label, 'url': next_url, 'is_folder': True, 'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON}, 'info': {'mediatype': 'video', 'plot': next_page_plot(page + 1)}, 'cm_items': []})

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))

    xbmcplugin.setContent(HANDLE, 'movies' if media_type == 'movie' else 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('movies' if media_type == 'movie' else 'tvshows')

    set_fast_cache(cache_key, [{'label': i['li'].getLabel() if 'li' in i else i['label'], 'url': i['url'], 'is_folder': i['is_folder'], 'art': i['art'], 'info': i['info'], 'cm': i['cm_items'], 'resume_time': i.get('resume_time', 0), 'total_time': i.get('total_time', 0)} for i in cache_list])


def list_highest_revenue(params):
    media_type = params.get('media_type', 'movie')
    page = int(params.get('page', '1'))

    cache_key = f"highest_revenue_{page}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='movies')
        return

    url = f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&region=US&page={page}&sort_by=revenue.desc&vote_count.gte=10"

    data = get_json(url)
    if not data or not data.get('results'):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    results = data['results']
    prefetch_metadata_parallel(results, media_type)

    items_to_add = []
    cache_list = []

    for item in results:
        processed = _process_movie_item(item, return_data=True)
        if processed:
            items_to_add.append((processed['url'], processed['li'], processed['is_folder']))
            cache_list.append(processed)

    total_pages = data.get('total_pages', 1)
    if page < total_pages:
        next_label = next_page_label(page + 1)
        next_params = {'mode': 'list_highest_revenue', 'page': str(page+1)}
        next_url = plugin_url(next_params)
        next_li = xbmcgui.ListItem(next_label)
        style_page_nav_item(next_li, page + 1)
        items_to_add.append((next_url, next_li, True))
        cache_list.append({'label': next_label, 'url': next_url, 'is_folder': True, 'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON}, 'info': {'mediatype': 'video', 'plot': next_page_plot(page + 1)}, 'cm_items': []})

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))

    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('movies')

    set_fast_cache(cache_key, [{'label': i['li'].getLabel() if 'li' in i else i['label'], 'url': i['url'], 'is_folder': i['is_folder'], 'art': i['art'], 'info': i['info'], 'cm': i['cm_items'], 'resume_time': i.get('resume_time', 0), 'total_time': i.get('total_time', 0)} for i in cache_list])


def list_most_voted(params):
    media_type = params.get('media_type', 'movie')
    page = int(params.get('page', '1'))

    cache_key = f"most_voted_{media_type}_{page}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='movies' if media_type == 'movie' else 'tvshows')
        return

    if media_type == 'movie':
        url = f"{BASE_URL}/discover/movie?api_key={API_KEY}&language={LANG}&region=US&page={page}&sort_by=vote_count.desc&vote_count.gte=10"
    else:
        url = f"{BASE_URL}/discover/tv?api_key={API_KEY}&language={LANG}&region=US&page={page}&sort_by=vote_count.desc&vote_count.gte=10"

    data = get_json(url)
    if not data or not data.get('results'):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    results = data['results']
    prefetch_metadata_parallel(results, media_type)

    items_to_add = []
    cache_list = []

    for item in results:
        processed = _process_movie_item(item, return_data=True) if media_type == 'movie' else _process_tv_item(item, return_data=True)
        if processed:
            items_to_add.append((processed['url'], processed['li'], processed['is_folder']))
            cache_list.append(processed)

    total_pages = data.get('total_pages', 1)
    if page < total_pages:
        next_label = next_page_label(page + 1)
        next_params = {'mode': 'list_most_voted', 'media_type': media_type, 'page': str(page+1)}
        next_url = plugin_url(next_params)
        next_li = xbmcgui.ListItem(next_label)
        style_page_nav_item(next_li, page + 1)
        items_to_add.append((next_url, next_li, True))
        cache_list.append({'label': next_label, 'url': next_url, 'is_folder': True, 'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON}, 'info': {'mediatype': 'video', 'plot': next_page_plot(page + 1)}, 'cm_items': []})

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))

    xbmcplugin.setContent(HANDLE, 'movies' if media_type == 'movie' else 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('movies' if media_type == 'movie' else 'tvshows')

    set_fast_cache(cache_key, [{'label': i['li'].getLabel() if 'li' in i else i['label'], 'url': i['url'], 'is_folder': i['is_folder'], 'art': i['art'], 'info': i['info'], 'cm': i['cm_items'], 'resume_time': i.get('resume_time', 0), 'total_time': i.get('total_time', 0)} for i in cache_list])


def navigator_networks(params):
    menu_type = params.get('menu_type', 'tv')
    page = int(params.get('page', '1'))
    per_page = 50
    icons_path = os.path.join(ADDON_PATH, 'resources', 'media')
    fallback_icon = os.path.join(icons_path, 'networks.png')

    networks = menus.TV_NETWORKS
    total = len(networks)
    start = (page - 1) * per_page
    end = min(start + per_page, total)
    page_networks = networks[start:end]

    def fetch_logo(net):
        nid = str(net['id'])
        net_url = f"{BASE_URL}/network/{nid}?api_key={API_KEY}"
        net_data = get_json(net_url)
        if net_data and net_data.get('logo_path'):
            return nid, f"{IMG_BASE}{net_data['logo_path']}"
        return nid, None

    logos = {}
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = {executor.submit(fetch_logo, net): net for net in page_networks}
        for future in as_completed(futures):
            nid, logo = future.result()
            logos[nid] = logo

    for network in page_networks:
        nid = str(network['id'])
        thumb = logos.get(nid)
        add_directory(network['name'],
                     {'mode': 'list_by_network', 'media_type': menu_type, 'network_id': nid},
                     icon=thumb or fallback_icon, thumb=thumb, folder=True)

    if end < total:
        add_directory(next_page_label(page + 1),
                     {'mode': 'navigator_networks', 'menu_type': menu_type, 'page': str(page+1)},
                     icon=os.path.join(icons_path, 'item_next.png'), thumb=os.path.join(icons_path, 'item_next.png'),
                     info={'mediatype': 'video', 'plot': next_page_plot(page + 1)}, folder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    _set_views_apply('main')


def list_by_network(params):
    media_type = params.get('media_type', 'tv')
    network_id = params.get('network_id')
    page = int(params.get('page', '1'))

    if not network_id:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    cache_key = f"network_{media_type}_{network_id}_{page}"
    cached_data = get_fast_cache(cache_key)
    if cached_data:
        render_from_fast_cache(cached_data, view_type='tvshows')
        return

    url = f"{BASE_URL}/discover/tv?api_key={API_KEY}&language={LANG}&region=US&with_networks={network_id}&page={page}&sort_by=popularity.desc&vote_count.gte=10"

    data = get_json(url)
    if not data or not data.get('results'):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    results = data['results']
    prefetch_metadata_parallel(results, media_type)

    items_to_add = []
    cache_list = []

    for item in results:
        processed = _process_tv_item(item, return_data=True)
        if processed:
            items_to_add.append((processed['url'], processed['li'], processed['is_folder']))
            cache_list.append(processed)

    total_pages = data.get('total_pages', 1)
    if page < total_pages:
        next_label = next_page_label(page + 1)
        next_params = {'mode': 'list_by_network', 'media_type': media_type, 'network_id': network_id, 'page': str(page+1)}
        next_url = plugin_url(next_params)
        next_li = xbmcgui.ListItem(next_label)
        style_page_nav_item(next_li, page + 1)
        items_to_add.append((next_url, next_li, True))
        cache_list.append({'label': next_label, 'url': next_url, 'is_folder': True, 'art': {'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON, 'poster': NEXT_PAGE_ICON}, 'info': {'mediatype': 'video', 'plot': next_page_plot(page + 1)}, 'cm_items': []})

    if items_to_add:
        xbmcplugin.addDirectoryItems(HANDLE, items_to_add, len(items_to_add))

    xbmcplugin.setContent(HANDLE, 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    _set_views_apply('tvshows')

    set_fast_cache(cache_key, [{'label': i['li'].getLabel() if 'li' in i else i['label'], 'url': i['url'], 'is_folder': i['is_folder'], 'art': i['art'], 'info': i['info'], 'cm': i['cm_items'], 'resume_time': i.get('resume_time', 0), 'total_time': i.get('total_time', 0)} for i in cache_list])
