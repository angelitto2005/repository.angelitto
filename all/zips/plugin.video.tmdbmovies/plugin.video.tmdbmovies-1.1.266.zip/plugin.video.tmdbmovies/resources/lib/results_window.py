import os
import re
import json
# pyrefly: ignore [missing-import]
import xbmcgui

QUALITY_ICONS = {
    '4K':    'flag4k.png',
    '1080p': 'flag1080p.png',
    '720p':  'flag720p.png',
    'SD':    'flagsd.png',
}

_RE_COMPILED = {}
def _cached_re(pattern):
    if pattern not in _RE_COMPILED:
        _RE_COMPILED[pattern] = re.compile(pattern, re.I)
    return _RE_COMPILED[pattern]

CODEC_PATTERNS = [
    (_cached_re(r'HEVC|[Xx]\.?265|[Hh]\.?265'), 'HEVC'),
    (_cached_re(r'[Xx]\.?264|[Hh]\.?264'),       'x264'),
    (_cached_re(r'AV1'),                         'AV1'),
]

SOURCE_PATTERNS = [
    _cached_re(r'Remux'),
    _cached_re(r'BluRay'),
    _cached_re(r'BLU-RAY'),
    _cached_re(r'BDRip'),
    _cached_re(r'BRRip'),
    _cached_re(r'WEB-DL'),
    _cached_re(r'WEBRip'),
    _cached_re(r'WEB'),
    _cached_re(r'HDTV'),
    _cached_re(r'HDRip'),
    _cached_re(r'DVDRip'),
    _cached_re(r'DVDScr'),
    _cached_re(r'HDCAM'),
    _cached_re(r'CAM'),
    _cached_re(r'TeleSync'),
    _cached_re(r'TS'),
    _cached_re(r'TC'),
]

HDR_PATTERNS = [
    (_cached_re(r'HDR10\+'),                  'HDR10+'),
    (_cached_re(r'HDR10'),                    'HDR10'),
    (_cached_re(r'\bHDR\b'),                  'HDR'),
    (_cached_re(r'\bSDR\b'),                  'SDR'),
    (_cached_re(r'\bHLG\b'),                  'HLG'),
    (_cached_re(r'Dolby[.\s]?Vision'),        'DV'),
    (_cached_re(r'\b(DV|DoVi)\b'),            'DV'),
]

AUDIO_PATTERNS = [
    (_cached_re(r'Atmos'),              'Atmos'),
    (_cached_re(r'TrueHD'),             'TrueHD'),
    (_cached_re(r'DTS[\-\.]?HD(?:[\-\.]?MA)?'),   'DTS-HD'),
    (_cached_re(r'\bDTS\b'),            'DTS'),
    (_cached_re(r'DDP\s?5[\. ]?1|DD\+\s?5[\. ]?1|EAC3\s?5[\. ]?1'), 'DDP 5.1'),
    (_cached_re(r'\bDDP\b|DD\+|EAC3'),      'DDP'),
    (_cached_re(r'DD\s?5[\. ]?1|AC3\s?5[\. ]?1'), 'DD 5.1'),
    (_cached_re(r'\bAC3\b|\bDD\b'),            'AC3'),
    (_cached_re(r'AAC\s?5[\. ]?1'), 'AAC 5.1'),
    (_cached_re(r'\bAAC\b'),            'AAC'),
    (_cached_re(r'\bFLAC\b'),           'FLAC'),
    (_cached_re(r'6CH|\b5[\. ]?1\b'),   '5.1'),
    (_cached_re(r'2\.0|2CH'),           '2.0'),
]

_SEEDERS_RE = _cached_re(r'(?:👤|👥|S:)\s*(\d+)')
_COLOR_STRIP_RE = _cached_re(r'\[/?COLOR.*?\]')
_RO_DUB_RE = _cached_re(r'(?i)(?:\bRO[\s._-]?DUB(?:BED)?\b|\bROMANIAN\b|\bLIMBA.?ROM[ÂA]NA?\b|\(RO\)|\[RO\]|\bRO\b.*?\bDUB(?:BED)?\b)')

# === AIO STREAMS DICTS ===
AIO_ADDON_COLORS = {
    'comet':          'FFFF4500',
    'mediafusion':    'FFFF4500',
    'torrentio':      'FFFF4500',
    'jackettio':      'FF32CD32',
    'orionoid':       'FFFFA500',
    'easynews':       'FF00CED1',
    'debridio':       'FFEE82EE',
    'annatar':        'FFFFD700',
    'zilean':         'FF20B2AA',
    'stremio-gdrive': 'FF87CEEB',
    'knightcrawler':  'FFDDA0DD',
    'torbox':         'FF00FA9A',
    'peeratar':       'FFFF69B4',
    'heartive':       'FFFF1493',
    'meteor':         'FFFF4500',
    'torz':           'FFFF4500',
    'custom1':        'FF87CEEB',
    'custom2':        'FF87CEEB',
    'custom3':        'FF87CEEB',
    'custom4':        'FF87CEEB',
    'custom5':        'FF87CEEB',
    'tamilmv':        'FF32CD32',
    'yts':            'FF32CD32',
    'torrent9':       'FF32CD32',
    'besttorrents':   'FF32CD32',
    'wolfmax4k':      'FF32CD32',
    'uindex':         'FF32CD32',
    'bludv':          'FF32CD32',
    'cinecalidad':    'FF32CD32',
    'comando':        'FF32CD32',
    'bt4g':           'FF32CD32',
    'knaben':         'FF32CD32',
    'bitmagnet':      'FF32CD32',
    'limetorrents':   'FF32CD32',
    'ilcorsaronero':  'FF32CD32',
    'eztv':           'FF228B22',
    'kickass':        'FF8B4513',
    '1337x':          'FFD2691E',
    'rutracker':      'red',
    'rutor':          'red',
    'tpb':            'red',
    'piratebay+':     'red',
    'thepiratebay':   'red',
    'the pirate bay': 'red',
    'torrentgalaxy':  'red',
    'therarbg':       'red',
    'torrentsdb':     'red',
    'stremthru torz': 'red',
    'nyaa':           'FFDC143C',
    'webstreamr':     'FFC71585',

    'sootio':     'lightskyblue',
    'hdhub':      'FF00FA9A',
    'primesrcme': 'FF00BFFF',
    'vsembed': 'FFFFA500',
    'vaplayer': 'FF00FA9A',
    'netmirror': 'FF00FA9A',
    'cineby': 'FFFF8C00',
    'cinefreak': 'FF00FF00',
    'usenet':         'FF00CED1',
    'usenetstreamer': 'FFFFA500',
    'p2p_yts':        'FFDAA520',
    'p2p_torrentio':  'FFDAA520',
    'p2p_comet':      'FFCC8899',
    'p2p_mediafusion':'FFFF4500',
    'p2p_filelist':   'FF00BFFF',
    'p2p_speedapp':   'FF50C878',
    'p2p_seedpool':   'FF32CD32',
    'p2p_knaben':     'FFDAA520',
    'p2p_thepiratebay': 'FF8B4513',
    'p2p_custom1':    'FFE238EC',
    'p2p_custom2':    'FFE238EC',
    'p2p_custom3':    'FFE238EC',
    'p2p_custom4':    'FFE238EC',
    'p2p_custom5':    'FFE238EC',
}

DEBRID_SHORTNAMES = {
    'realdebrid': 'RD',
    'alldebrid': 'AD',
    'premiumize': 'PM',
    'torbox': 'TB',
    'offcloud': 'OC',
    'easydebrid': 'ED',
    'easynews': 'EN',
    'debrider': 'DB',
    'debridlink': 'DL',
    'putio': 'PU',
    'aiostreams': 'AIO',
}

from resources.lib.config import ADDON, ADDON_PATH

class SourcesInfo(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.item = kwargs.get('item')
        self.meta = kwargs.get('meta', {})

    def onInit(self):
        # Proprietati de baza
        # Folosim numele complet al release-ului (torrent-ului)
        name = self.item.getProperty('tmdbmovies.name')
        self.setProperty('tmdbmovies.release_name', name)
        
        # Logica speciala pentru Provider/Indexer (AIO / Stremio)
        provider = self.item.getProperty('tmdbmovies.provider')
        addon = self.item.getProperty('tmdbmovies.addon')
        indexer = self.item.getProperty('tmdbmovies.indexer')
        server = self.item.getProperty('tmdbmovies.server')
        
        if addon and addon.lower() != 'none' and addon != '':
            self.setProperty('tmdbmovies.provider', addon)
            self.setProperty('tmdbmovies.server_label', provider) # aiostreams
        else:
            self.setProperty('tmdbmovies.provider', provider)
            self.setProperty('tmdbmovies.server_label', server)
            
        self.setProperty('tmdbmovies.size', self.item.getProperty('tmdbmovies.size'))
        self.setProperty('tmdbmovies.quality', self.item.getProperty('tmdbmovies.quality'))
        self.setProperty('tmdbmovies.quality_icon', self.item.getProperty('tmdbmovies.quality_icon'))
        self.setProperty('tmdbmovies.tags', self.item.getProperty('tmdbmovies.tags'))
        self.setProperty('tmdbmovies.highlight', self.item.getProperty('tmdbmovies.highlight'))
        
        # Proprietati noi: Status si Tip Stream
        status = self.item.getProperty('tmdbmovies.status')
        stream_type = self.item.getProperty('tmdbmovies.stream_type')
        
        # Daca e HTTP, simplificam statusul
        if stream_type and 'HTTP' in stream_type.upper():
            self.setProperty('tmdbmovies.status_clean', '[COLOR cyan]Direct HTTP Stream[/COLOR]')
        else:
            self.setProperty('tmdbmovies.status_clean', f"{stream_type} | {status}")
        
        # Imagini
        poster = self.item.getProperty('tmdbmovies.poster') or self.meta.get('poster', '')
        fanart = self.item.getProperty('tmdbmovies.fanart') or self.meta.get('fanart', '')
        self.setProperty('tmdbmovies.poster', poster)
        self.setProperty('tmdbmovies.fanart', fanart)
        
        # Info aditionale
        self.setProperty('tmdbmovies.group', self.item.getProperty('tmdbmovies.group'))
        self.setProperty('tmdbmovies.codec', self.item.getProperty('tmdbmovies.codec'))
        self.setProperty('tmdbmovies.audio', self.item.getProperty('tmdbmovies.audio'))
        self.setProperty('tmdbmovies.lang', self.item.getProperty('tmdbmovies.lang'))
        self.setProperty('tmdbmovies.indexer', indexer)
        self.setProperty('tmdbmovies.year', str(self.meta.get('year', '')))
        self.setProperty('tmdbmovies.rating', str(self.meta.get('rating', '')))

    def onAction(self, action):
        if action.getId() in (9, 10, 13, 92, 110, 117, 101):
            self.close()

    def onClick(self, controlId):
        self.close()


class ResultsWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.results = kwargs.get('results', [])
        self.all_results = list(self.results)
        self.meta = kwargs.get('meta', {})
        self.selected = None
        self.filter_applied = False
        self.last_cm_time = 0
        self.is_info_open = False

    def onInit(self):
        self._set_window_properties()
        self._populate_list()
        try:
            ctrl = self.getControl(2000)
            if ctrl:
                self.setFocusId(2000)
        except: pass

    def _extract_codec(self, name):
        for compiled, label in CODEC_PATTERNS:
            if compiled.search(name): return label
        return ''

    def _extract_source(self, name):
        for compiled in SOURCE_PATTERNS:
            m = compiled.search(name)
            if m: return m.group(0)
        return ''

    def _extract_hdr(self, name):
        found =[]
        for compiled, label in HDR_PATTERNS:
            if compiled.search(name):
                if label not in found: found.append(label)
        return found

    def _extract_audio(self, name):
        name_normalized = name.replace('.', ' ').replace('_', ' ')
        found_tags =[]
        for compiled, label in AUDIO_PATTERNS:
            if compiled.search(name_normalized):
                if not any(label in t or t in label for t in found_tags):
                    found_tags.append(label)
        return found_tags

    def _set_window_properties(self):
        import xbmcaddon
        import os
        import xbmc # <--- ADDED
        
        # --- DEBUG LOGGING FOR CLEARLOGO AND PLOT ---
        log_title = self.meta.get('title', 'Unknown')
        log_logo = self.meta.get('clearlogo', 'MISSING!')
        xbmc.log(f"[TMDb Movies] [RESULTS-WINDOW] Loading UI for: {log_title} | Logo: {log_logo}", xbmc.LOGINFO)
        # ----------------------------------------------
        
        self.setProperty('tmdbmovies.title', self.meta.get('title', 'Unknown'))
        self.setProperty('tmdbmovies.poster', self.meta.get('poster', ''))
        self.setProperty('tmdbmovies.plot', self.meta.get('plot', ''))
        self.setProperty('tmdbmovies.fanart', self.meta.get('fanart', ''))
        self.setProperty('tmdbmovies.clearlogo', self.meta.get('clearlogo', ''))
        self.setProperty('tmdbmovies.total_results', str(len(self.results)))

        try:
            import xbmcaddon
            from resources.lib.config import get_plot_language_code, LANG_TO_TMDB
            check_lang = get_plot_language_code()
            if check_lang in ('ro', 'enro'):
                addon_path = xbmcaddon.Addon('plugin.video.tmdbmovies').getAddonInfo('path')
                self.setProperty('tmdbmovies.flag_ro', os.path.join(addon_path, 'resources', 'media', 'ro.png'))
            else:
                lang_to_country = {
                    'en': 'gb', 'el': 'gr', 'cs': 'cz', 'sv': 'se',
                    'da': 'dk', 'no': 'no', 'sr': 'rs', 'uk': 'ua',
                    'he': 'il', 'vi': 'vn', 'ms': 'my', 'hi': 'in',
                    'fa': 'ir', 'zh': 'cn', 'ja': 'jp', 'ko': 'kr',
                    'ar': 'sa', 'eu': 'es',
                }
                country = lang_to_country.get(check_lang, check_lang)
                self.setProperty('tmdbmovies.flag_ro', f"https://flagcdn.com/80x60/{country}.png")
        except:
            self.setProperty('tmdbmovies.flag_ro', '')

        counts = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0}
        
        for r in self.results:
            quality = r.get('info', {}).get('quality', 'SD')
            if quality in counts:
                counts[quality] += 1
            else:
                counts['SD'] += 1

        self.setProperty('tmdbmovies.count_4k',    str(counts['4K']))
        self.setProperty('tmdbmovies.count_1080p', str(counts['1080p']))
        self.setProperty('tmdbmovies.count_720p',  str(counts['720p']))
        self.setProperty('tmdbmovies.count_sd',    str(counts['SD']))

        # Quality label colors based on theme
        try:
            theme_opt = ADDON.getSetting('source_theme')
        except:
            theme_opt = '0'
        is_custom = theme_opt == '3'
        if is_custom:
            try:
                p = os.path.join(os.path.dirname(__file__), 'json', 'colors.json')
                with open(p, 'r', encoding='utf-8') as f:
                    clist = json.load(f)
            except:
                clist = []
            def _qc(setting, default_idx):
                val = ADDON.getSetting(setting)
                if not val:
                    try: return clist[default_idx]['hex'] if clist else 'FF1E90FF'
                    except: return 'FF1E90FF'
                if val.startswith('[COLOR '): return val[7:15]
                if val.startswith('FF') and len(val) == 8: return val
                if val.isdigit():
                    try: return clist[int(val)]['hex'] if clist else 'FF1E90FF'
                    except: return 'FF1E90FF'
                for c in (clist or []):
                    if c['name'] == val: return c['hex']
                return 'FF1E90FF'
            c4k = _qc('color_4k', 20)
            c1080 = _qc('color_1080p', 49)
            c720 = _qc('color_720p', 30)
            csd = _qc('color_sd', 17)
        else:
            c4k = 'FFFF00FF'
            c1080 = 'FFDAA520'
            c720 = 'FF9932CC'
            csd = 'FF6495ED'
        self.setProperty('tmdbmovies.color_4k', c4k)
        self.setProperty('tmdbmovies.color_1080p', c1080)
        self.setProperty('tmdbmovies.color_720p', c720)
        self.setProperty('tmdbmovies.color_sd', csd)

        season = self.meta.get('season')
        episode = self.meta.get('episode')
        if season and episode:
            self.setProperty('tmdbmovies.episode_label', f"S{int(season):02d}E{int(episode):02d}")
        else:
            self.setProperty('tmdbmovies.episode_label', '')

    def _populate_list(self):
        items =[]
        global_poster = self.meta.get('poster', '')
        global_plot = self.meta.get('plot', '')
        
        import xbmcaddon
        try:
            theme_opt = ADDON.getSetting('source_theme')
        except:
            theme_opt = '0'
            
        is_simple = theme_opt == '1'
        is_mono = theme_opt == '2'
        is_custom = theme_opt == '3'
        
        try: show_indexers = ADDON.getSetting('show_aio_indexers') != 'false'
        except: show_indexers = True
        
        try: show_seeders = ADDON.getSetting('show_seeders') != 'false'
        except: show_seeders = True
        
        # Pre-compute custom colors ONCE (evitam getSetting() in loop)
        if is_custom:
            try:
                cp = os.path.join(os.path.dirname(__file__), 'json', 'colors.json')
                with open(cp, 'r', encoding='utf-8') as f:
                    _clist = json.load(f)
            except:
                _clist = []
            def _qc(setting, default_idx):
                val = ADDON.getSetting(setting)
                if not val:
                    try: return _clist[default_idx]['hex'] if _clist else 'FF1E90FF'
                    except: return 'FF1E90FF'
                if val.startswith('[COLOR '): return val[7:15]
                if val.startswith('FF') and len(val) == 8: return val
                if val.isdigit():
                    try: return _clist[int(val)]['hex'] if _clist else 'FF1E90FF'
                    except: return 'FF1E90FF'
                for c in (_clist or []):
                    if c['name'] == val: return c['hex']
                try: return _clist[default_idx]['hex'] if _clist else 'FF1E90FF'
                except: return 'FF1E90FF'
            c4k = _qc('color_4k', 20)
            c1080 = _qc('color_1080p', 49)
            c720 = _qc('color_720p', 30)
            csd = _qc('color_sd', 17)
        else:
            c4k = 'FFFF00FF'
            c1080 = 'FFDAA520'
            c720 = 'FF9932CC'
            csd = 'FF6495ED'
        
        for idx, res in enumerate(self.results):
            info = res.get('info', {})
            quality = info.get('quality', 'SD')
            size = info.get('size', '')
            provider = info.get('provider', 'Unknown')
            source_provider = info.get('source_provider', '')
            server = info.get('server', '')
            
            release_group = res.get('raw_stream_data', {}).get('releaseGroup', '')
            if not release_group:
                release_group = info.get('releaseGroup', '')
            
            raw_name = res['name']
            provider_id = res.get('raw_stream_data', {}).get('provider_id', '') or res.get('provider_id', '')
            
            is_aio = provider_id in ['aiostreams']
            is_stremio_addon = provider_id in ['torrentio', 'mediafusion', 'comet', 'meteor', 'torz', 'usenet', 'custom1', 'custom2', 'custom3', 'custom4', 'custom5']
            is_p2p = provider_id.startswith('p2p_')
            
            # --- ATRIBUIREA CULORILOR PENTRU FUNDAL ---
            if quality == '4K': 
                base_color = c4k
            elif quality == '1080p': 
                base_color = c1080
            elif quality == '720p': 
                base_color = c720
            else: 
                base_color = csd
                
            hl_focus = '35' + base_color[2:]
            
            if is_simple or is_mono:
                hl_unfocus = 'FFCCCCCC' 
                hl_dim = '25FFFFFF'     
            else:
                # Si "Custom" si "Multicolor" au fundalul colorat
                hl_unfocus = base_color
                hl_dim = '15' + base_color[2:]

# -------------------------------------------------------------
            # LOGICA DEBRID (Coloana stanga sub Calitate)
            # -------------------------------------------------------------
            debrid_label = 'HTTP'

            if is_p2p:
                debrid_label = '[COLOR gold]P2P[/COLOR]'
            elif is_aio or is_stremio_addon:
                addon_name_raw = info.get('addon', '')
                addon_name_lower = addon_name_raw.lower()
                source_provider_lower = info.get('source_provider', '').lower()
                
                if 'usenet' in addon_name_lower or 'usenet' in source_provider_lower:
                    debrid_label = 'NZB'
                else:
                    debrid_service = info.get('debrid_service', '').lower().replace('-', '').replace('.', '')
                    if debrid_service in ('none', 'nodebrid', 'noname', 'noprovider') or debrid_service.startswith('no') or not debrid_service:
                        base_name = 'AIO' if is_aio else 'HTTP'
                    else:
                        base_name = DEBRID_SHORTNAMES.get(debrid_service, debrid_service[:2].upper())
                    
                    if info.get('is_cloud'):
                        debrid_label = f"{base_name}++"
                    elif info.get('is_cached'):
                        debrid_label = f"{base_name}+"
                    else:
                        debrid_label = base_name

            # -------------------------------------------------------------
            # CONSTRUIRE INFO LINE (Randul 2)
            # -------------------------------------------------------------
            parts =[]
            
            if size and size != "N/A": 
                parts.append(f"[COLOR lime][B]{size}[/B][/COLOR]")
            
            # Detectare RO DUBBED (mutat devreme ca sa fie disponibil pentru FileList/SpeedApp/SeedPool)
            ro_indexer = info.get('indexer', '')
            if _RO_DUB_RE.search(raw_name) or _RO_DUB_RE.search(ro_indexer):
                ro_dub_tag = "[COLOR FFDAA520][B]RO DUB[/B][/COLOR]"
            else:
                ro_dub_tag = ""
            
            # FileList / SpeedApp numele imediat dupa size
            _fl_handled = False
            _sa_handled = False
            _sp_handled = False
            if provider_id == 'p2p_filelist':
                parts.append(f"[COLOR FF00BFFF][B]FileList[/B][/COLOR]")
                fl_indexer = info.get('indexer', '')
                if show_indexers and fl_indexer and not ro_dub_tag:
                    parts.append(f"[COLOR lightskyblue][B]{fl_indexer}[/B][/COLOR]")
                _fl_handled = True
            elif provider_id == 'p2p_speedapp':
                parts.append("[COLOR FFFFFF00][B]SpeedApp[/B][/COLOR]")
                sa_indexer = info.get('indexer', '')
                if show_indexers and sa_indexer and not ro_dub_tag:
                    parts.append(f"[COLOR lightskyblue][B]{sa_indexer}[/B][/COLOR]")
                _sa_handled = True
            elif provider_id == 'p2p_seedpool':
                parts.append("[COLOR FFFF5555][B]SeedPool[/B][/COLOR]")
                sp_indexer = info.get('indexer', '')
                if show_indexers and sp_indexer and not ro_dub_tag:
                    parts.append(f"[COLOR lightskyblue][B]{sp_indexer}[/B][/COLOR]")
                _sp_handled = True
            
            # P2P flags (FREE/2X/INT/HALF)
            if is_p2p and provider_id == 'p2p_filelist':
                if info.get('freeleech'):
                    parts.append("[COLOR FF00FF00][B]FREE[/B][/COLOR]")
                if info.get('doubleup'):
                    parts.append("[COLOR FFFFFF00][B]2X[/B][/COLOR]")
                if info.get('internal'):
                    parts.append("[COLOR FF87CEEB][B]INT[/B][/COLOR]")
            if is_p2p and provider_id == 'p2p_speedapp':
                if info.get('freeleech'):
                    parts.append("[COLOR FF00FF00][B]FREE[/B][/COLOR]")
                if info.get('doubleup'):
                    parts.append("[COLOR FFFFFF00][B]2X[/B][/COLOR]")
                if info.get('halfdw'):
                    parts.append("[COLOR FF50C878][B]½DW[/B][/COLOR]")
                if info.get('internal'):
                    parts.append("[COLOR FF87CEEB][B]INT[/B][/COLOR]")
            if is_p2p and provider_id == 'p2p_seedpool':
                if info.get('freeleech'):
                    parts.append("[COLOR FF00FF00][B]FREE[/B][/COLOR]")
                if info.get('doubleup'):
                    parts.append("[COLOR FFFFFF00][B]2X[/B][/COLOR]")
                if info.get('internal'):
                    parts.append("[COLOR FF87CEEB][B]INT[/B][/COLOR]")
            
            # Formatare Addon si Indexer (Pentru AIO si Stremio Addons) vs HTTP Normal
            if is_aio or is_stremio_addon:
                addon_name = info.get('addon', '')
                indexer = info.get('indexer', '')
                
                if ro_dub_tag:
                    parts.append(ro_dub_tag)
                if addon_name and addon_name.lower() != 'none':
                    if is_stremio_addon:
                        addon_color = 'FFCCCCFF'
                    else:
                        addon_color = AIO_ADDON_COLORS.get(addon_name.lower(), 'FF00BFFF')
                        
                    parts.append(f"[COLOR {addon_color}][B]{addon_name}[/B][/COLOR]")
                
                if show_indexers and indexer and indexer.lower() != 'none':
                    idx_display = indexer
                    if addon_name and idx_display.lower().startswith(addon_name.lower()):
                        suffix = idx_display[len(addon_name):]
                        if suffix and suffix[0] in ' |,':
                            idx_display = suffix.strip(' |-,.')
                    if idx_display:
                        parts.append(f"[COLOR lightskyblue][B]{idx_display}[/B][/COLOR]")
                        
            if not (is_aio or is_stremio_addon):
                # HTTP Normal sau P2P
                p_color = AIO_ADDON_COLORS.get(provider_id.lower(), 'red')
                if _fl_handled:
                    if ro_dub_tag:
                        parts.append(ro_dub_tag)
                elif _sa_handled:
                    if ro_dub_tag:
                        parts.append(ro_dub_tag)
                elif _sp_handled:
                    if ro_dub_tag:
                        parts.append(ro_dub_tag)
                elif provider_id == 'p2p_knaben':
                    if ro_dub_tag:
                        parts.append(ro_dub_tag)
                    parts.append(f"[COLOR {p_color}][B]Knaben[/B][/COLOR]")
                    if show_indexers:
                        kn_indexer = info.get('indexer', '')
                        if kn_indexer and not ro_dub_tag:
                            parts.append(f"[COLOR lightskyblue][B]{kn_indexer}[/B][/COLOR]")
                elif provider_id == 'p2p_thepiratebay':
                    if ro_dub_tag:
                        parts.append(ro_dub_tag)
                    parts.append(f"[COLOR {p_color}][B]TPB[/B][/COLOR]")
                elif 'vsembed' in raw_name.lower():
                    p_color = AIO_ADDON_COLORS.get('vsembed', 'FFFFA500')
                    if source_provider and source_provider.lower() != provider.lower():
                        parts.append(f"[COLOR {p_color}][B]{provider} [COLOR FF7B68EE]{source_provider}[/B][/COLOR]")
                    else:
                        parts.append(f"[COLOR {p_color}][B]{provider}[/B][/COLOR]")
                    if show_indexers and server and server.lower() not in [provider.lower(), source_provider.lower()]:
                        parts.append(f"[COLOR FF7B68EE][B]{server}[/B][/COLOR]")
                else:
                    if ro_dub_tag:
                        parts.append(ro_dub_tag)
                    _sp_dupe = bool(source_provider and provider and source_provider.lower() in provider.lower())
                    if source_provider and not _sp_dupe and source_provider.lower() != provider.lower():
                        parts.append(f"[COLOR {p_color}][B]{provider} [COLOR FF7B68EE]{source_provider}[/B][/COLOR]")
                    else:
                        parts.append(f"[COLOR {p_color}][B]{provider}[/B][/COLOR]")
                    if show_indexers and server and server.lower() not in [provider.lower(), source_provider.lower()]:
                        parts.append(f"[COLOR FF7B68EE][B]{server}[/B][/COLOR]")

            if release_group:
                parts.append(f"[COLOR FFFF69B4][B]{release_group}[/B][/COLOR]")

            # --- Adaugare Seederi (dupa release group, inainte de WEB-DL/extensie) ---
            if show_seeders or is_p2p:
                seeders = 0
                raw_stream = res.get('raw_stream_data', {})

                if 'seeders' in raw_stream:
                    seeders = raw_stream.get('seeders', 0)
                elif isinstance(raw_stream.get('info'), dict) and 'seeders' in raw_stream['info']:
                    seeders = raw_stream['info'].get('seeders', 0)

                if not seeders:
                    m = _SEEDERS_RE.search(raw_name)
                    if m: seeders = int(m.group(1))

                if seeders and str(seeders) != '0':
                    parts.append(f"[COLOR FF87CEEB][B]S: {seeders}[/B][/COLOR]")
            # ----------------------------------------------------------------------

            # Eticheta extensie fisier (MKV/MP4/AVI etc.)
            _ext_tag = ''
            # Incerc intai din URL, apoi din numele release-ului
            _u = res.get('raw_stream_data', {})
            if isinstance(_u, dict):
                _url = _u.get('url', '')
                if not _url:
                    _url = res.get('url', '')
                if _url:
                    _clean = _url.split('|')[0].split('?')[0].rstrip('/')
                    _xm = re.search(r'\.([a-zA-Z0-9]{2,4})$', _clean)
                    if _xm:
                        _ext_tag = _xm.group(1).upper()
            if not _ext_tag:
                _xm = re.search(r'\.(mkv|mp4|avi|mov|wmv|flv|webm|ts|ogv)(?:\s|$|\))', raw_name, re.I)
                if _xm:
                    _ext_tag = _xm.group(1).upper()
            if _ext_tag in ('MKV','MP4','AVI','MOV','WMV','FLV','WEBM','TS','OGV'):
                parts.append(f"[COLOR FFCCCCFF][B]{_ext_tag}[/B][/COLOR]")
                
            # Etichete Video si Audio
            codec = self._extract_codec(raw_name)
            source = self._extract_source(raw_name)
            hdr_tags = self._extract_hdr(raw_name)
            audio_tags = self._extract_audio(raw_name)
            
            # Sistem de dedublare inteligenta
            added_tags_normalized = []
            
            def add_tag(tag, color=None, bold=True):
                if not tag: return
                clean_tag = _COLOR_STRIP_RE.sub('', tag).strip().upper()
                clean_tag = clean_tag.replace('[B]', '').replace('[/B]', '')
                if clean_tag in added_tags_normalized: return
                for existing in added_tags_normalized:
                    if clean_tag in existing or existing in clean_tag: return
                added_tags_normalized.append(clean_tag)
                
                final_tag = tag
                if bold and '[B]' not in final_tag: final_tag = f"[B]{final_tag}[/B]"
                if color and '[COLOR' not in final_tag: final_tag = f"[COLOR {color}]{final_tag}[/COLOR]"
                parts.append(final_tag)

            if source:
                src_up = source.upper()
                if 'REMUX' in src_up: add_tag('REMUX', 'FFFF0000')
                elif 'BLURAY' in src_up or 'BLU-RAY' in src_up: add_tag('BluRay', 'FF00BFFF')
                elif 'WEBRIP' in src_up: add_tag('WebRip', 'FF00FA9A')
                elif 'WEB' in src_up: add_tag('WEB-DL', 'FF00FA9A')
                elif 'BDRIP' in src_up or 'BRRIP' in src_up: add_tag('BDRip', 'FFDDA0DD')
                elif 'TS' in src_up or 'TC' in src_up: add_tag('TS/TC', 'FF808080')
                elif 'HDTV' in src_up: add_tag('HDTV', 'FF87CEEB')
                elif 'CAM' in src_up: add_tag('CAM', 'FFFF0000')
                elif 'HDRIP' in src_up: add_tag('HDRip', 'FFBA55D3')
                elif 'DVDRIP' in src_up: add_tag('DVDRip', 'FFFFA500')
                elif 'DVDSCR' in src_up: add_tag('DVDScr', 'FFFF6347')
                else: add_tag(source, 'FFAAAAAA')

            if codec:
                cod_up = codec.upper()
                if 'HEVC' in cod_up or '265' in cod_up: add_tag('HEVC', 'red')
                elif '264' in cod_up: add_tag('x264', 'red')
                else: add_tag(codec)

            for htag in hdr_tags:
                add_tag(htag, 'FFFFCC00')

            for atag in audio_tags:
                aud_up = atag.upper()
                color = 'FF7CFC00'
                if 'ATMOS' in aud_up: color = 'FFFF4500'
                elif 'TRUEHD' in aud_up: color = 'FFFF4500'
                elif 'DTS' in aud_up: color = 'FF1E90FF'
                elif 'DDP' in aud_up or 'DD+' in aud_up or 'EAC' in aud_up: color = 'FFADFF2F'
                elif 'AC3' in aud_up: color = 'FF7CFC00'
                elif 'AAC' in aud_up: color = 'FFFFFFFF'
                elif 'FLAC' in aud_up: color = 'FF00CED1'
                add_tag(atag, color)
            
            def _color_tag(tag):
                tu = tag.upper()
                if 'MULTI' in tu: return 'FFFFCC00'
                if 'REMUX' in tu: return 'FFFF0000'
                if 'BLURAY' in tu or 'BLU-RAY' in tu or 'BDRIP' in tu or 'BRRIP' in tu: return 'FF00BFFF'
                if 'WEB' in tu or 'WEBRIP' in tu: return 'FF00FA9A'
                if 'HEVC' in tu or '265' in tu or '264' in tu or 'AV1' in tu: return 'FFFF0000'
                if 'ATMOS' in tu or 'TRUEHD' in tu: return 'FFFF4500'
                if 'DTS' in tu: return 'FF1E90FF'
                if 'DDP' in tu or 'DD+' in tu or 'EAC3' in tu or 'EAC' in tu: return 'FFADFF2F'
                if 'AC3' in tu or 'DD ' in tu or tu == 'DD': return 'FF7CFC00'
                if 'AAC' in tu: return 'FFFFFFFF'
                if 'FLAC' in tu: return 'FF00CED1'
                if 'DV' in tu or 'DOVI' in tu or 'VISION' in tu: return 'FFFFCC00'
                if 'HDR' in tu: return 'FFFFCC00'
                return None
            scraper_tags = info.get('tags',[])
            for t in scraper_tags:
                tc = _color_tag(t)
                add_tag(t, tc or 'gray', bold=True)

            info_line_colored = " | ".join(parts)
            info_line_white = _COLOR_STRIP_RE.sub('', info_line_colored)
            
            # Daca e Simplu, Mono sau Custom, folosim text curat (alb/gri) cand NU are focus
            if is_simple or is_mono or is_custom:
                info_line_unfocus = info_line_white
            else:
                info_line_unfocus = info_line_colored
            
            # STABILIM CULOAREA TITLULUI SI TEXTULUI LA FOCUS
            if is_mono or is_custom:
                # EXACT CA LA MONO - Doar alb si gri deschis
                info_line_focus = info_line_white
                title_color_focus = 'FFCCCCFF' # Gri-ul simplu
            else:
                # MULTICOLOR
                info_line_focus = info_line_colored
                title_color_focus = 'FFCCCCFF' # FFFFFF00 Galbenul original stralucitor FFCCCCFF silver

            li = xbmcgui.ListItem(res['name'])
            
            li.setProperty('tmdbmovies.count', f"{idx+1}.")
            li.setProperty('tmdbmovies.quality', quality)
            li.setProperty('tmdbmovies.debrid', debrid_label)  
            li.setProperty('tmdbmovies.highlight', base_color)
            li.setProperty('tmdbmovies.hl_unfocus', hl_unfocus)
            li.setProperty('tmdbmovies.highlight_dim', hl_dim)
            li.setProperty('tmdbmovies.highlight_focus', hl_focus)
            li.setProperty('tmdbmovies.name', res['name'])
            li.setProperty('tmdbmovies.title_color_focus', title_color_focus)
            li.setProperty('tmdbmovies.info_line_unfocus', info_line_unfocus)
            li.setProperty('tmdbmovies.info_line_focus', info_line_focus)
            li.setProperty('tmdbmovies.quality_icon', QUALITY_ICONS.get(quality, 'flagsd.png'))
            
            li.setProperty('tmdbmovies.poster', global_poster)
            li.setProperty('tmdbmovies.plot', global_plot)
            li.setProperty('tmdbmovies.fanart', self.meta.get('fanart', ''))
            li.setProperty('tmdbmovies.provider', provider)
            li.setProperty('tmdbmovies.server', server)
            li.setProperty('tmdbmovies.size', size)
            li.setProperty('tmdbmovies.group', release_group)
            li.setProperty('tmdbmovies.codec', codec)
            li.setProperty('tmdbmovies.audio', ', '.join(audio_tags))
            li.setProperty('tmdbmovies.lang', ', '.join(info.get('languages', [])))
            li.setProperty('tmdbmovies.addon', info.get('addon', ''))
            li.setProperty('tmdbmovies.indexer', info.get('indexer', '')) # Ignoram setarea de hide pentru Info
            
            # Status si Tip
            is_cached = info.get('is_cached', False)
            li.setProperty('tmdbmovies.status', '[COLOR lime]Cached[/COLOR]' if is_cached else '[COLOR orange]Not Cached[/COLOR]')
            li.setProperty('tmdbmovies.stream_type', '[COLOR cyan]AIO Stream[/COLOR]' if is_aio or is_stremio_addon else 'Direct Stream')
            
            li.setProperty('tmdbmovies.tags', ', '.join(info.get('tags', [])))
            li.setProperty('tmdbmovies.data', json.dumps(res['raw_stream_data']))
            
            items.append(li)
            
        self.getControl(2000).addItems(items)

    def onClick(self, controlId):
        if controlId == 2000:
            item = self.getControl(2000).getSelectedItem()
            if item:
                self.selected = item.getProperty('tmdbmovies.data')
            self.close()
        elif controlId == 3000:
            return

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (117, 101):
            try:
                if self.getFocusId() == 3000:
                    return
            except:
                pass
            import time
            if time.time() - self.last_cm_time < 0.5:
                return
            self.handle_context_menu()
            self.last_cm_time = time.time()
            return
        if action_id in (9, 10, 13, 92, 110):
            try:
                if self.getFocusId() == 3000:
                    return
            except:
                pass
            if self.filter_applied:
                self.clear_filter()
                return
            self.selected = None
            self.close()

    def handle_context_menu(self):
        try:
            ctrl = self.getControl(2000)
            item = ctrl.getSelectedItem()
            if not item: return
            
            raw_data = item.getProperty('tmdbmovies.data')
            if not raw_data: return
            stream_data = json.loads(raw_data)
            
            tmdb_id = str(self.meta.get('tmdb_id', ''))
            season = self.meta.get('season')
            episode = self.meta.get('episode')
            c_type = 'tv' if season and episode else 'movie'
            
            from resources.lib.downloader import get_dl_id, start_download_thread
            import xbmcgui
            
            unique_id = get_dl_id(tmdb_id, c_type, season, episode)
            window = xbmcgui.Window(10000)
            is_downloading = window.getProperty(unique_id) == 'active'
            
            options = []
            options.append("[B][COLOR FFFDBD01]Source Info[/COLOR][/B]")
            if is_downloading:
                options.append("[B][COLOR red]Stop Download[/COLOR][/B]")
            else:
                options.append("[B][COLOR cyan]Download Source[/COLOR][/B]")

            options.append("[B]SHOW 4K ONLY[/B]")
            options.append("[B]SHOW 1080P ONLY[/B]")
            options.append("[B]SHOW 720P ONLY[/B]")
            options.append("[B]SHOW SD ONLY[/B]")
            options.append("[B]Filter by HDR/DV[/B]")
            options.append("[B]Filter by SDR[/B]")
            options.append("[B]Filter by Provider[/B]")
            options.append("[B]Filter by Title[/B]")
            options.append("[B]Filter by Info[/B]")
                
            ret = xbmcgui.Dialog().contextmenu(options)
            if ret == 0:
                if self.is_info_open: return
                
                import xbmc
                import time
                # Blocam imediat orice alta incercare (debounce preventiv pentru mouse)
                self.last_cm_time = time.time() + 2.0
                self.is_info_open = True
                
                # Inchidem meniul contextual fortat
                xbmc.executebuiltin('Dialog.Close(contextmenu, true)')
                xbmc.sleep(400) 
                
                # Deschidem fereastra de Info
                dialog = SourcesInfo('sources_info.xml', ADDON_PATH, 'Default', '1080i', item=item, meta=self.meta)
                dialog.doModal()
                del dialog
                
                self.is_info_open = False
                self.last_cm_time = time.time() + 1.5
                xbmc.executebuiltin('Dialog.Close(contextmenu, true)')
            elif ret == 1:
                # Logica Download
                if is_downloading:
                    window.setProperty(f"{unique_id}_stop", "true")
                    window.clearProperty(unique_id)
                    xbmcgui.Dialog().notification("Download", "Stopping...", "", 2000, False)
                else:
                    url = stream_data.get('url', '')
                    raw_release_name = stream_data.get('title', '')
                    if not raw_release_name or len(raw_release_name) < 10:
                        raw_release_name = stream_data.get('name', '')
                    
                    if c_type == 'tv':
                        title = self.meta.get('tvshowtitle', self.meta.get('title', ''))
                    else:
                        title = self.meta.get('title', '')
                        
                    year = str(self.meta.get('year', ''))
                    
                    start_download_thread(url, title, year, tmdb_id, c_type, season, episode, release_name=raw_release_name)
            elif ret == 2: self.apply_filter('quality', '4K')
            elif ret == 3: self.apply_filter('quality', '1080p')
            elif ret == 4: self.apply_filter('quality', '720p')
            elif ret == 5: self.apply_filter('quality', 'SD')
            elif ret == 6: self.apply_filter('hdr', True)
            elif ret == 7: self.apply_filter('sdr', True)
            elif ret == 8:
                providers = sorted(list(set([str(r.get('info', {}).get('provider') or r.get('raw_stream_data', {}).get('provider_id', '') or r.get('provider_id', '')).strip() for r in self.all_results if (r.get('info', {}).get('provider') or r.get('raw_stream_data', {}).get('provider_id') or r.get('provider_id'))])))
                if not providers: return
                p_idx = xbmcgui.Dialog().select("Select Provider", providers)
                if p_idx >= 0:
                    self.apply_filter('provider', providers[p_idx])
            elif ret == 9:
                keyword = xbmcgui.Dialog().input("Enter keyword")
                if keyword:
                    self.apply_filter('title', keyword)
            elif ret == 10:
                all_tags = []
                for r in self.all_results:
                    # Colectam toate tag-urile din info/tags
                    t_list = r.get('info', {}).get('tags', [])
                    if isinstance(t_list, list):
                        all_tags.extend(t_list)
                
                # Eliminam '7.1' deoarece este considerat junk/incorect
                tags = sorted(list(set([t for t in all_tags if t != '7.1'])))
                if not tags: 
                    xbmcgui.Dialog().notification("Filter", "No info tags found!", "", 2000, False)
                    return
                    
                t_idx = xbmcgui.Dialog().select("Filter by Info (Tags)", tags)
                if t_idx >= 0:
                    self.apply_filter('info', tags[t_idx])
        except Exception as e:
            import xbmc
            xbmc.log(f"[CM ERROR] {e}", xbmc.LOGERROR)

    def apply_filter(self, filter_type, value):
        import xbmcgui
        if filter_type == 'quality':
            self.results = [r for r in self.all_results if r.get('info', {}).get('quality') == value]
        elif filter_type == 'hdr':
            self.results = [r for r in self.all_results if any(x in ['HDR', 'HDR10', 'HDR10+', 'DV', 'Dolby Vision'] for x in r.get('info', {}).get('tags', []))]
        elif filter_type == 'sdr':
            self.results = [r for r in self.all_results if not any(x in ['HDR', 'HDR10', 'HDR10+', 'DV', 'Dolby Vision'] for x in r.get('info', {}).get('tags', []))]
        elif filter_type == 'provider':
            v = str(value).strip().lower()
            def _prov_match(r):
                prov = str(r.get('info', {}).get('provider') or '').strip().lower()
                if prov == v:
                    return True
                pid = str(r.get('raw_stream_data', {}).get('provider_id') or r.get('provider_id') or '').strip().lower()
                if pid == v:
                    return True
                return False
            self.results = [r for r in self.all_results if _prov_match(r)]
        elif filter_type == 'title':
            self.results = [r for r in self.all_results if value.lower() in r['name'].lower()]
        elif filter_type == 'info':
            self.results = [r for r in self.all_results if value.lower() in str(r.get('info', {})).lower()]
        
        if not self.results:
            xbmcgui.Dialog().notification("Filter", "No results for this filter!", "", 2000, False)
            self.results = list(self.all_results)
            return

        self.filter_applied = True
        self.getControl(2000).reset()
        self._populate_list()
        self.setProperty('tmdbmovies.total_results', str(len(self.results)))
        self.setProperty('tmdbmovies.filter_applied', 'true')

    def clear_filter(self):
        self.filter_applied = False
        self.results = list(self.all_results)
        self.getControl(2000).reset()
        self._populate_list()
        self.setProperty('tmdbmovies.total_results', str(len(self.results)))
        self.setProperty('tmdbmovies.filter_applied', 'false')

    def _build_source_info(self, stream_data):
        import re
        from urllib.parse import urlparse, unquote
        
        info = stream_data.get('info', {})
        
        # Extragem Numele
        raw_name = stream_data.get('title', '')
        if not raw_name or len(raw_name) < 5:
            raw_name = stream_data.get('name', '')
        raw_name = ''.join(c for c in raw_name if ord(c) <= 0xFFFF)
            
        clean_dots = raw_name.replace('.', ' ').replace('_', ' ')
        
        # Extragem Calitatea si Marimea CORECT (Aici era bugul cu SD)
        quality = stream_data.get('quality', 'SD')
        size = stream_data.get('size') or info.get('size', '')
        
        lines = []
        lines.append(f"[COLOR FF00CED1]■ FILE:[/COLOR] [B]{raw_name}[/B]")
        lines.append("")
        
        # --- VIDEO ---
        source = self._extract_source(raw_name)
        codec = self._extract_codec(raw_name)
        hdr_tags = self._extract_hdr(raw_name)
        
        vid_parts = [f"[COLOR FF00FA9A]Quality:[/COLOR] {quality}"]
        if source: vid_parts.append(f"[COLOR FF00FA9A]Source:[/COLOR] {source}")
        if codec: vid_parts.append(f"[COLOR FF00FA9A]Codec:[/COLOR] {codec}")
        if hdr_tags: vid_parts.append(f"[COLOR FF00FA9A]HDR:[/COLOR] {' / '.join(hdr_tags)}")
        
        # Varianta (Extended / Unrated etc)
        editions = []
        for tag in ['PROPER', 'REPACK', 'EXTENDED', 'UNCUT', 'DIRECTOR', 'UNRATED']:
            if re.search(rf'(?i)\b{tag}\b', raw_name): editions.append(tag.upper())
        if editions: vid_parts.append(f"[COLOR FF00FA9A]Edition:[/COLOR] {' '.join(editions)}")
        
        lines.append(" • ".join(vid_parts))
        
        # --- AUDIO ---
        audio_tags = self._extract_audio(raw_name)
        ch_match = re.search(r'(?i)\b(7\.1|5\.1|2\.0|2\.1|1\.0)\b', clean_dots)
        
        aud_parts = []
        if audio_tags: aud_parts.append(f"[COLOR FFFF4500]Audio:[/COLOR] {' / '.join(audio_tags)}")
        if ch_match: aud_parts.append(f"[COLOR FFFF4500]Canale:[/COLOR] {ch_match.group(1)}")
        if aud_parts:
            lines.append(" • ".join(aud_parts))
            
        # --- LIMBI ---
        lang_in_title = []
        for lp, ln in [
            (r'(?i)\bRO(?:manian)?\b', 'Romanian'),
            (r'(?i)\bEN(?:glish)?\b', 'English'),
            (r'(?i)\bMULTI\b', 'Multi-Audio'),
            (r'(?i)\bDUAL\b', 'Dual-Audio'),
            (r'(?i)\bHUN(?:garian)?\b', 'Hungarian'),
            (r'(?i)\bGER(?:man)?\b|DEUTSCH', 'German'),
            (r'(?i)\bFR(?:ench|E)?\b', 'French'),
            (r'(?i)\bITA(?:lian)?\b', 'Italian'),
            (r'(?i)\bSPA(?:nish)?\b', 'Spanish'),
            (r'(?i)\bHIN(?:di)?\b', 'Hindi')
        ]:
            if re.search(lp, clean_dots):
                lang_in_title.append(ln)
        
        if lang_in_title:
            lines.append(f"[COLOR FF87CEEB]Language:[/COLOR] {', '.join(lang_in_title)}")
            
        lines.append("")
        
        # --- HOSTING / STATUS ---
        seeders = info.get('seeders', 0)
        host_parts = []
        if size: host_parts.append(f"[COLOR FFFDBD01]Size:[/COLOR] {size}")
        if seeders and str(seeders) != '0': host_parts.append(f"[COLOR FFFDBD01]Seeders:[/COLOR] {seeders}")
        
        is_cached = info.get('is_cached', False)
        is_cloud = info.get('is_cloud', False)
        url = str(stream_data.get('url', ''))
        
        if is_cached:
            host_parts.append("[COLOR FFFDBD01]Status:[/COLOR] [COLOR lime]Cached (Debrid)[/COLOR]")
        elif is_cloud:
            host_parts.append("[COLOR FFFDBD01]Status:[/COLOR] [COLOR cyan]Cloud[/COLOR]")
        elif 'magnet:' in url:
            host_parts.append("[COLOR FFFDBD01]Status:[/COLOR] [COLOR red]P2P (Not Cached)[/COLOR]")
        elif url.startswith('http'):
            host_parts.append("[COLOR FFFDBD01]Status:[/COLOR] HTTP Direct Link")
            
        if host_parts:
            lines.append(" • ".join(host_parts))
            
        # --- PROVIDER INFO ---
        addon = info.get('addon', '') or stream_data.get('provider_id', '')
        indexer = info.get('indexer', '') or info.get('server', '')
        debrid = info.get('debrid_service', '')
        
        prov_parts = []
        if addon: prov_parts.append(f"[COLOR gray]Addon:[/COLOR] {addon.capitalize()}")
        if indexer: prov_parts.append(f"[COLOR gray]Tracker:[/COLOR] {indexer.capitalize()}")
        if debrid: prov_parts.append(f"[COLOR gray]Debrid:[/COLOR] {debrid.capitalize()}")
        
        if prov_parts:
            lines.append(" • ".join(prov_parts))
            
        # --- DATE TEHNICE ---
        if url:
            tech_parts = []
            if 'btih:' in url:
                hash_m = re.search(r'btih:([a-fA-F0-9]+)', url)
                if hash_m: tech_parts.append(f"[COLOR gray]Hash:[/COLOR] {hash_m.group(1)[:25]}...")
            elif url.startswith('http'):
                try:
                    domain = urlparse(url.split('|')[0]).netloc
                    tech_parts.append(f"[COLOR gray]Domain:[/COLOR] {domain}")
                except: pass
                
            if tech_parts:
                lines.append(" • ".join(tech_parts))
                
        return '\n'.join(lines)


