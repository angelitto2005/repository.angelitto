import requests
import xbmc
import xbmcvfs
import re
import json
import base64
import hashlib
import time
import random
import datetime
import threading
from urllib.parse import urlencode, quote, urlparse
from resources.lib.config import BASE_URL, API_KEY, ADDON, get_headers, get_random_ua
from resources.lib.utils import get_json, clean_text
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# === SESSION POOLING PENTRU PERFORMANTA ===
# Refoloseste conexiunile TCP in loc sa creeze una noua pentru fiecare request
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# =============================================================================
# CONSTANTE GLOBALE
# =============================================================================
MAX_WORKERS = 10  # Numarul maxim de thread-uri paralele

def get_session():
    """Returneaza o sesiune requests optimizata cu connection pooling."""
    session = requests.Session()
    
    # Retry automat pentru erori temporare
    retry_strategy = Retry(
        total=2,
        backoff_factor=0.3,
        status_forcelist=[500, 502, 503, 504],
    )
    
    adapter = HTTPAdapter(
        pool_connections=20,
        pool_maxsize=20,
        max_retries=retry_strategy
    )
    
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    
    return session

# Sesiune globala pentru refolosire
_global_session = None

def get_shared_session():
    """Returneaza sesiunea partajata (thread-safe pentru citire)."""
    global _global_session
    if _global_session is None:
        _global_session = get_session()
    return _global_session


# --- HELPERE ---
# =============================================================================
# LOGGING CU VERIFICARE SETARI
# =============================================================================
_debug_cache = None

def _is_debug_enabled():
    """Verifica daca debug-ul e activat (cu cache pentru performanta)."""
    global _debug_cache
    if _debug_cache is None:
        try:
            _debug_cache = ADDON.getSetting('debug_enabled') == 'true'
        except:
            _debug_cache = True  # Default on daca nu poate citi setarea
    return _debug_cache

def reset_debug_cache():
    """Reseteaza cache-ul debug (apelat cand se schimba setarile)."""
    global _debug_cache
    _debug_cache = None

def log(msg, level=xbmc.LOGINFO):
    """
    Logheaza mesaje respectand setarea debug din addon.
    - LOGERROR si LOGWARNING: se logheaza MEREU (erori importante)
    - LOGINFO si LOGDEBUG: doar daca debug e activat in setari
    """
    # Erorile si warning-urile se logheaza mereu
    if level in (xbmc.LOGERROR, xbmc.LOGWARNING):
        xbmc.log(f"[TMDb Movies] {msg}", level)
        return
    
    # Info/Debug doar daca e activat
    if _is_debug_enabled():
        xbmc.log(f"[TMDb Movies] {msg}", level)

def get_external_ids(content_type, tmdb_id):
    url = f"{BASE_URL}/{content_type}/{tmdb_id}/external_ids?api_key={API_KEY}"
    return get_json(url)

# =============================================================================
# HELPER PENTRU CONSTRUIREA URL-URILOR CU HEADERE (IMPORTANT!)
# =============================================================================

# UA fix pentru AIO/Stremio/Debrid playback URLs — folosit in loc de get_random_ua()
# pentru a permite reutilizarea conexiunilor HTTP (acelasi UA de fiecare data)
_AIO_UA_HEADERS = "User-Agent=Mozilla%2F5.0+%28Linux%3B+Android+13%3B+M2101K6G%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F120.0.0.0+Mobile+Safari%2F537.36&Connection=keep-alive"

def build_stream_url(url, referer=None, origin=None, user_agent=None):
    if '|' in url:
        return url

    headers = {
        'User-Agent': user_agent if user_agent else get_random_ua(),
        'Connection': 'keep-alive'
    }

    if referer:
        headers['Referer'] = referer
    if origin:
        headers['Origin'] = origin

    return f"{url}|{urlencode(headers)}"


def _parse_m3u8_variants(master_url, custom_headers=None):
    """Parses master m3u8 playlist to find available resolutions."""
    try:
        session = get_shared_session()
        headers = custom_headers if custom_headers else {"User-Agent": "Mozilla/5.0"}
        resp = session.get(master_url, headers=headers, timeout=10, verify=False)
        if resp.status_code != 200:
            return []
            
        content = resp.text
        lines = content.splitlines()
        variants = []
        base = master_url.rsplit("/", 1)[0]
        
        for i, line in enumerate(lines):
            if "#EXT-X-STREAM-INF" in line:
                resolution = "UNKNOWN"
                if "RESOLUTION=" in line:
                    try:
                        resolution = line.split("RESOLUTION=")[1].split(",")[0]
                    except: pass
                
                # Cautam urmatoarea linie care nu e comentariu si nu e goala
                final_url = None
                for j in range(i + 1, len(lines)):
                    next_line = lines[j].strip()
                    if not next_line or next_line.startswith("#"):
                        continue
                    
                    if next_line.startswith("http"):
                        final_url = next_line
                    elif next_line.startswith("/"):
                        parsed = urlparse(master_url)
                        final_url = f"{parsed.scheme}://{parsed.netloc}{next_line}"
                    else:
                        final_url = f"{base}/{next_line}"
                    break
                
                if final_url:
                    variants.append({
                        "resolution": resolution,
                        "url": final_url
                    })
        return variants
    except Exception as e:
        log(f"[M3U8] Error parsing variants for {master_url}: {e}")
        return []


def _get_quality_from_res(res_val):
    """Detecteaza eticheta de calitate (1080p, 720p etc.) din string-ul de rezolutie."""
    if not res_val or res_val == "UNKNOWN": return 'SD'
    res_val = res_val.lower()
    if '2160' in res_val or '3840' in res_val or '4k' in res_val: return '4K'
    if '1080' in res_val or '1920' in res_val: return '1080p'
    if '720' in res_val or '1280' in res_val: return '720p'
    match = re.search(r'x(\d+)', res_val)
    if match:
        h = int(match.group(1))
        if h >= 2160: return '4K'
        if h >= 1000: return '1080p'
        if h >= 700: return '720p'
    return 'SD'


# =============================================================================
# FILTRARE CALITATE - PENTRU UI (NU PENTRU CAUTARE!)
# =============================================================================

def _get_quality_priority(quality_str):
    """
    Returneaza prioritatea calitatii pentru sortare (mai mare = mai bun).
    """
    if not quality_str:
        return 0
    
    q = quality_str.upper()
    
    if '4K' in q or '2160' in q or 'UHD' in q:
        return 4
    elif '1080' in q:
        return 3
    elif '720' in q:
        return 2
    elif '480' in q or '360' in q or 'SD' in q:
        return 1
    else:
        return 0


def _normalize_quality(quality_str):
    """
    Normalizeaza calitatea la format standard.
    """
    if not quality_str:
        return 'SD'
    
    q = quality_str.upper()
    
    if '4K' in q or '2160' in q or 'UHD' in q:
        return '4K'
    elif '1080' in q:
        return '1080p'
    elif '720' in q:
        return '720p'
    else:
        return 'SD'


def filter_streams_for_display(streams):
    """
    Filtreaza streamurile pentru AFISARE bazat pe setarile curente.
    Apeleaza aceasta functie de fiecare data cand afisezi lista!
    
    Returneaza: (filtered_streams, stats_dict)
    """
    if not streams:
        return [], {'total': 0, '4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'filtered': 0}
    
    # Citeste setarile ACUM (la momentul afisarii)
    exclude_4k = ADDON.getSetting('exclude_4k') == 'true'
    exclude_1080p = ADDON.getSetting('exclude_1080p') == 'true'
    exclude_720p = ADDON.getSetting('exclude_720p') == 'true'
    exclude_sd = ADDON.getSetting('exclude_sd') == 'true'
    try: exclude_hdr_dv = ADDON.getSetting('exclude_hdr_dv') == 'true'
    except: exclude_hdr_dv = False
    # Source Priority (Sorting): la optiunile 1+ (grup-major) lista e deja sortata
    # de sort_streams_by_quality — nu o mai re-sortam dupa calitate (stable sort-ul
    # vechi facea calitatea cheie primara si grupurile doar tiebreaker).
    try: sort_opt = int(ADDON.getSetting('source_sorting') or '0')
    except: sort_opt = 0
    # Statistici pentru toate calitatile
    stats = {'total': len(streams), '4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'filtered': 0}
    
    # Numara toate calitatile (inainte de filtrare)
    for stream in streams:
        normalized = _normalize_quality(stream.get('quality', 'SD'))
        stats[normalized] = stats.get(normalized, 0) + 1
    
    # Daca nu e nimic de exclus, returneaza toate
    if not any([exclude_4k, exclude_1080p, exclude_720p, exclude_sd, exclude_hdr_dv]):
        if sort_opt > 0:
            return streams, stats
        sorted_streams = sorted(streams, key=lambda x: _get_quality_priority(x.get('quality', 'SD')), reverse=True)
        return sorted_streams, stats
    
    # Construieste set de calitati excluse
    excluded = set()
    if exclude_4k:
        excluded.add('4K')
    if exclude_1080p:
        excluded.add('1080p')
    if exclude_720p:
        excluded.add('720p')
    if exclude_sd:
        excluded.add('SD')
    
    # Filtreaza
    filtered =[]
    for stream in streams:
        normalized = _normalize_quality(stream.get('quality', 'SD'))
        if normalized in excluded:
            continue
            
        if exclude_hdr_dv:
            full_text = (str(stream.get('name', '')) + ' ' + str(stream.get('title', '')) + ' ' + str(stream.get('info', ''))).lower()
            if isinstance(stream.get('info'), dict):
                full_text += ' ' + str(stream['info'].get('original_info_str', '')).lower()
                full_text += ' ' + str(stream['info'].get('releaseGroup', '')).lower()
                
            if 'hdr' in full_text or 'dolby vision' in full_text or '.dv.' in full_text or 'hlg' in full_text or 'dovi' in full_text:
                continue
                
        filtered.append(stream)
    
    stats['filtered'] = len(streams) - len(filtered)
    
    # Sortare (grup-major la optiunile 1+ — pastram ordinea deja sortata)
    if filtered and sort_opt == 0:
        filtered = sorted(filtered, key=lambda x: _get_quality_priority(x.get('quality', 'SD')), reverse=True)
    
    log(f"[FILTER-UI] Display filter: {len(streams)} total -> {len(filtered)} shown (excluded {stats['filtered']})")
    
    return filtered, stats


def get_quality_stats(streams):
    """
    Returns quality statistics for UI display.
    Useful for showing "4K: 5 | 1080p: 12 | 720p: 8 | SD: 3"
    """
    stats = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0}
    
    for stream in streams:
        normalized = _normalize_quality(stream.get('quality', 'SD'))
        stats[normalized] = stats.get(normalized, 0) + 1
    
    return stats


# =============================================================================
# SCRAPERS
# =============================================================================




def scrape_sooti(imdb_id, content_type, season=None, episode=None):
    """
    Scraper pentru Sooti.
    V3 - Extragere corecta cu source_provider separat.
    """
    if ADDON.getSetting('use_sooti') == 'false':
        return None

    try:
        sooti_config_json = {
            "DebridServices": [{"provider": "httpstreaming", "http4khdhub": True, "httpHDHub4u": True, "httpUHDMovies": True, "httpMoviesDrive": True, "httpMKVCinemas": True, "httpMalluMv": True, "httpCineDoze": True}],
            "Languages": [], "Scrapers": [], "IndexerScrapers": [], "minSize": 0, "maxSize": 200, "ShowCatalog": False, "DebridProvider": "httpstreaming"
        }
        encoded_config = quote(json.dumps(sooti_config_json))
        
        base_urls = [
            f"https://sooti.click/{encoded_config}",
            f"https://sooti.info/{encoded_config}",
            f"https://sootiofortheweebs.midnightignite.me/{encoded_config}"
        ]

        for base_sooti_url in base_urls:
            if content_type == 'movie':
                api_url = f"{base_sooti_url}/stream/movie/{imdb_id}.json"
            else:
                api_url = f"{base_sooti_url}/stream/series/{imdb_id}:{season}:{episode}.json"

            # log(f"[SOOTI] Trying mirror: {base_sooti_url[:30]}...")

            try:
                r = requests.get(api_url, headers=get_headers(), timeout=10, verify=False)
                if r.status_code == 200:
                    data = r.json()
                    if 'streams' in data and data['streams']:
                        found_streams = []
                        
                        for s in data['streams']:
                            url = s.get('url')
                            if not url:
                                continue
                            
                            raw_name = s.get('name', '')
                            raw_title = s.get('title', '')
                            
                            # =================================================
                            # 1. EXTRAGE CALITATEA
                            # =================================================
                            quality = None
                            
                            # 1.1 Campul 'resolution' direct
                            resolution = s.get('resolution', '').lower()
                            if resolution:
                                if resolution in ['2160p', '4k', 'uhd']:
                                    quality = '4K'
                                elif resolution == '1080p':
                                    quality = '1080p'
                                elif resolution == '720p':
                                    quality = '720p'
                                elif resolution in ['480p', '360p']:
                                    quality = '480p'
                                elif resolution in ['auto', 'other', 'unknown']:
                                    quality = 'SD'
                            
                            # 1.2 Campul 'quality' direct
                            if not quality:
                                q_field = s.get('quality', '').lower()
                                if q_field:
                                    if '4k' in q_field or '2160' in q_field:
                                        quality = '4K'
                                    elif '1080' in q_field:
                                        quality = '1080p'
                                    elif '720' in q_field:
                                        quality = '720p'
                                    elif 'unknown' in q_field:
                                        quality = 'SD'
                            
                            # 1.3 Extrage din 'name' dupa \n
                            if not quality and '\n' in raw_name:
                                name_parts = raw_name.split('\n')
                                if len(name_parts) >= 2:
                                    qual_part = name_parts[-1].strip().lower()
                                    if qual_part in ['4k', '2160p', 'uhd']:
                                        quality = '4K'
                                    elif qual_part == '1080p':
                                        quality = '1080p'
                                    elif qual_part == '720p':
                                        quality = '720p'
                                    elif qual_part in ['480p', '360p', 'sd']:
                                        quality = '480p'
                                    elif qual_part in ['auto', 'other']:
                                        quality = 'SD'
                            
                            # 1.4 Fallback
                            if not quality:
                                quality = _extract_quality_from_string(raw_title)
                            
                            if not quality:
                                quality = 'SD'
                            
                            # =================================================
                            # 2. EXTRAGE SURSA INTERNA (UHDMovies, MoviesDrive, etc)
                            # =================================================
                            source_provider = ""
                            
                            # 2.1 Din title dupa ultimul "|"
                            if '|' in raw_title:
                                last_part = raw_title.split('|')[-1].strip()
                                last_part = re.sub(r'[^\w\s-]', '', last_part).strip()
                                if last_part and len(last_part) < 25:
                                    source_provider = last_part
                            
                            # 2.2 Din bingeGroup
                            if not source_provider:
                                binge_group = s.get('behaviorHints', {}).get('bingeGroup', '')
                                if binge_group and '-' in binge_group:
                                    provider_part = binge_group.split('-')[-1].lower()
                                    provider_map = {
                                        'uhdmovies': 'UHDMovies',
                                        'moviesdrive': 'MoviesDrive',
                                        'mkvcinemas': 'MKVCinemas',
                                        'hdhub4u': 'HDHub4u',
                                        '4khdhub': '4KHDHub',
                                        'mallumv': 'MalluMV',
                                        'cinedoze': 'CineDoze',
                                        'streams': ''
                                    }
                                    source_provider = provider_map.get(provider_part, provider_part.title())
                            
                            # =================================================
                            # 3. EXTRAGE SIZE
                            # =================================================
                            size = s.get('size', '')
                            if not size or size == 'null' or size == 'Unknown':
                                size_match = re.search(r'💾\s*([\d.]+\s*(?:GB|MB|TB))', raw_title, re.IGNORECASE)
                                if size_match:
                                    size = size_match.group(1)
                                else:
                                    size_match2 = re.search(r'([\d.]+)\s*(GB|MB|TB)', raw_title, re.IGNORECASE)
                                    if size_match2:
                                        size = f"{size_match2.group(1)} {size_match2.group(2).upper()}"
                            
                            if size:
                                size = size.strip()
                                if re.match(r'^\d+\.?\d*(GB|MB|TB)$', size, re.IGNORECASE):
                                    size = re.sub(r'(\d)(GB|MB|TB)', r'\1 \2', size, flags=re.IGNORECASE)
                            
                            # =================================================
                            # 4. EXTRAGE FILENAME
                            # =================================================
                            filename = s.get('behaviorHints', {}).get('filename', '')
                            if not filename:
                                filename = s.get('fullTitle', '')
                            if not filename:
                                if '\n' in raw_title:
                                    filename = raw_title.split('\n')[0].strip()
                                else:
                                    filename = raw_title
                            
                            filename = re.sub(r'[🇬🇧🇮🇳🇺🇸💾🔗]', '', filename).strip()
                            
                            # =================================================
                            # 5. CONSTRUIESTE OBIECTUL STREAM
                            # IMPORTANT: Punem source_provider ca camp SEPARAT!
                            # =================================================
                            stream_obj = {
                                'name': 'Sootio',  # Doar alias-ul principal
                                'url': build_stream_url(url),
                                'quality': quality,
                                'title': filename,
                                'size': size,  # Separate field for size
                                'source_provider': source_provider,  # UHDMovies, MoviesDrive, etc
                                'info': '',
                                'provider_id': 'sooti'
                            }
                            
                            found_streams.append(stream_obj)
                        
                        log(f"[SOOTI] ✓ Success! {len(found_streams)} surse gasite.")
                        return found_streams
                        
            except Exception as e:
                log(f"[SOOTI] Mirror failed ({e}). Moving to next...")
                continue

    except Exception as e:
        log(f"[SOOTI] Critical error: {e}", xbmc.LOGERROR)
    
    return None

# =============================================================================
# =============================================================================
# SCRAPER VIDLINK
# =============================================================================
def scrape_vidlink(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_vidlink') == 'false': return None
    tmdb_id = _get_tmdb_id_internal(imdb_id)
    if not tmdb_id: return None
    
    try:
        session = get_shared_session()
        enc_res = session.get(f"https://enc-dec.app/api/enc-vidlink?text={tmdb_id}", headers=get_headers(), timeout=10, verify=False).json()
        enc_id = enc_res.get('result')
        if not enc_id: return None
        
        headers = get_headers()
        headers.update({"Referer": "https://vidlink.pro/", "Origin": "https://vidlink.pro"})
        
        if content_type == 'movie':
            api_url = f"https://vidlink.pro/api/b/movie/{enc_id}?multiLang=0"
        else:
            api_url = f"https://vidlink.pro/api/b/tv/{enc_id}/{season}/{episode}?multiLang=0"
            
        data = session.get(api_url, headers=headers, timeout=10, verify=False).json()
        
        streams = []
        display_title = title_query if title_query else "VidLink Stream"
        if year_query and content_type == 'movie': display_title += f" ({year_query})"
        if content_type == 'tv' and season and episode: display_title += f" S{int(season):02d}E{int(episode):02d}"

        stream_data = data.get('stream', {})
        qualities = stream_data.get('qualities', {})
        if qualities:
            best = None
            for q in ['2160', '1080', '720', '480', '360']:
                if q in qualities:
                    best = qualities[q]
                    break
            if best and best.get('url'):
                streams.append({
                    'name': "VidLink",
                    'url': build_stream_url(best['url'], referer="https://vidlink.pro/"),
                    'quality': f"{q}p" if q else "1080p",
                    'title': display_title,
                    'size': '',
                    'info': best.get('type', 'mp4').upper(),
                    'provider_id': 'vidlink'
                })
        
        return streams if streams else None
    except Exception as e:
        log(f"[VIDLINK] Error: {e}")
        return None


# =============================================================================
# SCRAPER VSEMBED (PlayIMDb) - IFRAME CHAIN RESOLVER (JS BYPASS)
# =============================================================================
def scrape_vsembed(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_vsembed') == 'false': return None
    if not imdb_id or not str(imdb_id).startswith('tt'): return None

    tmdb_id = _get_tmdb_id_internal(imdb_id)
    if not tmdb_id:
        return None

    _UA = 'Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0'
    _HEADERS = {'User-Agent': _UA, 'Referer': 'https://primesrc.me/', 'Accept': 'application/json'}

    def _get_servers():
        params = {'type': content_type, 'tmdb': tmdb_id}
        if content_type == 'tv' and season is not None and episode is not None:
            params['season'] = int(season)
            params['episode'] = int(episode)
        try:
            r = requests.get('https://primesrc.me/api/v1/s', params=params, headers=_HEADERS, timeout=10)
            if r.ok:
                return r.json().get('servers', [])
            log(f'[VSEMBED] /api/v1/s status={r.status_code}', xbmc.LOGWARNING)
        except Exception as e:
            log(f'[VSEMBED] _get_servers: {e}', xbmc.LOGWARNING)
        return []

    try:
        servers = _get_servers()
        if not servers:
            log(f'[VSEMBED] niciun server pentru tmdb={tmdb_id}', xbmc.LOGWARNING)
            return []

        sources = []
        seen = set()
        display_title = title_query if title_query else "VSEmbed Stream"
        if year_query and content_type == 'movie':
            display_title += f" ({year_query})"
        if content_type == 'tv' and season is not None and episode is not None:
            display_title += f" S{int(season):02d}E{int(episode):02d}"

        for srv in servers:
            key = srv.get('key', '')
            name = srv.get('name', '')
            if not key:
                continue
            api_url = f'https://primesrc.me/api/v1/l?key={key}'
            if api_url in seen:
                continue
            seen.add(api_url)

            size = srv.get('file_size') or ''
            quality = srv.get('quality') or '1080p'
            audio_type = srv.get('audio_type') or ''

            if content_type == 'tv' and season is not None and episode is not None:
                tmdb_id_str = f"{tmdb_id}:tv:{season}:{episode}"
            else:
                tmdb_id_str = f"{tmdb_id}:movie"

            q_norm = quality
            if quality.lower() in ('4k', '2160p', '2160'): q_norm = '4K'
            elif quality.lower() in ('1080p', '1080', 'fhd'): q_norm = '1080p'
            elif quality.lower() in ('720p', '720', 'hd'): q_norm = '720p'
            elif quality.lower() in ('480p', '480', 'sd'): q_norm = 'SD'

            sources.append({
                'url': api_url,
                'name': display_title,
                'quality': q_norm,
                'title': '',
                'tmdb_id': tmdb_id_str,
                'info': {
                    'original_info_str': f'VSEmbed | {name}',
                    'provider': 'VSEmbed',
                    'source_provider': f'| {name}',
                    'size': size
                },
                'source_provider': f'| {name}',
                'provider_id': 'vsembed',
            })

        log(f'[VSEMBED] {len(sources)} surse pentru tmdb={tmdb_id}', xbmc.LOGINFO)
        return sources

    except Exception as e:
        log(f'[VSEMBED] eroare: {e}', xbmc.LOGERROR)
        return []


# =============================================================================
# SCRAPER VIDEASY (UNIFICAT SI IMBUNATATIT)
# Inlocuieste atat scrape_fmovies, cat si scrape_videasy
# =============================================================================
def scrape_videasy(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_videasy') == 'false':
        return None

    tmdb_id = _get_tmdb_id_internal(imdb_id)
    if not tmdb_id:
        return None

    s = get_shared_session()
    streams = []

    display_title = title_query or "Videasy Stream"
    if year_query and content_type == 'movie':
        display_title += f" ({year_query})"
    if content_type == 'tv' and season and episode:
        display_title += f" S{int(season):02d}E{int(episode):02d}"

    try:
        # 1. Get seed
        r_seed = s.get(f"https://api.wingsdatabase.com/seed?mediaId={tmdb_id}", headers=get_headers(), timeout=10)
        if r_seed.status_code != 200:
            log(f"[VIDEASY] Seed failed: {r_seed.status_code}")
            return None
        seed = r_seed.json().get('seed')
        if not seed:
            log(f"[VIDEASY] No seed in response")
            return None

        # 2. Fetch encrypted sources
        params = {
            'title': title_query or '',
            'mediaType': content_type,
            'year': year_query or '',
            'tmdbId': tmdb_id,
            'imdbId': imdb_id if str(imdb_id).startswith('tt') else '',
            'enc': '2',
            'seed': seed
        }
        if content_type == 'tv':
            params.update({'seasonId': season, 'episodeId': episode})

        r_src = s.get("https://api.wingsdatabase.com/cdn/sources-with-title", params=params, headers=get_headers(), timeout=15)
        if r_src.status_code != 200:
            log(f"[VIDEASY] Sources failed: {r_src.status_code}")
            return None

        r_text = r_src.text
        if not r_text or len(r_text) < 50:
            log(f"[VIDEASY] Invalid sources response")
            return None

        # 3. Decrypt
        dec_res = s.post(
            'https://enc-dec.app/api/dec-videasy',
            json={'text': r_text, 'id': str(tmdb_id), 'seed': seed},
            timeout=15
        ).json()

        # 4. Parse sources
        sources = []
        if isinstance(dec_res, dict):
            result_obj = dec_res.get('result', {})
            if isinstance(result_obj, dict):
                sources = result_obj.get('sources', [])
            elif 'sources' in dec_res:
                sources = dec_res.get('sources', [])

        if not isinstance(sources, list):
            log(f"[VIDEASY] 'sources' is not a list")
            return None

        for src in sources:
            if not isinstance(src, dict) or not src.get('url'):
                continue

            s_url = src['url']
            q_str = src.get('quality', 'Auto').lower()

            if '2160' in q_str or '4k' in q_str:
                quality = '4K'
            elif '1080' in q_str:
                quality = '1080p'
            elif '720' in q_str:
                quality = '720p'
            elif '480' in q_str:
                quality = 'SD'
            else:
                quality = 'Auto'

            streams.append({
                'name': 'Videasy',
                'url': build_stream_url(s_url, referer='https://player.videasy.to/', origin='https://player.videasy.to'),
                'quality': quality,
                'title': display_title,
                'size': '',
                'info': f"HLS | {src.get('quality', 'Auto')}",
                'provider_id': 'videasy'
            })

    except Exception as e:
        log(f"[VIDEASY] Error: {e}")

    log(f"[VIDEASY] Total: {len(streams)} streams")
    return streams if streams else None


# =============================================================================
# SCRAPER CINEBY (Videasy network extended servers)
# =============================================================================
def scrape_cineby(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_cineby') == 'false':
        return None

    tmdb_id = _get_tmdb_id_internal(imdb_id)
    if not tmdb_id:
        return None

    s = get_shared_session()
    streams = []

    display_title = title_query or "Cineby"
    if year_query and content_type == 'movie':
        display_title += f" ({year_query})"
    if content_type == 'tv' and season and episode:
        display_title += f" S{int(season):02d}E{int(episode):02d}"

    try:
        r_seed = s.get(f"https://api.wingsdatabase.com/seed?mediaId={tmdb_id}", headers=get_headers(), timeout=10)
        if r_seed.status_code != 200:
            return None
        seed = r_seed.json().get('seed')
        if not seed:
            return None

        params = {
            'title': title_query or '',
            'mediaType': 'movie' if content_type == 'movie' else 'tv',
            'year': year_query or '',
            'tmdbId': tmdb_id,
            'imdbId': imdb_id if str(imdb_id).startswith('tt') else '',
            'enc': '2',
            'seed': seed
        }
        if content_type == 'tv':
            params.update({'seasonId': season, 'episodeId': episode})

        r_src = s.get("https://api.wingsdatabase.com/cdn/sources-with-title", params=params, headers=get_headers(), timeout=15)
        if r_src.status_code != 200:
            return None

        r_text = r_src.text
        if not r_text or len(r_text) < 50:
            return None

        dec_res = s.post(
            'https://enc-dec.app/api/dec-videasy',
            json={'text': r_text, 'id': str(tmdb_id), 'seed': seed},
            timeout=15
        ).json()

        sources = []
        if isinstance(dec_res, dict):
            result_obj = dec_res.get('result', {})
            if isinstance(result_obj, dict):
                sources = result_obj.get('sources', [])
            elif 'sources' in dec_res:
                sources = dec_res.get('sources', [])

        if not isinstance(sources, list):
            return None

        for src in sources:
            if not isinstance(src, dict) or not src.get('url'):
                continue

            s_url = src['url']
            q_str = src.get('quality', 'Auto').lower()

            if '2160' in q_str or '4k' in q_str:
                quality = '4K'
            elif '1080' in q_str:
                quality = '1080p'
            elif '720' in q_str:
                quality = '720p'
            elif '480' in q_str:
                quality = 'SD'
            else:
                quality = 'Auto'

            streams.append({
                'name': 'Cineby',
                'url': build_stream_url(s_url, referer='https://player.videasy.to/', origin='https://player.videasy.to'),
                'quality': quality,
                'title': display_title,
                'size': '',
                'info': f"HLS | {src.get('quality', 'Auto')}",
                'provider_id': 'cineby'
            })

    except Exception as e:
        log(f"[CINEBY] Error: {e}")

    log(f"[CINEBY] Total: {len(streams)} streams")
    return streams if streams else None


# =============================================================================
# SCRAPER PEACHIFY was removed — replaced by CineFreak
# SCRAPER FIBWATCH was removed — replaced by CineFreak
# =============================================================================
# =============================================================================
# SCRAPER NETMIRROR (Fixed API Headers)
# =============================================================================
def scrape_netmirror(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_netmirror') == 'false': return None
    if not title_query: return None

    s = get_shared_session()
    UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) rv:136.0) Gecko/20100101 Firefox/136.0 /OS.GatuNewTV v1.0"

    display_title = title_query
    if year_query and content_type == 'movie': display_title += f" ({year_query})"
    if content_type == 'tv' and season and episode: display_title += f" S{int(season):02d}E{int(episode):02d}"

    BASE = "https://tv.imgcdn.kim/newtv"
    platforms = [{'name': 'Netflix', 'ott': 'nf'}, {'name': 'PrimeVideo', 'ott': 'pv'}, {'name': 'Hotstar', 'ott': 'hs'}]

    def _fetch(url, ott):
        try:
            r = s.get(url, headers={'ott': ott, 'User-Agent': UA, 'x-requested-with': 'NetmirrorNewTV v1.0'}, timeout=10, verify=False)
            return r.json() if r.ok else None
        except:
            return None

    try:
        for plat in platforms:
            ott = plat['ott']
            time.sleep(1.0)
            sd = _fetch(f"{BASE}/search.php?s={quote(title_query)}", ott)
            if not sd: continue
            results = sd.get('searchResult', [])
            if not results: continue

            best = None
            tq_lower = title_query.strip().lower()
            for r in results:
                if r.get('t', '').strip().lower() == tq_lower: best = r; break
            if not best:
                for r in results:
                    if tq_lower in r.get('t', '').strip().lower(): best = r; break
            if not best: best = results[0]
            target_id = best.get('id')
            if not target_id: continue

            if content_type == 'tv':
                pd = _fetch(f"{BASE}/post.php?id={target_id}", ott)
                if not pd: continue
                sid = None
                for se in pd.get('season', []):
                    if str(season) in str(se.get('s', '')): sid = se.get('id'); break
                if not sid and pd.get('season'): sid = pd['season'][0].get('id')
                if not sid: continue
                eid = None
                for pg in range(1, 10):
                    ed = _fetch(f"{BASE}/episodes.php?id={sid}&p={pg}", ott)
                    if not ed: break
                    for ep in ed.get('episodes', []):
                        if str(ep.get('ep', '')).strip() == str(episode).strip(): eid = ep.get('id'); break
                    if eid or ed.get('nextPageShow') != 1: break
                if not eid: continue
                target_id = eid

            pl = _fetch(f"{BASE}/player.php?id={target_id}", ott)
            if not pl: continue
            video_link = pl.get('video_link', '')
            referer = pl.get('referer', 'https://net52.cc')
            if not video_link: continue

            q = '1080p'
            if '.m3u8' in video_link:
                try:
                    resp = s.get(video_link, headers={'User-Agent': UA, 'ott': ott, 'x-requested-with': 'NetmirrorNewTV v1.0'}, timeout=10, verify=False)
                    if resp.status_code == 200:
                        for line in resp.text.splitlines():
                            if 'RESOLUTION=' in line:
                                try:
                                    res = line.split('RESOLUTION=')[1].split(',')[0]
                                    if '2160' in res or '3840' in res: q = '4K'; break
                                    elif '1080' in res or '1920' in res: q = '1080p'; break
                                    elif '720' in res or '1280' in res: q = '720p'; break
                                except: pass
                except: pass
            else:
                if '2160' in video_link: q = '4K'
                elif '1080' in video_link: q = '1080p'
                elif '720' in video_link: q = '720p'

            _headers = {'User-Agent': UA, 'Referer': referer, 'ott': ott, 'x-requested-with': 'NetmirrorNewTV v1.0'}
            streams = [{
                'name': f"NetMirror | {plat['name']}",
                'url': f"{video_link}|{urlencode(_headers)}",
                'quality': q,
                'title': display_title,
                'size': '',
                'info': 'NetMirror',
                'provider_id': 'netmirror'
            }]
            return streams

    except Exception as e:
        log(f"[NETMIRROR] Error: {e}")

    return None


# =============================================================================
# =============================================================================
# SCRAPER VIDMODY (Strict Timeout Fix)
# =============================================================================
def scrape_vidmody(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_vidmody') == 'false': return None
    if not imdb_id or not str(imdb_id).startswith('tt'): return None
    
    display_title = title_query if title_query else "Vidmody Stream"
    if year_query and content_type == 'movie': display_title += f" ({year_query})"
    if content_type == 'tv' and season and episode: display_title += f" S{int(season):02d}E{int(episode):02d}"

    target_url = f"https://vidmody.com/vs/{imdb_id}#.m3u8" if content_type == 'movie' else f"https://vidmody.com/vs/{imdb_id}/s{season}/e{int(episode):02d}#.m3u8"

    try:
        import requests
        # Folosim o cerere nativa requests (fara session retry) cu timeout agresiv de 3 secunde
        res = requests.head(target_url.replace('#.m3u8', ''), headers=get_headers(), timeout=3, verify=False, allow_redirects=True)
        if res.status_code == 200:
            return [{
                'name': 'Vidmody',
                'url': build_stream_url(target_url, referer="https://vidmody.com/"),
                'quality': '1080p',
                'title': display_title,
                'size': '',
                'info': 'Auto HLS',
                'provider_id': 'vidmody'
            }]
    except Exception as e: 
        log(f"[VIDMODY] Skipped (Timeout or Error): {e}")
    return None


# =============================================================================
# SCRAPER MOVIEBLAST (HMAC-SHA256 Token Auth)
# =============================================================================
def scrape_movieblast(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_movieblast') == 'false': return None
    tmdb_id = _get_tmdb_id_internal(imdb_id)
    if not tmdb_id: return None
    
    import hmac, hashlib, base64, time
    from urllib.parse import urlparse

    base_url = "https://app.cloud-mb.xyz"
    token = "jdvhhjv255vghhghdhvfch2565656jhdcghfdf"
    sign_secret = b"GJ8reydarI7Jqat9rvbAJKNQ9gY4DoEQF2H5nfuI1gi"
    headers = {"user-agent": "okhttp/5.0.0-alpha.6", "x-request-x": "com.movieblast"}
    search_headers = {**headers, "hash256": "86dc03244adddb3cbedbf0ae36074a736ee293a64774b18e82a6244eafd0df30", "packagename": "com.movieblast"}

    display_title = title_query if title_query else "MovieBlast Stream"
    if year_query and content_type == 'movie': display_title += f" ({year_query})"
    if content_type == 'tv' and season and episode: display_title += f" S{int(season):02d}E{int(episode):02d}"

    def gen_signed_url(url_str):
        try:
            path = urlparse(url_str).path
            ts = str(int(time.time()))
            msg = (path + ts).encode('utf-8')
            h = hmac.new(sign_secret, msg, hashlib.sha256).digest()
            sig = base64.b64encode(h).decode('utf-8')
            return f"{url_str}?verify={ts}-{quote(sig)}"
        except: return url_str

    s = get_shared_session()
    try:
        s_res = s.get(f"{base_url}/api/search/{quote(title_query)}/{token}", headers=search_headers, timeout=10, verify=False).json()
        results = s_res.get('search', [])
        if not results: return None
        
        match = next((r for r in results if title_query.lower() in r.get('name', '').lower()), results[0])
        internal_id = match['id']
        is_series = 'serie' in match.get('type', '').lower() or content_type == 'tv'
        
        detail_path = "series/show" if is_series else "media/detail"
        d_res = s.get(f"{base_url}/api/{detail_path}/{internal_id}/{token}", headers=headers, timeout=10, verify=False).json()
        
        target_videos = []
        if is_series:
            for season_obj in d_res.get('seasons', []):
                if str(season_obj.get('season_number')) == str(season):
                    for ep_obj in season_obj.get('episodes', []):
                        if str(ep_obj.get('episode_number')) == str(episode):
                            target_videos = ep_obj.get('videos', [])
                            break
                    break
        else:
            target_videos = d_res.get('videos', [])
            
        if not target_videos: return None
        
        streams = []
        for vid in target_videos:
            raw_url = vid.get('link')
            if not raw_url: continue
            https_url = raw_url if raw_url.startswith('http') else f"https://{raw_url}"
            
            srv = str(vid.get('server', '')).lower()
            quality = '4K' if '2160' in srv or '4k' in srv else '1080p' if '1080' in srv else '720p' if '720' in srv else 'SD'
            
            streams.append({
                'name': f"MovieBlast | {vid.get('server', 'Server')}",
                'url': build_stream_url(gen_signed_url(https_url), referer="MovieBlast"),
                'quality': quality,
                'title': f"{display_title} [{vid.get('lang', 'EN')}]",
                'size': '',
                'info': "Signed API",
                'provider_id': 'movieblast'
            })
        return streams if streams else None
    except Exception as e:
        log(f"[MOVIEBLAST] Error: {e}")
        return None


# =============================================================================
# SCRAPER MOVIEBOX (CU REZOLVARE DE REDIRECT)
# =============================================================================
def scrape_moviebox(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_moviebox') == 'false': return None
    tmdb_id = _get_tmdb_id_internal(imdb_id)
    if not tmdb_id: return None
    
    worker_base = "https://moviebox.s4nch1tt.workers.dev"
    # Folosim quote_plus pentru siguranta maxima la encodare URL
    from urllib.parse import quote_plus
    url = f"{worker_base}/streams?tmdb_id={tmdb_id}&type={content_type}&proxy={quote_plus(worker_base)}"
    if content_type == 'tv': url += f"&se={season}&ep={episode}"
    
    try:
        s = get_shared_session()
        r = s.get(url, headers={'Accept': 'application/json', 'User-Agent': 'Nuvio/1.0'}, timeout=15).json()
        
        raw_streams = r if isinstance(r, list) else r.get('streams', [])
        if not raw_streams:
            return None
            
        streams = []
        display_title = title_query if title_query else "MovieBox Stream"
        if year_query and content_type == 'movie': display_title += f" ({year_query})"
        if content_type == 'tv' and season and episode: display_title += f" S{int(season):02d}E{int(episode):02d}"

        for item in raw_streams:
            # Luam intotdeauna proxy_url daca exista, asa cum face si codul JS
            proxy_url = item.get('proxy_url')
            if not proxy_url:
                continue

            # --- AICI ESTE MAGIA: REZOLVAREA REDIRECT-ULUI ---
            resolved_url = None
            try:
                # log(f"[MOVIEBOX] Resolving redirect for: {proxy_url}")
                # Folosim o cerere HEAD pentru eficienta - nu descarcam tot continutul, doar header-ele
                # allow_redirects=True este implicit, dar il punem pentru claritate
                # stream=True ajuta la a nu citi tot corpul in memorie
                # Este important sa folosim o sesiune noua sau una curata pentru a evita conflictele de cookie-uri
                # Dar vom incerca cu sesiunea partajata initial.
                
                # In loc de o sesiune noua, folosim direct libraria requests pentru a fi siguri
                # ca nu avem header-e conflictuale de la sesiunea anterioara.
                # Cererea GET este uneori mai fiabila decat HEAD pentru servere prost configurate.
                with requests.get(proxy_url, headers={'User-Agent': 'Nuvio/1.0'}, stream=True, timeout=10, allow_redirects=True) as res:
                    # Dupa ce toate redirect-urile s-au terminat, `res.url` va contine URL-ul final
                    resolved_url = res.url
                    log(f"[MOVIEBOX] Resolved to: {resolved_url}")

            except Exception as resolve_error:
                log(f"[MOVIEBOX] Failed to resolve URL: {resolve_error}")
                continue # Trecem la urmatorul stream daca rezolvarea esueaza

            if not resolved_url:
                continue
            # --------------------------------------------------

            res_str = str(item.get('resolution', ''))
            quality = '4K' if '2160' in res_str else '1080p' if '1080' in res_str else '720p' if '720' in res_str else 'SD'
            
            lang_match = re.search(r'\(([^)]+)\)', item.get('name', ''))
            lang = lang_match.group(1) if lang_match else 'Original'
            
            size_mb = item.get('size_mb')
            size_str = f"{size_mb} MB" if size_mb and float(size_mb) > 0 else ""
            codec = item.get('codec', '')
            
            streams.append({
                'name': f"MovieBox | {lang}",
                # Folosim URL-ul rezolvat, nu cel proxy!
                'url': resolved_url,
                'quality': quality,
                'title': display_title,
                'size': size_str,
                'info': codec,
                'provider_id': 'moviebox'
            })
            
        return streams if streams else None
        
    except Exception as e:
        import traceback
        log(f"[MOVIEBOX] Scraper Error: {e}\n{traceback.format_exc()}")
        return None

# SCRAPER ONLYKDRAMA (FilePress + AJAX)
# =============================================================================
def scrape_onlykdrama(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_onlykdrama') == 'false': return None
    if not title_query: return None

    base_url = "https://onlykdrama.top"
    s = get_shared_session()
    
    display_title = title_query
    if year_query and content_type == 'movie': display_title += f" ({year_query})"
    if content_type == 'tv' and season and episode: display_title += f" S{int(season):02d}E{int(episode):02d}"

    try:
        r_search = s.get(f"{base_url}/?s={quote(title_query)}", headers=get_headers(), timeout=20, verify=False).text
        link_regex = r'href=["\'](https?://onlykdrama\.top/(?:movies|drama)/[^"\']+)["\']'
        links = re.findall(link_regex, r_search, re.I)
        if not links: return None
        
        # Filtram primul link valid
        target_url = links[0]
        html = s.get(target_url, headers=get_headers(), timeout=10, verify=False).text
        streams = []

        if content_type == 'movie':
            options = re.findall(r'data-post=["\']([^"\']+)["\'][^>]*data-nume=["\']([^"\']+)["\'][^>]*data-type=["\']([^"\']+)["\']', html)
            for post, nume, ttype in options:
                res = s.post(f"{base_url}/wp-admin/admin-ajax.php", data={"action":"doo_player_ajax", "post":post, "nume":nume, "type":ttype}, headers={"Content-Type": "application/x-www-form-urlencoded", "X-Requested-With": "XMLHttpRequest", "Referer": target_url}, timeout=10, verify=False).json()
                embed = res.get('embed_url', '')
                if embed:
                    parsed_url = embed.split('source=')[-1] if 'source=' in embed else embed
                    streams.append({'name': 'OnlyKDrama', 'url': build_stream_url(parsed_url), 'quality': '1080p', 'title': display_title, 'size': '', 'info': 'Fast Stream', 'provider_id': 'onlykdrama'})
        else:
            anchors = re.findall(r'<a[^>]+href=["\'](https://new3\.filepress\.wiki/file/([A-Za-z0-9]+))["\'][^>]*>([\s\S]*?)</a>', html, re.I)
            for full_url, file_id, text in anchors:
                if f"E{int(episode):02d}" in text or f"Episode {int(episode)}" in text or f"E{int(episode)}" in text:
                    fp_headers = {"Origin": "https://new3.filepress.wiki", "Referer": full_url, "Content-Type": "application/json", "User-Agent": get_random_ua()}
                    
                    r1 = s.post("https://new3.filepress.wiki/api/file/downlaod/", json={"id":file_id, "method":"indexDownlaod", "captchaValue":""}, headers=fp_headers, timeout=10, verify=False).json()
                    if r1.get('status') and r1.get('data'):
                        r2 = s.post("https://new3.filepress.wiki/api/file/downlaod2/", json={"id":r1['data'], "method":"indexDownlaod", "captchaValue":""}, headers=fp_headers, timeout=10, verify=False).json()
                        final_url = r2.get('data', [''])[0] if isinstance(r2.get('data'), list) else r2.get('data')
                        if final_url:
                            streams.append({'name': 'OnlyKDrama', 'url': build_stream_url(final_url), 'quality': '1080p', 'title': display_title, 'size': '', 'info': 'FilePress API', 'provider_id': 'onlykdrama'})
                    break

        return streams if streams else None
    except Exception as e:
        log(f"[ONLYKDRAMA] Error: {e}")
        return None



# =============================================================================
# SCRAPER HDHUB4U (V10 - UNIVERSAL RECURSIVE & NAMING FIX)
# =============================================================================

_hdhub_base_cache = {'url': None, 'ts': 0.0}

def _get_hdhub_base_url():
    """
    Gaseste domeniul REAL al site-ului de filme folosind API-urile din
    hdhub4u.ec (scriptul chkh din pagina principala). Fiecare API intoarce JSON:
      - 'h': host-ul sitului principal (base64) — redirectul browserului
      - 'c': URL-ul complet al sitului de filme (base64) — tinta butonului
             "View Full Site" (ex: https://new4.hdhub4u.cl/?utm=mn1)
    Site-ul de filme isi schimba domeniul frecvent, asa ca lookup-ul automat
    inlocuieste domeniul hardcodat.
    """
    now = time.time()
    if _hdhub_base_cache['url'] and (now - _hdhub_base_cache['ts']) < 10800:
        return _hdhub_base_cache['url']

    # Endpoint-uri decodate din array-ul _rx al scriptului chkh (pagina principala)
    api_hosts = [
        "https://h4.suncdn.org/host/",
        "https://points.topapii.com/host/",
        "https://ml.theapii.org/host/",
        "https://dns.pingora.fyi/v2/host",
        "https://cdn.hub4u.cloud/host/",
    ]

    try:
        # Formula din JS: (Year*1000000) + (Month*10000) + (Day*100) + Hour + 1
        # tm_mon din Python e 1-based, identic cu getMonth()+1 din JS
        t = time.gmtime()
        seed = (t.tm_year * 1000000) + (t.tm_mon * 10000) + (t.tm_mday * 100) + t.tm_hour + 1

        for api_url in api_hosts:
            try:
                r = requests.get(api_url, params={'v': seed}, headers=get_headers(), timeout=4, verify=False)
                if r.status_code != 200:
                    continue
                data = r.json()
                if not isinstance(data, dict):
                    continue

                # 1. 'c' = situl de filme ("View Full Site") — prima alegere
                if data.get('c'):
                    full = base64.b64decode(data['c']).decode('utf-8', 'ignore').strip()
                    full = re.sub(r'[?#].*$', '', full).rstrip('/')
                    if full.startswith('http'):
                        _hdhub_base_cache['url'] = full
                        _hdhub_base_cache['ts'] = now
                        return full

                # 2. 'h' = host principal (fallback)
                if data.get('h'):
                    host = base64.b64decode(data['h']).decode('utf-8', 'ignore').strip()
                    if host:
                        url = f"https://{host}"
                        _hdhub_base_cache['url'] = url
                        _hdhub_base_cache['ts'] = now
                        return url
            except Exception:
                continue

    except Exception:
        pass

    # 3. Fallback HARDCODED (ultima solutie) — cache scurt (15 min) ca API-ul
    #    sa fie re-incercat curand daca era doar o cadere temporara
    _hdhub_base_cache['url'] = "https://new4.hdhub4u.cl"
    _hdhub_base_cache['ts'] = now - 9900
    return _hdhub_base_cache['url']


# =============================================================================
# SCRAPER HDHUB4U (V15 - ADDED MISSING DOMAINS + BRANCH LABEL)
# =============================================================================

def _extract_quality_from_string(text):
    """
    Extrage calitatea video dintr-un string.
    """
    if not text:
        return None
    
    t = text.lower()

    
    # === Detectare Multi-Rezolutie: alege cea mai inalta ===
    clean_t = t.replace('ds4k', '').replace('4kds', '').replace('hdr4k', '').replace('sdr4k', '').replace('4khdhub', '')
    found_res = [r for r in ['2160p', '1080p', '720p', '480p', '360p'] if r in t]
    if re.search(r'(?:^|[\.\-\s_])4k(?:$|[\.\-\s_])', clean_t) and '2160p' not in t: 
        found_res.append('4k_text')
    if len(found_res) >= 2:
        if '2160p' in found_res: return '4K'
        if '1080p' in found_res: return '1080p'
        if '720p' in found_res: return '720p'
        if '480p' in found_res: return '480p'
        return 'SD'
    # =======================================================================
    
    # =================================================================
    # METODA 1 (PRIORITARA): Cauta AN.CALITATE sau AN-CALITATE
    # Exemplu: "2025.720p" sau "2025-1080p" sau "2025.4K"
    # =================================================================
    
    # Capteaza ce vine IMEDIAT dupa an (primul segment)
    after_year_match = re.search(r'(?:19|20)\d{2}[\.\-\s_]+([^\.\-\s_]+)', t)
    if after_year_match:
        first_segment = after_year_match.group(1).lower()
        
        # Verifica calitati standard
        if first_segment.startswith('2160p'):
            # log(f"[QUALITY] Found 2160p after year -> 4K")
            return '4K'
        if first_segment.startswith('1080p'):
            # log(f"[QUALITY] Found 1080p after year")
            return '1080p'
        if first_segment.startswith('720p'):
            # log(f"[QUALITY] Found 720p after year")
            return '720p'
        if first_segment.startswith('480p'):
            # log(f"[QUALITY] Found 480p after year")
            return '480p'
        if first_segment.startswith('360p'):
            # log(f"[QUALITY] Found 360p after year")
            return '360p'
        # 4K trebuie sa fie EXACT "4k" la inceput, nu parte din alt cuvant
        if first_segment == '4k' or first_segment.startswith('4k-') or first_segment.startswith('4k.'):
            # log(f"[QUALITY] Found 4K after year")
            return '4K'
    
    # =================================================================
    # METODA 2 (FALLBACK): Cauta oriunde in text — ordine descrescatoare
    # =================================================================
    
    if '2160p' in t:
        return '4K'
    
    if '1080p' in t:
        return '1080p'
    
    if '720p' in t:
        return '720p'
    
    if '480p' in t:
        # log(f"[QUALITY] Fallback: found 480p in text")
        return '480p'
    
    if '360p' in t:
        # log(f"[QUALITY] Fallback: found 360p in text")
        return '360p'
    
    # 4K DOAR daca nu e precedat de litera (evita DS4K, HDR4K, SDR4K)
    # Pattern: spatiu/punct/inceput + 4k + non-litera
    if re.search(r'(?:^|[\.\-\s_])4k(?:$|[\.\-\s_])', clean_t):
        return '4K'
    
    # UHD = 4K
    if 'uhd' in t or 'ultrahd' in t:
        # log(f"[QUALITY] Fallback: found UHD -> 4K")r
        return '4K'
    
    # log(f"[QUALITY] No quality found in: {t[:50]}")
    return None


def _is_web_source(text):
    """
    Filtreaza daca textul contine: 
    - webrip, bdrip, hdrip, dvdrip
    - web-dl, web dl, web.dl (including with rip at the end)
    - bluray.x264, hdtv.x264, hdtv.xvid, web.x264, web.h264
    
    Completely ignores single words (e.g. just 'bluray', just 'x264', just 'web').
    """
    if not text:
        return False
    
    # Am adaugat noile combinatii folosind \. pentru a reprezenta exact punctul.
    pattern = (
        r'webrip|bdrip|hdrip|dvdrip|web[- .]dl(rip)?|'
        r'bluray\.x264|hdtv\.x264|hdtv\.xvid|web\.x264|web\.h264'
    )
    
    if re.search(pattern, text, re.IGNORECASE):
        return True
        
    return False


def _identify_host_from_url(url):
    """Identifica numele host-ului din URL - VERSIUNE V3 cu TrashBytes si altele."""
    if not url:
        return 'Direct'
    
    url_lower = url.lower()
    
    # Ordinea conteaza - cele mai specifice primele!
    if 'pixeldrain.dev/api/file' in url_lower or 'pixeldrain.com/api/file' in url_lower:
        return 'PixelDrain'
    elif 'pixel.hubcdn' in url_lower:
        return 'HubPixel (10Gbps)'
    elif 'yummy.monster' in url_lower:
        return 'FSL Server'
    elif 'trashbytes.net' in url_lower:
        return 'TrashBytes'
    elif 'awsdllaaa' in url_lower or 'aws-storage' in url_lower:
        return 'FastCloud'
    elif 'bbdownload.filesdl' in url_lower:
        if 'adl.php' in url_lower:
            return 'FastCloud-02'
        elif 'fdownload.php' in url_lower:
            return 'DirectDL'
        else:
            return 'FilesDL'
    elif 'busycdn' in url_lower or 'instant.busycdn' in url_lower:
        return 'InstantDL'
    elif 'r2.cloudflarestorage.com' in url_lower:
        return 'FSL-V2'
    elif 'r2.dev' in url_lower or 'pub-' in url_lower:
        return 'CloudR2'
    elif 'gpdl' in url_lower and 'hubcdn' in url_lower:
        return 'HubCDN'
    elif 'fsl-lover' in url_lower:
        return 'FSL-Lover'
    elif 'fsl-buckets' in url_lower or 'fsl.gdboka' in url_lower:
        return 'CDN'
    elif 'gdboka' in url_lower:
        return 'FastServer'
    elif 'polgen.buzz' in url_lower:
        return 'Flash'
    elif 'workers.dev' in url_lower:
        return 'CFWorker'
    elif 'hubcdn' in url_lower:
        return 'HubCDN'
    elif 'hubcloud' in url_lower:
        return 'HubCloud'
    elif 'gdflix' in url_lower:
        return 'GDFlix'
    elif 'filesdl' in url_lower:
        return 'FilesDL'
    elif 'gofile' in url_lower:
        return 'GoFile'
    elif 'mediafire' in url_lower:
        return 'MediaFire'
    elif 'mega.nz' in url_lower or 'mega.co' in url_lower:
        return 'MEGA'
    elif 'streamtape' in url_lower:
        return 'StreamTape'
    elif 'doodstream' in url_lower or 'dood.' in url_lower:
        return 'DoodStream'
    elif 'mixdrop' in url_lower:
        return 'MixDrop'
    elif 'upstream' in url_lower:
        return 'UpStream'
    elif 'buzzheavie' in url_lower:
        return 'BuzzHeavie'
    elif 'bzzhr' in url_lower:
        return 'BuzzShort'
    elif 'buzzserver' in url_lower:
        return 'BuzzServer'
    else:
        # Incearca sa extraga din domeniu
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower().replace('www.', '')
            parts = domain.split('.')
            if parts and len(parts[0]) >= 2:
                # Capitalizeaza prima litera
                return parts[0].title()
        except:
            pass
        
        return 'Direct'


# =============================================================================
# HELPER: Verifica daca URL-ul e stream direct (nu intermediar)
# =============================================================================

def _is_direct_video_url(url):
    """
    Verifica daca URL-ul e un stream video direct (nu intermediar).
    """
    if not url:
        return False
    
    url_lower = url.lower()
    
    # Extensii video
    video_extensions = ['.mkv', '.mp4', '.avi', '.mov', '.webm', '.m3u8', '.ts']
    if any(ext in url_lower for ext in video_extensions):
        return True
    
    # Domenii de stocare directa
    direct_hosts = [
        'r2.dev', 'pub-', 'r2.cloudflarestorage',
        'aws-storage', 'awsdllaaa',
        'pixeldrain.dev/api/file/',
        'pixeldrain.com/api/file/',
        'busycdn.xyz',
        'instant.busycdn',
        'workers.dev',
        'storage.googleapis.com',
        'googleusercontent.com', # <--- ADAUGAT
        'googlevideo.com',       # <--- ADAUGAT
        'buzzheavie',            # BuzzHeavie direct
        'buzzserver',            # BuzzServer redirect
        'polgen.buzz',           # Polgen Buzz
        'pixel.hubcdn',          # HubPixel 10Gbps
        'gpdl',                  # GPDL direct
        'yummy.monster',         # FSL Server
        'gdboka',                # GDBoka
        'fsl-buckets',           # FSL buckets
        'fsl-lover',             # FSL lover
        'trashbytes.net',        # TrashBytes
    ]
    
    if any(h in url_lower for h in direct_hosts):
        return True
    
    # Token-uri de download (exclude intermediarii)
    if '?token=' in url_lower or '&token=' in url_lower:
        if 'adl.php' not in url_lower and 'fdownload.php' not in url_lower:
            return True
    
    return False


def _resolve_intermediate_url(url, timeout=8):
    """
    Rezolva URL-uri intermediare (adl.php, fdownload.php) la stream-ul final.
    Returneaza URL-ul final sau None daca esueaza.
    """
    if not url:
        return None
    
    url_lower = url.lower()
    
    # Lista de URL-uri intermediare care necesita rezolvare
    intermediate_patterns = [
        'adl.php',
        'fdownload.php',
        '/dl.php',
        '/download.php',
    ]
    
    # Daca nu e intermediar, returneaza ca atare
    if not any(p in url_lower for p in intermediate_patterns):
        return url
    
    try:
        headers = {
            'User-Agent': get_random_ua(),
            'Referer': 'https://filesdl.top/',
            'Accept': '*/*',
        }
        
        # Incearca HEAD request
        try:
            r = requests.head(url, headers=headers, timeout=timeout, verify=False, allow_redirects=True)
            final_url = r.url
            
            if r.status_code == 200 and _is_direct_video_url(final_url):
                # log(f"[RESOLVE-URL] ✓ HEAD: {url[:40]}... -> {final_url[:60]}...")
                return final_url
        except:
            pass
        
        # Fallback: GET request
        try:
            r = requests.get(url, headers=headers, timeout=timeout, verify=False, allow_redirects=True, stream=True)
            final_url = r.url
            r.close()
            
            if r.status_code == 200:
                # log(f"[RESOLVE-URL] ✓ GET: {url[:40]}... -> {final_url[:60]}...")
                return final_url
        except:
            pass
        
        # log(f"[RESOLVE-URL] ✗ Failed: {url[:50]}...")
        return None
        
    except Exception as e:
        # log(f"[RESOLVE-URL] ✗ Error: {e}")
        return None


# =============================================================================
# REZOLVARE BUZZSERVER (redirect cu ?download=1)
# =============================================================================

def _resolve_buzzserver_url(url, timeout=10):
    """
    Rezolva URL-urile BuzzServer/BuzzHeavie facand fetch cu ?download=1
    si urmarind redirect-ul pana la URL-ul video final.
    Returneaza URL-ul final sau None daca esueaza.
    """
    if not url:
        return None
    
    try:
        # log(f"[BUZZSERVER] Resolving: {url[:50]}...")
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': url,
            'Accept': '*/*',
        }
        
        # La fel ca in Nuvio JS: fetch cu ?download=1 si urmareste redirect-ul
        download_url = url + ('&' if '?' in url else '?') + 'download=1'
        r = requests.get(download_url, headers=headers, timeout=timeout, verify=False, allow_redirects=True, stream=True)
        final_url = r.url
        r.close()
        
        if final_url and final_url != url and _is_direct_video_url(final_url):
            # log(f"[BUZZSERVER] ✓ Resolved: {url[:40]}... -> {final_url[:60]}...")
            return final_url
        
        # Fallback: incearca direct URL-ul fara ?download=1
        r = requests.get(url, headers=headers, timeout=timeout, verify=False, allow_redirects=True, stream=True)
        final_url = r.url
        r.close()
        
        if final_url and final_url != url:
            # log(f"[BUZZSERVER] ✓ Resolved (direct): {url[:40]}... -> {final_url[:60]}...")
            return final_url
            
        # log(f"[BUZZSERVER] ✗ No redirect for: {url[:50]}...")
        return url  # return original if can't resolve, might still work
        
    except Exception as e:
        # log(f"[BUZZSERVER] ✗ Error: {e}")
        return url  # return original on error


# =============================================================================
# PROCESOR GDFLIX PAGES
# =============================================================================

def _process_gdflix_page(url, quality_label, title_label, branch_label):
    """
    Proceseaza paginile GDFlix si extrage link-uri directe.
    V2 - Cu server names corecte.
    """
    streams = []
    # log(f"[GDFLIX-PAGE] Processing: {url}")
    
    try:
        headers = get_headers()
        r = requests.get(url, headers=headers, timeout=12, verify=False, allow_redirects=True)
        
        if r.status_code != 200:
            log(f"[GDFLIX-PAGE] Error: Status {r.status_code}")
            return []
        
        html = r.text
        final_url = r.url
        # log(f"[GDFLIX-PAGE] Final URL: {final_url}")
        
        # === NOU: Extragere Nume Real Fisier ===
        name_match = re.search(r'Name\s*:\s*([^<]+)', html, re.I)
        filename = name_match.group(1).strip() if name_match else title_label
        # log(f"[DEBUG-MKV] GDFlix filename match: {filename}")
        # ======================================
        
        # Extrage titlu din pagina
        page_title = title_label
        title_match = re.search(r'<title>([^<]+)</title>', html, re.IGNORECASE)
        if title_match:
            raw_title = title_match.group(1).strip()
            raw_title = re.sub(r'\s*-\s*GDFlix.*', '', raw_title, flags=re.IGNORECASE)
            raw_title = re.sub(r'\s*\|\s*GDFlix.*', '', raw_title, flags=re.IGNORECASE)
            if raw_title and len(raw_title) > 5:
                page_title = raw_title
        
        # Extrage calitatea din titlu
        if not quality_label or quality_label == 'SD':
            quality_label = _extract_quality_from_string(page_title) or 'SD'
        
        # =========================================================
        # EXTRAGE MARIMEA - GDFlix V3 (FIX pentru 872.27MB fara spatiu)
        # =========================================================
        page_size = ""
        
        # Pattern 1: list-group-item...>Size : 872.27MB</li> (FARA spatiu)
        size_match = re.search(r'list-group-item[^>]*>[^<]*Size\s*:\s*([\d.,]+)(GB|MB|TB)', html, re.IGNORECASE)
        if size_match:
            page_size = f"{size_match.group(1)} {size_match.group(2).upper()}"
            # log(f"[GDFLIX-PAGE] Size P1 (list-item no-space): {page_size}")
        
        # Pattern 2: >Size : 872.27MB (FARA spatiu, general)
        if not page_size:
            size_match = re.search(r'>Size\s*:\s*([\d.,]+)(GB|MB|TB)', html, re.IGNORECASE)
            if size_match:
                page_size = f"{size_match.group(1)} {size_match.group(2).upper()}"
                # log(f"[GDFLIX-PAGE] Size P2 (no-space): {page_size}")
        
        # Pattern 3: >Size : 9.24 GB (CU spatiu)
        if not page_size:
            size_match = re.search(r'>Size\s*:\s*([\d.,]+)\s+(GB|MB|TB)', html, re.IGNORECASE)
            if size_match:
                page_size = f"{size_match.group(1)} {size_match.group(2).upper()}"
                # log(f"[GDFLIX-PAGE] Size P3 (with-space): {page_size}")
        
        # Pattern 4: "Size : 872.27MB" oriunde in text
        if not page_size:
            size_match = re.search(r'Size\s*:\s*([\d.,]+)\s*(GB|MB|TB)', html, re.IGNORECASE)
            if size_match:
                page_size = f"{size_match.group(1)} {size_match.group(2).upper()}"
                # log(f"[GDFLIX-PAGE] Size P4 (anywhere): {page_size}")
        
        # Pattern 5: Cautare bruta pentru (numar)(GB|MB)
        if not page_size:
            list_items = re.findall(r'<li[^>]*list-group-item[^>]*>([^<]+)</li>', html, re.IGNORECASE)
            for item in list_items:
                if 'size' in item.lower():
                    size_match = re.search(r'([\d.,]+)\s*(GB|MB|TB)', item, re.IGNORECASE)
                    if size_match:
                        page_size = f"{size_match.group(1)} {size_match.group(2).upper()}"
                        # log(f"[GDFLIX-PAGE] Size P5 (list-item extract): {page_size}")
                        break
        
        if page_size:
            log(f"[GDFLIX-PAGE] ✓ Final size: {page_size}")
        else:
            log(f"[GDFLIX-PAGE] ✗ No size found in page!")
        
        seen_urls = set()
        
        # =========================================================
        # EXCLUDE GOOGLE
        # =========================================================
        google_patterns = ['googleusercontent.com', 'googlevideo.com', 'photos.google.com']
        
        # 1. CLOUD DOWNLOAD R2 (pub-*.r2.dev)
        r2_pattern = r'href=["\']?(https://pub-[a-z0-9]+\.r2\.dev/[^"\'>\s]+)["\']?'
        r2_matches = re.findall(r2_pattern, html, re.IGNORECASE)
        
        for r2_url in r2_matches:
            if r2_url in seen_urls:
                continue
            if any(g in r2_url.lower() for g in google_patterns):
                continue
            seen_urls.add(r2_url)
            
            # Determinam calitatea din filename pentru sortare
            actual_q = _extract_quality_from_string(filename) or quality_label

            streams.append({
                'name': filename,
                'url': build_stream_url(r2_url),
                'quality': actual_q,
                'title': filename,
                'size': page_size,
                'info': "GDFlix | R2"
            })
            log(f"[GDFLIX-PAGE] ✓ R2: {r2_url[:60]}...")
        
        # 2. INSTANT DL
        instant_matches = re.findall(r'href=["\']?(https://instant\.busycdn\.xyz/[^"\'>\s]+)["\']?', html, re.IGNORECASE)
        for instant_url in instant_matches:
            if instant_url in seen_urls:
                continue
            seen_urls.add(instant_url) # <--- FIX: Asigura-te ca aici scrie instant_url
            
            # Determinam calitatea din filename pentru sortare
            actual_q = _extract_quality_from_string(filename) or quality_label

            streams.append({
                'name': filename,
                'url': build_stream_url(instant_url),
                'quality': actual_q,
                'title': filename,
                'size': page_size,
                'info': "GDFlix | Instant"
            })
            log(f"[GDFLIX-PAGE] ✓ Instant: {instant_url[:60]}...")
        
        # =========================================================
        # 3. PIXELDRAIN
        # =========================================================
        # Pattern pentru iframe
        pd_iframe = re.search(r'src=["\']https://pixeldrain\.dev/u/([a-zA-Z0-9]+)\?embed["\']', html, re.IGNORECASE)
        if pd_iframe:
            pd_id = pd_iframe.group(1)
            api_url = f"https://pixeldrain.dev/api/file/{pd_id}"
            if api_url not in seen_urls:
                seen_urls.add(api_url)
                
                # Determinam calitatea reala din numele fisierului pentru sortare
                actual_q = _extract_quality_from_string(filename) or quality_label

                streams.append({
                    'name': filename,
                    'url': build_stream_url(api_url),
                    'quality': actual_q,
                    'title': filename,
                    'size': page_size,
                    'info': "GDFlix | PixelDrain"
                })
                log(f"[GDFLIX-PAGE] ✓ PixelDrain: {api_url}")
        
        # Pattern pentru href (backup)
        pd_href = re.search(r'href=["\']https://pixeldrain\.dev/u/([a-zA-Z0-9]+)["\']', html, re.IGNORECASE)
        if pd_href:
            pd_id = pd_href.group(1)
            api_url = f"https://pixeldrain.dev/api/file/{pd_id}"
            if api_url not in seen_urls:
                seen_urls.add(api_url)
                
                # Determinam calitatea reala din numele fisierului pentru sortare
                actual_q = _extract_quality_from_string(filename) or quality_label

                streams.append({
                    'name': filename,
                    'url': build_stream_url(api_url),
                    'quality': actual_q,
                    'title': filename,
                    'size': page_size,
                    'info': "GDFlix | PixelDrain"
                })
                log(f"[GDFLIX-PAGE] ✓ PixelDrain (href): {api_url}")
        
        # =========================================================
        # 4. EXTRACTOR GENERIC PENTRU ALTE TIPURI DE SERVER
        # =========================================================
        all_gd_links = re.findall(r'href=["\'](https?://[^"\']+)["\']', html, re.IGNORECASE)
        generic_hosts = [
            'fsl-buckets', 'fsl-lover', 'fsl.gdboka', 'gdboka',
            'yummy.monster', 'polgen.buzz', 'workers.dev',
            'gpdl', 'hubcdn', 'aws-storage', 'awsdllaaa',
            'bbdownload.filesdl', 'busycdn.xyz', 'buzzserver', 'buzzheavie',
            'r2.cloudflarestorage.com',
        ]
        for gd_link in all_gd_links:
            if gd_link in seen_urls:
                continue
            gd_lower = gd_link.lower()
            if any(g in gd_lower for g in google_patterns):
                continue
            
            if any(h in gd_lower for h in generic_hosts):
                # BuzzServer/BuzzHeavie needs redirect resolution
                if 'buzzserver' in gd_lower or 'buzzheavie' in gd_lower:
                    resolved = _resolve_buzzserver_url(gd_link)
                    if resolved:
                        gd_link = resolved
                
                seen_urls.add(gd_link)
                actual_q = _extract_quality_from_string(filename) or quality_label
                server_name = _identify_host_from_url(gd_link)
                
                streams.append({
                    'name': filename,
                    'url': build_stream_url(gd_link),
                    'quality': actual_q,
                    'title': filename,
                    'size': page_size,
                    'info': f"GDFlix | {server_name}"
                })
                log(f"[GDFLIX-PAGE] ✓ {server_name}: {gd_link[:60]}...")
        
        log(f"[GDFLIX-PAGE] Found {len(streams)} streams")
        
    except Exception as e:
        log(f"[GDFLIX-PAGE] Error: {e}", xbmc.LOGERROR)
    
    return streams


def _is_video_url(url):
    """
    Verifica daca un URL pare a fi un link video direct.
    V2 - FIX: Exclude GoFile pages si GDFlix intermediate pages.
    """
    if not url or not url.startswith('http'):
        return False
    
    url_lower = url.lower()
    
    # =================================================================
    # EXCLUDERE PAGINI INTERMEDIARE (NU SUNT STREAMURI!)
    # =================================================================
    intermediate_pages = [
        'gofile.io/d/',           # GoFile download pages
        'gdflix.dev/file/',       # GDFlix v1
        'gdflix.net/file/',       # GDFlix v2
        'gdflix.filesdl.in/file/',# GDFlix FilesDL variant
        '/zfile/',                # GDFlix zfile pages
        'mulitup.workers.dev',    # Multiup mirrors (typo intentional - site-ul)
        't.me/',                  # Telegram
        'telegram',
        '/tg/go',                  # HubCloud Telegram gateway
        '/dl.php',                 # HubCloud PHP download page
    ]
    
    if any(page in url_lower for page in intermediate_pages):
        return False
    
    # Domenii blocate
    blocked_domains = [
        'googletagmanager.com', 'google-analytics.com', 'googlesyndication.com',
        'doubleclick.net', 'facebook.com', 'twitter.com', 'instagram.com',
        'yandex.ru', 'mc.yandex', 'metrika', 'analytics',
        'gadgetsweb', 'arc.io', 
        'gravatar.com', 'wp.com', 'wordpress.com',
        'disqus.com', 'addthis.com', 'sharethis.com',
        'cloudflare.com/cdn-cgi', 'challenges.cloudflare.com',
        'recaptcha', 'captcha', 'hcaptcha',
        '//ads.', '//ad.', 'adserver', 'adservice',
        'tracker.', 'tracking.', 'pixel.facebook', 'pixel.ads',
        'gtag/js', 'gtm.js', 'ga.js',
        'bit.ly', 'megaup.net', 'megaup'
    ]
    
    if any(blocked in url_lower for blocked in blocked_domains):
        return False
    
    # Exclude fisiere archive si resurse (DAR nu vcloud.zip!)
    if any(ext in url_lower for ext in ['.zip', '.rar', '.7z', '.tar', '.gz']):
        if 'vcloud.zip' not in url_lower:
            return False
    
    # Exclude resurse web
    if any(x in url_lower for x in ['/admin', '/login', '/signup', '/register', '/account', 
                                      'javascript:', 'mailto:', '#', '/page/', '/category/',
                                      '.css', '.js?', '.png', '.jpg', '.jpeg', '.gif', '.svg',
                                      '.woff', '.woff2', '.ttf', '.eot', '.ico']):
        return False
    
    # =================================================================
    # STREAMURI DIRECTE CUNOSCUTE
    # =================================================================
    
    # Verifica extensii video directe
    video_extensions = ['.mkv', '.mp4', '.avi', '.mov', '.webm', '.m3u8', '.ts']
    if any(ext in url_lower for ext in video_extensions):
        return True
    
    # Domenii de hosting video DIRECTE (nu pages!)
    direct_video_hosts = [
        'pixeldrain.com/api/file/',   # PixelDrain API (direct)
        'pixeldrain.dev/api/file/',   # PixelDrain API v2 (direct)
        'pixel.hubcdn',               # HubCDN Pixel
        'hubcdn.fans/dl',             # HubCDN direct
        'yummy.monster',              # FSL / Hub Yummy Monster (NOU)
        'gpdl',                        # GPDL
        'r2.dev',                      # Cloudflare R2
        'pub-',                        # Cloudflare R2 public
        'r2.cloudflarestorage.com',   # Cloudflare R2 storage
        'fsl-buckets',                # FSL buckets
        'fsl-lover',                  # FSL lover
        'fsl.gdboka',                 # FSL gdboka
        'gdboka',                     # GDBoka
        'polgen.buzz',                # Polgen
        'workers.dev',                # CF Workers (direct links)
        'aws-storage',                # AWS storage (direct)
        'awsdllaaa',                  # AWS variant
        'bbdownload.filesdl',         # FilesDL direct download
        'busycdn.xyz',                # BusyCDN (instant DL)
        'instant.busycdn',            # BusyCDN instant
        'googleusercontent.com', 'googlevideo.com',
        'buzzheavie',                 # BuzzHeavie direct
        'buzzserver',                 # BuzzServer (redirect handler)
        'trashbytes.net',             # TrashBytes
        'hubcdn.fans/file/',          # HubCDN file pages (redirect)
        'cdn.telesco.pe',            # Telegram CDN (direct video)
        'fafda.to',                  # bzzhr.co CDN (direct video)
        'ts.bzzhr.co',              # bzzhr.co streaming CDN
    ]
    
    if any(host in url_lower for host in direct_video_hosts):
        return True
    
    # Verifica parametri token/id (indicator de link direct)
    if '?token=' in url_lower or '&token=' in url_lower:
        if 'google' not in url_lower and 'facebook' not in url_lower:
            # Exclude daca e pagina intermediara
            if not any(page in url_lower for page in intermediate_pages):
                return True
    
    if '?id=' in url_lower or '&id=' in url_lower:
        # Verifica ca nu e fdownload.php sau adl.php (care sunt de fapt directe!)
        if 'fdownload.php' in url_lower or 'adl.php' in url_lower:
            return True
        if 'google' not in url_lower and 'facebook' not in url_lower:
            if not any(page in url_lower for page in intermediate_pages):
                return True
    
    return False

def _resolve_hdhub_redirect(url, depth=0, parent_title=None, branch_label=None):
    """
    Rezolva lantul complex HDHub4u/MKVCinemas si returneaza TOATE link-urile video finale gasite.
    """
    if not url or depth > 10: 
        return []
    
    url_lower = url.lower()
    
    # =================================================================
    # EXCLUDERE DOMENII PROBLEMATICE
    # =================================================================
    blocked_domains = [
        'gadgetsweb',
        'googletagmanager.com', 'google-analytics.com', 'gtag/js',
        'googlesyndication.com', 'doubleclick.net',
        'facebook.com', 'twitter.com', 'instagram.com',
        'yandex.ru', 'mc.yandex', 'metrika',
        'arc.io', 'ads.', 'adserver',
        'recaptcha', 'captcha', 'hcaptcha', 'challenges.cloudflare',
        'disqus.com', 'gravatar.com',
        'filepress.cloud', 'new4.filepress',
        'bit.ly', 'telegram', 't.me',
        'megaup.net', 'megaup',
        '/admin',
    ]
    
    if any(blocked in url_lower for blocked in blocked_domains):
        # log(f"[HDHUB-RES] Skipping blocked domain: {url[:60]}...")
        return []
    
    # Exclude fisiere archive si resurse web
    if any(ext in url_lower for ext in ['.zip', '.rar', '.7z', '.tar', '.css', '.js?', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.woff']):
        # EXCEPTIE: vcloud.zip e un domeniu valid!
        if 'vcloud.zip' not in url_lower:
            return []
    
    # Verifica daca URL-ul curent e deja un link video final
    if _is_video_url(url):
        wrapper_indicators = ['hubcloud', 'gamerxyt', 'cryptoinsights', 'carnewz', 
                              'hblinks', 'inventoryidea', 'hubdrive',
                              'hubstream', '/drive/', '/file/', 'vcloud.zip']
        
        is_wrapper = any(w in url_lower for w in wrapper_indicators)
        
        # Exceptii: linkuri directe CDN care coincid cu indicatori wrapper
        if is_wrapper and 'gpdl.hubcloud.cx' in url_lower:
            is_wrapper = False
        
        if not is_wrapper:
            host = _identify_host_from_url(url)
            q = _extract_quality_from_string(parent_title) or _extract_quality_from_string(branch_label)
            
            if 'pixeldrain' in url_lower:
                pd_id = re.search(r'/u/([a-zA-Z0-9]+)', url)
                if pd_id:
                    api_url = f"https://pixeldrain.dev/api/file/{pd_id.group(1)}"
                    return [('PixelDrain', api_url, parent_title, q, branch_label)]
            
            return [(host, url, parent_title, q, branch_label)]
    
    # =================================================================
    # DOMENII WRAPPER
    # =================================================================
    wrapper_domains = [
        'hubdrive', 'hubstream', 'drive', 'hubcloud', 'katmovie', 
        'gamerxyt', 'cryptoinsights', 'hblinks', 'inventoryidea', 'hubcdn', 
        'hubfiles', 'carnewz', 'bzzhr',
        'vcloud.zip',  # VCloud
        '/tg/go', '/dl.php',
    ]
    
    found_urls = []
    seen_urls = set()
    current_title = parent_title
    current_branch = branch_label

    if any(x in url_lower for x in wrapper_domains):
        try:
            # log(f"[HDHUB-RES] Step {depth} Processing: {url}")
            
            s = requests.Session()
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Referer': 'https://mkvcinemas.al/',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            }
            
            # Cookie bypass
            if any(x in url for x in ['gamerxyt', 'cryptoinsights', 'carnewz']):
                domain = urlparse(url).netloc
                s.cookies.set("xyt", "2", domain=domain)
                s.cookies.set("xyt", "2", domain=".gamerxyt.com") 

            r = s.get(url, headers=headers, timeout=12, verify=False, allow_redirects=True)
            content = r.text
            final_url = r.url
            
            # === NOU: Extragere Filename din card-header HubCloud ===
            h_match = re.search(r"<div[^>]*class=['\"]card-header[^>]*>\s*(.*?)\s*</div>", content, re.I | re.S)
            if h_match:
                raw_fn = h_match.group(1).strip()
                if len(raw_fn) > 10: current_title = raw_fn
            # =======================================================
            
            # =================================================================
            # VCLOUD SPECIAL: Extrage URL din JavaScript "var url = '...'"
            # =================================================================
            if 'vcloud.zip' in url_lower or 'vcloud.zip' in final_url.lower():
                js_url_match = re.search(r"var\s+url\s*=\s*['\"]([^'\"]+)['\"]", content)
                if js_url_match:
                    extracted_url = js_url_match.group(1)
                    # log(f"[HDHUB-RES] ✓ VCloud extracted URL: {extracted_url[:60]}...")
                    
                    # Urmeaza acest URL (de obicei gamerxyt.com)
                    if extracted_url not in seen_urls:
                        seen_urls.add(extracted_url)
                        sub_results = _resolve_hdhub_redirect(extracted_url, depth + 1, current_title, current_branch)
                        for res in sub_results:
                            if res[1] not in seen_urls:
                                found_urls.append(res)
                                seen_urls.add(res[1])
                else:
                    pass
            
            # Extragere titlu si marime din HubCloud
            if any(x in url_lower or x in final_url.lower() for x in ['hubcloud', 'vcloud']):
                title_match = re.search(r'<title>([^<]+)</title>', content, re.IGNORECASE)
                if title_match:
                    raw_title = title_match.group(1).strip()
                    if any(x in raw_title.lower() for x in ['.mkv', '.mp4', 'x264', 'x265', 'hevc', 'bluray', '1080p', '720p']):
                        current_title = raw_title
                        # log(f"[RESOLVE] Title: {current_title[:50]}...")
                
                # Extrage marimea din pagina (daca exista)
                size_match = re.search(r'>Size\s*:\s*([\d.]+)\s*(GB|MB)', content, re.IGNORECASE)
                if not size_match:
                    size_match = re.search(r'File Size\s*:\s*([\d.]+)\s*(GB|MB)', content, re.IGNORECASE)
                if not size_match:
                    size_match = re.search(r'([\d.]+)\s*(GB|MB)(?:</|<br)', content, re.IGNORECASE)
                
                if size_match:
                    current_size = f"{size_match.group(1)} {size_match.group(2).upper()}"
                    # log(f"[RESOLVE] Size: {current_size}")

            # Verifica daca redirect-ul final e un link video
            if _is_video_url(final_url):
                wrapper_check = ['hubcloud', 'gamerxyt', 'cryptoinsights', 'carnewz', 'vcloud']
                if not any(w in final_url.lower() for w in wrapper_check):
                    host = _identify_host_from_url(final_url)
                    q = _extract_quality_from_string(current_title) or _extract_quality_from_string(current_branch)
                    return [(host, final_url, current_title, q, current_branch)]

            # Bypass JS Cookie (stck function)
            if 'stck(' in content or 'Redirecting' in content:
                cookie_match = re.search(r"stck\s*\(\s*['\"]([^'\"]+)['\"]\s*,\s*['\"]([^'\"]+)['\"]", content)
                if cookie_match:
                    c_n, c_v = cookie_match.groups()
                    # log(f"[HDHUB-RES] Bypassing Cookie: {c_n}={c_v}")
                    s.cookies.set(c_n, c_v, domain=urlparse(url).netloc)
                    time.sleep(1.5)
                    r2 = s.get(url, headers=headers, timeout=12, verify=False, allow_redirects=True)
                    content = r2.text

            # =========================================================
            # EXTRACTOR GENERIC
            # =========================================================
            
            def add_found(link):
                if link in seen_urls:
                    return
                
                link_lower = link.lower()
                
                blocked = [
                    'googletagmanager', 'google-analytics', 'gtag/js',
                    'facebook.com', 'twitter.com', 'yandex', 'metrika',
                    'gadgetsweb', 'arc.io', 'disqus', 'gravatar',
                    'recaptcha', 'captcha', 'cloudflare.com/cdn-cgi',
                    '.css', '.js?v=', '.png', '.jpg', '.gif', '.svg', '.ico',
                    'filepress.cloud', 'new4.filepress',
                    'bit.ly', 't.me', 'telegram', 'megaup.net', 'megaup'
                ]
                if any(b in link_lower for b in blocked):
                    return
                    
                if not _is_video_url(link):
                    return
                
                wrapper_check = ['hubcloud', 'gamerxyt', 'cryptoinsights', 'carnewz', 
                                '/drive/', '/file/', 'hblinks', 'inventoryidea', 'vcloud.zip']
                if any(w in link_lower for w in wrapper_check):
                    return
                
                host = _identify_host_from_url(link)
                q = _extract_quality_from_string(current_title) or _extract_quality_from_string(current_branch)
                
                if 'pixeldrain' in link_lower:
                    pd_id = re.search(r'/u/([a-zA-Z0-9]+)', link)
                    if pd_id:
                        api_link = f"https://pixeldrain.dev/api/file/{pd_id.group(1)}"
                        if api_link not in seen_urls:
                            found_urls.append(('PixelDrain', api_link, current_title, q, current_branch))
                            seen_urls.add(api_link)
                            # log(f"[HDHUB-RES] ✓ Found: PixelDrain -> {api_link[:60]}...")
                    return
                
                found_urls.append((host, link, current_title, q, current_branch))
                seen_urls.add(link)
                # log(f"[HDHUB-RES] ✓ Found: {host} -> {link[:60]}...")

            # Extrage toate link-urile din href
            all_hrefs = re.findall(r'href=["\']([^"\']+)["\']', content)
            
            for href in all_hrefs:
                if href.startswith('//'):
                    href = 'https:' + href
                elif href.startswith('/') and not href.startswith('//'):
                    continue
                
                if href.startswith('http'):
                    add_found(href)
            
            # Extrage link-uri din JavaScript
            js_patterns = [
                r'["\'](https?://[^"\']*\?token=[^"\']*)["\']',
                r'["\'](https?://[^"\']*\?id=[^"\']*)["\']',
                r'["\'](https?://[^"\']*\.mkv[^"\']*)["\']',
                r'["\'](https?://[^"\']*\.mp4[^"\']*)["\']',
                r'["\'](https?://[^"\']*r2\.dev[^"\']*)["\']',
                r'["\'](https?://[^"\']*r2\.cloudflarestorage\.com[^"\']*)["\']',  # NOU! FSL v2
                r'["\'](https?://[^"\']*pixeldrain[^"\']*)["\']',
                r'["\'](https?://[^"\']*pixel\.hubcdn[^"\']*)["\']',
                r'["\'](https?://[^"\']*gpdl[^"\']*hubcdn[^"\']*)["\']',  # NOU! gpdl2.hubcdn.fans
                r'["\'](https?://[^"\']*fsl-[^"\']*)["\']',
                r'["\'](https?://[^"\']*gdboka[^"\']*)["\']',
                r'["\'](https?://[^"\']*polgen\.buzz[^"\']*)["\']',
            ]
            
            for pattern in js_patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                for match in matches:
                    add_found(match)

            # =========================================================
            # NEXT HOP PATTERNS
            # =========================================================
            next_hop_patterns = [
                r'href=["\'](https?://[^"\']*hubcloud[^"\']*/drive/[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*vcloud\.zip[^"\']+)["\']',
                r'href=["\'](https?://[^"\']*gamerxyt\.com[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*hblinks[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*inventoryidea[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*hubcdn\.fans/file/[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*hubdrive[^"\']*/file/[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*hubstream[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*carnewz\.site[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*cryptoinsights\.site[^"\']*)["\']',
            ]

            for pattern in next_hop_patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                for next_link in matches:
                    if next_link != url and next_link not in seen_urls:
                        if '/admin' in next_link or '/login' in next_link:
                            continue
                        
                        seen_urls.add(next_link)
                        sub_results = _resolve_hdhub_redirect(next_link, depth + 1, current_title, current_branch)
                        for res in sub_results:
                            if res[1] not in seen_urls:
                                found_urls.append(res)
                                seen_urls.add(res[1])

            # JS Redirect
            js_redirect = re.search(r'window\.location\.href\s*=\s*["\'](https?://[^"\']+)["\']', content)
            if js_redirect:
                redirect_url = js_redirect.group(1)
                if redirect_url not in seen_urls:
                    seen_urls.add(redirect_url)
                    sub = _resolve_hdhub_redirect(redirect_url, depth + 1, current_title, current_branch)
                    found_urls.extend(sub)

        except Exception as e:
            # log(f"[HDHUB-RES] Error on {url}: {e}")
            pass
            
    # Curatare duplicate
    unique_results = []
    seen_final = set()
    for item in found_urls:
        if item[1] not in seen_final:
            unique_results.append(item)
            seen_final.add(item[1])
            
    return unique_results


# =============================================================================
# SCRAPER HDHUB4U, MKVCINEMAS, MOVIESDRIVE - OPTIMIZAT V2 (FULL PARALLEL)
# =============================================================================

_mdrive_base_cache = {'url': None, 'ts': 0.0}

def _get_moviesdrive_base():
    """
    Determina domeniul activ MoviesDrive.
    Mecanism (din https://moviesdrives.mov/):
      - Butonul "Explore Movies" deschide /?re=md&t=2 care face redirect 302
        server-side catre situl de filme curent (ex: new1.moviesdrive.christmas)
      - Scriptul din pagina principala contine si URL-ul curent codat base64
        (fallback pe care operatorul sitului il actualizeaza la fiecare schimbare)
      - API-ul cdn.mdrivecdn.net/host/ (campul 'c') era mecanismul vechi
    """
    now = time.time()
    if _mdrive_base_cache['url'] and (now - _mdrive_base_cache['ts']) < 10800:
        return _mdrive_base_cache['url']

    landing = "https://moviesdrives.mov/"

    # 1. SERVER REDIRECT (?re=md&t=2) — exact ceea ce face butonul "Explore Movies"
    try:
        r = requests.get(landing + "?re=md&t=2", headers=get_headers(), timeout=8, verify=False, allow_redirects=True)
        if r.status_code == 200:
            parsed = urlparse(r.url)
            if parsed.scheme in ('http', 'https') and 'moviesdrives.mov' not in parsed.netloc and 'mdrive.today' not in parsed.netloc:
                final = r.url.rstrip('/')
                _mdrive_base_cache['url'] = final
                _mdrive_base_cache['ts'] = now
                return final
    except Exception as e:
        log(f"[MOVIESDRIVE] Redirect check failed: {e}")

    # 2. EXTRACTIE JS — fallback base64 cu URL-ul curent din pagina principala
    try:
        r = requests.get(landing, headers=get_headers(), timeout=8, verify=False)
        if r.status_code == 200:
            scripts = re.findall(r'<script[^>]*>([\s\S]*?)</script>', r.text, re.I)
            for sc in scripts:
                for b in re.findall(r'atob\(["\']([A-Za-z0-9+/=]+)["\']\)', sc):
                    try:
                        dec = base64.b64decode(b).decode('utf-8', 'ignore').strip()
                    except Exception:
                        continue
                    if dec.startswith('http') and 'moviesdrive' in dec.lower():
                        clean = re.sub(r'[?#].*$', '', dec).rstrip('/')
                        if 'moviesdrives.mov' not in clean and 'mdrive.today' not in clean:
                            _mdrive_base_cache['url'] = clean
                            _mdrive_base_cache['ts'] = now
                            return clean
    except Exception:
        pass

    # 3. API CHECK (mecanismul vechi — cdn.mdrivecdn.net a cazut, dar poate reveni)
    try:
        api_url = "https://cdn.mdrivecdn.net/host/"
        headers = get_headers()
        headers['Origin'] = landing.rstrip('/')
        headers['Referer'] = landing
        r = requests.get(api_url, headers=headers, timeout=5, verify=False)
        if r.status_code == 200:
            data = r.json()
            if isinstance(data, dict):
                # 'c' = URL complet al sitului de filme
                if data.get('c'):
                    full = base64.b64decode(data['c']).decode('utf-8', 'ignore').strip()
                    full = re.sub(r'[?#].*$', '', full).rstrip('/')
                    if full.startswith('http') and 'moviesdrives.mov' not in full and 'mdrive.today' not in full:
                        _mdrive_base_cache['url'] = full
                        _mdrive_base_cache['ts'] = now
                        return full
                # 'h' = doar host-ul
                if data.get('h'):
                    decoded_host = base64.b64decode(data['h']).decode('utf-8', 'ignore').strip()
                    if 'moviesdrives.mov' not in decoded_host and 'mdrive.today' not in decoded_host:
                        base = f"https://{decoded_host}"
                        _mdrive_base_cache['url'] = base
                        _mdrive_base_cache['ts'] = now
                        return base
    except Exception as e:
        log(f"[MOVIESDRIVE] API check failed: {e}")

    # 4. FALLBACK HARDCODED — domeniul curent stiut ca functioneaza.
    #    Cache scurt (15 min) ca metodele de mai sus sa fie re-incercate curand.
    log("[MOVIESDRIVE] Using hardcoded fallback.")
    _mdrive_base_cache['url'] = "https://new1.moviesdrive.christmas"
    _mdrive_base_cache['ts'] = now - 9900
    return _mdrive_base_cache['url']


# =============================================================================
# FUNCTIA REPARATA: _process_filesdl_cloud_page (V13 - SUPORT COMPLET DRIVE & HUBCLOUD)
# =============================================================================

def _process_filesdl_cloud_page(url, quality_label, title_label, info_label):
    """
    Proceseaza paginile FilesDL / HubCDN cu REZOLVARE intermediari.
    V13 - FIX: Suporta si URL-uri cu /drive/ si rezolva HubCloud/GDFlix incluse!
    """
    streams = []
    # log(f"[CLOUD] Processing URL: {url}")
    
    try:
        headers = get_headers()
        domain_netloc = urlparse(url).netloc
        headers['Referer'] = f'https://{domain_netloc}/'
        
        r = requests.get(url, headers=headers, timeout=12, verify=False)
        if r.status_code != 200:
            return []
            
        html = r.text
        
        # === NOU: Extragere Nume Real Fisier din title ===
        name_match = re.search(r"<div[^>]*class=['\"]title['\"][^>]*>(.*?)</div>", html, re.I | re.S)
        filename = name_match.group(1).strip() if name_match else title_label
        # log(f"[DEBUG-MKV] FilesDL filename match: {filename}")
        # ===============================================
        
        # 1. HubCDN DL Bypass
        dl_link = None
        dl_match = re.search(r'["\'](https?://[^"\']*/dl/\?link=[^"\']+)["\']', html)
        if not dl_match: dl_match = re.search(r'["\'](/dl/\?link=[^"\']+)["\']', html)
        if dl_match: dl_link = dl_match.group(1)
        else:
            js_token = re.search(r'/dl/\?link=["\']?\s*\+?\s*["\']([a-zA-Z0-9_-]+)["\']', html)
            if js_token: dl_link = f"/dl/?link={js_token.group(1)}"
        if dl_link:
            if dl_link.startswith('/'): dl_link = f"https://{domain_netloc}{dl_link}"
            r2 = requests.get(dl_link, headers=headers, timeout=12, verify=False)
            if r2.status_code == 200: html = r2.text

        # 2. Google Direct Extractor
        vd_match = re.search(r'id=["\']vd["\'][^>]*href=["\']([^"\']+)["\']', html, re.IGNORECASE)
        if not vd_match: vd_match = re.search(r'href=["\']([^"\']+video-downloads\.googleusercontent[^"\']+)["\']', html, re.IGNORECASE)
        if vd_match:
            direct_google_url = vd_match.group(1)
            safe_ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            streams.append({
                'name': 'MKV | GoogleDrive',
                'url': f"{direct_google_url}|User-Agent={safe_ua}&seekable=0",
                'quality': quality_label,
                'title': title_label,
                'size': '',
                'info': info_label or ""
            })
            return streams 

        # 3. Parsare pagina normala
        page_title = title_label
        page_size = ""
        size_match = re.search(r'Size:\s*([\d.]+)\s*(GB|MB)', html, re.IGNORECASE)
        if size_match: page_size = f"{size_match.group(1)} {size_match.group(2).upper()}"
        
        all_a_tags = re.findall(r'<a\s+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', html, re.IGNORECASE | re.DOTALL)
        seen_urls = set()
        pending_resolves = []
        
        for link_url, link_text in all_a_tags:
            if not link_url.startswith('http'): continue
            link_lower = link_url.lower()
            
            if any(skip in link_lower for skip in ['gofile.io', 't.me', 'javascript:', '/login', 'facebook.com']): continue
            if link_url in seen_urls: continue
            seen_urls.add(link_url)
            
            # ATENTIE: Daca gaseste un WRAPPER (Hubcloud/GDFlix) inauntrul paginii, il trimitem la rezolvat!
            if 'hubcloud' in link_lower or 'vcloud' in link_lower:
                resolved = _resolve_hdhub_redirect_parallel(link_url, 0, page_title, info_label, None)
                if resolved:
                    _process_resolved_results(resolved, quality_label, page_title, info_label, streams, seen_urls)
                continue
                
            if 'gdflix' in link_lower:
                gd_streams = _process_gdflix_page(link_url, quality_label, page_title, info_label)
                if gd_streams:
                    for gs in gd_streams:
                        uc = gs['url'].split('|')[0]
                        if uc not in seen_urls:
                            streams.append(gs)
                            seen_urls.add(uc)
                continue

            # Altfel, URL intermediar/direct
            stream_url = link_url
            server_name = 'Direct'
            needs_resolve = False
            
            if 'aws-storage' in link_lower or 'awsdllaaa' in link_lower:
                server_name = 'FastCloud'
            elif 'fdownload.php' in link_lower:
                server_name = 'DirectDL'; needs_resolve = True
            elif 'adl.php' in link_lower:
                server_name = 'FastCloud-02'; needs_resolve = True
            elif 'r2.dev' in link_lower or 'pub-' in link_lower:
                server_name = 'CloudR2'
            elif 'busycdn' in link_lower or 'instant.busycdn' in link_lower:
                server_name = 'InstantDL'
            elif 'pixeldrain' in link_lower:
                pd_match = re.search(r'/u/([a-zA-Z0-9]+)', link_url)
                if pd_match:
                    stream_url = f"https://pixeldrain.dev/api/file/{pd_match.group(1)}"
                    server_name = 'PixelDrain'
            elif 'buzzserver' in link_lower or 'buzzheavie' in link_lower:
                resolved = _resolve_buzzserver_url(link_url)
                if resolved:
                    stream_url = resolved
                    server_name = 'BuzzServer'
            elif 'workers.dev' in link_lower:
                server_name = 'CFWorker'
            else:
                server_name = _identify_host_from_url(link_url)

            if stream_url and server_name:
                if needs_resolve:
                    pending_resolves.append((link_url, server_name, quality_label, filename, page_size))
                else:
                    # Determinam calitatea reala din numele fisierului
                    actual_q = _extract_quality_from_string(filename) or quality_label

                    streams.append({
                        'name': filename,
                        'url': build_stream_url(stream_url, referer=f'https://{domain_netloc}/'),
                        'quality': actual_q,
                        'title': filename,
                        'size': page_size,
                        'info': f"MKV | {server_name}"
                    })

        if pending_resolves:
            def resolve_task(args):
                raw_url, srv_name, qual, title, size = args
                resolved_url = _resolve_intermediate_url(raw_url)
                if resolved_url:
                    # display = f"MKV | {srv_name}"
                    # if size: display += f" | {size}"
                    
                    if 'googleusercontent' in resolved_url.lower() or 'googlevideo' in resolved_url.lower() or 'pixel.hubcdn' in resolved_url.lower():
                        safe_ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
                        final_url = f"{resolved_url}|User-Agent={safe_ua}&seekable=0"
                    else:
                        final_url = build_stream_url(resolved_url, referer=f'https://{domain_netloc}/')
                        
                    return {
                        'name': title, # <--- AICI (title este de fapt filename-ul lung trimis ca argument)
                        'url': final_url,
                        'quality': qual,
                        'title': title,
                        'size': size,
                        'info': info_label or ""
                    }
                return None
            
            _thrs = []
            _tlock_p = threading.Lock()
            def _tworker(args):
                try:
                    r = resolve_task(args)
                    if r:
                        with _tlock_p:
                            uc = r['url'].split('|')[0]
                            if uc not in seen_urls: streams.append(r); seen_urls.add(uc)
                except: pass
            for args in pending_resolves:
                th = threading.Thread(target=_tworker, args=(args,), daemon=True)
                th.start(); _thrs.append(th)
            _tstart = time.time()
            while _thrs and (time.time() - _tstart) < 17:
                _thrs = [th for th in _thrs if th.is_alive()]
                if not _thrs: break
                time.sleep(0.1)

    except Exception as e:
        log(f"[CLOUD] Critical Error: {e}", xbmc.LOGERROR)

    return streams


# =============================================================================
# _resolve_hdhub_redirect_parallel - FIX pentru GDFlix, HubCDN si Referer
# =============================================================================

def _resolve_pixel_redirect(url):
    """
    Pixel hubcloud -> 302 -> gamerxyt.com/dl.php?link=<google drive URL>.
    Extrage link-ul video Google real din parametrul link al redirectului.
    Returneaza URL-ul Google sau None daca redirectul nu duce la dl.php.
    """
    try:
        from urllib.parse import unquote
        r = requests.get(url, headers={'User-Agent': get_random_ua()}, timeout=10, verify=False, allow_redirects=True)
        if 'dl.php' in r.url and 'link=' in r.url:
            m = re.search(r'[?&]link=(https?[^&]+)', r.url)
            if m:
                return unquote(m.group(1))
    except Exception:
        pass
    return None

def _resolve_hdhub_redirect_parallel(url, depth=0, parent_title=None, branch_label=None, executor=None):
    """
    Resolves HDHub4u/MKVCinemas chain WITH PARALLELIZATION.
    V6 - FIX: Support for relative token links (href="/drive/..." or var url = "/drive/...")
    """
    if not url or depth > 8: 
        return []
    
    url_lower = url.lower()
    
    # EXCLUDERE DOMENII PROBLEMATICE
    blocked_domains = [
        'googletagmanager', 'google-analytics', 'facebook.com', 
        'twitter.com', 'instagram.com', 'yandex', 'arc.io', '//ads.', 
        'recaptcha', 'captcha', 'disqus', 'gravatar', 'filepress',
        'bit.ly', 'telegram', 't.me',
        'gofile.io/d/',
        'megaup.net', 'megaup',
        'gadgetsweb', 'hubcloud.fans', '4khdhub.one',
        'gpdl.hubcloud.cx',
        '/admin',
    ]
    
    if any(blocked in url_lower for blocked in blocked_domains):
        return []
    
    # Exclude fisiere non-video (verifica doar PATH, nu domeniul)
    parsed_path = urlparse(url_lower).path
    if any(parsed_path.endswith(ext) for ext in ['.zip', '.rar', '.css', '.js', '.png', '.jpg', '.gif', '.ico']):
        return []
    
    # =========================================================
    # VERIFICA PAGINI SPECIALE (CLOUD PAGES)
    # =========================================================
    
    # Cloud Page (FilesDL sau HubCDN)
    if ('filesdl' in url_lower and '/cloud/' in url_lower) or ('hubcdn.fans/file/' in url_lower):
        q = _extract_quality_from_string(parent_title) or _extract_quality_from_string(branch_label)
        return [('CloudPage', url, parent_title, q, branch_label)]
    
    # GDFlix Page (toate variantele)
    gdflix_patterns = [
        'gdflix.dev/file/',
        'gdflix.net/file/',
        'gdflix.filesdl.in/file/',
    ]
    if any(p in url_lower for p in gdflix_patterns):
        q = _extract_quality_from_string(parent_title) or _extract_quality_from_string(branch_label)
        return [('GDFlixPage', url, parent_title, q, branch_label)]
    
    # BuzzServer/BuzzHeavie - rezolvare redirect
    if 'buzzserver' in url_lower or 'buzzheavie' in url_lower:
        resolved = _resolve_buzzserver_url(url)
        if resolved and resolved != url:
            host = _identify_host_from_url(resolved)
            q = _extract_quality_from_string(parent_title) or _extract_quality_from_string(branch_label)
            return [(host, resolved, parent_title, q, branch_label)]
        # fallback: continua ca link direct
    
    # Pixel hubcloud - 302 catre gamerxyt.com/dl.php?link=<google drive URL>
    if 'pixel.hubcloud.cx' in url_lower:
        glink = _resolve_pixel_redirect(url)
        if glink:
            q = _extract_quality_from_string(parent_title) or _extract_quality_from_string(branch_label)
            return [('GoogleDrive', glink, parent_title, q, branch_label)]
        return []
    
    # Verifica daca e link video final direct
    if _is_video_url(url):
        wrapper_indicators = ['hubcloud', 'gamerxyt', 'cryptoinsights', 'carnewz', 
                              'hblinks', 'inventoryidea', 'hubdrive', 'hubstream', 
                              '/drive/', '/file/', 'vcloud.zip', 'buzzserver', 'buzzheavie']
        
        is_wrapper = any(w in url_lower for w in wrapper_indicators)
        
        # Exceptii: linkuri directe CDN care coincid cu indicatori wrapper
        if is_wrapper and 'gpdl.hubcloud.cx' in url_lower:
            is_wrapper = False
        
        if not is_wrapper:
            host = _identify_host_from_url(url)
            q = _extract_quality_from_string(parent_title) or _extract_quality_from_string(branch_label)
            
            if 'pixeldrain' in url_lower:
                pd_id = re.search(r'/u/([a-zA-Z0-9]+)', url)
                if pd_id:
                    api_url = f"https://pixeldrain.dev/api/file/{pd_id.group(1)}"
                    return [('PixelDrain', api_url, parent_title, q, branch_label)]
            
            return [(host, url, parent_title, q, branch_label)]
    
    # =========================================================
    # DOMENII WRAPPER - procesare recursiva
    # =========================================================
    wrapper_domains = [
        'hubdrive', 'hubstream', 'drive', 'hubcloud', 'katmovie', 
        'gamerxyt', 'cryptoinsights', 'hblinks', 'inventoryidea', 'hubcdn', 
        'hubfiles', 'carnewz', 'vcloud.zip', 'fastdl.zip', 'nexdrive.pro', 'nexdrive', 'filebee.xyz',
        'buzzserver', 'buzzheavie', 'bzzhr', 'hdstream4u',
        '/tg/go', '/dl.php',
    ]
    
    found_urls = []
    seen_urls = set()
    seen_urls.add(url)
    current_title = parent_title
    current_branch = branch_label

    if any(x in url_lower for x in wrapper_domains):
        try:
            s = requests.Session()
            domain_netloc = urlparse(url).netloc
            base_domain = f"https://{domain_netloc}"
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
                'Referer': f'{base_domain}/',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            }
            
            # Cookie bypass
            if any(x in url for x in ['gamerxyt', 'cryptoinsights', 'carnewz']):
                s.cookies.set("xyt", "2", domain=domain_netloc)
                s.cookies.set("xyt", "2", domain=".gamerxyt.com") 

            r = s.get(url, headers=headers, timeout=12, verify=False, allow_redirects=True)
            content = r.text
            final_url = r.url
            
            # VCLOUD & HubCloud: Extrage URL din JavaScript (var url = '/drive/...')
            # Aceasta rezolva linkurile token relative!
            js_url_match = re.search(r"var\s+(?:re)?url\s*=\s*['\"]([^'\"]+)['\"]", content)
            if js_url_match:
                extracted_url = js_url_match.group(1)
                
                # Transforma link-ul relativ in absolut!
                if extracted_url.startswith('/'):
                    extracted_url = base_domain + extracted_url
                    
                if extracted_url not in seen_urls:
                    seen_urls.add(extracted_url)
                    sub_results = _resolve_hdhub_redirect_parallel(extracted_url, depth + 1, current_title, current_branch, executor)
                    for res in sub_results:
                        if res[1] not in seen_urls:
                            found_urls.append(res)
                            seen_urls.add(res[1])
            
            # Extragere titlu SI MARIME din HubCloud
            if any(x in url_lower or x in final_url.lower() for x in ['hubcloud', 'vcloud']):
                title_match = re.search(r'<title>([^<]+)</title>', content, re.IGNORECASE)
                if title_match:
                    raw_title = title_match.group(1).strip()
                    if any(x in raw_title.lower() for x in ['.mkv', '.mp4', 'x264', 'x265', 'hevc', 'bluray', '1080p', '720p']):
                        current_title = raw_title
                
                size_extracted = ""
                size_match = re.search(r'File Size<i[^>]*>([^<]+)</i>', content, re.IGNORECASE)
                if size_match: size_extracted = size_match.group(1).strip()
                
                if not size_extracted:
                    size_match = re.search(r'id="size">([^<]+)</i>', content, re.IGNORECASE)
                    if size_match: size_extracted = size_match.group(1).strip()
                
                if not size_extracted:
                    size_match = re.search(r'>Size\s*:\s*([\d.]+\s*(?:GB|MB|TB))', content, re.IGNORECASE)
                    if size_match: size_extracted = size_match.group(1).strip()
                
                if size_extracted:
                    size_extracted = re.sub(r'(\d)(GB|MB|TB)', r'\1 \2', size_extracted, flags=re.IGNORECASE).upper().replace('  ', ' ').strip()
                    if current_branch:
                        if size_extracted not in current_branch:
                            current_branch = f"{current_branch} [{size_extracted}]"
                    else:
                        current_branch = f"[{size_extracted}]"

            # Verifica redirect final
            if _is_video_url(final_url):
                wrapper_check = ['hubcloud', 'gamerxyt', 'cryptoinsights', 'carnewz', 'vcloud']
                if not any(w in final_url.lower() for w in wrapper_check):
                    host = _identify_host_from_url(final_url)
                    q = _extract_quality_from_string(current_title) or _extract_quality_from_string(current_branch)
                    return [(host, final_url, current_title, q, current_branch)]

            # Bypass Cookie JS
            if 'stck(' in content:
                cookie_match = re.search(r"stck\s*\(\s*['\"]([^'\"]+)['\"]\s*,\s*['\"]([^'\"]+)['\"]", content)
                if cookie_match:
                    c_n, c_v = cookie_match.groups()
                    s.cookies.set(c_n, c_v, domain=domain_netloc)
                    time.sleep(1)
                    r2 = s.get(url, headers=headers, timeout=12, verify=False, allow_redirects=True)
                    content = r2.text

            # =========================================================
            # EXTRACTOR LINK-URI DIRECTE (Cauta in elemente href)
            # =========================================================
            def add_direct_link(link):
                if link in seen_urls: return
                link_lower = link.lower()
                
                if 'gofile.io/d/' in link_lower: return
                
                if ('filesdl' in link_lower and '/cloud/' in link_lower) or ('hubcdn.fans/file/' in link_lower):
                    q = _extract_quality_from_string(current_title) or _extract_quality_from_string(current_branch)
                    found_urls.append(('CloudPage', link, current_title, q, current_branch))
                    seen_urls.add(link)
                    return
                
                if any(p in link_lower for p in ['gdflix.dev/file/', 'gdflix.net/file/', 'gdflix.filesdl.in/file/']):
                    q = _extract_quality_from_string(current_title) or _extract_quality_from_string(current_branch)
                    found_urls.append(('GDFlixPage', link, current_title, q, current_branch))
                    seen_urls.add(link)
                    return
                
                # BuzzServer/BuzzHeavie - rezolvare redirect
                if 'buzzserver' in link_lower or 'buzzheavie' in link_lower:
                    resolved = _resolve_buzzserver_url(link)
                    if resolved and resolved != link:
                        q = _extract_quality_from_string(current_title) or _extract_quality_from_string(current_branch)
                        host = _identify_host_from_url(resolved)
                        if resolved not in seen_urls:
                            found_urls.append((host, resolved, current_title, q, current_branch))
                            seen_urls.add(resolved)
                    return
                
                # WRAPPER CHECK - procesare recursiva doar pentru pagini cu fisiere
                if 'hubcloud' in link_lower and '/drive/' in link_lower:
                    sub_results = _resolve_hdhub_redirect_parallel(link, depth + 1, current_title, current_branch, executor)
                    for res in sub_results:
                        if res[1] not in seen_urls:
                            found_urls.append(res)
                            seen_urls.add(res[1])
                    return
                
                # Telegram gateway - resolve redirect to CDN (cdn.telesco.pe)
                if '/tg/go' in link_lower:
                    try:
                        sub_results = _resolve_hdhub_redirect_parallel(link, depth + 1, current_title, current_branch, executor)
                        for res in sub_results:
                            if res[1] not in seen_urls:
                                found_urls.append(res)
                                seen_urls.add(res[1])
                    except: pass
                    return
                
                # PHP download page (dl.php) - resolve stck + var url
                if '/dl.php' in link_lower:
                    try:
                        sub_results = _resolve_hdhub_redirect_parallel(link, depth + 1, current_title, current_branch, executor)
                        for res in sub_results:
                            if res[1] not in seen_urls:
                                found_urls.append(res)
                                seen_urls.add(res[1])
                    except: pass
                    return
                
                # Buzz shortener (bzzhr.co) - fetch hx-get links, follow redirect chain
                if 'bzzhr' in link_lower:
                    try:
                        sub_results = _resolve_hdhub_redirect_parallel(link, depth + 1, current_title, current_branch, executor)
                        for res in sub_results:
                            if res[1] not in seen_urls:
                                found_urls.append(res)
                                seen_urls.add(res[1])
                    except: pass
                    return
                
                blocked = ['googletagmanager', 'facebook', 'twitter', 'yandex', 'gadgetsweb',
                          'disqus', 'gravatar', 'recaptcha', '.css', '.js', '.png', '.jpg', 
                          'filepress', 'bit.ly', 't.me', 'telegram', 'megaup.net', 'megaup',
                          '/admin', 'gpdl.hubcloud.cx']
                if any(b in link_lower for b in blocked): return
                
                # PixelDrain - rezolvare inainte de _is_video_url
                if 'pixeldrain' in link_lower:
                    pd_id = re.search(r'/u/([a-zA-Z0-9]+)', link)
                    if pd_id:
                        api_link = f"https://pixeldrain.dev/api/file/{pd_id.group(1)}?download"
                        if api_link not in seen_urls:
                            q = _extract_quality_from_string(current_title) or _extract_quality_from_string(current_branch)
                            found_urls.append(('PixelDrain', api_link, current_title, q, current_branch))
                            seen_urls.add(api_link)
                    return
                
                # Pixel hubcloud - 302 catre gamerxyt.com/dl.php?link=<google drive URL>
                if 'pixel.hubcloud.cx' in link_lower:
                    glink = _resolve_pixel_redirect(link)
                    if glink and glink not in seen_urls:
                        q = _extract_quality_from_string(current_title) or _extract_quality_from_string(current_branch)
                        found_urls.append(('GoogleDrive', glink, current_title, q, current_branch))
                        seen_urls.add(glink)
                    return
                
                if not _is_video_url(link): return
                
                host = _identify_host_from_url(link)
                q = _extract_quality_from_string(current_title) or _extract_quality_from_string(current_branch)
                
                found_urls.append((host, link, current_title, q, current_branch))
                seen_urls.add(link)

            # Acum transformam si href-urile relative in absolute!
            # Include si hx-get (folosit de bzzhr.co si alte site-uri HTMX)
            all_hrefs = re.findall(r'(?:href|hx-get)=["\']([^"\']+)["\']', content)
            for href in all_hrefs:
                if href.startswith('//'): 
                    href = 'https:' + href
                elif href.startswith('/') and not href.startswith('//'): 
                    href = base_domain + href # Le transformam!
                
                if href.startswith('http'): 
                    add_direct_link(href)
            
            js_patterns = [
                r'["\'](https?://[^"\']*\?token=[^"\']*)["\']',
                r'["\'](https?://[^"\']*\.mkv[^"\']*)["\']',
                r'["\'](https?://[^"\']*\.mp4[^"\']*)["\']',
                r'["\'](https?://[^"\']*r2\.dev[^"\']*)["\']',
                r'["\'](https?://[^"\']*r2\.cloudflarestorage\.com[^"\']*)["\']',
                r'["\'](https?://[^"\']*pixeldrain[^"\']*)["\']',
                r'["\'](https?://[^"\']*pixel\.hubcdn[^"\']*)["\']',
                r'["\'](https?://[^"\']*gpdl[^"\']*hubcdn[^"\']*)["\']',
                r'["\'](https?://[^"\']*fsl-[^"\']*)["\']',
                r'["\'](https?://[^"\']*yummy\.monster[^"\']*)["\']', # NOU
                r'["\'](https?://[^"\']*gdboka[^"\']*)["\']',
                r'["\'](https?://[^"\']*polgen\.buzz[^"\']*)["\']',
                r'["\'](https?://[^"\']*filesdl[^"\']*\/cloud\/[^"\']*)["\']',
                r'["\'](https?://[^"\']*hubcdn\.fans\/file\/[^"\']*)["\']',
                r'["\'](https?://[^"\']*gdflix[^"\']*\/file\/[^"\']*)["\']',
                r'["\'](https?://[^"\']*buzzserver[^"\']*)["\']',
                r'["\'](https?://[^"\']*buzzheavie[^"\']*)["\']',
            ]
            
            for pattern in js_patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                for match in matches: add_direct_link(match)

            next_hop_patterns = [
                r'href=["\'](https?://[^"\']*hubcloud[^"\']*/drive/[^"\']*)["\']',
                r'href=["\'](/drive/[^"\']*\?token=[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*vcloud\.zip[^"\']+)["\']',
                r'href=["\'](https?://[^"\']*fastdl\.zip[^"\']+)["\']',
                r'href=["\'](https?://[^"\']*gamerxyt\.com[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*hblinks[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*inventoryidea[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*hubcdn\.fans/file/[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*hubdrive[^"\']*/file/[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*hubstream[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*carnewz\.site[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*cryptoinsights\.site[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*buzzserver[^"\']*)["\']',
                r'href=["\'](https?://[^"\']*buzzheavie[^"\']*)["\']',
            ]

            next_hops = []
            for pattern in next_hop_patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                for next_link in matches:
                    if next_link.startswith('/'):
                        next_link = base_domain + next_link
                    
                    if next_link != url and next_link not in seen_urls:
                        if '/admin' not in next_link and '/login' not in next_link:
                            next_hops.append(next_link)
                            seen_urls.add(next_link)
            
            if next_hops and depth < 6:
                def resolve_next_hop(next_link):
                    return _resolve_hdhub_redirect_parallel(next_link, depth + 1, current_title, current_branch, None)
                
                _nh_thrs = []
                _nh_lock = threading.Lock()
                def _nh_worker(nh):
                    try:
                        sub = resolve_next_hop(nh)
                        with _nh_lock:
                            for res in sub:
                                if res[1] not in seen_urls:
                                    found_urls.append(res); seen_urls.add(res[1])
                    except: pass
                for nh in next_hops[:10]:
                    th = threading.Thread(target=_nh_worker, args=(nh,), daemon=True)
                    th.start(); _nh_thrs.append(th)
                _nh_start = time.time()
                while _nh_thrs and (time.time() - _nh_start) < 17:
                    _nh_thrs = [th for th in _nh_thrs if th.is_alive()]
                    if not _nh_thrs: break
                    time.sleep(0.1)

            js_redirect = re.search(r'window\.location\.href\s*=\s*["\'](https?://[^"\']+)["\']', content)
            if js_redirect:
                redirect_url = js_redirect.group(1)
                if redirect_url not in seen_urls:
                    seen_urls.add(redirect_url)
                    sub = _resolve_hdhub_redirect_parallel(redirect_url, depth + 1, current_title, current_branch, executor)
                    for res in sub:
                        if res[1] not in seen_urls:
                            found_urls.append(res)
                            seen_urls.add(res[1])

        except Exception as e:
            pass
            
    unique_results = []
    seen_final = set()
    for item in found_urls:
        if item[1] not in seen_final:
            unique_results.append(item)
            seen_final.add(item[1])
    
    return unique_results


# =============================================================================
# HELPER: Proceseaza rezultate cu suport pentru Cloud si GDFlix Pages
# =============================================================================

def _process_resolved_results(resolved, quality, title, branch, streams_list, seen_urls):
    """
    Proceseaza rezultatele de la _resolve_hdhub_redirect_parallel.
    V3 - Extrage marimea din branch si o seteaza ca camp separat.
    """
    for host_name, final_url, file_title, file_quality, returned_branch in resolved:
        
        # Extrage marimea din branch
        extracted_size = ""
        if returned_branch:
            size_match = re.search(r'\[([\d.]+\s*(?:GB|MB|TB))\]', returned_branch, re.IGNORECASE)
            if size_match:
                extracted_size = size_match.group(1)

        # 1. Cloud Page - procesare speciala
        if host_name == 'CloudPage':
            # log(f"[PROCESS] Processing Cloud Page: {final_url[:50]}...")
            cloud_streams = _process_filesdl_cloud_page(
                final_url,
                file_quality or quality,
                file_title or title,
                returned_branch or branch
            )
            if cloud_streams:
                for cs in cloud_streams:
                    url_check = cs['url'].split('|')[0]
                    if url_check not in seen_urls:
                        streams_list.append(cs)
                        seen_urls.add(url_check)
            continue
        
        # 2. GDFlix Page - procesare speciala
        if host_name == 'GDFlixPage':
            # log(f"[PROCESS] Processing GDFlix Page: {final_url[:50]}...")
            gd_streams = _process_gdflix_page(
                final_url,
                file_quality or quality,
                file_title or title,
                returned_branch or branch
            )
            if gd_streams:
                for gs in gd_streams:
                    url_check = gs['url'].split('|')[0]
                    if url_check not in seen_urls:
                        streams_list.append(gs)
                        seen_urls.add(url_check)
            continue
        
        # 3. Link direct video
        if final_url.startswith('http'):
            url_check = final_url.split('|')[0]
            if url_check in seen_urls:
                continue
            
            final_quality = file_quality or quality
            display_title = file_title or title
            
            # Construieste display name - Prioritate pe titlul extras (.mkv)
            if file_title and len(file_title) > 10:
                display_name = file_title
            elif extracted_size:
                display_name = f"{host_name} | {extracted_size}"
            else:
                display_name = host_name

            # Fortam calitatea corecta din display_name pentru a nu pica la fundul listei
            actual_q = _extract_quality_from_string(display_name) or final_quality

            streams_list.append({
                'name': display_name,
                'url': build_stream_url(final_url),
                'quality': actual_q,
                'title': display_title,
                'size': extracted_size,
                'info': f"{host_name} | {returned_branch or ''}"
            })
            seen_urls.add(url_check)


# =============================================================================
# SCRAPER HDHUB4U (V24 - WORKING VERSION + 4K PRIORITIZATION)
# =============================================================================

def scrape_hdhub4u(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_hdhub4u') == 'false':
        return None

    try:
        base_url = _get_hdhub_base_url()
        session = get_shared_session()
        
        search_query = title_query if title_query else imdb_id
        clean_search = re.sub(r'[^a-zA-Z0-9\s]', ' ', search_query).strip()
        clean_search = re.sub(r'\s+', ' ', clean_search)
        
        bad_qualities = ['hdtc', 'hdts', 'hdcam', 'camrip', 'predvd', 'pre-dvd', 'telesync', 'telecine']
        movie_url = None

        # 1. CAUTARE (JSON API) — site-ul a schimbat domeniul, API-ul vechi e mort
        try:
            api_url = "https://search.hdhub4u.glass/collections/post/documents/search"
            r = session.get(api_url, params={'q': clean_search, 'query_by': 'post_title,imdb_id', 'limit': 15}, timeout=10)
            if r.status_code == 200:
                hits = r.json().get('hits', [])
                for hit in hits:
                    doc = hit.get('document', {})
                    link = doc.get('permalink', '')
                    title = doc.get('post_title', '').lower()
                    if not link or any(bad in title for bad in bad_qualities): continue
                    
                    if (imdb_id and imdb_id in str(doc.get('imdb_id', ''))) or (clean_search.lower() in title):
                        movie_url = f"{base_url.rstrip('/')}{link}" if link.startswith('/') else link
                        break
        except: pass

        # 2. CONSTRUIRE SLUG DIRECT (fallback principal — site-ul nu mai returneaza RSS/JSON)
        if not movie_url and title_query:
            try:
                slug = re.sub(r'[^\w\s-]', '', title_query.lower().strip())
                slug = re.sub(r'\s+', '-', slug).strip('-')
                slug_patterns = [
                    f"{slug}-{year_query}-webrip-hindi-full-movie",
                    f"{slug}-{year_query}-hindi-webrip-full-movie",
                    f"{slug}-{year_query}-hindi-bluray-full-movie",
                    f"{slug}-{year_query}-web-dl-hindi-full-movie",
                    f"{slug}-{year_query}-hindi-web-dl-full-movie",
                    f"{slug}-{year_query}-hindi-720p-bluray",
                    f"{slug}-{year_query}-hindi-bluray-720p",
                    f"{slug}-{year_query}-hindi-1080p-bluray",
                    f"{slug}-{year_query}-bluray-hindi-720p",
                    f"{slug}-{year_query}-webrip-hindi",
                    f"{slug}-{year_query}-hindi-webrip",
                    f"{slug}-{year_query}-hindi-full-movie",
                    f"{slug}-{year_query}-full-movie",
                ]
                for sp in slug_patterns:
                    try:
                        r = session.head(f"{base_url}/{sp}/", timeout=5)
                        if r.status_code == 200:
                            movie_url = f"{base_url}/{sp}/"
                            # log(f"[HDHUB] Slug match: {movie_url}")
                            break
                    except: pass
            except: pass

        # 3. SCANARE SITEMAP (fallback cand slug-urile nu se potrivesc)
        if not movie_url and title_query:
            try:
                slug = re.sub(r'[^\w\s-]', '', title_query.lower().strip())
                slug = re.sub(r'\s+', '-', slug).strip('-')
                sm_r = session.get(f"{base_url}/sitemap.xml", timeout=10)
                if sm_r.status_code == 200:
                    post_sms = re.findall(r"<loc>(https?://[^/]+/post-sitemap\d*\.xml)</loc>", sm_r.text)
                    for sm_url in post_sms[:5]:
                        sm_r2 = session.get(sm_url, timeout=10)
                        if sm_r2.status_code != 200:
                            continue
                        matches = re.findall(rf"<loc>([^<]*{re.escape(slug)}[^<]*)</loc>", sm_r2.text, re.I)
                        if matches:
                            movie_url = matches[0]
                            # log(f"[HDHUB] Sitemap match: {movie_url}")
                            break
            except: pass

        # 4. FALLBACK RSS (possible future fix)
        if not movie_url:
            try:
                rss_url = f"{base_url}/?s={quote(clean_search)}&feed=rss2"
                r = session.get(rss_url, timeout=10)
                if r.status_code == 200:
                    items = r.text.split('<item>')
                    for item in items[1:]:
                        l_m = re.search(r'<link>(.*?)</link>', item)
                        t_m = re.search(r'<title>(.*?)</title>', item)
                        if l_m and t_m:
                            if any(bad in t_m.group(1).lower() for bad in bad_qualities): continue
                            movie_url = l_m.group(1).strip()
                            break
            except: pass

        if not movie_url: return None

        # 3. EXTRAGERE LINK-URI
        r_movie = session.get(movie_url, timeout=12)
        movie_html = r_movie.text
        title_m = re.search(r'<h1[^>]*>.*?<span[^>]*>(.*?)</span>', movie_html, re.DOTALL)
        fallback_title = title_m.group(1).strip() if title_m else title_query

        all_links = re.findall(r'<a\s+href=["\'](https?://[^"\']+)["\'][^>]*>(.*?)</a>', movie_html)
        
        valid_domains = ['hubdrive', 'hubcloud', 'hubcdn', 'hubstream', 'gamerxyt', 'vcloud', 'hblinks', 'search-recover.php',
                         'buzzserver', 'buzzheavie', 'hubcdn.fans', 'filesdl', 'gdflix', 'pixeldrain']
        hdhub_tasks = []
        
        for link, text in all_links:
            link = link.replace('&amp;', '&')
            txt_low = text.lower()
            if any(bad in txt_low for bad in bad_qualities): continue
            if not any(d in link.lower() for d in valid_domains): continue
            
            # PRIORITIZARE (nu mai sarim peste SD/480p!)
            q_label, weight = None, 0
            if '2160' in txt_low or '4k' in txt_low: q_label, weight = "4K", 3
            elif '1080' in txt_low: q_label, weight = "1080p", 2
            elif '720' in txt_low: q_label, weight = "720p", 1
            else: q_label, weight = "SD", 0  # Pastram si SD/480p!
            
            hdhub_tasks.append({'link': link, 'branch': text.strip(), 'quality': q_label, 'w': weight})

        # SORTARE: 4K primele pe teava
        hdhub_tasks.sort(key=lambda x: x['w'], reverse=True)

        streams = []
        seen = set()
        lock = threading.Lock()
        
        def process_task(t):
            res_list = []
            try:
                if 'search-recover.php' in t['link'].lower():
                    res_list = _process_hubcloud_search_recover(t['link'], t['quality'], fallback_title, t['branch'], session)
                else:
                    resolved = _resolve_hdhub_redirect_parallel(t['link'], 0, fallback_title, t['branch'], None)
                    if resolved:
                        _process_resolved_results(resolved, t['quality'], fallback_title, t['branch'], res_list, set())
            except: pass
            return res_list

        # EXECUTIE PARALELA CU DAEMON THREADS (Kodi-safe)
        _hdhub_thrs = []
        _hdhub_lock = threading.Lock()
        _hdhub_out = []
        def _hdhub_worker(t):
            try:
                r = process_task(t)
                if r:
                    with _hdhub_lock:
                        for s in r:
                            if any(bad in str(s.get('title','')).lower() for bad in bad_qualities): continue
                            uc = s['url'].split('|')[0]
                            if uc not in seen: streams.append(s); seen.add(uc)
            except: pass
        for t in hdhub_tasks:
            th = threading.Thread(target=_hdhub_worker, args=(t,), daemon=True)
            th.start()
            _hdhub_thrs.append(th)
        _hdhub_start = time.time()
        while _hdhub_thrs and (time.time() - _hdhub_start) < 20:
            _hdhub_thrs = [th for th in _hdhub_thrs if th.is_alive()]
            if not _hdhub_thrs: break
            time.sleep(0.1)

        return streams if streams else None
    except: return None


# =============================================================================
# SCRAPER MKVCINEMAS (V14 - CLEAN RESOLUTION & CLOUD ROUTING)
# =============================================================================

_mkv_base_cache = {'url': None, 'ts': 0.0}

def _get_mkvcinemas_base():
    """
    Gaseste domeniul activ MKVCinemas.
    MKVCinemas e un WordPress direct (fara landing page cu JS/API ca hdhub4u
    sau moviesdrive), deci probeaza o lista de candidate si valideaza ca situl
    chiar e mkvcinemas dupa titlu — evita preluarile de domeniu (ex: mkvcinemas.sc
    a ajuns FilmyFly, titlu diferit).
    """
    now = time.time()
    if _mkv_base_cache['url'] and (now - _mkv_base_cache['ts']) < 10800:
        return _mkv_base_cache['url']

    candidates = [
        "https://mkvcinemas.as",   # domeniul curent verificat
        "https://mkvcinemas.sc",
        "https://mkvcinemas.al",
        "https://mkvcinemas.nl",
        "https://mkvcinemas.cam",
    ]

    for cand in candidates:
        try:
            r = requests.get(cand + "/", headers=get_headers(), timeout=6, verify=False, allow_redirects=True)
            if r.status_code != 200:
                continue
            title = re.search(r'<title>(.*?)</title>', r.text, re.I | re.S)
            t = title.group(1) if title else ''
            if 'mkvcinemas' not in t.lower():
                continue
            final = r.url.rstrip('/')
            if final.startswith('http'):
                _mkv_base_cache['url'] = final
                _mkv_base_cache['ts'] = now
                return final
        except Exception:
            continue

    # FALLBACK HARDCODED — cache scurt (15 min) ca lista sa fie re-probata curand
    _mkv_base_cache['url'] = "https://mkvcinemas.as"
    _mkv_base_cache['ts'] = now - 9900
    return _mkv_base_cache['url']


def _stream_probe_ok(url, min_bytes=262144, timeout=10):
    """
    Verifica rapid daca URL-ul serveste date video reale (nu blob/404/CF-challenge).
    GET simplu (fara Range - ca Kodi) cu descarcare partiala:
    content-length >= 1MB sau >= min_bytes cititi.
    """
    try:
        clean_url = url.split('|')[0]
        headers = {'User-Agent': get_random_ua()}
        r = requests.get(clean_url, headers=headers, timeout=timeout, verify=False, stream=True)
        if r.status_code >= 400:
            return False
        cl = r.headers.get('content-length')
        if cl and cl.isdigit() and int(cl) >= 1048576:
            return True
        got = 0
        for chunk in r.iter_content(65536):
            got += len(chunk)
            if got >= min_bytes:
                return True
        return got >= min_bytes // 2
    except Exception:
        return False


def scrape_mkvcinemas(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_mkvcinemas') == 'false':
        return None

    try:
        base_url = _get_mkvcinemas_base()
        session = get_shared_session()
        
        search_query = title_query if title_query else imdb_id
        clean_search = re.sub(r'[^a-zA-Z0-9\s]', ' ', search_query).strip()
        clean_search = re.sub(r'\s+', ' ', clean_search)
        bad_qualities = ['hdtc', 'hdts', 'hdcam', 'camrip', 'predvd', 'pre-dvd', 'telesync', 'telecine']
        
        # 1. CAUTARE RSS (Bypass JS)
        movie_url = None
        try:
            rss_url = f"{base_url}/?s={quote(clean_search)}&feed=rss2"
            r = session.get(rss_url, timeout=12, verify=False)
            if r.status_code == 200:
                items = r.text.split('<item>')
                for item in items[1:]:
                    l_m = re.search(r'<link>(.*?)</link>', item)
                    t_m = re.search(r'<title>(.*?)</title>', item)
                    if l_m and t_m:
                        p_t, p_l = t_m.group(1).lower(), l_m.group(1).strip()
                        if any(bad in p_t for bad in bad_qualities): continue
                        if clean_search.lower() in p_t or clean_search.lower().replace(' ', '-') in p_l:
                            if year_query and str(year_query) in p_l: movie_url = p_l; break
                            if not movie_url: movie_url = p_l
        except: pass

        if not movie_url: return None

        # 2. EXTRAGERE LINK-URI FILESDL + HUBDRIVE
        r_post = session.get(movie_url, timeout=12, verify=False)
        post_html = r_post.text
        filesdl_links = re.findall(r'href=["\'](https?://filesdl\.[a-z]+/(?:view/)?(\d+))["\']', post_html, re.I)
        hubdrive_links = re.findall(r'<a\s+href=["\'](https?://hubdrive\.one/file/\d+)["\'][^>]*>([\s\S]*?)</a>', post_html, re.I)
        
        if not filesdl_links and not hubdrive_links: return None
        
        mkv_tasks = []
        seen_ids = set()

        # 3. PROCESARE PAGINI INTERMEDIARE (FilesDL)
        for f_url, f_id in filesdl_links:
            if f_id in seen_ids: continue
            seen_ids.add(f_id)
            
            try:
                # Bypass Cloudflare via WP-API pentru a lua butoanele de download
                api_url = f"https://filesdl.live/wp-json/wp/v2/posts/{f_id}"
                r_api = session.get(api_url, timeout=8, verify=False)
                
                content_html = ""
                if r_api.status_code == 200:
                    content_html = r_api.json().get('content', {}).get('rendered', '')
                else:
                    r_f = session.get(f_url, headers={'Referer': movie_url}, timeout=8, verify=False)
                    content_html = r_f.text

                # "Sapam" dupa Download Boxes (4K, 1080p, 720p)
                boxes = content_html.split('download-box')
                for box in boxes[1:]:
                    q_low = box.lower()
                    
                    quality, weight = None, 0
                    if '2160' in q_low or '4k' in q_low: quality, weight = "4K", 3
                    elif '1080' in q_low: quality, weight = "1080p", 2
                    elif '720' in q_low: quality, weight = "720p", 1
                    else: continue # Sarim peste 480p/SD
                    
                    # Extragem link-urile butoanelor din fiecare box
                    btns = re.findall(r'href=["\'](https?://[^"\']+)["\'][^>]*>(.*?)</a>', box, re.I)
                    for b_url, b_text in btns:
                        b_text_clean = re.sub(r'<[^>]+>', '', b_text).strip()
                        # Nu adaugam direct in lista! Le punem ca sarcini de rezolvat.
                        mkv_tasks.append({
                            'url': b_url, 
                            'quality': quality, 
                            'weight': weight, 
                            'info': b_text_clean
                        })
            except: continue

        # 3b. PROCESARE LINK-URI HUBDRIVE (sistem nou - direct pe pagina postului)
        for h_url, h_label in hubdrive_links:
            h_clean = re.sub(r'<[^>]+>', '', h_label).strip()
            h_low = h_clean.lower()
            if any(bad in h_low for bad in bad_qualities): continue
            quality, weight = "SD", 0
            if '2160' in h_low or '4k' in h_low: quality, weight = "4K", 3
            elif '1080' in h_low: quality, weight = "1080p", 2
            elif '720' in h_low: quality, weight = "720p", 1
            mkv_tasks.append({
                'url': h_url,
                'quality': quality,
                'weight': weight,
                'info': h_clean
            })

        if not mkv_tasks: return None
        # Sortam: 4K primele
        mkv_tasks.sort(key=lambda x: x['weight'], reverse=True)

        streams = []
        seen_urls = set()
        lock = threading.Lock()

        # 4. RESOLVER FINAL (Curatenie & Routing)
        def work(t):
            local_found = []
            u = t['url'].replace('&amp;', '&')
            u_low = u.lower()
            try:
                # Rutam fiecare link catre procesorul lui specific
                if 'search-recover' in u_low:
                    return _process_hubcloud_search_recover(u, t['quality'], title_query, t['info'], session)
                
                elif any(x in u_low for x in ['hubcloud', 'vcloud']):
                    resolved = _resolve_hdhub_redirect_parallel(u, 0, title_query, t['info'], None)
                    if resolved:
                        _process_resolved_results(resolved, t['quality'], title_query, t['info'], local_found, set())
                    return local_found

                elif 'hubdrive' in u_low:
                    resolved = _resolve_hdhub_redirect_parallel(u, 0, title_query, t['info'], None)
                    if resolved:
                        _process_resolved_results(resolved, t['quality'], title_query, t['info'], local_found, set())
                    return local_found

                elif 'gdflix' in u_low:
                    # Folosim procesorul de pagini GDFlix existent
                    return _process_gdflix_page(u, t['quality'], title_query, t['info'])

                elif 'filesdl' in u_low and ('/cloud/' in u_low or '/drive/' in u_low):
                    # Folosim procesorul de pagini Cloud existent (REZOLVA EROAREA TA DIN LOG)
                    return _process_filesdl_cloud_page(u, t['quality'], title_query, t['info'])

                # Fallback doar daca e link video direct verificat
                elif _is_direct_video_url(u):
                    h = _identify_host_from_url(u)
                    local_found.append({
                        'name': f"MKV | {h}", 
                        'url': build_stream_url(u), 
                        'quality': t['quality'], 
                        'title': title_query, 
                        'info': t['info'], 
                        'provider_id': 'mkvcinemas'
                    })
            except: pass
            return local_found

        _mkv_thrs = []
        _mkv_lock = threading.Lock()
        def _mkv_worker(t):
            try:
                r = work(t)
                if r:
                    with _mkv_lock:
                        for s in r:
                            if any(bad in str(s.get('title','')).lower() for bad in bad_qualities): continue
                            if not _stream_probe_ok(s['url']): continue
                            uc = s['url'].split('|')[0]
                            if uc not in seen_urls: streams.append(s); seen_urls.add(uc)
            except: pass
        for t in mkv_tasks:
            th = threading.Thread(target=_mkv_worker, args=(t,), daemon=True)
            th.start()
            _mkv_thrs.append(th)
        _mkv_start = time.time()
        while _mkv_thrs and (time.time() - _mkv_start) < 20:
            _mkv_thrs = [th for th in _mkv_thrs if th.is_alive()]
            if not _mkv_thrs: break
            time.sleep(0.1)

        return streams if streams else None
    except Exception as e:
        log(f"[MKV] Critical error: {e}")
        return None


# =============================================================================
# HELPER NOU: API HubCloud (search-recover.php) - V2 (SORTARE & FILTRARE JSON)
# =============================================================================
def _process_hubcloud_search_recover(url, quality, title, branch_info, session, target_episode=None):
    """
    Rezolva noul sistem MoviesDrive/HubCloud (search-recover.php).
    V2: Sorteaza hit-urile din JSON pentru a prioritiza 4K/1080p.
    """
    streams = []
    bad_qualities = ['hdtc', 'hdts', 'hdcam', 'camrip', 'predvd', 'pre-dvd', 'telesync', 'telecine']
    
    try:
        url = url.replace('&amp;', '&').replace('&#038;', '&')
        parsed = urlparse(url)
        qs = dict(parse_qsl(parsed.query))
        
        from_ac = qs.get('from_ac', '')
        q_b64 = qs.get('q', '')
        if not from_ac or not q_b64: return streams

        q_b64 = q_b64.replace('-', '+').replace('_', '/')
        q_b64 += "=" * ((4 - len(q_b64) % 4) % 4)
        decoded_q = base64.b64decode(q_b64).decode('utf-8')

        api_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
        params = {'api': 'search', 'q': decoded_q, 'page': '1', 'from_ac': from_ac}
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'Accept': 'application/json', 'Referer': url, 'X-Requested-With': 'XMLHttpRequest'
        }

        r = session.get(api_url, params=params, headers=headers, timeout=10, verify=False)
        if r.status_code == 200:
            hits = r.json().get('hits', [])
            
            # --- PASUL 1: FILTRARE SI ATRIBUIRE GREUTATE ---
            valid_hits = []
            for hit in hits:
                fn = hit.get('file_name', '').lower()
                # 1. Filtru bad quality
                if any(bad in fn for bad in bad_qualities): continue
                # 2. Filtru episod
                if target_episode:
                    if not re.search(rf'(?i)(?:E|Ep|Episode)[\s0]*{int(target_episode)}\b', fn): continue
                
                # 3. Calcul greutate (4K=3, 1080=2, 720=1, Restul=0)
                weight = 0
                hit_q = "SD"
                if '2160' in fn or '4k' in fn: hit_q, weight = "4K", 3
                elif '1080' in fn: hit_q, weight = "1080p", 2
                elif '720' in fn: hit_q, weight = "720p", 1
                
                if weight >= 0: # Includem SD/480p
                    hit['w'] = weight
                    hit['q_label'] = hit_q
                    valid_hits.append(hit)

            # --- PASUL 2: SORTARE HIT-URI (4K PRIMELE) ---
            valid_hits.sort(key=lambda x: x['w'], reverse=True)

            # --- PASUL 3: REZOLVARE IN ORDINEA PRIORITATII ---
            for hit in valid_hits:
                file_url = hit.get('url', '')
                if not file_url: continue
                
                # Rezolvam link-ul HubCloud (de obicei PixelDrain/R2)
                resolved = _resolve_hdhub_redirect_parallel(file_url, 0, title, branch_info, None)
                if resolved:
                    temp_streams = []
                    _process_resolved_results(resolved, hit['q_label'], title, branch_info, temp_streams, set())
                    for s in temp_streams:
                        if hit.get('size'): s['size'] = hit['size']
                        # Verificare finala nume fisier
                        if not any(bad in s['title'].lower() for bad in bad_qualities):
                            streams.append(s)
                            
    except Exception as e:
        log(f"[MDRIVE-RECOVER] Error: {e}")
    return streams


# =============================================================================
# SCRAPER MOVIESDRIVE (V16 - ULTRA FAST & 4K PRIORITIZED)
# =============================================================================

def scrape_moviesdrive(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_moviesdrive') == 'false': return None
    try:
        base_url = _get_moviesdrive_base()
        session = get_shared_session()
        search_query = title_query if title_query else imdb_id
        clean_search = re.sub(r'[^a-zA-Z0-9\s]', ' ', search_query).strip()
        
        # 1. CAUTARE JSON
        search_api_url = f"{base_url}/search.php"
        headers = {'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json'}
        r = session.get(search_api_url, params={'q': clean_search, 'page': '1'}, headers=headers, timeout=12, verify=False)
        if r.status_code != 200: return None
        hits = r.json().get('hits', [])
        if not hits: return None

        # 2. GASIRE PAGINA (Match slug/an)
        movie_url = None
        search_slug = clean_search.lower().replace(' ', '-')
        bad_qualities = ['hdtc', 'hdts', 'hdcam', 'camrip', 'predvd', 'telesync']
        
        for hit in hits:
            doc = hit.get('document', {})
            raw_link = doc.get('permalink', '')
            raw_title = doc.get('post_title', '').lower()
            if not raw_link or any(bad in raw_title for bad in bad_qualities): continue
            
            full_link = raw_link if raw_link.startswith('http') else f"{base_url.rstrip('/')}/{raw_link.lstrip('/')}"
            if search_slug in full_link.lower() or clean_search.lower() in raw_title:
                if year_query and str(year_query) in full_link: movie_url = full_link; break
                if not movie_url: movie_url = full_link
        
        if not movie_url: movie_url = hits[0].get('document', {}).get('permalink', '')
        if not movie_url: return None

        # 3. ACCESARE PAGINA & EXTRAGERE BUTOANE
        r_page = session.get(movie_url, timeout=10, verify=False)
        target_html = r_page.text
        title_match = re.search(r'<title>([^<]+)</title>', target_html)
        target_title = title_match.group(1).split('|')[0].strip().replace('– MoviesDrive', '') if title_match else title_query

        # Daca e TV, mergem la pagina sezonului
        if content_type == 'tv' and season:
            sn = int(season)
            s_link = None
            for p in [rf'href=["\']([^"\']*season[- ]?{sn}[^"\']*)["\']', rf'href=["\']([^"\']*s{sn:02d}[^"\']*)["\']']:
                m = re.search(p, target_html, re.I)
                if m: s_link = base_url + m.group(1) if m.group(1).startswith('/') else m.group(1); break
            if s_link: target_html = session.get(s_link, timeout=10).text

        # 4. PROCESARE BUTOANE (SORTATE DUPA CALITATE)
        btn_links = []
        all_a = re.findall(r'<a\s+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', target_html, re.I)
        for url, text in all_a:
            txt = text.lower()
            if any(key in url.lower() for key in ['search-recover.php', 'hubcloud', 'mdrive.lol']):
                w = 3 if ('2160' in txt or '4k' in txt) else 2 if '1080' in txt else 1 if '720' in txt else 0
                if w > 0 and not any(bad in txt for bad in bad_qualities):
                    btn_links.append({'url': url, 'text': text, 'w': w})
        
        btn_links.sort(key=lambda x: x['w'], reverse=True)
        
        streams = []
        seen_urls = set()
        lock = threading.Lock()
        
        def work(item):
            q = "4K" if item['w'] == 3 else "1080p" if item['w'] == 2 else "720p"
            u = item['url'].replace('&amp;', '&')
            res_streams = []
            if 'search-recover.php' in u.lower():
                res_streams = _process_hubcloud_search_recover(u, q, target_title, item['text'], session, episode if content_type=='tv' else None)
            elif 'mdrive.lol' in u.lower():
                # Pentru mdrive.lol trebuie sa intram o data
                try:
                    inner = session.get(u, timeout=8).text
                    m = re.search(r'href=["\'](https?://[^"\']*search-recover\.php[^"\']+)["\']', inner, re.I)
                    if m: res_streams = _process_hubcloud_search_recover(m.group(1), q, target_title, item['text'], session, episode if content_type=='tv' else None)
                except: pass
            return res_streams

        _hc_thrs = []
        _hc_lock = threading.Lock()
        def _hc_worker(b):
            try:
                r = work(b)
                if r:
                    with _hc_lock:
                        for s in r:
                            uc = s['url'].split('|')[0]
                            if uc not in seen_urls: streams.append(s); seen_urls.add(uc)
            except: pass
        for b in btn_links[:10]:
            th = threading.Thread(target=_hc_worker, args=(b,), daemon=True)
            th.start()
            _hc_thrs.append(th)
        _hc_start = time.time()
        while _hc_thrs and (time.time() - _hc_start) < 22:
            _hc_thrs = [th for th in _hc_thrs if th.is_alive()]
            if not _hc_thrs: break
            time.sleep(0.1)
        
        return streams if streams else None
    except Exception as e:
        log(f"[MDRIVE] Error: {e}")
        return None


def scrape_moviesdrive(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_moviesdrive') == 'false':
        return None

    try:
        base_url = _get_moviesdrive_base()
        session = get_shared_session()
        
        # --- PASUL 0: SESIUNE PRE-WARMUP (Anti-Bot Bypass) ---
        try:
            session.get(f"{base_url}/", timeout=5, verify=False)
        except: pass

        search_query = title_query if title_query else imdb_id
        clean_search = re.sub(r'[^a-zA-Z0-9\s]', ' ', search_query).strip()
        clean_search = re.sub(r'\s+', ' ', clean_search)
        
        bad_qualities = ['hdtc', 'hdts', 'hdcam', 'camrip', 'predvd', 'pre-dvd', 'telesync', 'telecine']
        movie_url = None
        search_slug = clean_search.lower().replace(' ', '-')
        import html as html_lib

        # =========================================================
        # 1. CAUTARE HYBRIDA (JSON + FALLBACK HTML)
        # =========================================================
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'X-Requested-With': 'XMLHttpRequest',
            'Referer': f"{base_url}/"
        }

        # Incercam JSON prima data
        try:
            r = session.get(f"{base_url}/search.php", params={'q': clean_search, 'page': '1'}, headers=headers, timeout=10, verify=False)
            if r.status_code == 200:
                hits = r.json().get('hits', [])
                for hit in hits:
                    doc = hit.get('document', {})
                    raw_link = doc.get('permalink', '')
                    raw_title = html_lib.unescape(doc.get('post_title', ''))
                    if not raw_link: continue
                    full_link = raw_link if raw_link.startswith('http') else f"{base_url.rstrip('/')}/{raw_link.lstrip('/')}"
                    
                    if any(bad in full_link.lower() or bad in raw_title.lower() for bad in bad_qualities): continue
                    
                    if (imdb_id and imdb_id in full_link) or (search_slug in full_link.lower()):
                        movie_url = full_link
                        if year_query and str(year_query) in full_link.lower(): break
        except: pass

        # Fallback la HTML Search daca JSON a esuat
        if not movie_url:
            try:
                r_html = session.get(f"{base_url}/", params={'s': clean_search}, headers={'User-Agent': headers['User-Agent']}, timeout=10, verify=False)
                res_links = re.findall(r'<h2[^>]*><a href=["\']([^"\']+)["\']', r_html.text, re.IGNORECASE)
                for lnk in res_links:
                    if any(bad in lnk.lower() for bad in bad_qualities): continue
                    if search_slug in lnk.lower():
                        movie_url = lnk
                        break
            except: pass

        if not movie_url: return None

        # =========================================================
        # 2. PROCESARE PAGINA (FILM SAU SERIAL)
        # =========================================================
        r_page = session.get(movie_url, timeout=10, verify=False)
        target_html = r_page.text
        
        # Daca este serial, cautam pagina sezonului
        if content_type == 'tv' and season:
            season_num = int(season)
            season_link = None
            for pattern in [rf'href=["\']([^"\']*season[- ]?{season_num}[^"\']*)["\']', rf'href=["\']([^"\']*s{season_num:02d}[^"\']*)["\']']:
                match = re.search(pattern, target_html, re.IGNORECASE)
                if match:
                    season_link = base_url + match.group(1) if match.group(1).startswith('/') else match.group(1)
                    break
            if season_link:
                target_html = session.get(season_link, timeout=10, verify=False).text

        title_match = re.search(r'<title>([^<]+)</title>', target_html)
        target_title = html_lib.unescape(title_match.group(1).split('|')[0].strip().replace('– MoviesDrive', '')) if title_match else title_query

        # =========================================================
        # 3. COLECTARE SI PRIORITIZARE LINK-URI (4K -> 1080 -> 720)
        # =========================================================
        # Restrangem cautarea la sectiunea de download
        start_search = target_html.find("DOWNLOAD LINKS")
        html_section = target_html[start_search:] if start_search != -1 else target_html
        
        raw_found = re.findall(r'<a\s+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', html_section, re.IGNORECASE)
        
        mdrive_tasks = []
        seen_urls = set()

        for l_url, l_text in raw_found:
            text_clean = html_lib.unescape(re.sub(r'<[^>]+>', '', l_text).strip())
            text_lower = text_clean.lower()
            
            # Filtru ANTI-HDTC / CAM
            if any(bad in text_lower for bad in bad_qualities): continue
            
            # Filtru PRIORITATE si EXCLUDERE SD/480p
            quality, weight = None, 0
            if '2160' in text_lower or '4k' in text_lower: quality, weight = "4K", 3
            elif '1080' in text_lower: quality, weight = "1080p", 2
            elif '720' in text_lower: quality, weight = "720p", 1
            else: continue # Skip SD/480p/360p
            
            if any(key in l_url.lower() for key in ['search-recover.php', 'hubcloud', 'gdflix', 'vcloud', 'mdrive.lol']):
                mdrive_tasks.append({
                    'url': l_url.replace('&amp;', '&'),
                    'text': text_clean,
                    'quality': quality,
                    'weight': weight
                })

        if not mdrive_tasks: return None
        
        # --- SORTARE: 4K INCEPE PRIMUL PE RETEA ---
        mdrive_tasks.sort(key=lambda x: x['weight'], reverse=True)

        streams = []
        final_seen_urls = set()
        streams_lock = threading.Lock()
        episode_num = int(episode) if episode else 1

        def process_node(item):
            local_res = []
            try:
                d_url = item['url']
                # Daca suntem la seriale, filtram blocul de episoade inainte
                if content_type == 'tv' and 'search-recover.php' not in d_url:
                    # Request rapid pentru a vedea daca episodul exista in mdrive.lol
                    r_node = session.get(d_url, timeout=7, verify=False)
                    node_html = r_node.text
                    if f"Ep{episode_num:02d}" not in node_html and f"Episode {episode_num}" not in node_html:
                        return [] # Skip daca nu e episodul nostru
                    
                if 'search-recover.php' in d_url.lower():
                    local_res.extend(_process_hubcloud_search_recover(d_url, item['quality'], target_title, item['text'], session, target_episode=(episode if content_type=='tv' else None)))
                else:
                    # Rezolvam mdrive.lol sau hubcloud direct
                    resolved = _resolve_hdhub_redirect_parallel(d_url, 0, target_title, item['text'], None)
                    if resolved:
                        _process_resolved_results(resolved, item['quality'], target_title, item['text'], local_res, set())
            except: pass
            return local_res

        # EXECUTIE PARALELA CU DAEMON THREADS (Kodi-safe)
        _md_thrs = []
        _md_lock = threading.Lock()
        def _md_worker(t):
            try:
                r = process_node(t)
                if r:
                    with _md_lock:
                        for s in r:
                            if any(bad in s.get('title', '').lower() for bad in bad_qualities): continue
                            uc = s['url'].split('|')[0]
                            if uc not in final_seen_urls: streams.append(s); final_seen_urls.add(uc)
            except: pass
        for t in mdrive_tasks:
            th = threading.Thread(target=_md_worker, args=(t,), daemon=True)
            th.start()
            _md_thrs.append(th)
        _md_start = time.time()
        while _md_thrs and (time.time() - _md_start) < 22:
            _md_thrs = [th for th in _md_thrs if th.is_alive()]
            if not _md_thrs: break
            time.sleep(0.1)

        return streams if streams else None

    except Exception as e:
        log(f"[MDRIVE] Critical error: {e}", xbmc.LOGERROR)
        return None

# =============================================================================
# HELPER PROVIDERI JSON (StreamVix, Vidzee, Webstreamr)
# =============================================================================
def _resolve_hubcloud_url(url):
    if not url or 'hubcloud.cx/drive/' not in url:
        return url
    try:
        r = requests.get(url, headers=get_headers(), timeout=10)
        if r.status_code != 200 or 'text/html' not in r.headers.get('content-type', ''):
            return None
        m = re.search(r"var url\s*=\s*'([^']+)'", r.text)
        if m:
            return m.group(1)
        m = re.search(r'href="([^"]*gamerxyt\.com[^"]*)"', r.text)
        if m:
            return m.group(1)
    except:
        pass
    return None

def _scrape_json_provider(base_url, pattern, label, imdb_id, content_type, season, episode, title_query=None, year_query=None):
    """
    Helper pentru providerii JSON (StreamVix, Vidzee, Webstreamr).
    FIX: Extrage calitatea din name/title/description si foloseste titlul fallback.
    """
    local_streams = []
    
    timeout = 25
    
    try:
        if content_type == 'movie':
            api_url = f"{base_url}/stream/movie/{imdb_id}.json" if pattern == 'stream' else f"{base_url}/movie/{imdb_id}.json"
        else:
            api_url = f"{base_url}/stream/series/{imdb_id}:{season}:{episode}.json" if pattern == 'stream' else f"{base_url}/series/{imdb_id}:{season}:{episode}.json"

        r = requests.get(api_url, headers=get_headers(), timeout=timeout, verify=False)
        r.raise_for_status()

        if r.status_code == 200:
            data = r.json()
            if 'streams' in data:
                ref = base_url + '/'
                origin = base_url

                for s in data['streams']:
                    url = s.get('url', '')
                    if not url: continue

                    # =====================================================
                    # FIX 1: OCOLIM CLOUDFLARE EXTRAGAND URL-UL DIRECT (M3U8)
                    # =====================================================
                    import urllib.parse
                    if 'meowserver' in url and 'url=' in url:
                        try:
                            parsed_qs = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
                            if 'url' in parsed_qs:
                                url = parsed_qs['url'][0]
                        except:
                            pass

                    if 'hubcloud.cx/drive/' in url:
                        url = _resolve_hubcloud_url(url)
                        if not url:
                            continue
                    
                    raw_name = s.get('name', '')
                    raw_title = s.get('title', '')
                    description = s.get('description', '')

                    # =====================================================
                    # FIX 2: IGNORAM CALITATEA "AUTO" PENTRU A EVITA DEDUPLICAREA GRESITA A 1080P
                    # =====================================================
                    if 'Auto' in raw_name or 'Auto' in description:
                        continue

                    # =====================================================
                    # EXTRAGERE FILENAME ORIGINAL (Din description pt Volecitor/etc)
                    # =====================================================
                    if description:
                        first_line = description.split('\n')[0].strip()
                        # Verificam strict daca pe prima linie exista o extensie video
                        if re.search(r'(\.mkv|\.mp4|\.avi|\.ts|\.webm)', first_line, re.IGNORECASE):
                            # Eliminam doar parantezele patrate de la inceput (ex: [10Gbps] [💾 9.58 GB])
                            clean_filename = re.sub(r'^(\[[^\]]+\]\s*)+', '', first_line).strip()
                            if clean_filename:
                                raw_title = clean_filename
                    
                    # APLICARE TITLU FALLBACK (Daca nu s-a extras niciun fisier video si raw_title e gol)
                    if not raw_title and title_query:
                        if content_type == 'tv' and season and episode:
                            raw_title = f"{title_query} S{int(season):02d}E{int(episode):02d}"
                        else:
                            raw_title = title_query

                    try: clean_name = raw_name.encode('ascii', 'ignore').decode('ascii')
                    except: clean_name = raw_name

                    # Eliminare nume provider din afisare
                    banned_names = ['WebStreamr', 'StreamVix', 'Vidzee', 'Sooti', 'Sootio', 'HDHub']
                    for bn in banned_names:
                        clean_name = clean_name.replace(bn, '').strip()
                    
                    clean_name = clean_name.replace('|', '').replace('[', '').replace(']', '').strip()
                    clean_name = clean_name.replace('\n', ' ').strip()
                    while '  ' in clean_name: clean_name = clean_name.replace('  ', ' ')

                    final_name = f"{label} | {clean_name}" if clean_name else label
                    
                    # Extragere Calitate
                    quality = None
                    if s.get('quality'): quality = s.get('quality')
                    if not quality and description: quality = _extract_quality_from_string(description)
                    if not quality or quality.upper() == 'SD': quality = _extract_quality_from_string(raw_name)
                    if not quality: quality = _extract_quality_from_string(raw_title)
                    if not quality: quality = _extract_quality_from_string(s.get('behaviorHints', {}).get('filename', ''))
                    if not quality: quality = 'SD'
                    
                    # Inglobam description in info pentru ca regex-urile din player.py sa extraga corect marimea (ex: 💾 9.58 GB)
                    info_text = str(s.get('behaviorHints', {}).get('filename', '')) + " " + description
                    
                    stream_obj = {
                        'name': final_name,
                        'url': build_stream_url(url, referer=ref, origin=origin),
                        'quality': quality,
                        'title': raw_title,
                        'info': info_text.strip(),
                        'provider_id': label.lower()
                    }
                    local_streams.append(stream_obj)
                
                log(f"[SCRAPER] ✓ {label}: {len(local_streams)} surse")
                
    except Exception as e:
        log(f"[JSON-PROV] Error {label}: {e}")

    return local_streams
    


def _extract_release_group(filename):
    """Extrage Release Group din coada numelui (ex: ...-BYNDR.mkv -> BYNDR) ca fallback."""
    if not filename: return ""
    import re
    clean_name = filename.strip()
    
    # Eliminam extensia video daca exista
    clean_name = re.sub(r'(?i)\.(mkv|mp4|avi|ts|webm|m4v)$', '', clean_name)
    
    # Cautam ultimul '-' urmat de litere/cifre (dar nu prea lung, max 15 caractere)
    m = re.search(r'-([a-zA-Z0-9_]+)$', clean_name)
    if m:
        grp = m.group(1)
        bad_groups = ['x264', 'x265', 'h264', 'h265', 'hevc', '1080p', '720p', '2160p', '4k', 'hdr', 'sdr', 'remux', 'ESub', 'DV', 'Dual', 'e', 'web', 'webdl', 'webrip', 'bluray', 'bdrip', 'brrip', 'hdtv', 'dvdrip', 'dl']
        if grp.lower() not in bad_groups and 2 <= len(grp) <= 15:
            return grp
    dot_bad = ['x264', 'x265', 'h264', 'h265', 'hevc', 'av1', 'vp9', 'xvid', '1080p', '720p', '2160p', '480p', '360p', '4k', 'uhd', 'fhd', 'hd', 'hdr', 'hdr10', 'dv', 'sdr', 'hlg', 'webdl', 'webrip', 'web', 'hdtv', 'bluray', 'bdrip', 'brrip', 'remux', 'ddp', 'dd', 'ac3', 'eac3', 'aac', 'dts', 'atmos', 'truehd', 'flac', 'mp3', 'opus', 'stereo', 'multi', '10bit', '8bit', '12bit', 'esub', 'subbed', 'dubbed', 'dublado', 'legendado', 'proper', 'repack', 'rerip', 'extended', 'uncut', 'unrated', 'dual', 'sdh', 'ma', 'esp', 'ita', 'eng', 'fre', 'ger', 'lat', 'sub', 'subs', 'imax', 'hybrid', 'internal', 'pal', 'ntsc']
    b = re.search(r'(?:-\[|\[)([A-Za-z0-9_]{2,14})[^\]]*\]$', clean_name)
    if b:
        br_grp = b.group(1)
        if re.search(r'[A-Za-z]', br_grp) and br_grp.lower() not in dot_bad:
            return br_grp
    clean_name = re.sub(r'[\s\)\]]+$', '', clean_name)
    d = re.search(r'\.([A-Za-z0-9_]{2,14})$', clean_name)
    if d:
        dot_grp = d.group(1)
        if not re.search(r'[A-Za-z]', dot_grp):
            return ""
        if re.match(r'(?i)^v\d+$', dot_grp):
            return ""
        if dot_grp.lower() not in dot_bad:
            return dot_grp
    s = re.search(r'\s([A-Za-z0-9_]{2,14})$', clean_name)
    if s:
        sp_grp = s.group(1)
        if re.search(r'(19|20)\d{2}|1080p|720p|2160p|480p|\b4k\b', clean_name, re.I):
            if re.search(r'[A-Z]', sp_grp) or (re.search(r'[A-Za-z]', sp_grp) and re.search(r'\d', sp_grp)):
                if sp_grp.lower() not in dot_bad:
                    return sp_grp
    return ""

import urllib.parse

def full_unquote(text):
    """Decodeaza repetat (ex: %2520 -> %20 -> Spatiu) pentru Mediafusion."""
    if not text: return ""
    prev = text
    for _ in range(3):
        text = urllib.parse.unquote(text)
        if text == prev: break
        prev = text
    return text

def _parse_stremio_addon_stream(s, addon_name, provider_id):
    """
    Extrage Numele Fisierului, Debrid, Indexer si Seederi.
    Rezolva URL parameters pt Comet si double encoding pt Mediafusion.
    """
    url = s.get('url')
    if not url:
        info_hash = s.get('infoHash')
        if not info_hash:
            return None
        trackers = s.get('sources', [])
        url = "magnet:?xt=urn:btih:%s" % info_hash
        for tr in trackers:
            url += "&tr=%s" % tr
        # Magnet URLs from non-P2P providers (custom1-5 etc.) are blocked — P2P only
        if not provider_id.startswith('p2p_'):
            return None
    
    raw_name = s.get('name', '')
    raw_title = (s.get('title', '') + '\n' + s.get('description', '')).strip()
    name_upper = raw_name.upper()
    url_lower = url.lower()
    
    # 1. Debrid & Cached Status
    is_cached = False
    debrid_service = ""

    # Map debrid initials to full names (TB=torbox, RD=realdebrid, AD=alldebrid, PM=premiumize, EN=easynews)
    DEBRID_INITIALS = {
        'TB': 'torbox', 'RD': 'realdebrid', 'AD': 'alldebrid',
        'PM': 'premiumize', 'EN': 'easynews',
    }

    # Priority 1: Name-based — matches [TB+], [TB⚡], [TB🌩️] (Torrentio/Comet/Meteor)
    for initial, service in DEBRID_INITIALS.items():
        if f'[{initial}' in name_upper:
            debrid_service = service
            is_cached = f'[{initial}+]' in name_upper
            break
    if debrid_service and not is_cached and provider_id == 'torz' and '⚡️' in raw_name:
        is_cached = True
    if debrid_service and not is_cached and provider_id == 'meteor' and '📫' in raw_name:
        is_cached = True
    if not debrid_service:
        # MediaFusion pattern: 🧲 CODE ⚡️ (e.g. 🧲 TRB ⚡️ for TorBox)
        mf_match = re.search(r'🧲\s*(\w+)\s*⚡', raw_name)
        if mf_match:
            mf_code = mf_match.group(1).upper()
            mf_map = {'TRB': 'torbox', 'RD': 'realdebrid', 'AD': 'alldebrid', 'PM': 'premiumize', 'EN': 'easynews'}
            if mf_code in mf_map:
                debrid_service = mf_map[mf_code]
                is_cached = True

    # Priority 2: URL path patterns
    if not debrid_service:
        url_checks = {
            '/realdebrid/': 'realdebrid', '/rd/': 'realdebrid',
            '/alldebrid/': 'alldebrid', '/ad/': 'alldebrid',
            '/premiumize/': 'premiumize', '/pm/': 'premiumize',
            '/torbox/': 'torbox', '/tb/': 'torbox',
            '/easynews/': 'easynews', '/en/': 'easynews',
        }
        for pattern, service in url_checks.items():
            if pattern in url_lower:
                debrid_service = service
                break

    # Priority 3: Description/title patterns (Comet puts "DebridAccount|torbox" in description)
    if not debrid_service:
        title_lower = raw_title.lower()
        for initial, service in DEBRID_INITIALS.items():
            if f'|{service}' in title_lower or service in title_lower:
                debrid_service = service
                break

    # Priority 4: behaviorHints.cached — set is_cached if not already set
    if not is_cached and debrid_service:
        is_cached = s.get('behaviorHints', {}).get('cached', False)

    # 2. Extragem numele fisierului din title / behaviorHints
    raw_title_unquoted = full_unquote(raw_title)
    lines = [line.strip() for line in raw_title_unquoted.split('\n') if line.strip()]
    filename = ""
    info_line = ""
    
    # Prioritate 1: behaviorHints.filename (Meteor pune numele real aici)
    try:
        bh_filename = s.get('behaviorHints', {}).get('filename', '')
        if bh_filename and len(bh_filename) > 5:
            filename = bh_filename
    except:
        pass
    
    # Prioritate 2: Linia cu 📄 sau 📂 din title (Meteor / Mediafusion)
    if not filename:
        for line in lines:
            if '📄' in line or '📂' in line:
                potential = line.replace('📄', '').replace('📂', '').strip()
                if potential and len(potential) > 5:
                    filename = potential
                    break
    
    # Prioritate 3: Prima linie non-info (TorrentIO / Comet / Mediafusion)
    # Only treat seeders/size/indexer lines as "skip" -- quality/audio/language lines
    # are valid fallback filenames when the real name is unavailable
    if not filename:
        for line in lines:
            if not any(e in line for e in ('👤', '👥', '💾', '⚙️', '🇵🇱')) and 'GB' not in line.upper() and 'MB' not in line.upper() and 'TB' not in line.upper() and ' peers ' not in line.lower() and 'multi audio' not in line.lower():
                filename = line
                break
    
    if not filename:
        filename = raw_title_unquoted.replace('\n', ' ')
    
    # Identificam linia de info (marime, seederi, indexer)
    for line in lines:
        if any(e in line for e in ('👤', '💾', '⚙️', '🇵🇱')) or 'GB' in line.upper() or 'MB' in line.upper() or ' peers ' in line.lower() or 'multi audio' in line.lower():
            info_line = line

    # 3. EXTRATIE NUME FISIER DIN URL (Pentru Comet / Fallback)
    def is_valid_filename(fname):
        return bool(re.search(r'\.(mkv|mp4|avi|ts|webm|m4v)', fname, re.IGNORECASE))
        
    # Daca numele e gol, e un hash random, sau n-are extensie (skip pentru magnet URLs)
    if not url.startswith('magnet:') and (not is_valid_filename(filename) or len(filename) < 5 or (' ' not in filename and '.' not in filename)):
        try:
            clean_url = url.split('|')[0]
            parsed_url = urllib.parse.urlparse(clean_url)
            qs = urllib.parse.parse_qs(parsed_url.query)
            
            # Verificam variabilele din link (Comet foloseste torrent_name= sau name=)
            if 'torrent_name' in qs:
                filename = qs['torrent_name'][0]
            elif 'name' in qs:
                filename = qs['name'][0]
            else:
                # Nu are parametri, incercam din Path (Torrentio / Meteor)
                url_name = ""
                if '/null/0/' in clean_url: url_name = clean_url.split('/null/0/')[-1]
                elif '/null/undefined/' in clean_url: url_name = clean_url.split('/null/undefined/')[-1]
                else: url_name = clean_url.split('/')[-1]
                
                url_name = url_name.split('?')[0]
                
                # Evitam nume care par ID-uri (numere, hash-uri hex) in loc de nume de fisiere
                if url_name and len(url_name) > 5 and not url_name.isdigit() and not re.match(r'^[a-f0-9]{32,40}$', url_name, re.I):
                    filename = url_name
        except:
            pass

    filename = full_unquote(filename).strip(' |-,')
    
    # 3.5 FILTRU CAM/TS/SAMPLE — aceleasi reguli ca in scrape_aiostreams
    if re.search(r'(?i)\b(trailer|sample|cam|camrip|hdts|hdtc|ts|telesync)\b', filename):
        return None
    
    # 3.6 BLOCARE FISIERE GUNOI / MALWARE / NON-VIDEO / AUDIO
    bad_extensions = [
        '.iso', '.zip', '.rar', '.7z', '.tar', '.gz', '.zipx', '.arj',
        '.txt', '.nfo', '.jpg', '.png', '.pdf',
        '.exe', '.bat', '.cmd', '.scr', '.msi', '.ps1', '.vbs', '.js', '.jar', '.com', '.pif', '.reg', '.dll', '.sys', '.lnk',
        '.mp3', '.wav', '.flac', '.m4a', '.aac', '.ogg', '.wma', '.ape', '.alac'
    ]
    filename_lower = filename.lower()
    if any(filename_lower.endswith(ext) for ext in bad_extensions) or any(f"{ext} " in filename_lower for ext in bad_extensions):
        return None

    # 3.6 FILTRU WEB (Optional din setari) - DOAR PENTRU RD
    try:
        if ADDON.getSetting('filter_web_sources') == 'true' and debrid_service == 'realdebrid':
            if _is_web_source(filename) or _is_web_source(raw_title) or _is_web_source(raw_name):
                # log(f"[FILTER-WEB] Excluding WEB RD source: {filename[:50]}...")
                return None
    except:
        pass

    # 4. Marime si Seederi
    size_match = re.search(r'([\d.,]+\s*(?:GiB|MiB|TiB|KiB|GB|MB|TB))', raw_title_unquoted, re.IGNORECASE)
    size = size_match.group(1).upper() if size_match else ""
    
    seeders = 0
    seed_match = re.search(r'(?:👤|👥|S:|P:|Peers:)\s*(\d+)', raw_title_unquoted, re.IGNORECASE)
    if seed_match: seeders = int(seed_match.group(1))
    
    # 5. Indexer — prioritate 1: decodeaza `t` din URL (cel mai autoritar, suprascrie AIO)
    indexer = ""
    if url and '?t=' in url:
        try:
            import base64, json as _json
            _t = url.split('?t=')[1].split('|')[0].split('&')[0]
            _t = _t + '=='
            _decoded = _json.loads(base64.urlsafe_b64decode(_t).decode('utf-8'))
            _t_idxer = str(_decoded.get('indexer', '')).strip()
        except:
            _t_idxer = ''
        if _t_idxer:
            indexer = _t_idxer
    # Prioritate 2: 🗂️ (Usenet), apoi 🔗, apoi ⚙️ (codec fallback)
    if not indexer:
        idx_match = re.search(r'🗂️\s*([^\n📅🏴]+)', raw_title_unquoted)
        if idx_match:
            indexer = idx_match.group(1).strip()
    if not indexer:
        spy_match = re.search(r'🔍\s*([^\n]+)', raw_title_unquoted)
        if spy_match:
            indexer = spy_match.group(1).strip()
    if not indexer:
        link_match = re.search(r'🔗\s*(.*)', raw_title_unquoted)
        if link_match:
            indexer = link_match.group(1).strip()
            if provider_id == 'meteor':
                indexer = indexer.split(',')[0].strip()
    if not indexer and provider_id not in ('torz', 'meteor'):
        gear_match = re.search(r'⚙️\s*([^\n💾]+)', raw_title_unquoted)
        if gear_match:
            indexer = gear_match.group(1).strip()
    if not indexer and provider_id not in ('torz', 'meteor') and info_line:
        clean = re.sub(r'[\d.,]+\s*(?:GiB|MiB|TiB|KiB|GB|MB|TB)', '', info_line, flags=re.IGNORECASE)
        clean = re.sub(r'(?:👤|👥|S:|P:|Peers:)\s*\d+', '', clean, flags=re.IGNORECASE)
        clean = clean.replace('👤', '').replace('💾', '').replace('⚙️', '').replace('📦', '').replace('🔗', '').strip(' |-,')
        if clean and not is_valid_filename(clean): indexer = clean
    # Emoji/flag cleanup from indexer (EX: 'EXT 🇬🇧 / 🇷🇺 / 🇺🇦' -> 'EXT')
    if indexer:
        indexer = re.sub(r'[\U0001F000-\U0001FFFF\u2600-\u27BF\uFE0F]', '', indexer)
        indexer = re.sub(r'^[\s/]+|[\s/]+$', '', indexer)
    # Garbage validation: none, emoji, codec terms, GB/MB
    if indexer and (indexer.lower() == 'none' or re.search(r'[🗂️⚙️💾📅🏴]', indexer)):
        indexer = ''
            
    # 6. Calitate
    quality = _extract_quality_from_string(raw_name)
    if not quality or quality == 'SD':
        quality = _extract_quality_from_string(filename) or 'SD'
        
    release_group = _extract_release_group(filename)
    if provider_id == 'meteor':
        try:
            _bg_parts = str(s.get('behaviorHints', {}).get('bingeGroup', '')).split('|')
            if len(_bg_parts) >= 2 and _bg_parts[1] == 'library':
                is_cached = True
            elif not release_group and len(_bg_parts) >= 4:
                _bg_cand = _bg_parts[3].strip()
                if re.match(r'^[A-Za-z0-9_]{2,15}$', _bg_cand) and re.search(r'[A-Za-z]', _bg_cand) and _bg_cand.lower() not in ('web', 'webdl', 'webrip', 'bluray', 'hdtv', 'remux', 'e', '2160p', '1080p', '720p', '480p', '4k'):
                    release_group = _bg_cand
        except:
            pass
    stream_obj = {
        'name': filename, 
        'url': url if url.startswith('magnet:') else (url if '|' in url else f"{url}|{_AIO_UA_HEADERS}"),
        'quality': quality,
        'title': filename, 
        'size': size,
        'source_provider': addon_name,
        'server': indexer,
        'provider_id': provider_id,
        'info': {
            'debrid_service': debrid_service,
            'is_cached': is_cached,
            'addon': addon_name,
            'provider': addon_name,
            'indexer': indexer,
            'seeders': seeders,
            'releaseGroup': release_group,
            'quality': quality,
        }
    }
    return stream_obj


def scrape_stremio_addon(imdb_id, content_type, season, episode, addon_id, addon_name):
    """Scraper universal pentru Torrentio/Comet/Mediafusion etc. cu Instante Multiple"""
    if ADDON.getSetting(f'use_{addon_id}') == 'false':
        return None

    # 1. Aflam indexul instantei selectate (0, 1, 2...)
    try:
        instance_idx = int(ADDON.getSetting(f'{addon_id}_instance') or '0')
    except:
        instance_idx = 0

    # 2. Citim URL-ul manifestului corespunzator acelei instante
    # Formatul este: idaddon_manifest.0, idaddon_manifest.1 etc.
    manifest_url = ADDON.getSetting(f'{addon_id}_manifest.{instance_idx}').strip()

    if not manifest_url:
        log(f"[{addon_name.upper()}] URL manifest.json lipseste pentru instanta {instance_idx}!")
        return None
        
    # Restul codului ramane identic...
    base_url = manifest_url.split('/manifest.json')[0].rstrip('/')
    
    try:
        if content_type == 'movie': api_url = f"{base_url}/stream/movie/{imdb_id}.json"
        else: api_url = f"{base_url}/stream/series/{imdb_id}:{season}:{episode}.json"
            
        r = get_shared_session().get(api_url, headers=get_headers(), timeout=15, verify=False)
        if r.status_code == 200:
            data = r.json()
            found_streams = []
            for s in data.get('streams', []):
                stream_obj = _parse_stremio_addon_stream(s, addon_name, addon_id)
                if stream_obj: found_streams.append(stream_obj)
            log(f"[{addon_name.upper()}] Gasite: {len(found_streams)} surse.")
            return found_streams
    except Exception as e:
        log(f"[{addon_name.upper()}] Error: {e}", xbmc.LOGERROR)
        
    return None


# =============================================================================
# AIO STREAMS
# =============================================================================
def scrape_aiostreams(imdb_id, content_type, season=None, episode=None):
    if ADDON.getSetting('use_aiostreams') == 'false':
        return None

    try:
        instance_id = int(ADDON.getSetting('aiostreams_instance') or '0')
    except:
        instance_id = 0

    default_urls =[
        'https://aiostreams.stremio.ru', 'https://aiostreams-nightly.stremio.ru',
        'https://aiostreams.viren070.me', 'https://aiostreams.fortheweak.cloud',
        'https://aiostreams-nightly.fortheweak.cloud', 'https://aiostreamsfortheweebsstable.midnightignite.me',
        'https://aiostreamsfortheweebs.midnightignite.me', 'https://aiostreams.elfhosted.com', ''
    ]

    if instance_id == 8: # Custom
        base_url = (ADDON.getSetting('aio_url.8') or '').strip().rstrip('/')
    else:
        base_url = (ADDON.getSetting(f'aio_url.{instance_id}') or '').strip().rstrip('/')
        if not base_url and instance_id < len(default_urls):
            base_url = default_urls[instance_id]

    aio_uuid = ADDON.getSetting(f'aio_uuid.{instance_id}') or ''
    aio_pass = ADDON.getSetting(f'aio_password.{instance_id}') or ''

    aio_auth = None
    if aio_uuid and aio_pass: aio_auth = (aio_uuid, aio_pass)
    elif aio_uuid: aio_auth = (aio_uuid, '')

    search_link = f"{base_url}/api/v1/search"
    m_type = 'series' if content_type in ('tv', 'show', 'episode') else 'movie'

    # Preluam timeout-ul global din setari pentru a nu taia conexiunea prematur
    try: req_timeout = int(ADDON.getSetting('scraper_timeout'))
    except: req_timeout = 25

    def _fetch(st_id):
        try:
            # Adaugam headere complete (inclusiv User-Agent) pentru a nu fi blocati de Cloudflare
            headers = get_headers()
            headers['Accept'] = 'application/json'
            
            # log(f"[AIO] Cerere API: {search_link} | type: {m_type} | id: {st_id} | timeout: {req_timeout}s")
            
            r = get_shared_session().get(
                search_link, params={'type': m_type, 'id': st_id},
                auth=aio_auth, headers=headers, timeout=req_timeout, verify=False
            )
            if r.status_code == 200: 
                res = r.json().get('data', {}).get('results', [])
                log(f"[AIO] ✓ Success! Am primit {len(res)} surse de la server.")
                return res
            else:
                log(f"[AIO] Error HTTP {r.status_code}: {r.text[:100]}", xbmc.LOGWARNING)
        except Exception as e: 
            log(f"[AIO] Error conexiune: {e}", xbmc.LOGERROR)
        return[]

    streams =[]
    if m_type == 'movie' or not season:
        results = _fetch(str(imdb_id))
    else:
        ep_num = int(episode or 1)
        results = _fetch(f"{imdb_id}:{season}:{ep_num}")

    for item in results:
        try:
            if 'p2p' in str(item.get('type', '')).lower(): continue
            play_url = item.get('url', '')
            if not play_url or not play_url.startswith('http'): continue

            parsed = item.get('parsedFile', {})
            bh = item.get('behaviorHints', {})
            
            full_title_raw = str(item.get('title', ''))
            title = str(item.get('filename') or bh.get('filename') or parsed.get('filename') or '').strip()
            if not title or len(title) < 5:
                title = full_title_raw.split('\n')[0].strip()

            if re.search(r'(?i)\b(trailer|sample|cam|camrip|hdts|hdtc|ts|telesync)\b', title):
                continue
                
            # BLOCARE FISIERE GUNOI / MALWARE / NON-VIDEO / AUDIO
            bad_extensions = [
                '.iso', '.zip', '.rar', '.7z', '.tar', '.gz', '.zipx', '.arj',
                '.txt', '.nfo', '.jpg', '.png', '.pdf',
                '.exe', '.bat', '.cmd', '.scr', '.msi', '.ps1', '.vbs', '.js', '.jar', '.com', '.pif', '.reg', '.dll', '.sys', '.lnk',
                '.mp3', '.wav', '.flac', '.m4a', '.aac', '.ogg', '.wma', '.ape', '.alac'
            ]
            title_lower = title.lower()
            if any(title_lower.endswith(ext) for ext in bad_extensions) or any(f"{ext} " in title_lower for ext in bad_extensions):
                continue

            # FILTRU WEB (Optional din setari) - DOAR PENTRU RD
            try:
                if ADDON.getSetting('filter_web_sources') == 'true':
                    # Extragem service-ul mai devreme pentru a filtra doar RD
                    aio_service = str(item.get('service', '')).strip().lower()
                    if aio_service == 'realdebrid' or aio_service == 'rd':
                        if _is_web_source(title) or _is_web_source(full_title_raw):
                            # log(f"[FILTER-WEB] Excluding WEB RD AIO source: {title[:50]}...")
                            continue
            except:
                pass

            res_tag = "SD"
            check_text = (str(parsed.get('resolution', '')) + ' ' + full_title_raw + ' ' + title).upper()
            
            # --- FIX: Multi-rezolutie si izolare grupuri (inclusiv 4KHDHUB) ---
            clean_text = check_text.replace('DS4K', '').replace('4KDS', '').replace('SDR4K', '').replace('HDR4K', '').replace('4KHDHUB', '')
            
            res_count = sum(1 for r in ['2160P', '1080P', '720P', '480P', '360P'] if r in check_text)
            if '4K' in clean_text and '2160P' not in check_text: res_count += 1
            
            if res_count >= 2: res_tag = 'SD'
            elif any(x in check_text for x in['720P', '720I']): res_tag = '720p'
            elif any(x in check_text for x in ['1080P', '1080I', 'FHD']): res_tag = '1080p'
            elif any(x in check_text for x in['2160P', '2160', 'UHD']) or '4K' in clean_text: res_tag = '4K'
            else: res_tag = 'SD'

            size_bytes = item.get('size') or bh.get('videoSize') or 0
            size_str = ""
            if size_bytes:
                try:
                    size_bytes = float(size_bytes)
                    for factor, suffix in[(1024**4, ' TB'), (1024**3, ' GB'), (1024**2, ' MB'), (1024**1, ' KB'), (1024**0, ' B')]:
                        if size_bytes >= factor: 
                            size_str = f"{round(size_bytes / factor, 2)}{suffix}"
                            break
                except: pass

            # --- EXTRAGERE PUTERNICA SEEDERI (Fallback din titlu) ---
            seeders = 0
            try:
                s_val = item.get('seeders')
                if s_val:
                    seeders = int(s_val)
                else:
                    m_seeds = re.search(
                        r'(?:👤|👥|S:)\s*(\d+)',
                        full_title_raw + str(item.get('description', '')),
                        re.IGNORECASE)
                    if m_seeds:
                        seeders = int(m_seeds.group(1))
            except: pass

            # --- Extragere service ---
            debrid_service = str(item.get('service', '')).strip()
            
            # Anihilam valoarea literala "None" de pe server
            if debrid_service.lower() == 'none':
                debrid_service = ''
            # "aiostreams" e numele providerului, nu un debrid service real
            if debrid_service.lower() == 'aiostreams':
                debrid_service = ''
                
            is_cached = bool(item.get('cached', False))
            is_cloud = 'cloud' in str(item.get('indexer', '')).lower() or 'cloud' in str(item.get('type', '')).lower()
            source_addon = str(item.get('addon') or item.get('provider') or parsed.get('source') or '').strip()
            # Indexer — prioritate 1: decodeaza `t` din URL (cel mai autoritar, suprascrie AIO)
            indexer = ''
            if '?t=' in play_url:
                try:
                    import base64, json as _json
                    _t = play_url.split('?t=')[1].split('|')[0].split('&')[0]
                    _t = _t + '=='
                    _decoded = _json.loads(base64.urlsafe_b64decode(_t).decode('utf-8'))
                    _t_idxer = str(_decoded.get('indexer', '')).strip()
                except:
                    _t_idxer = ''
                if _t_idxer:
                    indexer = _t_idxer
            # Prioritate 2: din AIO server
            if not indexer:
                indexer = str(item.get('indexer', '')).strip()
            # Garbage validation: none, emoji, GB/MB
            if indexer and (indexer.lower() == 'none' or re.search(r'[🗂️⚙️💾📅🏴]', indexer) or re.search(r'\d+(\.\d+)?\s*(GB|MB|TB)', indexer, re.I)):
                indexer = ''
            # Prioritate 3: din titlu (🗂️ altHUB)
            if not indexer:
                _idx_m = re.search(r'🗂️\s*([^\n📅🏴]+)', full_title_raw)
                if _idx_m:
                    indexer = _idx_m.group(1).strip()
            # Fallback 3: extrage addonul din description dupa ⛉
            if not source_addon:
                _a_m = re.search(r'⛉\s*([^·\n]+)', str(item.get('description', '')))
                if _a_m:
                    source_addon = _a_m.group(1).strip()
            
            # --- Extragere Release Group ---
            release_group = str(item.get('releaseGroup') or parsed.get('releaseGroup') or '').strip()
            # Fallback inteligent din nume daca serverul nu ne da grupul
            if not release_group:
                release_group = _extract_release_group(title)
            
            streams.append({
                'name': title,
                'url': play_url if '|' in play_url else f"{play_url}|{_AIO_UA_HEADERS}",
                'quality': res_tag,
                'title': title,
                'size': size_str,
                'source_provider': source_addon,
                'server': indexer,
                'provider_id': 'aiostreams',
                'info': {
                    'debrid_service': debrid_service,
                    'is_cached': is_cached,
                    'is_cloud': is_cloud,
                    'addon': source_addon,
                    'indexer': indexer,
                    'seeders': seeders,
                    'releaseGroup': release_group,
                    'quality': res_tag,
                }
            })
        except: continue
    return streams


def scrape_torrentio(imdb_id, content_type, season=None, episode=None):
    if ADDON.getSetting('use_torrentio') == 'false':
        return None

    manifest_url = ADDON.getSetting('torrentio_manifest').strip()
    if not manifest_url:
        log("[TORRENTIO] Lipseste URL manifest.json din setari!")
        return None

    # Extragem baza URL-ului (tot ce e inainte de /manifest.json)
    base_url = manifest_url.split('/manifest.json')[0].rstrip('/')

    try:
        if content_type == 'movie':
            api_url = f"{base_url}/stream/movie/{imdb_id}.json"
        else:
            api_url = f"{base_url}/stream/series/{imdb_id}:{season}:{episode}.json"

        # log(f"[TORRENTIO] Caut pe: {api_url[:80]}...")
        r = get_shared_session().get(api_url, headers=get_headers(), timeout=15, verify=False)
        
        if r.status_code == 200:
            data = r.json()
            found_streams = []
            
            for s in data.get('streams', []):
                url = s.get('url')
                if not url: continue
                
                raw_name = s.get('name', '')
                raw_title = s.get('title', '')
                
                # FILTRU WEB (Optional din setari) - DOAR PENTRU RD
                try:
                    if ADDON.getSetting('filter_web_sources') == 'true':
                        name_up = raw_name.upper()
                        if '[RD+]' in name_up or '[RD]' in name_up:
                            if _is_web_source(raw_name) or _is_web_source(raw_title):
                                continue
                except:
                    pass

                name_upper = raw_name.upper()
                
                # 1. Detectare Debrid / Cached (Pentru a aparea RD+ in stanga)
                is_cached = False
                debrid_service = ""
                
                if '[RD+]' in name_upper: is_cached = True; debrid_service = 'realdebrid'
                elif '[AD+]' in name_upper: is_cached = True; debrid_service = 'alldebrid'
                elif '[PM+]' in name_upper: is_cached = True; debrid_service = 'premiumize'
                elif '[TB+]' in name_upper: is_cached = True; debrid_service = 'torbox'
                elif '[EN+]' in name_upper or '[EN]' in name_upper: is_cached = True; debrid_service = 'easynews'
                
                # 2. Extragere Marime si Seederi
                size_match = re.search(r'([\d.]+\s*(?:GB|MB|TB))', raw_title, re.IGNORECASE)
                size = size_match.group(1).upper() if size_match else ""
                
                seeders = 0
                seed_match = re.search(r'(?:👤|👥|S:)\s*(\d+)', raw_title)
                if seed_match: seeders = int(seed_match.group(1))

                # 3. Extragere Nume Fisier REAL (pt Subtitrari si UI linia 1) si Indexer
                lines = raw_title.split('\n')
                filename = lines[-1].strip() if lines else raw_title
                
                indexer = ""
                if len(lines) > 1:
                    # Curatam prima linie de emoji-uri si marimi pentru a pastra doar numele site-ului
                    first_line = lines[0].replace('👤', '').replace('💾', '').replace('⚙️', '').replace('☁️', '')
                    first_line = re.sub(r'[\d.]+\s*(?:GB|MB|TB)', '', first_line, flags=re.IGNORECASE)
                    first_line = re.sub(r'\d+', '', first_line).strip(' |-,')
                    indexer = first_line

                # Fallback in caz ca numele fisierului extras e prea scurt
                if len(filename) < 5:
                    filename = raw_title.replace('\n', ' ')

                # 4. Calitate
                quality = _extract_quality_from_string(raw_name) 
                if not quality or quality == 'SD':
                    quality = _extract_quality_from_string(filename) or 'SD'
                
                stream_obj = {
                    'name': filename,  # Linia 1 in UI
                    'url': url if '|' in url else f"{url}|{_AIO_UA_HEADERS}",
                    'quality': quality,
                    'title': filename, # Saved here to be found by Wyzie (Subtitles)
                    'size': size,
                    'source_provider': 'Torrentio',
                    'server': indexer,
                    'provider_id': 'torrentio',
                    'info': {
                        'debrid_service': debrid_service,
                        'is_cached': is_cached,
                        'addon': 'Torrentio',
                        'indexer': indexer,
                        'seeders': seeders,
            'releaseGroup': release_group,
                        'quality': quality,
                    }
                }
                found_streams.append(stream_obj)

            log(f"[TORRENTIO] Found: {len(found_streams)} sources.")
            return found_streams
    except Exception as e:
        log(f"[TORRENTIO] Error: {e}", xbmc.LOGERROR)

    return None


# =============================================================================
# =============================================================================
# SCRAPER PRIMESRC.ME ([PSM])
# =============================================================================
THRAX_KEY = "7d9f4987bcd1a2026e6a422931bd7dbff0060977d189f37fa5727d9288b4abbb"
THRAX_HEADERS = {"X-Thrax-Key": THRAX_KEY}



def scrape_primesrcme(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_primesrcme') == 'false':
        return None

    tmdb_id = _get_tmdb_id_internal(imdb_id)
    if not tmdb_id:
        return None

    _BASE        = 'https://primesrc.me'
    _UA          = 'Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0'
    _HEADERS     = {
        'User-Agent': _UA,
        'Referer':    f'{_BASE}/',
        'Accept':     'application/json',
    }

    def _get_servers(media_type, tmdb_id, season=None, episode=None):
        params = {'type': media_type, 'tmdb': tmdb_id}
        if season is not None:
            params['season'] = season
        if episode is not None:
            params['episode'] = episode
        try:
            r = requests.get(f'{_BASE}/api/v1/s', params=params, headers=_HEADERS, timeout=10)
            if r.ok:
                return r.json().get('servers', [])
            if r.status_code == 403 and 'cloudflare' in r.text.lower():
                log(f'[PRIMESRC] /api/v1/s blocat Cloudflare pentru tmdb={tmdb_id}', xbmc.LOGWARNING)
            else:
                log(f'[PRIMESRC] /api/v1/s status={r.status_code}', xbmc.LOGWARNING)
        except Exception as e:
            log(f'[PRIMESRC] get_servers: {e}', xbmc.LOGWARNING)
        return []

    try:
        servers = _get_servers(content_type, tmdb_id, season, episode)
        if not servers:
            log(f'[PRIMESRC] niciun server pentru tmdb={tmdb_id}', xbmc.LOGWARNING)
            return []

        sources = []
        seen    = set()

        for srv in servers:
            key  = srv.get('key', '')
            name = srv.get('name', '')
            if not key:
                continue
            api_url = f'{_BASE}/api/v1/l?key={key}'
            if api_url in seen:
                continue
            seen.add(api_url)

            size       = srv.get('file_size') or ''
            quality    = srv.get('quality') or '1080p'
            audio_type = srv.get('audio_type') or ''
            audio_lang = srv.get('audio_language') or ''

            display_title = f"{title_query} ({year_query})" if title_query else name

            # Construim tmdb_id pentru Thrax caching
            if content_type == 'movie':
                tmdb_id_str = f"{tmdb_id}:movie"
            else:
                tmdb_id_str = f"{tmdb_id}:tv:{season}:{episode}"

            sources.append({
                'url':        api_url,
                'name':       display_title,
                'quality':    quality,
                'title':      '',
                'tmdb_id':    tmdb_id_str,
                'info': {
                    'original_info_str': f'PrimeSrc | {name}',
                    'provider': 'PrimeSrc',
                    'source_provider': f'| {name}',
                    'size': size
                },
                'source_provider': f'| {name}',
                'provider_id': 'primesrcme',
            })

        log(f'[PRIMESRC] {len(sources)} surse pentru tmdb={tmdb_id}', xbmc.LOGINFO)
        return sources

    except Exception as e:
        log(f'[PRIMESRC] eroare: {e}', xbmc.LOGERROR)
        return []


def resolve_primesrcme(url, tmdb_id=None):
    """Extrage key-ul din URL si il rezolva prin Thrax API (FlareSolverr server-side).
    If tmdb_id is specified, it is passed to Thrax for automatic caching."""
    from urllib.parse import urlparse, parse_qs
    _THRAX = 'https://api.derzis.xyz'
    
    qs = parse_qs(urlparse(url).query)
    key = (qs.get('key') or [''])[0]
    if not key:
        log(f'[PRIMESRC] resolve_primesrcme: key lipsa din {url}', xbmc.LOGWARNING)
        return None
    try:
        params = {'key': key}
        if tmdb_id:
            params['tmdb_id'] = tmdb_id
        r = requests.get(f'{_THRAX}/primesrcme/resolve', params=params, timeout=90,
                         headers={**THRAX_HEADERS, 'Accept-Encoding': 'gzip, deflate'})
        if not r.ok:
            log(f'[PRIMESRC] Thrax /primesrcme/resolve HTTP {r.status_code}', xbmc.LOGWARNING)
            return None
        data = r.json()
        link = data.get('link', '')
        if not link:
            log(f'[PRIMESRC] Thrax: campul link lipsa: {data}', xbmc.LOGWARNING)
            return None
        
        return link
    except Exception as e:
        log(f'[PRIMESRC] resolve_primesrcme eroare: {e}', xbmc.LOGWARNING)
        return None


# =============================================================================
# HELPER PENTRU ID-URI TMDB
# =============================================================================
def _get_tmdb_id_internal(id_str):
    if not id_str: return None
    id_str = str(id_str)
    if id_str.startswith('tmdb:'):
        return id_str.replace('tmdb:', '')
    if id_str.startswith('tt'):
        try:
            url = f"{BASE_URL}/find/{id_str}?api_key={API_KEY}&external_source=imdb_id"
            data = get_json(url)
            # Prioritate pentru tv_episode_results (luam show_id)
            if data.get('tv_episode_results'):
                return str(data['tv_episode_results'][0].get('show_id'))
            results = data.get('movie_results', []) or data.get('tv_results', [])
            if results:
                return str(results[0]['id'])
        except: pass
    return id_str

# =============================================================================
# SCRAPER VAPLAYER (VAPlayer.ru)
# =============================================================================
def scrape_vaplayer(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_vaplayer') == 'false':
        return None
        
    try:
        api_url = "https://streamdata.vaplayer.ru/api.php"
        params = {
            "imdb": imdb_id,
            "type": "movie" if content_type == 'movie' else 'tv'
        }
        if content_type == 'tv':
            params['season'] = season
            params['episode'] = episode

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Referer": "https://nextgencloudfabric.com/",
            "Origin": "https://nextgencloudfabric.com",
            "Accept": "*/*",
            "Accept-Language": "ro-RO,ro-GB;q=0.9,en;q=0.8"
        }
        
        session = get_shared_session()
        resp = session.get(api_url, params=params, headers=headers, timeout=10, verify=False)
        if resp.status_code != 200:
            return None
            
        data = resp.json()
        if not data or data.get('status_code') != '200':
            return None
            
        inner_data = data.get('data', {})
        # Luam doar prima parte din file_name (inainte de slash)
        file_name = inner_data.get('file_name', '')
        if '/' in file_name:
            file_name = file_name.split('/')[0].strip()
        
        release_title = file_name or inner_data.get('title') or title_query or "VAPlayer"
        streams = inner_data.get('stream_urls', [])
        
        if not streams:
            return None
        
        # Curatam titlul de tag-uri de calitate pentru a evita detectia gresita in player.py
        clean_release_title = re.sub(r'(?i)\b(2160p|1080p|720p|480p|360p|4k|sd|uhd|hd)\b', '', release_title)
        # Curatam doar parantezele drepte, pastrand continutul (pentru ca tag-urile sa fie inca detectate)
        clean_release_title = clean_release_title.replace('[', '').replace(']', '')
        clean_release_title = re.sub(r'\s+', ' ', clean_release_title).strip()

        # Detectam o calitate de baza din titlul original pentru fallback
        base_quality = '1080p'
        if '2160' in release_title or '4K' in release_title: base_quality = '4K'
        elif '1080' in release_title: base_quality = '1080p'
        elif '720' in release_title: base_quality = '720p'
        elif '480' in release_title or 'SD' in release_title: base_quality = 'SD'

        # Extragem release group (de obicei dupa ultimul crampei de dupa cratima, ignorand extensia)
        temp_title = re.sub(r'\.(mkv|mp4|avi|mov|ts|m3u8)$', '', release_title, flags=re.I)
        release_group = ""
        group_match = re.search(r'-([A-Za-z0-9]+)$', temp_title)
        if group_match:
            release_group = group_match.group(1)
        
        # Daca nu am gasit cu cratima, incercam sa vedem daca e in paranteze patrate la final
        if not release_group:
            group_match = re.search(r'\[([A-Za-z0-9.]+)\]$', temp_title)
            if group_match:
                release_group = group_match.group(1)

        results = []
        for master_url in streams:
            # Parserul m3u8 acum foloseste doar User-Agent simplu (ca in scriptul tau)
            variants = _parse_m3u8_variants(master_url)
            
            if not variants:
                # Daca nu putem parsa variantele, adaugam master-ul cu calitatea detectata din titlu
                results.append({
                    'name': f'VAPlayer | {base_quality} | {clean_release_title}',
                    'url': build_stream_url(master_url, referer="https://nextgencloudfabric.com/"),
                    'quality': base_quality,
                    'title': clean_release_title,
                    'info': {
                        'original_info_str': 'VAPlayer',
                        'provider': 'VAPlayer',
                        'source_provider': '',
                        'releaseGroup': release_group,
                        'size': ''
                    },
                    'source_provider': '',
                    'provider_id': 'vaplayer'
                })
                continue
                
            for v in variants:
                raw_res = v['resolution']
                # Normalizare rezolutie mai permisiva (pentru formate ultra-wide etc.)
                if any(x in raw_res for x in ['2160', '3840', '4K', '4k']):
                    quality = '4K'
                elif any(x in raw_res for x in ['1080', '1920']):
                    quality = '1080p'
                elif any(x in raw_res for x in ['720', '1280']):
                    quality = '720p'
                else:
                    quality = 'SD'
                    
                results.append({
                    'name': f"VAPlayer | {quality} | {clean_release_title}",
                    'url': build_stream_url(v['url'], referer="https://nextgencloudfabric.com/"),
                    'quality': quality,
                    'title': clean_release_title,
                    'info': {
                        'original_info_str': 'VAPlayer',
                        'provider': 'VAPlayer',
                        'source_provider': '',
                        'releaseGroup': release_group,
                        'size': ''
                    },
                    'source_provider': '',
                    'provider_id': 'vaplayer'
                })
                
        return results
    except Exception as e:
        log(f"[VAPLAYER] Error: {e}")
        return None


# =============================================================================
# SCRAPER FLIXER (MULTI-SERVER FIXED - KODI HLS BYPASS + TV SHOWS)
# =============================================================================
def scrape_flixer(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_flixer') == 'false': return None
    tmdb_id = _get_tmdb_id_internal(imdb_id)
    if not tmdb_id: return None
    
    from urllib.parse import quote
    
    try:
        session = get_shared_session()
        _UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0'
        headers = {
            'User-Agent': _UA,
            'Referer': 'https://movie-scraper-theta-11.vercel.app/',
            'Origin': 'https://movie-scraper-theta-11.vercel.app'
        }
        
        flixer_type = 'tv' if content_type in ('tv', 'show', 'episode', 'tvshow') else 'movie'
        streams = []
        
        display_title = title_query if title_query else "Flixer Stream"
        if year_query and flixer_type == 'movie': display_title += f" ({year_query})"
        if flixer_type == 'tv' and season and episode: display_title += f" S{int(season):02d}E{int(episode):02d}"
        
        # --- PARTEA 1: Vynx API (currently broken - missing WASM + API key) ---
        try:
            health = session.get("https://media-proxy.vynx-3b3.workers.dev/flixer/health", timeout=5, verify=False)
            if health.status_code == 200:
                h_data = health.json()
                if h_data.get('wasmLoaded') and h_data.get('hasApiKey'):
                    url = f"https://media-proxy.vynx-3b3.workers.dev/flixer/extract?tmdbId={tmdb_id}&type={flixer_type}"
                    if flixer_type == 'tv' and season and episode:
                        url += f"&season={int(season)}&episode={int(episode)}"
                    r = session.get(url, headers=headers, timeout=10, verify=False)
                    if r.status_code == 200:
                        data = r.json()
                        if data.get('success') and data.get('sources'):
                            for source in data['sources']:
                                source_url = source.get('url')
                                if not source_url: continue
                                referer = source.get('referer', 'https://hexa.su/')
                                stream_referer = referer if referer else "https://hexa.su/"
                                source_type = source.get('type', 'hls')
                                if source_type == 'hls' or '.m3u8' in source_url:
                                    custom_headers = {'Referer': stream_referer, 'User-Agent': _UA, 'Origin': 'https://hexa.su'}
                                    variants = _parse_m3u8_variants(source_url, custom_headers=custom_headers)
                                    if variants:
                                        for var in variants:
                                            res_val = var.get('resolution', 'UNKNOWN')
                                            quality = _get_quality_from_res(res_val)
                                            var_kodi_url = f"{var['url']}|User-Agent={quote(_UA)}&Referer={quote(stream_referer)}&Origin=https://hexa.su&Connection=keep-alive"
                                            streams.append({
                                                'name': f"Flixer | {source.get('server', 'Auto')} ({res_val})",
                                                'url': var_kodi_url,
                                                'quality': quality,
                                                'title': display_title,
                                                'size': '',
                                                'info': f"{source.get('server', 'Auto')} | {res_val}",
                                                'provider_id': 'flixer'
                                            })
                                        continue
                                quality = '1080p' if source.get('quality') == '1080p' else '720p' if source.get('quality') == '720p' else 'SD'
                                if source.get('quality') == 'auto': quality = '1080p'
                                kodi_url = f"{source_url}|User-Agent={quote(_UA)}&Referer={quote(stream_referer)}&Origin=https://hexa.su&Connection=keep-alive"
                                streams.append({
                                    'name': f"Flixer | {source.get('server', 'Auto')}",
                                    'url': kodi_url,
                                    'quality': quality,
                                    'title': display_title,
                                    'size': '',
                                    'info': source.get('server', 'Auto'),
                                    'provider_id': 'flixer'
                                })
        except Exception as e:
            log(f"[FLIXER-VYNX] API broken (missing WASM/key), skipping: {e}")

        # --- PARTEA 2: VideoDB (filme + seriale) ---
        # Pagina embed poate contine:
        #   A) <iframe> cu URL player VideoDB (filme noi cu HLS)
        #   B) Playerjs inline cu date JSON (filme vechi cu MP4 direct)
        # Ambele cazuri: API-ul videodb.stream/file/play functioneaza.
        # HLS necesita iframe_url ca Referer, MP4 functioneaza si fara.
        try:
            if flixer_type == 'movie':
                vdb_embed = f"https://videodb.cloud/embed/player.php?type=movie&id={tmdb_id}"
                api_url = f"https://videodb.stream/file/play?type=movie&id={tmdb_id}&name=slug&lang=ru&p=l.playlist"
            else:
                s_num = int(season)
                e_num = int(episode)
                vdb_embed = f"https://videodb.cloud/embed/splayer.php?type=serial&id={tmdb_id}&season={s_num}&episode={e_num}"
                api_url = f"https://videodb.stream/file/play?type=serial&id={tmdb_id}&name=serial&season={s_num}&episode={e_num}&lang=ru&p=l.playlist"

            # Determinam Referer: din iframe (daca exista) sau generic
            vdb_referer = 'https://videodb.cloud/'
            r_embed = session.get(vdb_embed, headers={'Referer': 'https://www.tenies.site/', 'User-Agent': _UA}, timeout=8, verify=False)
            if r_embed.status_code == 200:
                iframe_match = re.search(r'<iframe[^>]+src=["\'](https://videodb\.stream/[^"\']+)["\']', r_embed.text)
                if iframe_match:
                    vdb_referer = iframe_match.group(1)

            v_headers = {
                'User-Agent': _UA,
                'Referer': vdb_referer,
                'Accept': 'application/json, text/javascript, */*; q=0.01'
            }

            r_api = session.get(api_url, headers=v_headers, timeout=8, verify=False)
            if r_api.status_code == 200:
                v_data = r_api.json()
                target_files = []

                if flixer_type == 'movie':
                    if isinstance(v_data, list) and len(v_data) > 0:
                        f_str = v_data[0].get('file', '')
                        if f_str:
                            if f_str.startswith('['):
                                # Format: [HD]{lang}url;{lang}url;,[SD]{lang}url;{lang}url;
                                for part in f_str.split(','):
                                    part = part.strip()
                                    if not part:
                                        continue
                                    if '[4K]' in part or '[2160p]' in part:
                                        q = '4K'
                                    elif '[HD]' in part or '[1080p]' in part:
                                        q = '1080p'
                                    elif '[SD]' in part or '[480p]' in part:
                                        q = 'SD'
                                    else:
                                        q = '1080p'
                                    url_match = re.search(r'(https?://[^\{\};]+)', part)
                                    if url_match:
                                        target_files.append((url_match.group(1), q))
                            else:
                                # Direct HLS URL (master.txt) sau MP4
                                if f_str.endswith('.mp4'):
                                    target_files.append((f_str, '1080p'))
                                else:
                                    # HLS master — CDN-ul e protejat (403), nu putem accesa
                                    log(f"[FLIXER-VIDEODB] Skipping protected HLS stream (Movie uses VideoDB HLS CDN which returns 403)")
                else:
                    if isinstance(v_data, list):
                        target_id = f"{s_num}-{e_num}"
                        for s_data in v_data:
                            for ep_data in s_data.get('folder', []):
                                if str(ep_data.get('id')) == target_id:
                                    f_str = ep_data.get('file', '')
                                    if f_str:
                                        for part in f_str.split(','):
                                            part = part.strip()
                                            if not part:
                                                continue
                                            if '[4K]' in part or '[2160p]' in part:
                                                q = '4K'
                                            elif '[HD]' in part or '[1080p]' in part:
                                                q = '1080p'
                                            elif '[SD]' in part or '[480p]' in part:
                                                q = 'SD'
                                            else:
                                                q = '1080p'
                                            url_match = re.search(r'(https?://[^\{\};]+)', part)
                                            if url_match:
                                                target_files.append((url_match.group(1), q))
                                    break

                for file_url, q_label in target_files:
                    kodi_vdb_url = f"{file_url}|User-Agent={quote(_UA)}&Referer={quote(vdb_referer)}&Origin=https://videodb.stream&Connection=keep-alive"
                    streams.append({
                        'name': f"Flixer (VideoDB) | {q_label}",
                        'url': kodi_vdb_url,
                        'quality': q_label,
                        'title': display_title,
                        'size': '',
                        'info': f"VideoDB | {q_label}",
                        'provider_id': 'flixer'
                    })
        except Exception as e:
            log(f"[FLIXER-VIDEODB] Error: {e}")

        return streams if streams else None
    except Exception as e:
        log(f"[FLIXER] Fatal Error: {e}")
        return None


# =============================================================================
# SCRAPER CINEFREAK (cinefreak.nl - Direct MKV/MP4 Streams via CineCloud)
# =============================================================================
CINEFREAK_BASE = 'https://cinefreak.nl'
CINECLOUD_BASE = 'https://new5.cinecloud.site'

def _cinefreak_fetch_text(url, timeout=15):
    try:
        hdrs = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
        }
        r = get_shared_session().get(url, headers=hdrs, timeout=timeout, verify=False)
        if r.status_code == 200:
            return r.text
    except: pass
    return None

def _cinefreak_fetch_json(url, timeout=15):
    try:
        text = _cinefreak_fetch_text(url, timeout)
        if text:
            return json.loads(text)
    except: pass
    return None

def _cinefreak_parse_quality(label):
    if not label: return 'HD'
    s = str(label).lower()
    if '2160' in s or '4k' in s: return '4K'
    if '1080' in s: return '1080p'
    if '720' in s: return '720p'
    if '480' in s: return '480p'
    return 'HD'

def _cinefreak_decode_generate_id(encoded):
    try:
        raw = base64.b64decode(encoded).decode('utf-8', errors='replace')
        if raw.endswith('newgo32'):
            raw = raw[:-7]
        return raw
    except: return None

def _cinefreak_extract_fsl_url(html):
    idx = html.find('href="https://pub-')
    if idx == -1: return None
    start = idx + 6
    end = html.find('"', start)
    if end == -1: return None
    url = html[start:end]
    url = url.replace('&amp;', '&')
    return url

def _cinefreak_resolve_fsl(decoded_url):
    if not decoded_url: return None
    hash_part = None
    f_idx = decoded_url.find('/f/')
    x_idx = decoded_url.find('/x/')
    if f_idx >= 0: hash_part = decoded_url[f_idx + 3:]
    elif x_idx >= 0: hash_part = decoded_url[x_idx + 3:]
    if not hash_part: return None
    fsl_url = f'{CINECLOUD_BASE}/f/{hash_part}'
    html = _cinefreak_fetch_text(fsl_url, timeout=10)
    if not html: return None
    return _cinefreak_extract_fsl_url(html)

def _cinefreak_extract_movie_qualities(html):
    if not html: return []
    parts = html.split('dlbtn-container')
    results = []
    for i in range(1, len(parts)):
        prev_part = parts[i - 1]
        current = parts[i]
        m = re.search(r'href="(?:https?://[^"]*?)?/generate\.php\?id=([a-zA-Z0-9+/=]+)"', current)
        if not m: continue
        enc_id = m.group(1)
        dec_url = _cinefreak_decode_generate_id(enc_id)
        if not dec_url or dec_url.find('/f/') == -1: continue
        label = ''
        qm = re.search(r'</span>\s*([^<]*?(?:2160|1080|720|480|4K)[^<]*?)\s*\[', prev_part, re.IGNORECASE)
        if qm: label = qm.group(1).strip()
        if not label:
            qm = re.search(r'\b(?:4K\s*2160p|UHD|2160p|1080p|720p|480p|SD|HD)\b', prev_part, re.IGNORECASE)
            if qm: label = qm.group(0)
        if not label: label = dec_url
        quality = _cinefreak_parse_quality(label)
        dup = False
        for r in results:
            if r['decodedUrl'] == dec_url: dup = True; break
        if dup: continue
        results.append({'encodedId': enc_id, 'decodedUrl': dec_url, 'label': label, 'quality': quality})
    return results

def _cinefreak_extract_episode_qualities(html, episode_num):
    if not html: return []
    cards = html.split('<div class="ep-card"')
    target_html = None
    for card in cards[1:]:
        m = re.search(r'episode-badge[^>]*>Episode\s*(\d+)', card, re.IGNORECASE)
        if m and int(m.group(1)) == episode_num:
            target_html = card
            break
    if not target_html: return []
    links = re.findall(r'<a[^>]*href="(?:https?://[^"]*?)?/generate\.php\?id=([a-zA-Z0-9+/=]+)"[^>]*>([^<]*)</a>', target_html)
    results = []
    for enc_id, link_label in links:
        dec_url = _cinefreak_decode_generate_id(enc_id)
        if not dec_url or dec_url.find('/f/') == -1: continue
        label = link_label.strip()
        quality = _cinefreak_parse_quality(label)
        dup = False
        for r in results:
            if r['decodedUrl'] == dec_url: dup = True; break
        if dup: continue
        results.append({'encodedId': enc_id, 'decodedUrl': dec_url, 'label': label or quality, 'quality': quality})
    return results

def _cinefreak_filter_qualities(qualities):
    filtered = []
    seen_q = set()
    for q in qualities:
        if q['quality'] in ('480p', 'SD'): continue
        if q['quality'] in seen_q: continue
        seen_q.add(q['quality'])
        filtered.append(q)
    priority = {'4K': 0, '1080p': 1, '720p': 2, 'HD': 3}
    filtered.sort(key=lambda x: priority.get(x['quality'], 99))
    return filtered

def _cinefreak_match_result(search_title, search_year, results, target_season=None):
    if not results: return None
    search_lower = str(search_title or '').lower().strip()
    search_year_str = str(search_year or '')

    def score_item(item):
        s = 0
        title = str(item.get('title', '')).lower().strip()
        url = str(item.get('url', ''))
        # titleStartsWith equivalent
        if title.startswith(search_lower) or title.startswith(search_lower + ' ') or ('(' + search_lower + ')') in title:
            s += 10
        # urlContains: count how many significant words from title appear in URL
        words = [w for w in re.sub(r'[^a-z0-9\s]', ' ', search_lower).split() if len(w) > 2]
        if words:
            url_lower = url.lower().replace(' ', '-')
            word_matches = sum(1 for w in words if w in url_lower)
            s += (word_matches / len(words)) * 5
        # wordMatchScore
        if words:
            word_hits = 0
            for w in words:
                if re.search(r'\b' + re.escape(w) + r'\b', title, re.IGNORECASE):
                    word_hits += 1
            s += word_hits / len(words)
        # year in title
        if search_year_str and search_year_str in title:
            s += 3
        return s

    # For TV with season, prefer results mentioning the season
    if target_season:
        season_pattern = rf'(?:season|s)\s*{target_season}\b'
        best = None
        best_score = -1
        for item in results:
            title = str(item.get('title', ''))
            if re.search(season_pattern, title, re.IGNORECASE):
                sc = score_item(item) + 10
                if sc > best_score:
                    best_score = sc
                    best = item
        if best:
            return best

    # Find best match overall
    best = None
    best_score = -1
    for item in results:
        sc = score_item(item)
        if sc > best_score:
            best_score = sc
            best = item
    if best and best_score >= 3:
        return best
    return None

def scrape_cinefreak(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_cinefreak') == 'false':
        return None
    if not title_query:
        return None

    display_title = title_query
    if year_query and content_type == 'movie':
        display_title += f" ({year_query})"
    if content_type == 'tv' and season and episode:
        display_title += f" S{int(season):02d}E{int(episode):02d}"

    # log(f"[CINEFREAK] Searching: {title_query} ({year_query})")

    try:
        # Step 1: Search via WP JSON API
        search_url = f"{CINEFREAK_BASE}/wp-json/wp/v2/search?search={quote(title_query)}&per_page=10"
        results = _cinefreak_fetch_json(search_url)
        if not results:
            log(f"[CINEFREAK] No search results")
            return None

        search_items = []
        for r in results:
            r_title = str(r.get('title', '')).replace('Download ', '', 1).strip()
            r_url = str(r.get('url', ''))
            if not r_title or not r_url: continue
            search_items.append({'id': r.get('id'), 'title': r_title, 'url': r_url})

        if not search_items:
            log(f"[CINEFREAK] No valid search items")
            return None

        # If few results, retry with title + year
        if len(search_items) < 3:
            retry_url = f"{CINEFREAK_BASE}/wp-json/wp/v2/search?search={quote(title_query)} {quote(str(year_query or ''))}&per_page=10"
            retry_results = _cinefreak_fetch_json(retry_url)
            if retry_results:
                for r in retry_results:
                    r_title = str(r.get('title', '')).replace('Download ', '', 1).strip()
                    r_url = str(r.get('url', ''))
                    if not r_title or not r_url: continue
                    dup = any(s['url'] == r_url for s in search_items)
                    if not dup:
                        search_items.append({'id': r.get('id'), 'title': r_title, 'url': r_url})

        # Step 2: Match by title/year
        target_season = int(season) if content_type == 'tv' and season else None
        matched = _cinefreak_match_result(title_query, year_query, search_items, target_season)
        if not matched:
            log(f"[CINEFREAK] No match found for '{title_query}'")
            return None

        log(f"[CINEFREAK] Matched: {matched['title']} -> {matched['url']}")

        # Step 3: Fetch post page
        post_url = matched['url']
        if not post_url.startswith('http'):
            post_url = CINEFREAK_BASE + ('/' if not post_url.startswith('/') else '') + post_url
        html = _cinefreak_fetch_text(post_url)
        if not html:
            log(f"[CINEFREAK] Failed to fetch post page")
            return None

        # Step 4: Extract quality links
        if content_type == 'tv' and episode:
            ep_num = int(episode)
            qualities = _cinefreak_extract_episode_qualities(html, ep_num)
        else:
            qualities = _cinefreak_extract_movie_qualities(html)

        if not qualities:
            log(f"[CINEFREAK] No quality links found")
            return None

        # Step 5: Filter (remove 480p/SD) and sort
        filtered = _cinefreak_filter_qualities(qualities)
        if not filtered:
            log(f"[CINEFREAK] No usable qualities after filtering")
            return None

        log(f"[CINEFREAK] Qualities: {', '.join(q['quality'] for q in filtered)}")

        # Step 6: Resolve each quality's stream URL
        streams = []
        ep_label = ''
        if content_type == 'tv' and season and episode:
            sn = int(season); en = int(episode)
            ep_label = f"S{sn:02d}E{en:02d} "

        for q in filtered:
            final_url = _cinefreak_resolve_fsl(q['decodedUrl'])
            if not final_url:
                log(f"[CINEFREAK] Failed to resolve FSL for {q['quality']}")
                continue
            streams.append({
                'name': 'CineFreak',
                'url': final_url,
                'quality': q['quality'],
                'title': f"{display_title} [{q['quality']}]",
                'size': '',
                'info': f"{q['quality']} | FSL",
                'provider_id': 'cinefreak',
                'custom_headers': {'Referer': f'{CINECLOUD_BASE}/'}
            })

        log(f"[CINEFREAK] Total: {len(streams)} streams")
        return streams if streams else None

    except Exception as e:
        log(f"[CINEFREAK] Error: {e}")
        return None



# =============================================================================
# SCRAPER FSHD (filmeserialehd.net) — HTML + AJAX + HLS multi-server/variant
# =============================================================================
def _fshd_process_server(server_link, server_name, target_url, display_title):
    """Incearca un server FSHD: extrage HLS, parseaza variante. Returneaza lista de streamuri."""
    results = []
    s = get_shared_session()
    try:
        is_vidmoly = 'vidmoly' in server_link.lower() or 'vidmoly' in server_name.lower() or 'byse' in server_link.lower()
        headers = {'User-Agent': get_random_ua(), 'Referer': target_url}

        # Vidmoly: Cookie cf_turnstile_demo_pass ocoleste Cloudflare Turnstile (ResolveURL)
        if is_vidmoly:
            media_m = re.search(r'/(?:embed-|w/|v/|dl/)?([0-9a-zA-Z]+)(?:\.\w+)?$', server_link.rstrip('/'))
            mid = media_m.group(1) if media_m else ''
            if mid:
                headers['Cookie'] = 'cf_turnstile_demo_pass_{0}=1'.format(mid)
            headers['Referer'] = 'https://vidmoly.biz'

        r = s.get(server_link, headers=headers, timeout=20, verify=False)
        html = r.text

        # Vidmoly: extrage doar din <script> tags (dupa AniWorld-Downloader)
        if is_vidmoly:
            scripts = re.findall(r'<script[^>]*>(.*?)</script>', html, re.DOTALL | re.IGNORECASE)
            script_text = '\n'.join(filter(None, scripts))
            # Pattern ResolveURL: sources: [{ file: "..." }]
            m = re.search(r'sources\s*:\s*\[\s*\{\s*file\s*:\s*[\'"]([^\'"]+)', script_text, re.I)
            if not m:
                m = re.search(r'file\s*:\s*[\'"]([^\'"]+?\.m3u8[^\'"]*)[\'"]', script_text, re.I)
            if not m:
                m = re.search(r'file\s*:\s*[\'"]([^\'"]+)[\'"]', script_text, re.I)
            master_url = m.group(1) if m else None
            if master_url:
                master_url = master_url.strip()
        else:
            # Variabile JS posibile: var HLS, var videoUrl, var source, player.src
            master_url = None
            for pattern in [
                r'var\s+HLS\s*=\s*"([^"]+)"',
                r"var\s+HLS\s*=\s*'([^']+)'",
                r'var\s+hls\s*=\s*"([^"]+)"',
                r'source["\']*\s*:\s*["\']([^"\']+\.m3u8[^"\']*)["\']',
                r'src["\']*\s*:\s*["\']([^"\']+\.m3u8[^"\']*)["\']',
                r'file["\']*\s*:\s*["\']([^"\']+master\.m3u8[^"\']*)["\']',
                r'file["\']*\s*:\s*["\']([^"\']+playlist\.m3u8[^"\']*)["\']',
            ]:
                m = re.search(pattern, html, re.I)
                if m:
                    master_url = m.group(1)
                    break

        if not master_url:
            log(f"[FSHDNET] No HLS found in {server_name} page")
            return results

        # Incearca variante multiple din master m3u8
        try:
            variants = _parse_m3u8_variants(master_url, custom_headers={
                'User-Agent': get_random_ua(), 'Referer': server_link
            })
            if variants:
                for v in variants:
                    v_res = v.get("resolution", "UNKNOWN")
                    q_label = _get_quality_from_res(v_res)
                    results.append({
                        'name': f"FSHD | {server_name} | {v_res}",
                        'url': build_stream_url(v['url'], referer=server_link),
                        'quality': q_label,
                        'title': display_title,
                        'size': '',
                        'info': f'HLS {v_res}',
                        'provider_id': 'fshdnet'
                    })
                return results
        except:
            pass

        # Fallback: un singur stream
        quality = '1080p'
        if '2160' in master_url or '4k' in master_url.lower(): quality = '4K'
        elif '1080' in master_url: quality = '1080p'
        elif '720' in master_url: quality = '720p'
        results.append({
            'name': f"FSHD | {server_name}",
            'url': build_stream_url(master_url, referer=server_link),
            'quality': quality,
            'title': display_title,
            'size': '',
            'info': 'HLS Stream',
            'provider_id': 'fshdnet'
        })
    except Exception as e:
        log(f"[FSHDNET] Server {server_name} failed: {e}")
    return results


def scrape_fshdnet(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    if ADDON.getSetting('use_fshdnet') == 'false': return None
    if not title_query: return None
    if content_type == 'tv' and (season is None or episode is None): return None

    base_url = "https://filmeserialehd.net"
    s = get_shared_session()

    display_title = title_query
    if year_query and content_type == 'movie': display_title += f" ({year_query})"
    if content_type == 'tv' and season and episode: display_title += f" S{int(season):02d}E{int(episode):02d}"

    bad_qualities = ['cam', 'camrip', 'hdts', 'hdtc', 'ts', 'telesync', 'telecine', 'trailer', 'sample']

    try:
        # 1. CAUTARE
        r = s.get(f"{base_url}/search?keyword={quote(title_query)}", headers=get_headers(), timeout=15, verify=False)
        html = r.text

        path_prefix = 'vezi-filmul' if content_type == 'movie' else 'vezi-serialul'
        series_slug = None
        target_url = None

        chunks = html.split('<div class="flw-item">')
        for chunk in chunks[1:]:
            type_m = re.search(r'fdi-type">([^<]+)', chunk)
            item_type = type_m.group(1).strip().lower() if type_m else ''
            if content_type == 'movie' and 'serial' in item_type: continue
            if content_type == 'tv' and 'film' in item_type: continue

            title_m = re.search(r'<h3 class="film-name">.*?<a[^>]*>([^<]+)</a>', chunk, re.DOTALL)
            if not title_m: continue
            item_title = title_m.group(1).strip()

            qual_m = re.search(r'film-poster-quality">([^<]+)', chunk)
            if qual_m:
                q = qual_m.group(1).strip().lower()
                if any(bad in q for bad in bad_qualities): continue

            year_m = re.search(r'<span class="fdi-item">(\d{4})</span>', chunk)
            item_year = year_m.group(1) if year_m else ''

            link_m = re.search(r'href="([^"]*' + path_prefix + r'/([^"\']+))"', chunk)
            if not link_m: continue

            if title_query.lower() in item_title.lower():
                full_path = link_m.group(1)
                slug = link_m.group(2).rstrip('/')
                if year_query and str(year_query) == item_year:
                    series_slug = slug
                    break
                if not series_slug:
                    series_slug = slug

        if not series_slug: return None

        if content_type == 'movie':
            target_url = f"{base_url}/vezi-filmul/{series_slug}/"
        else:
            target_url = f"{base_url}/vezi-episodul/{series_slug}/s{int(season):02d}-e{int(episode):02d}/"

        # 2. PAGINA DETALIU (movie) / EPISOD (tv)
        r = s.get(target_url, headers=get_headers(), timeout=15, verify=False)
        page_html = r.text

        # Token extraction: #main-wrapper (movies) or #series-player (tv)
        token_m = re.search(r'<div[^>]*data-token="([^"]+)"', page_html)
        if not token_m: return None
        token = token_m.group(1)

        # 3. AJAX → SERVERE (try players_show first for TV, fallback players)
        ajax_fields = ['players_show', 'players'] if content_type == 'tv' else ['players']
        ajax_headers = {'User-Agent': get_random_ua(), 'Referer': target_url, 'X-Requested-With': 'XMLHttpRequest'}
        servers = []
        for field in ajax_fields:
            r_ajax = s.post(f"{base_url}/ajax/ajax.php", data={field: token}, headers=ajax_headers, timeout=15, verify=False)
            try:
                result = r_ajax.json()
                if isinstance(result, list) and result:
                    servers.extend(result)
            except:
                pass
        if not servers: return None

        streams = []
        for server in servers:
            server_link = server.get('link', '')
            server_name = server.get('name', 'Megacloud')
            if not server_link: continue
            results = _fshd_process_server(server_link, server_name, target_url, display_title)
            streams.extend(results)

        return streams if streams else None
    except Exception as e:
        log(f"[FSHDNET] Error: {e}")
        return None


# =============================================================================
# MAIN ORCHESTRATION FUNCTION (PARALLEL / MULTITHREADING)
# =============================================================================


# =============================================================================
# SCRAPER TORRENTIO P2P (Magnet links via Torrentio, no debrid)
# =============================================================================
def scrape_p2p_torrentio(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    xbmc.log("[TMDb Movies] [P2P Torrentio] called: imdb_id=%s content_type=%s" % (imdb_id, content_type), xbmc.LOGERROR)
    if ADDON.getSetting('use_p2p_torrentio') == 'false':
        return None

    custom_manifest = ADDON.getSetting('p2p_torrentio_manifest').strip()
    if custom_manifest:
        base_url = custom_manifest.split('/manifest.json')[0].rstrip('/')
    else:
        base_url = "https://torrentio.strem.fun/qualityfilter=cam,scr,threed,480p"

    try:
        if content_type == 'movie':
            api_url = "%s/stream/movie/%s.json" % (base_url, imdb_id)
        else:
            api_url = "%s/stream/series/%s:%s:%s.json" % (base_url, imdb_id, season or 1, episode or 1)

        r = get_shared_session().get(api_url, headers=get_headers(), timeout=15, verify=False)

        if r.status_code != 200:
            return None

        data = r.json()
        streams = []

        for s in data.get('streams', []):
            info_hash = s.get('infoHash')
            if not info_hash:
                continue

            magnet = "magnet:?xt=urn:btih:%s" % info_hash
            raw_name = s.get('name', '')
            raw_title = s.get('title', '')

            full_check = (raw_name + " " + raw_title).upper().replace('DS4K', '').replace('4KDS', '')
            q_label = '1080p'
            if '720P' in full_check:
                q_label = '720p'
            elif '1080P' in full_check:
                q_label = '1080p'
            elif any(x in full_check for x in ['2160P', '4K', 'UHD']):
                q_label = '4K'
            elif '480P' in full_check:
                q_label = 'SD'

            # Extract name: Torrentio puts filename in title first line or name second line
            title_parts = raw_title.split('\n')
            clean_title = title_parts[0].strip() if title_parts else ''
            if not clean_title or clean_title.lower() == 'torrentio':
                name_parts = raw_name.split('\n')
                if len(name_parts) > 1:
                    clean_title = name_parts[1].strip()
                else:
                    clean_title = name_parts[0].strip()

            for e in ['📄','📹','🔊','⭐','👤','💾','🔎','🏷️','🌎','🇬🇧','🇮🇹','🎥','🎬','👥','🎞️','🎞','⚙️']:
                clean_title = clean_title.replace(e, '')
            clean_title = clean_title.strip()

            if not clean_title:
                continue

            # Size from full title
            size_match = re.search(r'([\d.]+\s*(?:GB|MB|TB))', raw_title, re.IGNORECASE)
            size_str = size_match.group(1).upper() if size_match else ""

            # Seeders from full title
            seeders = 0
            seed_match = re.search(r'(?:👤|👥|S:)\s*(\d+)', raw_title)
            if seed_match:
                seeders = int(seed_match.group(1))

            streams.append({
                'url': magnet,
                'name': clean_title + " [S: %d]" % seeders,
                'title': clean_title,
                'quality': q_label,
                'size': size_str,
                'info': {
                    'seeders': seeders,
                    'peers': 0,
                    'indexer': 'Torrentio',
                    'freeleech': 0,
                    'doubleup': 0,
                    'internal': 0,
                    'quality': q_label,
                    'releaseGroup': _extract_release_group(clean_title),
                },
                'provider_id': 'p2p_torrentio'
            })

        if streams:
            xbmc.log("[TMDb Movies] [P2P Torrentio] %d streams returned" % len(streams), xbmc.LOGERROR)
        return streams if streams else None

    except Exception as e:
        xbmc.log("[TMDb Movies] [P2P Torrentio] error: %s" % str(e), xbmc.LOGERROR)
        return None


# =============================================================================
# SCRAPER COMET P2P (Magnet links via Comet, no debrid)
# =============================================================================
def scrape_p2p_comet(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    xbmc.log("[TMDb Movies] [P2P Comet] called: imdb_id=%s content_type=%s" % (imdb_id, content_type), xbmc.LOGERROR)
    if ADDON.getSetting('use_p2p_comet') == 'false':
        return None

    custom_manifest = ADDON.getSetting('p2p_comet_manifest').strip()
    if custom_manifest:
        base_url = custom_manifest.split('/manifest.json')[0].rstrip('/')
    else:
        base_url = "https://cometfortheweebs.midnightignite.me/eyJtYXhSZXN1bHRzUGVyUmVzb2x1dGlvbiI6MCwibWF4U2l6ZSI6MCwiY2FjaGVkT25seSI6ZmFsc2UsInNvcnRDYWNoZWRVbmNhY2hlZFRvZ2V0aGVyIjpmYWxzZSwicmVtb3ZlVHJhc2giOnRydWUsInJlc3VsdEZvcm1hdCI6WyJhbGwiXSwiZGVicmlkU2VydmljZXMiOltdLCJlbmFibGVUb3JyZW50Ijp0cnVlLCJkZWR1cGxpY2F0ZVN0cmVhbXMiOmZhbHNlLCJzY3JhcGVEZWJyaWRBY2NvdW50VG9ycmVudHMiOmZhbHNlLCJkZWJyaWRTdHJlYW1Qcm94eVBhc3N3b3JkIjoiIiwibGFuZ3VhZ2VzIjp7InJlcXVpcmVkIjpbXSwiYWxsb3dlZCI6W10sImV4Y2x1ZGUiOltdLCJwcmVmZXJyZWQiOltdfSwicmVzb2x1dGlvbnMiOnsicjU3NnAiOmZhbHNlLCJyNDgwcCI6ZmFsc2UsInIzNjBwIjpmYWxzZSwicjI0MHAiOmZhbHNlfSwib3B0aW9ucyI6eyJyZW1vdmVfcmFua3NfdW5kZXIiOi0xMDAwMDAwMDAwMCwiYWxsb3dfZW5nbGlzaF9pbl9sYW5ndWFnZXMiOmZhbHNlLCJyZW1vdmVfdW5rbm93bl9sYW5ndWFnZXMiOmZhbHNlfX0="

    try:
        if content_type == 'movie':
            api_url = "%s/stream/movie/%s.json" % (base_url, imdb_id)
        else:
            api_url = "%s/stream/series/%s:%s:%s.json" % (base_url, imdb_id, season or 1, episode or 1)

        r = get_shared_session().get(api_url, headers=get_headers(), timeout=15, verify=False)
        if r.status_code != 200:
            return None

        data = r.json()
        streams = []

        for s in data.get('streams', []):
            info_hash = s.get('infoHash')
            if not info_hash:
                continue

            trackers = s.get('sources', [])
            magnet = "magnet:?xt=urn:btih:%s" % info_hash
            for tr in trackers:
                magnet += "&tr=%s" % tr

            raw_name = s.get('name', '')
            description = s.get('description', '')
            bh = s.get('behaviorHints', {})

            filename = bh.get('filename', '')
            if not filename:
                fn_match = re.search(r'📄\s*(.+?)(?:\n|$)', description)
                if fn_match:
                    filename = fn_match.group(1).strip()

            if not filename:
                filename = raw_name

            display_name = filename
            for ext in ['.mkv', '.mp4', '.avi', '.m2ts', '.ts', '.mov']:
                if display_name.lower().endswith(ext):
                    display_name = display_name[:-(len(ext))]
                    break

            full_check = (raw_name + " " + display_name + " " + description).upper().replace('DS4K', '').replace('4KDS', '')
            q_label = '1080p'
            if '720P' in full_check:
                q_label = '720p'
            elif '1080P' in full_check:
                q_label = '1080p'
            elif any(x in full_check for x in ['2160P', '4K', 'UHD']):
                q_label = '4K'
            elif '480P' in full_check:
                q_label = 'SD'

            size_str = ""
            size_match = re.search(r'💾\s*([\d.]+\s*(?:GB|MB|TB))', description, re.IGNORECASE)
            if size_match:
                size_str = size_match.group(1).upper()
            elif bh.get('videoSize'):
                vs = float(bh['videoSize'])
                if vs >= 1073741824:
                    size_str = "%.2f GB" % (vs / 1073741824)
                elif vs >= 1048576:
                    size_str = "%.0f MB" % (vs / 1048576)

            seeders = 0

            clean_title = display_name
            for e in ['📄','📹','🔊','⭐','👤','💾','🔎','🏷️','🌎','🇬🇧','🇮🇹','🎥','🎬','👥','🎞️','🎞','⚙️','🧲','▪️','▫️']:
                clean_title = clean_title.replace(e, '')
            clean_title = clean_title.strip()

            if not clean_title:
                continue

            streams.append({
                'url': magnet,
                'name': clean_title,
                'title': clean_title,
                'quality': q_label,
                'size': size_str,
                'info': {
                    'seeders': seeders,
                    'peers': 0,
                    'indexer': 'Comet',
                    'freeleech': 0,
                    'doubleup': 0,
                    'internal': 0,
                    'quality': q_label,
                    'releaseGroup': _extract_release_group(clean_title),
                },
                'provider_id': 'p2p_comet'
            })

        if streams:
            xbmc.log("[TMDb Movies] [P2P Comet] %d streams returned" % len(streams), xbmc.LOGERROR)
        return streams if streams else None

    except Exception as e:
        xbmc.log("[TMDb Movies] [P2P Comet] error: %s" % str(e), xbmc.LOGERROR)
        return None


# =============================================================================
# SCRAPER MEDIAFUSION P2P (Magnet links via MediaFusion, no debrid)
# =============================================================================
def scrape_p2p_mediafusion(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    xbmc.log("[TMDb Movies] [P2P MediaFusion] called: imdb_id=%s content_type=%s" % (imdb_id, content_type), xbmc.LOGERROR)
    if ADDON.getSetting('use_p2p_mediafusion') == 'false':
        return None

    custom_manifest = ADDON.getSetting('p2p_mediafusion_manifest').strip()
    if custom_manifest:
        base_url = custom_manifest.split('/manifest.json')[0].rstrip('/')
    else:
        base_url = "https://mediafusionfortheweebs.midnightignite.me/D-MgIOYBm8hyaUIwwpw-vb7g1DkYuDWlVkR8yC2LTS3b7ejVz5s0yzfMZ1Gf5CxiqtreQCeRCfLfLhOWTFkTDsQL8ozlOF6Sig9mbbuqGnKCFO46BLz3EoWk2OGlL5oM7dpIsTJXVyJC7zWVlgRHXhPy8C-kzUcMHgCJwcFQ-p877sugPoevStrllmYQou9DPpyzbR87R58nJNFrrOj7AoAWK3EkJjAZrvA-t1JCXrrjKWJ-F5FBg4kP9NZ3-6kF8ukse-wG2rU1-xRrHa9r-oya4KwNbR7wYqc2RJVk8WZ5NlKl9SyhS-_FaCGLHinIvG_Spgi-_f9f1aEAVE6_f6rEF-23ajBhmoRu7E3-_F6Fzaahv5sXXG4PkOC62GE37K3OeWZf9X2x-zoIlvmDd6mQ6PAsbKrmhxZbe71uccjWeSjvAOd4iamk1dUiGZp_KPlgjFIEsp98dg7DDG_bXn2klWQuJspM_Pqnaa2T1v8VMuYkqEGcYfAlxYEDKwmB_FIGla9SB5eK2kxZ6NfY3eruKJZ-RDGll9oiTRql9boUeooCAIg839XoenYcHred5wx7r_j5Yx0yUAuC9gytKArPajtIc46TDa4bNsO3ugvJ8U2kKLkLcrCaDSyi3daFSS3Yw_zyv7OeNH2ZH-5UoGgiR49kxLUiGhhR0eM724890haspz40N1JyUeexC620OyAdYIm47hfshxAToEKnPL3fr3L9_HwjwAtxUTWTIO3mLc-RLUz_BDOxeSqKyW-ogq_iTYOVmKBrLVPuQhYIBTSHoZ9fwS4K6UalaQVSADTbun-Nw8xpW6uy9_pLXn-fzw0S-t7is3U63gAkET_f6y30LkWbkuCBF-haoyx7f8i6fMoDZ-i3JedLGw1ReXIK-SKUqo7a0OOWuZF97A-GPyYOu34TZTcGLL3YH-XbZm0kPMXUh9gIM5-vMbafSaZKobLIAg4LSHb0IQVmpQKUqiifXfjhQx7xdwgdTg0aZ-MUa1kZ__vAvWonmAlIXKoj3myCZ3CO4NhzMS90D4rcD7cMx5NGP5fG6EQVbnlyrfpqcT1bsuz1rk5QeIyhGGhRyivaJbJfCC9a5kGtiO9gFBkiDiRnq8Lmy_ADqcTnZYYc5vgbgCDHjZRW3uh2PT61UzN6oWnisSHMQUQWu_KwpAHQ"

    try:
        if content_type == 'movie':
            api_url = "%s/stream/movie/%s.json" % (base_url, imdb_id)
        else:
            api_url = "%s/stream/series/%s:%s:%s.json" % (base_url, imdb_id, season or 1, episode or 1)

        r = get_shared_session().get(api_url, headers=get_headers(), timeout=15, verify=False)
        if r.status_code != 200:
            return None

        data = r.json()
        streams = []

        for s in data.get('streams', []):
            info_hash = s.get('infoHash')
            if not info_hash:
                continue

            trackers = s.get('sources', [])
            magnet = "magnet:?xt=urn:btih:%s" % info_hash
            for tr in trackers:
                tr_url = tr.replace('tracker:', '', 1) if tr.startswith('tracker:') else tr
                magnet += "&tr=%s" % tr_url

            raw_name = s.get('name', '')
            description = s.get('description', '')
            bh = s.get('behaviorHints', {})

            filename = bh.get('filename', '')
            if not filename:
                fn_match = re.search(r'📄\s*(.+?)(?:\n|$)', description)
                if fn_match:
                    filename = fn_match.group(1).strip()

            if not filename:
                filename = raw_name

            display_name = filename
            for ext in ['.mkv', '.mp4', '.avi', '.m2ts', '.ts', '.mov']:
                if display_name.lower().endswith(ext):
                    display_name = display_name[:-(len(ext))]
                    break

            full_check = (raw_name + " " + display_name + " " + description).upper().replace('DS4K', '').replace('4KDS', '')
            q_label = '1080p'
            if '720P' in full_check:
                q_label = '720p'
            elif '1080P' in full_check:
                q_label = '1080p'
            elif any(x in full_check for x in ['2160P', '4K', 'UHD']):
                q_label = '4K'
            elif '480P' in full_check:
                q_label = 'SD'

            size_str = ""
            size_match = re.search(r'[💾📦]\s*([\d.]+\s*(?:GB|MB|TB))', description, re.IGNORECASE)
            if size_match:
                size_str = size_match.group(1).upper()
            elif bh.get('videoSize'):
                vs = float(bh['videoSize'])
                if vs >= 1073741824:
                    size_str = "%.2f GB" % (vs / 1073741824)
                elif vs >= 1048576:
                    size_str = "%.0f MB" % (vs / 1048576)

            seeders = 0

            clean_title = display_name
            for e in ['📄','📹','🔊','⭐','👤','💾','🔎','🏷️','🌎','🇬🇧','🇮🇹','🎥','🎬','👥','🎞️','🎞','⚙️','🧲','▪️','▫️','📦']:
                clean_title = clean_title.replace(e, '')
            clean_title = clean_title.strip()

            if not clean_title:
                continue

            streams.append({
                'url': magnet,
                'name': clean_title,
                'title': clean_title,
                'quality': q_label,
                'size': size_str,
                'info': {
                    'seeders': seeders,
                    'peers': 0,
                    'indexer': 'MediaFusion',
                    'freeleech': 0,
                    'doubleup': 0,
                    'internal': 0,
                    'quality': q_label,
                    'releaseGroup': _extract_release_group(clean_title),
                },
                'provider_id': 'p2p_mediafusion'
            })

        if streams:
            xbmc.log("[TMDb Movies] [P2P MediaFusion] %d streams returned" % len(streams), xbmc.LOGERROR)
        return streams if streams else None

    except Exception as e:
        xbmc.log("[TMDb Movies] [P2P MediaFusion] error: %s" % str(e), xbmc.LOGERROR)
        return None


# =============================================================================
# SCRAPER YTS (P2P - Torrents via YTS API)
# =============================================================================
def scrape_yts(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    xbmc.log(f"[TMDb Movies] [YTS] scrape_yts called: imdb_id={imdb_id} content_type={content_type} title_query={title_query}", xbmc.LOGERROR)
    if ADDON.getSetting('use_p2p_yts') == 'false':
        xbmc.log(f"[TMDb Movies] [YTS] use_p2p_yts is false, skipping", xbmc.LOGERROR)
        return None
    if content_type != 'movie':
        xbmc.log(f"[TMDb Movies] [YTS] content_type={content_type} != movie, skipping", xbmc.LOGERROR)
        return None

    query_term = None
    if imdb_id and str(imdb_id).startswith('tt'):
        query_term = imdb_id
        xbmc.log(f"[TMDb Movies] [YTS] using IMDb ID: {query_term}", xbmc.LOGERROR)
    elif title_query:
        query_term = title_query
        if year_query:
            query_term += " " + year_query
        xbmc.log(f"[TMDb Movies] [YTS] using title query: {query_term}", xbmc.LOGERROR)
    else:
        xbmc.log(f"[TMDb Movies] [YTS] no valid query (imdb_id={imdb_id}, title={title_query}), skipping", xbmc.LOGERROR)
        return None

    custom_domain = ADDON.getSetting('yts_custom_domain').strip()
    if custom_domain:
        domains = [custom_domain]
    else:
        domains = ['yts.gg', 'yts.bz', 'yts.ag', 'yts.lt', 'yts.mx', 'yts.rs']
    last_error = None
    for domain in domains:
        try:
            session = get_shared_session()
            api_url = "https://%s/api/v2/list_movies.json?query_term=%s&limit=20" % (domain, quote(str(query_term)))
            resp = session.get(api_url, headers={'User-Agent': get_random_ua()}, timeout=10, verify=False)
            if resp.status_code != 200:
                last_error = "[YTS] %s returned %d" % (domain, resp.status_code)
                continue

            data = resp.json()
            if data.get('status') != 'ok':
                last_error = "[YTS] %s bad status: %s" % (domain, data.get('status'))
                continue

            movies = data.get('data', {}).get('movies', [])
            if not movies:
                last_error = "[YTS] %s no movies in response" % domain
                continue

            movie = movies[0]
            title = movie.get('title', 'Unknown')
            year = movie.get('year', '')
            display_title = "%s (%s)" % (title, year) if year else title

            torrents = movie.get('torrents', [])
            if not torrents:
                last_error = "[YTS] %s no torrents for %s" % (domain, query_term)
                continue

            streams = []
            for t in torrents:
                quality = t.get('quality', '1080p')
                if quality == '2160p':
                    q_label = '4K'
                elif quality == '1080p':
                    q_label = '1080p'
                elif quality == '720p':
                    q_label = '720p'
                else:
                    q_label = 'SD'

                size = t.get('size', '')
                seeders = t.get('seeds', 0)
                peers = t.get('peers', 0)

                hash_val = t.get('hash', '')
                if not hash_val:
                    continue

                type_val = t.get('type', '').upper()
                codec = t.get('video_codec', '')
                bit_depth = t.get('bit_depth', '')
                audio = t.get('audio_channels', '')
                parts = [title.replace(' ', '.'), str(year), quality, type_val, codec]
                if bit_depth:
                    parts.append(bit_depth + 'bit')
                if audio:
                    parts.append(audio.replace('.', ''))
                torrent_name = '.'.join(parts)
                display_name = "%s (%s) %s %s [S: %d P: %d] %s" % (title, year, quality, type_val, seeders, peers, size)

                magnet = "magnet:?xt=urn:btih:%s&dn=%s" % (hash_val, quote(torrent_name))
                trackers = [
                    'udp://open.demonii.com:1337/announce',
                    'udp://tracker.openbittorrent.com:80',
                    'udp://tracker.coppersurfer.tk:6969',
                    'udp://glotorrents.pw:6969/announce',
                    'udp://tracker.opentrackr.org:1337/announce',
                    'udp://exodus.desync.com:6969/announce',
                    'udp://p4p.arenabg.com:1337/announce'
                ]
                for tr in trackers:
                    magnet += "&tr=" + quote(tr)

                streams.append({
                    'name': 'YTS | %s %s' % (quality, type_val),
                    'url': magnet,
                    'title': display_name,
                    'quality': q_label,
                    'size': size,
                    'info': {'seeders': seeders, 'peers': peers, 'quality': q_label},
                    'provider_id': 'p2p_yts'
                })

            if streams:
                log("[YTS] %d torrents found for %s via %s" % (len(streams), query_term, domain))
                return streams
            last_error = "[YTS] %s empty streams" % domain
        except Exception as e:
            last_error = "[YTS] %s error: %s" % (domain, str(e))

    log(last_error)
    return None


def _filter_tv_packs(streams, season, episode):
    if not streams or not season:
        return streams
    import re
    filtered = []
    is_episode_search = episode is not None
    season_int = int(season)
    episode_int = int(episode) if episode else None
    for s in streams:
        name = s.get('name', '') or s.get('title', '')
        s_match = re.search(r'(?i)S(\d+)', name)
        e_match = re.search(r'(?i)E(\d+)', name)
        item_season = int(s_match.group(1)) if s_match else -1
        item_episode = int(e_match.group(1)) if e_match else -1
        is_episode_item = (item_season != -1 and item_episode != -1)
        keep_item = True
        if is_episode_search:
            # Mode D1 - specific episode
            if item_season != -1 and item_season != season_int:
                keep_item = False
            elif is_episode_item and item_episode != episode_int:
                keep_item = False
        else:
            # Mode D2 - season only (reject individual episodes)
            if item_season != -1 and item_season != season_int:
                keep_item = False
            elif is_episode_item:
                keep_item = False
        if keep_item:
            filtered.append(s)
    return filtered


def scrape_filelist(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    xbmc.log("[TMDb Movies] [FileList] scrape_filelist called: imdb_id=%s content_type=%s season=%s episode=%s title_query=%s" % (imdb_id, content_type, season, episode, title_query), xbmc.LOGERROR)
    if ADDON.getSetting('use_p2p_filelist') == 'false':
        xbmc.log("[TMDb Movies] [FileList] use_p2p_filelist is false, skipping", xbmc.LOGERROR)
        return None

    username = ADDON.getSetting('filelist_username').strip()
    passkey = ADDON.getSetting('filelist_passkey').strip()
    fallback_enabled = ADDON.getSetting('filelist_fallback_name') == 'true'

    if not username or not passkey:
        xbmc.log("[TMDb Movies] [FileList] missing username or passkey", xbmc.LOGERROR)
        return None

    stream_map = {}
    session = get_shared_session()

    def fetch_and_parse(search_type, query_val):
        api_url = "https://filelist.io/api.php?username=%s&passkey=%s&action=search-torrents&type=%s&query=%s" % (
            username, passkey, search_type, quote(str(query_val)))
        xbmc.log("[TMDb Movies] [FileList] fetching: %s" % api_url.replace(passkey, '***'), xbmc.LOGERROR)
        try:
            resp = session.get(api_url, headers={'User-Agent': get_random_ua()}, timeout=15)
            if resp.status_code != 200:
                xbmc.log("[TMDb Movies] [FileList] HTTP %d" % resp.status_code, xbmc.LOGERROR)
                return False
            data = resp.json()
            if not isinstance(data, list):
                xbmc.log("[TMDb Movies] [FileList] unexpected response: %s" % str(data)[:200], xbmc.LOGERROR)
                return False
            for t in data:
                tid = t.get('id')
                if tid and tid not in stream_map:
                    stream_map[tid] = t
            xbmc.log("[TMDb Movies] [FileList] %d torrents from %s=%s" % (len(data), search_type, query_val), xbmc.LOGERROR)
            return True
        except Exception as e:
            xbmc.log("[TMDb Movies] [FileList] error: %s" % str(e), xbmc.LOGERROR)
            return False

    # 1. IMDb search
    if imdb_id and str(imdb_id).startswith('tt'):
        fetch_and_parse('imdb', imdb_id)

    # 2. Fallback name search
    if not stream_map and fallback_enabled and title_query:
        search_term = title_query
        if year_query:
            search_term += " " + year_query
        fetch_and_parse('name', search_term)

    if not stream_map:
        xbmc.log("[TMDb Movies] [FileList] no torrents found", xbmc.LOGERROR)
        return None

    streams = []
    for tid, t in stream_map.items():
        name = t.get('name', 'Unknown')
        size_bytes = t.get('size', 0)
        seeders = t.get('seeders', 0)
        leechers = t.get('leechers', 0)
        freeleech = t.get('freeleech', 0)
        doubleup = t.get('doubleup', 0)
        internal = t.get('internal', 0)
        category = t.get('category', '')
        download_link = t.get('download_link', '')

        if not download_link:
            continue

        # Build display name
        display_name = name
        display_name += " [S: %d P: %d]" % (seeders, leechers)

        # Size in human-readable
        try:
            size_gb = float(size_bytes) / (1024**3)
            if size_gb >= 1.0:
                size_str = "%.2f GB" % size_gb
            else:
                size_mb = float(size_bytes) / (1024**2)
                size_str = "%.0f MB" % size_mb
        except:
            size_str = ""

        # Quality extraction from name
        q_label = '1080p'
        name_upper = name.upper()
        if '720P' in name_upper:
            q_label = '720p'
        elif '1080P' in name_upper:
            q_label = '1080p'
        elif '2160P' in name_upper or '4K' in name_upper:
            q_label = '4K'
        elif '480P' in name_upper or 'SD' in name_upper:
            q_label = 'SD'

        streams.append({
            'url': download_link,
            'name': display_name,
            'title': display_name,
            'quality': q_label,
            'size': size_str,
            'info': {
                'seeders': seeders,
                'peers': leechers,
                'indexer': category,
                'freeleech': freeleech,
                'doubleup': doubleup,
                'internal': internal,
                'quality': q_label,
                'releaseGroup': _extract_release_group(name),
            },
            'provider_id': 'p2p_filelist'
        })

    if content_type == 'tv' and (season is not None) and streams:
        xbmc.log("[TMDb Movies] [FileList] applying tv pack filter: season=%s episode=%s" % (season, episode), xbmc.LOGERROR)
        streams = _filter_tv_packs(streams, season, episode)
        if streams:
            xbmc.log("[TMDb Movies] [FileList] %d streams after tv pack filter" % len(streams), xbmc.LOGERROR)
        else:
            xbmc.log("[TMDb Movies] [FileList] all streams filtered out by tv pack filter", xbmc.LOGERROR)
    if streams:
        xbmc.log("[TMDb Movies] [FileList] %d streams returned" % len(streams), xbmc.LOGERROR)
    return streams if streams else None


def scrape_speedapp(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    xbmc.log("[TMDb Movies] [SpeedApp] scrape_speedapp called: imdb_id=%s content_type=%s" % (imdb_id, content_type), xbmc.LOGERROR)
    if ADDON.getSetting('use_p2p_speedapp') == 'false':
        return None

    username = ADDON.getSetting('speedapp_username').strip()
    password = ADDON.getSetting('speedapp_password').strip()
    passkey = ADDON.getSetting('speedapp_passkey').strip()
    fallback_enabled = ADDON.getSetting('speedapp_fallback_name') == 'true'
    use_api = ADDON.getSetting('speedapp_use_api') == 'true'

    if not username or not password:
        xbmc.log("[TMDb Movies] [SpeedApp] missing username or password", xbmc.LOGERROR)
        return None
    if not passkey:
        xbmc.log("[TMDb Movies] [SpeedApp] missing passkey", xbmc.LOGERROR)
        return None

    base_url = 'https://speedapp.io'
    ua = get_random_ua()

    # === API MODE ===
    if use_api:
        xbmc.log("[TMDb Movies] [SpeedApp] using API mode", xbmc.LOGERROR)
        try:
            session = requests.Session()
            api_resp = session.post(base_url + '/api/login',
                json={'username': username, 'password': password},
                headers={"User-Agent": ua, "Content-Type": "application/json"},
                timeout=15)
            if api_resp.status_code == 201:
                token = api_resp.json().get('token')
                if token:
                    auth_headers = {"User-Agent": ua, "Authorization": "Bearer " + token}
                    api_streams = _speedapp_api_search(session, auth_headers, base_url, imdb_id, passkey, fallback_enabled, title_query, year_query)
                    if api_streams is not None and len(api_streams) > 0:
                        if content_type == 'tv' and (season is not None):
                            api_streams = _filter_tv_packs(api_streams, season, episode)
                        if api_streams is not None and len(api_streams) > 0:
                            xbmc.log("[TMDb Movies] [SpeedApp] %d streams returned via API" % len(api_streams), xbmc.LOGERROR)
                            return api_streams
            xbmc.log("[TMDb Movies] [SpeedApp] API failed (HTTP %d), falling back to HTML scrape" % api_resp.status_code, xbmc.LOGERROR)
        except Exception as e:
            xbmc.log("[TMDb Movies] [SpeedApp] API error: %s, falling back to HTML scrape" % str(e), xbmc.LOGERROR)

    # === HTML SCRAPE MODE (default / fallback) ===
    xbmc.log("[TMDb Movies] [SpeedApp] using HTML scrape mode", xbmc.LOGERROR)
    session = requests.Session()
    try:
        login_resp = session.get(base_url + '/login',
            headers={"User-Agent": ua, "Accept-Language": "en-US,en;q=0.5"},
            timeout=15)
        token_match = re.search(r'_csrf_token.+?value="(.+?)"', login_resp.text)
        if not token_match:
            xbmc.log("[TMDb Movies] [SpeedApp] no CSRF token found", xbmc.LOGERROR)
            return None
        csrf_token = token_match.group(1)
        login_post = session.post(base_url + '/login', data={
                'email': username, 'password': password, '_remember_me': 'on', '_csrf_token': csrf_token
            }, headers={"User-Agent": ua, "Origin": base_url, "Referer": base_url + '/login'}, timeout=15)
        if 'logout' not in login_post.text:
            xbmc.log("[TMDb Movies] [SpeedApp] login failed", xbmc.LOGERROR)
            return None
    except Exception as e:
        xbmc.log("[TMDb Movies] [SpeedApp] login error: %s" % str(e), xbmc.LOGERROR)
        return None

    def fetch_page(search_url):
        try:
            resp = session.get(search_url, headers={"User-Agent": ua}, timeout=15)
            return resp.text if resp.status_code == 200 else None
        except:
            return None

    def parse_html(html):
        streams = []
        blocks = re.split(r'<div class="separator separator-dashed"></div>\s*<div class="row mx-0 py-3">', html)
        if len(blocks) > 1:
            blocks = blocks[1:]
        for block in blocks:
            try:
                if 'href="/torrents/' not in block:
                    continue
                name_match = re.search(r'<a class="text-reset fw-bold" href="[^"]+">(.+?)</a>', block, re.DOTALL)
                if not name_match:
                    continue
                name = name_match.group(1).strip()
                if not name:
                    continue
                junk_pattern = r'(?i)\b(trailer|sample|cam|camrip|hdts|hdtc|ts|telesync|scr|screener|preair|clip|preview|tc|hc)\b'
                if re.search(junk_pattern, name):
                    continue
                dl_match = re.search(r'href="(/torrents/(\d+)/[^"]+\.torrent)"', block)
                if not dl_match:
                    continue
                tid = dl_match.group(2)
                size_match = re.search(r'<div class="col-6 col-sm-4 col-md-1 text-center text-muted"(?! data-bs-toggle)>([^<]+)</div>', block)
                size_str = size_match.group(1).strip() if size_match else ''
                seeds_match = re.search(r'<span class="text-success">(\d+)<span class="d-md-none"> seeders', block)
                seeders = int(seeds_match.group(1)) if seeds_match else 0
                leech_match = re.search(r'<span class="text-danger[^"]*">(\d+)<span class="d-md-none"> leechers', block)
                leechers = int(leech_match.group(1)) if leech_match else 0
                freeleech = 1 if 'Descarcarea acestui torrent este gratuita' in block else 0
                doubleup = 1 if 'Uploadul pe acest torrent se va contoriza dublu.' in block else 0
                halfdw = 1 if 'Descarcarea acestui torrent este redusa la jumatate.' in block else 0
                is_internal = 1 if 'Intern' in block else 0
                cat_match = re.search(r'href="/browse\?categories%5B0%5D=(\d+)"', block)
                cat_id = cat_match.group(1) if cat_match else ''
                cat_names = {
                    '3': 'Anime/Hentai', '43': 'Seriale HDTV', '44': 'Seriale HDTV-Ro',
                    '17': 'Filme BluRay', '24': 'Filme BluRay-Ro',
                    '7': 'Filme DVD', '2': 'Filme DVD-Ro',
                    '8': 'Filme HD', '29': 'Filme HD-Ro',
                    '61': 'Filme 4K(2160p)', '57': 'Filme 4K-RO(2160p)',
                    '10': 'Filme SD', '35': 'Filme SD-Ro',
                    '45': 'Seriale TV', '46': 'Seriale TV-Ro',
                    '9': 'Documentare', '63': 'Documentare-Ro',
                    '22': 'Sport', '58': 'Sport-Ro',
                    '38': 'Movies Packs', '41': 'TV Packs', '66': 'TV Packs-Ro',
                    '59': 'Filme Romanesti', '60': 'Seriale Romanesti',
                    '62': 'Desene Animate', '64': 'Videoclipuri'
                }
                category_name = cat_names.get(cat_id, '')
                q_label = 'SD'
                name_upper = name.upper()
                if '2160P' in name_upper or '4K' in name_upper:
                    q_label = '4K'
                elif '1080P' in name_upper:
                    q_label = '1080p'
                elif '720P' in name_upper:
                    q_label = '720p'
                elif '480P' in name_upper or 'SD' in name_upper:
                    q_label = 'SD'
                download_link = "%s/rss/download/%s/%s.torrent?passkey=%s" % (base_url, tid, quote(name), passkey)
                streams.append({
                    'url': download_link,
                    'name': name + " [S: %d P: %d]" % (seeders, leechers),
                    'title': name,
                    'quality': q_label,
                    'size': size_str,
                    'info': {
                        'seeders': seeders, 'peers': leechers, 'indexer': category_name,
                        'freeleech': freeleech, 'doubleup': doubleup, 'halfdw': halfdw,
                        'internal': is_internal, 'quality': q_label,
                        'releaseGroup': _extract_release_group(name),
                    },
                    'provider_id': 'p2p_speedapp'
                })
            except:
                continue
        return streams

    all_streams = []
    if imdb_id and str(imdb_id).startswith('tt'):
        for page in [1, 2]:
            html = fetch_page(base_url + "/browse?search=%s&submit=&sort=torrent.seeders&direction=desc&page=%d" % (imdb_id, page))
            if html:
                streams = parse_html(html)
                all_streams.extend(streams)
                if len(streams) < 50:
                    break
            else:
                break
    if not all_streams and fallback_enabled and title_query:
        search_term = title_query + (" " + year_query if year_query else "")
        for page in [1, 2]:
            html = fetch_page(base_url + "/browse?search=%s&submit=&sort=torrent.seeders&direction=desc&page=%d" % (quote(search_term), page))
            if html:
                streams = parse_html(html)
                all_streams.extend(streams)
                if len(streams) < 50:
                    break
            else:
                break

    if content_type == 'tv' and (season is not None) and all_streams:
        all_streams = _filter_tv_packs(all_streams, season, episode)
    if all_streams:
        xbmc.log("[TMDb Movies] [SpeedApp] %d streams returned" % len(all_streams), xbmc.LOGERROR)
    return all_streams if all_streams else None


# --- SeedPool (UNIT3D private tracker) ---
_SEEDPOOL_BASE = 'https://seedpool.org'
_SEEDPOOL_JUNK_RE = r'(?i)\b(trailer|sample|cam|camrip|hdts|hdtc|ts|telesync|scr|screener|preair|clip|preview)\b'
_SEEDPOOL_VIDEO_EXTS = ('.mkv', '.mp4', '.avi', '.mov', '.wmv', '.ts', '.m4v', '.webm', '.flv', '.m2ts', '.iso')
_seedpool_session = None
_seedpool_session_ts = 0
_seedpool_session_lock = threading.Lock()
_seedpool_announce = None
_seedpool_login_fail_ts = 0


def _seedpool_get_session(username, password, force=False):
    """Login HTML (Laravel cu honeypots); sesiune cached 30 min.
    Backoff 60s dupa un esec (trackerul throttleaza incercarile repetate)."""
    global _seedpool_session, _seedpool_session_ts, _seedpool_login_fail_ts
    with _seedpool_session_lock:
        now = time.time()
        if not force and _seedpool_session is not None and (now - _seedpool_session_ts) < 1800:
            return _seedpool_session
        if (now - _seedpool_login_fail_ts) < 60:
            xbmc.log("[TMDb Movies] [SeedPool] login backoff active", xbmc.LOGERROR)
            return None
        try:
            ua = get_random_ua()
            s = requests.Session()
            s.headers.update({'User-Agent': ua, 'Accept-Language': 'en-US,en;q=0.5'})
            r = s.get(_SEEDPOOL_BASE + '/login', timeout=15)
            fm = re.search(r'<form[^>]*action="[^"]*/login"[^>]*>(.*?)</form>', r.text, re.DOTALL)
            if not fm:
                xbmc.log("[TMDb Movies] [SeedPool] no login form found", xbmc.LOGERROR)
                _seedpool_login_fail_ts = time.time()
                return None
            data = {}
            for inp in re.finditer(r'<input([^>]*)>', fm.group(1)):
                nm = re.search(r'name="([^"]*)"', inp.group(1))
                vl = re.search(r'value="([^"]*)"', inp.group(1))
                if nm:
                    # honeypots text (_username etc.) raman goale; hidden pastreaza valoarea
                    data[nm.group(1)] = vl.group(1) if vl else ''
            data['username'] = username
            data['password'] = password
            if 'remember' in data:
                data['remember'] = 'on'
            r2 = s.post(_SEEDPOOL_BASE + '/login', data=data,
                        headers={'Origin': _SEEDPOOL_BASE, 'Referer': _SEEDPOOL_BASE + '/login'}, timeout=15)
            if 'logout' not in r2.text.lower():
                xbmc.log("[TMDb Movies] [SeedPool] login failed", xbmc.LOGERROR)
                _seedpool_session = None
                _seedpool_session_ts = 0
                _seedpool_login_fail_ts = time.time()
                return None
            _seedpool_session = s
            _seedpool_session_ts = time.time()
            _seedpool_login_fail_ts = 0
            xbmc.log("[TMDb Movies] [SeedPool] login OK", xbmc.LOGERROR)
            return s
        except Exception as e:
            xbmc.log("[TMDb Movies] [SeedPool] login error: %s" % str(e), xbmc.LOGERROR)
            _seedpool_login_fail_ts = time.time()
            return None


def _sp_bdecode(data, pos):
    c = data[pos:pos + 1]
    if c == b'i':
        e = data.index(b'e', pos)
        return int(data[pos + 1:e]), e + 1
    if c == b'l':
        pos += 1
        out = []
        while data[pos:pos + 1] != b'e':
            v, pos = _sp_bdecode(data, pos)
            out.append(v)
        return out, pos + 1
    if c == b'd':
        pos += 1
        out = {}
        while data[pos:pos + 1] != b'e':
            k, pos = _sp_bdecode(data, pos)
            v, pos = _sp_bdecode(data, pos)
            out[k] = v
        return out, pos + 1
    e = data.index(b':', pos)
    ln = int(data[pos:e])
    st = e + 1
    return data[st:st + ln], st + ln


def _seedpool_info_hash(tdata):
    """info_hash = sha1(bencode(info_dict)) din continutul .torrent."""
    try:
        i = tdata.find(b'4:info')
        if i < 0:
            return None
        obj, end = _sp_bdecode(tdata, i + 6)
        return hashlib.sha1(tdata[i + 6:end]).hexdigest()
    except Exception:
        return None


def _seedpool_extract_announce(tdata):
    """Announce URL (cu passkey embedded); valideaza fiecare candidat ca sa
    evite potrivirile false in interiorul datelor binare 'pieces'.
    Prefixul de lungime e calculat dinamic ('8:announce')."""
    global _seedpool_announce
    if _seedpool_announce:
        return _seedpool_announce
    key = b'announce'
    pat = re.compile(re.escape(str(len(key)).encode()) + b':' + re.escape(key) + rb'(\d+):')
    for m in pat.finditer(tdata):
        ln = int(m.group(1))
        st = m.end()
        cand = tdata[st:st + ln]
        if cand.startswith((b'http://', b'https://', b'udp://')):
            try:
                ann = cand.decode('utf-8', errors='ignore')
                _seedpool_announce = ann
                return ann
            except Exception:
                pass
    return None


def _seedpool_parse_rows(html):
    """Parseaza randurile UNIT3D din pagina de cautare."""
    rows = []
    for m in re.finditer(r'<tr[^>]*data-torrent-id="(\d+)"[^>]*>(.*?)</tr>', html, re.DOTALL):
        tid, row = m.group(1), m.group(2)
        try:
            nm = re.search(r'class="torrent-search--list__name"[^>]*>\s*(.+?)\s*</a>', row, re.DOTALL)
            if not nm:
                continue
            name = nm.group(1).strip()
            if not name or re.search(_SEEDPOOL_JUNK_RE, name):
                continue
            sz = re.search(r'torrent-search--list__size">\s*<span>([^<]+)</span>', row)
            sd = re.search(r'torrent-search--list__seeders">\s*<a[^>]*>\s*<span>(\d+)</span>', row)
            lc = re.search(r'torrent-search--list__leechers">\s*<a[^>]*>\s*<span>(\d+)</span>', row)
            typ = re.search(r'torrent-search--list__type">\s*([^<]+?)\s*</span>', row)
            rows.append({
                'id': tid,
                'name': name,
                'size_str': sz.group(1).strip() if sz else '',
                'seeders': int(sd.group(1)) if sd else 0,
                'leechers': int(lc.group(1)) if lc else 0,
                'type': typ.group(1).strip() if typ else '',
                'freeleech': 1 if 'torrent-icons__freeleech' in row else 0,
                'doubleup': 1 if 'torrent-icons__double-upload' in row else 0,
                'internal': 1 if ('torrent-icons__internal' in row or 'Internal' in row) else 0,
            })
        except Exception:
            continue
    return rows


def _seedpool_has_video(tdata):
    """Anti-fake: verifica daca .torrentul contine macar un fisier video.
    Torrenturile-fake (schema comuna pe trackere) contin doar .exe/.scr cu
    nume de release frumos. La eroare de parsare NU bloca sursa."""
    try:
        i = tdata.find(b'4:info')
        if i < 0:
            return True
        obj, end = _sp_bdecode(tdata, i + 6)
        if not isinstance(obj, dict):
            return True

        def _is_video(nb):
            n = nb.decode('utf-8', errors='ignore').lower()
            return any(n.endswith(e) for e in _SEEDPOOL_VIDEO_EXTS)

        nm = obj.get(b'name')
        if isinstance(nm, bytes) and _is_video(nm):
            return True
        fl = obj.get(b'files')
        if isinstance(fl, list):
            for it in fl:
                if isinstance(it, dict):
                    p = it.get(b'path')
                    if isinstance(p, list) and p and isinstance(p[-1], bytes) and _is_video(p[-1]):
                        return True
        return False
    except Exception:
        return True


def scrape_seedpool(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    xbmc.log("[TMDb Movies] [SeedPool] scrape_seedpool called: imdb_id=%s content_type=%s" % (imdb_id, content_type), xbmc.LOGERROR)
    if ADDON.getSetting('use_p2p_seedpool') == 'false':
        return None

    username = ADDON.getSetting('seedpool_username').strip()
    password = ADDON.getSetting('seedpool_password').strip()
    fallback_enabled = ADDON.getSetting('seedpool_fallback_name') == 'true'

    if not username or not password:
        xbmc.log("[TMDb Movies] [SeedPool] missing username or password", xbmc.LOGERROR)
        return None

    session = _seedpool_get_session(username, password)
    if session is None:
        return None

    found_rows = {}

    def fetch_search(params):
        nonlocal session
        try:
            r = session.get(_SEEDPOOL_BASE + '/torrents', params=params, timeout=15)
            if r.status_code != 200:
                xbmc.log("[TMDb Movies] [SeedPool] search HTTP %d" % r.status_code, xbmc.LOGERROR)
                return False
            # Sesiune expirata server-side -> re-login fortat + retry
            if 'name="password"' in r.text:
                xbmc.log("[TMDb Movies] [SeedPool] session expired, re-login", xbmc.LOGERROR)
                s2 = _seedpool_get_session(username, password, force=True)
                if not s2:
                    return False
                session = s2
                r = s2.get(_SEEDPOOL_BASE + '/torrents', params=params, timeout=15)
                if r.status_code != 200 or 'name="password"' in r.text:
                    return False
            n0 = len(found_rows)
            for row in _seedpool_parse_rows(r.text):
                found_rows.setdefault(row['id'], row)
            return len(found_rows) > n0
        except Exception as e:
            xbmc.log("[TMDb Movies] [SeedPool] search error: %s" % str(e), xbmc.LOGERROR)
            return False

    # 1. IMDb search
    if imdb_id and str(imdb_id).startswith('tt'):
        fetch_search({'imdbId': str(imdb_id)})

    # 2. Fallback name search
    if not found_rows and fallback_enabled and title_query:
        q = title_query + (" " + year_query if year_query else "")
        fetch_search({'name': q})

    if not found_rows:
        xbmc.log("[TMDb Movies] [SeedPool] no torrents found", xbmc.LOGERROR)
        return None

    # 3. .torrent -> info_hash -> magnet (parallel; TorrServer nu are cookies)
    from concurrent.futures import ThreadPoolExecutor
    rows = sorted(found_rows.values(), key=lambda x: x['seeders'], reverse=True)[:30]

    def build_magnet(row):
        try:
            rd = session.get('%s/torrents/download/%s' % (_SEEDPOOL_BASE, row['id']), timeout=20)
            # Trackerul poate throttle-a burst-uri de download - un singur retry
            if rd.status_code != 200:
                time.sleep(0.7)
                rd = session.get('%s/torrents/download/%s' % (_SEEDPOOL_BASE, row['id']), timeout=20)
            if rd.status_code != 200 or len(rd.content) < 100:
                return None
            ih = _seedpool_info_hash(rd.content)
            if not ih:
                return None
            if not _seedpool_has_video(rd.content):
                xbmc.log("[TMDb Movies] [SeedPool] FAKE skipped (fara fisiere video): %s" % row['name'][:70], xbmc.LOGERROR)
                return None
            ann = _seedpool_extract_announce(rd.content)
            # Bytes raw pentru upload direct in TorrServer (metadata instant,
            # fara BEP-9 pe magnet pur - blocat pe unele setup-uri)
            row['torrent_b64'] = base64.b64encode(rd.content).decode('ascii')
            mag = 'magnet:?xt=urn:btih:%s&dn=%s' % (ih, quote(row['name']))
            if ann:
                mag += '&tr=' + quote(ann, safe='')
            row['magnet'] = mag
            return row
        except Exception:
            return None

    with ThreadPoolExecutor(max_workers=4) as ex:
        built = list(ex.map(build_magnet, rows))

    # Completam announce-ul pentru magnetii construiti inainte de prima
    # extractie reusita (race intre workerii paraleli)
    ann_cached = _seedpool_announce
    if ann_cached:
        for row in built:
            if row and row.get('magnet') and '&tr=' not in row['magnet']:
                row['magnet'] += '&tr=' + quote(ann_cached, safe='')

    ok_rows = [r for r in built if r]
    xbmc.log("[TMDb Movies] [SeedPool] %d magnets built from %d torrents" % (len(ok_rows), len(rows)), xbmc.LOGERROR)

    streams = []
    for row in ok_rows:
        name = row['name']
        seeders = row['seeders']
        leechers = row['leechers']
        display_name = name + " [S: %d P: %d]" % (seeders, leechers)

        q_label = 'SD'
        name_upper = name.upper()
        if '2160P' in name_upper or '4K' in name_upper:
            q_label = '4K'
        elif '1080P' in name_upper:
            q_label = '1080p'
        elif '720P' in name_upper:
            q_label = '720p'
        elif '480P' in name_upper or 'SD' in name_upper:
            q_label = 'SD'

        streams.append({
            'url': row['magnet'],
            'name': display_name,
            'title': display_name,
            'quality': q_label,
            'size': row['size_str'],
            '_torrent_b64': row.get('torrent_b64', ''),
            'info': {
                'seeders': seeders,
                'peers': leechers,
                'indexer': row['type'],
                'freeleech': row['freeleech'],
                'doubleup': row['doubleup'],
                'internal': row['internal'],
                'quality': q_label,
                'releaseGroup': _extract_release_group(name),
            },
            'provider_id': 'p2p_seedpool'
        })

    if content_type == 'tv' and (season is not None) and streams:
        xbmc.log("[TMDb Movies] [SeedPool] applying tv pack filter: season=%s episode=%s" % (season, episode), xbmc.LOGERROR)
        streams = _filter_tv_packs(streams, season, episode)
    if streams:
        xbmc.log("[TMDb Movies] [SeedPool] %d streams returned" % len(streams), xbmc.LOGERROR)
    return streams if streams else None


# --- SpeedApp API helpers ---
_speedapp_channel_lock = threading.Lock()
_speedapp_channel_ids = None

def _speedapp_get_channel_ids(session, auth_headers):
    global _speedapp_channel_ids
    if _speedapp_channel_ids is not None:
        return _speedapp_channel_ids
    with _speedapp_channel_lock:
        if _speedapp_channel_ids is not None:
            return _speedapp_channel_ids
        channels = {1, 2, 3, 6, 8, 11, 14, 15, 16, 49, 52}  # cauta ”getrss?channels” in sursa paginii pentru id canal
        try:
            pub = session.get('https://speedapp.io/api/channel', headers=auth_headers, timeout=10)
            if pub.status_code == 200:
                for ch in pub.json():
                    if isinstance(ch, dict) and ch.get('id'):
                        ch_id = ch['id']
                        if ch_id not in (45, 51):  # exclude private/music channels that block the search
                            channels.add(ch_id)
        except:
            pass
        _speedapp_channel_ids = sorted(channels)
        xbmc.log("[TMDb Movies] [SpeedApp] using %d channels: %s" % (len(_speedapp_channel_ids), _speedapp_channel_ids), xbmc.LOGERROR)
        return _speedapp_channel_ids

def _speedapp_torrent_to_stream(t, passkey, base_url):
    try:
        tid = t.get('id')
        name = t.get('name', 'Unknown')
        if tid is None or not name:
            return None
        seeders = t.get('seeders', 0)
        leechers = t.get('leechers', 0)
        size_bytes = t.get('size', 0)
        try:
            size_gb = float(size_bytes) / 1073741824
            size_str = "%.2f GB" % size_gb if size_gb >= 1.0 else "%.0f MB" % (float(size_bytes) / 1048576)
        except:
            size_str = ""
        category = t.get('category', {})
        category_name = ''
        if isinstance(category, dict):
            cat_names = {
                '3': 'Anime/Hentai', '43': 'Seriale HDTV', '44': 'Seriale HDTV-Ro',
                '17': 'Filme BluRay', '24': 'Filme BluRay-Ro',
                '7': 'Filme DVD', '2': 'Filme DVD-Ro',
                '8': 'Filme HD', '29': 'Filme HD-Ro',
                '61': 'Filme 4K(2160p)', '57': 'Filme 4K-RO(2160p)',
                '10': 'Filme SD', '35': 'Filme SD-Ro',
                '45': 'Seriale TV', '46': 'Seriale TV-Ro',
                '9': 'Documentare', '63': 'Documentare-Ro',
                '22': 'Sport', '58': 'Sport-Ro',
                '38': 'Movies Packs', '41': 'TV Packs', '66': 'TV Packs-Ro',
                '59': 'Filme Romanesti', '60': 'Seriale Romanesti',
                '62': 'Desene Animate', '64': 'Videoclipuri'
            }
            category_name = cat_names.get(str(category.get('id', '')), str(category.get('name', '')))
        q_label = 'SD'
        name_upper = name.upper()
        if '2160P' in name_upper or '4K' in name_upper:
            q_label = '4K'
        elif '1080P' in name_upper:
            q_label = '1080p'
        elif '720P' in name_upper:
            q_label = '720p'
        elif '480P' in name_upper or 'SD' in name_upper:
            q_label = 'SD'
        freeleech = 1 if (t.get('download_volume_factor', 1) == 0 or t.get('is_freeleech')) else 0
        doubleup = 1 if (t.get('upload_volume_factor', 1) > 1 or t.get('is_double_upload')) else 0
        halfdw = 1 if (t.get('download_volume_factor', 1) == 0.5 or t.get('is_half_download')) else 0
        is_internal = 1 if t.get('is_internal') else 0
        download_link = "%s/rss/download/%s/%s.torrent?passkey=%s" % (base_url, tid, quote(name), passkey)
        return {
            'url': download_link,
            'name': name + " [S: %d P: %d]" % (seeders, leechers),
            'title': name,
            'quality': q_label,
            'size': size_str,
            'info': {
                'seeders': seeders, 'peers': leechers, 'indexer': category_name,
                'freeleech': freeleech, 'doubleup': doubleup, 'halfdw': halfdw,
                'internal': is_internal, 'quality': q_label,
                'releaseGroup': _extract_release_group(name),
            },
            'provider_id': 'p2p_speedapp'
        }
    except:
        return None

def _speedapp_api_search(session, auth_headers, base_url, imdb_id, passkey, fallback_enabled, title_query, year_query):
    channel_ids = _speedapp_get_channel_ids(session, auth_headers)
    if not channel_ids:
        return None
    all_streams = []
    if imdb_id and str(imdb_id).startswith('tt'):
        for attempt_channels in [channel_ids, [1, 6, 15, 49]]:
            try:
                r = session.get(base_url + '/api/torrent',
                    params={'imdbId': imdb_id, 'channels[]': attempt_channels, 'itemsPerPage': 100},
                    headers=auth_headers, timeout=15)
                if r.status_code == 200:
                    data = r.json()
                    items = data.get('data', []) if isinstance(data, dict) else data
                    for t in items:
                        stream = _speedapp_torrent_to_stream(t, passkey, base_url)
                        if stream:
                            all_streams.append(stream)
                    xbmc.log("[TMDb Movies] [SpeedApp] %d torrents from IMDb API" % len(items), xbmc.LOGERROR)
                    if all_streams:
                        return all_streams
                xbmc.log("[TMDb Movies] [SpeedApp] API search HTTP %d with channels %s" % (r.status_code, attempt_channels), xbmc.LOGERROR)
                if r.status_code != 403:
                    break
            except Exception as e:
                xbmc.log("[TMDb Movies] [SpeedApp] API search error: %s" % str(e), xbmc.LOGERROR)
                break
    if not all_streams and fallback_enabled and title_query:
        search_term = title_query + (" " + year_query if year_query else "")
        for attempt_channels in [channel_ids, [1, 6, 15, 49]]:
            try:
                r = session.get(base_url + '/api/torrent',
                    params={'search': search_term, 'channels[]': attempt_channels, 'itemsPerPage': 100},
                    headers=auth_headers, timeout=15)
                if r.status_code == 200:
                    data = r.json()
                    items = data.get('data', []) if isinstance(data, dict) else data
                    has_year = year_query and any(year_query in x.get('name', '') for x in items)
                    for t in items:
                        t_name = t.get('name', '')
                        if title_query.lower() not in t_name.lower():
                            continue
                        if has_year and year_query not in t_name:
                            continue
                        stream = _speedapp_torrent_to_stream(t, passkey, base_url)
                        if stream:
                            all_streams.append(stream)
                    xbmc.log("[TMDb Movies] [SpeedApp] %d torrents from name API" % len(items), xbmc.LOGERROR)
                    break
                if r.status_code != 403:
                    break
            except Exception as e:
                xbmc.log("[TMDb Movies] [SpeedApp] API name search error: %s" % str(e), xbmc.LOGERROR)
    return all_streams or None


def scrape_knaben(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    xbmc.log("[TMDb Movies] [Knaben] scrape_knaben called: imdb_id=%s content_type=%s" % (imdb_id, content_type), xbmc.LOGERROR)
    if ADDON.getSetting('use_p2p_knaben') == 'false':
        return None
    if not title_query:
        return None

    query = title_query
    if year_query:
        query += " " + year_query

    try:
        session = get_shared_session()
        api_base = 'https://api.knaben.org/v1'
        resp = session.post(api_base, json={
            'search_type': '75%',
            'search_field': 'title',
            'query': query,
            'order_by': 'seeders',
            'order_direction': 'desc',
            'from': 0, 'size': 50,
            'hide_unsafe': True, 'hide_xxx': True,
        }, headers={'User-Agent': get_random_ua(), 'Content-Type': 'application/json'}, timeout=15)
        if resp.status_code != 200:
            return None
        data = resp.json()
        hits = data.get('hits', [])
        if not hits:
            return None

        streams = []
        for t in hits:
            title = t.get('title', '')
            if not title:
                continue
            if year_query and year_query not in title:
                continue
            if title_query.lower() not in title.lower():
                continue
            magnet = t.get('magnetUrl')
            if not magnet:
                continue
            quality = '1080p'
            name_upper = title.upper()
            if '720P' in name_upper: quality = '720p'
            elif '1080P' in name_upper: quality = '1080p'
            elif '2160P' in name_upper or '4K' in name_upper: quality = '4K'
            elif '480P' in name_upper or 'SD' in name_upper: quality = 'SD'
            streams.append({
                'url': magnet,
                'name': title + " [S: %d P: %d]" % (t.get('seeders', 0), t.get('peers', 0)),
                'title': title,
                'quality': quality,
                'size': str(round(float(t.get('bytes', 0)) / 1073741824, 2)) + ' GB' if t.get('bytes') else '',
                'info': {
                    'seeders': t.get('seeders', 0), 'peers': t.get('peers', 0),
                    'indexer': t.get('tracker', t.get('category', '')),
                    'quality': quality,
                    'releaseGroup': _extract_release_group(title),
                },
                'provider_id': 'p2p_knaben'
            })
        if streams:
            xbmc.log("[TMDb Movies] [Knaben] %d torrents" % len(streams), xbmc.LOGERROR)
            if content_type == 'tv' and (season is not None):
                return _filter_tv_packs(streams, season, episode)
            return streams
        return None
    except Exception as e:
        xbmc.log("[TMDb Movies] [Knaben] error: %s" % str(e), xbmc.LOGERROR)
        return None


_TPB_TRACKERS = [
    'udp://tracker.coppersurfer.tk:6969/announce',
    'udp://tracker.leechers-paradise.org:6969/announce',
    'udp://tracker.opentrackr.org:1337/announce',
    'udp://9.rarbg.to:2710/announce',
    'udp://9.rarbg.me:2710/announce',
    'udp://exodus.desync.com:6969/announce',
    'udp://tracker.pirateparty.gr:6969/announce',
    'udp://tracker.cyberia.is:6969/announce',
    'udp://tracker3.itzmx.com:6961/announce',
    'https://tracker.nanoha.org:443/announce',
    'http://tracker.dler.org:6969/announce',
    'udp://open.demonii.com:1337/announce',
]


def scrape_thepiratebay(imdb_id, content_type, season=None, episode=None, title_query=None, year_query=None):
    xbmc.log("[TMDb Movies] [TPB] scrape_thepiratebay called: imdb_id=%s content_type=%s" % (imdb_id, content_type), xbmc.LOGERROR)
    if ADDON.getSetting('use_p2p_thepiratebay') == 'false':
        return None
    if not title_query:
        return None

    query = title_query.replace("'", "")
    if year_query:
        query += " " + year_query

    try:
        session = get_shared_session()
        categories = ['200', '205', '206', '207', '208', '209', '210', '211']
        query_encoded = requests.compat.quote(query)
        all_hits = []
        for cat in categories:
            try:
                url = 'https://apibay.org/q.php?q=%s&cat=%s' % (query_encoded, cat)
                resp = session.get(url, headers={'User-Agent': get_random_ua()}, timeout=10)
                if resp.status_code != 200:
                    continue
                data = resp.json()
                if not isinstance(data, list):
                    continue
                for item in data:
                    item['_cat'] = cat
                all_hits.extend(data)
            except:
                continue

        magnet_prefix = 'magnet:?xt=urn:btih:'
        streams = []
        seen_hashes = set()
        for t in all_hits:
            info_hash = t.get('info_hash', '').upper()
            if not info_hash or len(info_hash) != 40:
                continue
            if info_hash in seen_hashes:
                continue
            seen_hashes.add(info_hash)
            name = t.get('name', '')
            seeds = int(t.get('seeders', 0))
            if seeds == 0:
                continue
            if year_query and year_query not in name:
                continue
            if title_query.lower() not in name.lower():
                continue
            if content_type == 'tv' and season is not None:
                if not re.search(r'\bS\d{1,2}(E\d{1,2})?\b', name, re.I) and 'season' not in name.lower():
                    if year_query and year_query in name:
                        pass
                    else:
                        continue
            magnet = magnet_prefix + info_hash
            for tr in _TPB_TRACKERS[:4]:
                magnet += '&tr=' + requests.compat.quote(tr, safe='')
            size_bytes = int(t.get('size', 0))
            size_gb = round(size_bytes / 1073741824, 2) if size_bytes else ''
            quality = '1080p'
            name_upper = name.upper()
            if '720P' in name_upper: quality = '720p'
            elif '1080P' in name_upper: quality = '1080p'
            elif '2160P' in name_upper or '4K' in name_upper: quality = '4K'
            elif '480P' in name_upper or 'SD' in name_upper: quality = 'SD'
            streams.append({
                'url': magnet,
                'name': name + " [S: %d P: %d]" % (seeds, int(t.get('leechers', 0))),
                'title': name,
                'quality': quality,
                'size': str(size_gb) + ' GB' if size_gb else '',
                'info': {
                    'seeders': seeds,
                    'peers': int(t.get('leechers', 0)),
                    'quality': quality,
                    'releaseGroup': t.get('username', ''),
                },
                'provider_id': 'p2p_thepiratebay'
            })
        if streams:
            xbmc.log("[TMDb Movies] [TPB] %d torrents" % len(streams), xbmc.LOGERROR)
            if content_type == 'tv' and (season is not None):
                return _filter_tv_packs(streams, season, episode)
            return streams
        return None
    except Exception as e:
        xbmc.log("[TMDb Movies] [TPB] error: %s" % str(e), xbmc.LOGERROR)
        return None


def get_stream_data(imdb_id, content_type, season=None, episode=None, progress_callback=None, target_providers=None, override_title=None, override_year=None):
    """
    Orchestreaza scanarea PARALELA (Multithreading).
    override_title/override_year: forteaza titlu/an personalizat (Scrape with Custom Values).
    """
    all_streams = []
    seen_urls = set()
    failed_providers = [] 
    empty_providers = []
    was_canceled = False
    
    # --- CITIM SETAREA UTILIZATORULUI ---
    filter_duplicates = ADDON.getSetting('filter_duplicate_urls') == 'true'

    # 1. EXTRAGERE TITLU SI AN DIN TMDB (Necesar si foarte robust)
    extra_title = ""
    extra_year = ""
    
    # Daca avem override (Custom Values), le folosim direct
    if override_title:
        extra_title = override_title
        extra_year = override_year or ""
        log(f"[SCRAPER] Custom Values: '{extra_title}' ({extra_year})")
    else:
        title_based_scrapers = ['fshdnet', 'hdhub4u', 'mkvcinemas', 'moviesdrive', 'vidlink', 'vsembed', 'hdhub', 'streamvix', 'videasy', 'netmirror', 'vidmody', 'movieblast', 'moviebox', 'onlykdrama', 'primesrcme', 'vaplayer', 'flixer', 'cineby', 'cinefreak']
        needs_title = any(
            ADDON.getSetting(f'use_{scraper}') == 'true' 
            for scraper in title_based_scrapers
        ) or ADDON.getSetting('use_p2p_yts') == 'true' or ADDON.getSetting('use_p2p_filelist') == 'true' or ADDON.getSetting('use_p2p_speedapp') == 'true' or ADDON.getSetting('use_p2p_seedpool') == 'true' or ADDON.getSetting('use_p2p_torrentio') == 'true' or ADDON.getSetting('use_p2p_comet') == 'true' or ADDON.getSetting('use_p2p_mediafusion') == 'true' or ADDON.getSetting('use_p2p_knaben') == 'true' or ADDON.getSetting('use_p2p_thepiratebay') == 'true'
        
        if needs_title:
            try:
                imdb_str = str(imdb_id)
                if imdb_str.startswith('tt'):
                    url = f"{BASE_URL}/find/{imdb_str}?api_key={API_KEY}&external_source=imdb_id"
                    data = get_json(url)
                    res = data.get('movie_results', []) or data.get('tv_results', [])
                    if res:
                        extra_title = res[0].get('title') or res[0].get('name')
                        dt = res[0].get('release_date') or res[0].get('first_air_date')
                        extra_year = dt[:4] if dt else ""
                
                # Fallback 100% sigur: Daca IMDB a esuat sau ID-ul trimis era de fapt TMDB (tmdb:1234)
                if not extra_title:
                    clean_id = imdb_str.replace('tmdb:', '')
                    url = f"{BASE_URL}/{'tv' if content_type == 'tv' else 'movie'}/{clean_id}?api_key={API_KEY}"
                    data = get_json(url)
                    if data:
                        extra_title = data.get('title') or data.get('name')
                        dt = data.get('release_date') or data.get('first_air_date')
                        extra_year = dt[:4] if dt else ""
                        
                log(f"[SCRAPER] Title resolved safely: '{extra_title}' ({extra_year})")
            except Exception as e:
                log(f"[SCRAPER] Could not resolve title from TMDB: {e}")

    # 2. DEFINIRE PROVIDERI (ORDINEA CERUTA)
    providers_map = {
        'sooti': ('Sootio', lambda: scrape_sooti(imdb_id, content_type, season, episode)),
        'moviesdrive': ('MoviesDrive', lambda: scrape_moviesdrive(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'webstreamr': ('Webstreamr', lambda: _scrape_json_provider("https://87d6a6ef6b58-webstreamrmbg.baby-beamup.club", 'stream', 'Webstreamr', imdb_id, content_type, season, episode)),
        'streamvix': ('StreamVix', lambda: _scrape_json_provider("https://streamvix.hayd.uk", 'stream', 'StreamVix', imdb_id, content_type, season, episode)),
        'vidlink': ('VidLink', lambda: scrape_vidlink(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'vaplayer': ('VAPlayer', lambda: scrape_vaplayer(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'vsembed': ('VSEmbed', lambda: scrape_vsembed(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'videasy': ('VidEasy', lambda: scrape_videasy(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'netmirror': ('NetMirror', lambda: scrape_netmirror(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'vidmody': ('Vidmody', lambda: scrape_vidmody(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'movieblast': ('MovieBlast', lambda: scrape_movieblast(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'moviebox': ('MovieBox', lambda: scrape_moviebox(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'onlykdrama': ('OnlyKDrama', lambda: scrape_onlykdrama(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'primesrcme': ('PrimeSrc.me', lambda: scrape_primesrcme(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'flixer': ('Flixer', lambda: scrape_flixer(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        
        'cineby': ('Cineby', lambda: scrape_cineby(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'cinefreak': ('CineFreak', lambda: scrape_cinefreak(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        
        
        'fshdnet': ('FSHDnet', lambda: scrape_fshdnet(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'hdhub4u': ('HDHub4u', lambda: scrape_hdhub4u(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'mkvcinemas': ('MKVCinemas', lambda: scrape_mkvcinemas(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'hdhub': ('HDHub', lambda: _scrape_json_provider("https://hdhub.thevolecitor.qzz.io/eyJ0b3Jib3giOiJ1bnNldCIsInF1YWxpdGllcyI6IjIxNjBwLDEwODBwLDcyMHAiLCJzb3J0IjoiZGVzYyJ9", 'stream', 'HDHub', imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        
        # PROVIDERI DEBRID (IGNORA SWITCH-UL GLOBAL HTTP)
        'aiostreams': ('AIO Streams', lambda: scrape_aiostreams(imdb_id, content_type, season, episode)),
        'torrentio': ('Torrentio', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'torrentio', 'Torrentio')),
        'mediafusion': ('Mediafusion', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'mediafusion', 'Mediafusion')),
        'comet': ('Comet', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'comet', 'Comet')),
        'meteor': ('Meteor', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'meteor', 'Meteor')),
        'torz': ('Torz', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'torz', 'Torz')),
        'custom1': ('Custom 1', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'custom1', ADDON.getSetting('custom1_name') or 'Custom 1')),
        'custom2': ('Custom 2', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'custom2', ADDON.getSetting('custom2_name') or 'Custom 2')),
        'custom3': ('Custom 3', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'custom3', ADDON.getSetting('custom3_name') or 'Custom 3')),
        'custom4': ('Custom 4', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'custom4', ADDON.getSetting('custom4_name') or 'Custom 4')),
        'custom5': ('Custom 5', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'custom5', ADDON.getSetting('custom5_name') or 'Custom 5')),
        'usenet': ('Usenet', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'usenet', 'Usenet')),

        # PROVIDERI P2P (IGNORA SWITCH-UL GLOBAL HTTP, RESPECTA P2P MASTER SWITCH)
        'p2p_yts': ('YTS', lambda: scrape_yts(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'p2p_filelist': ('FileList', lambda: scrape_filelist(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'p2p_torrentio': ('Torrentio P2P', lambda: scrape_p2p_torrentio(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'p2p_comet': ('Comet P2P', lambda: scrape_p2p_comet(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'p2p_mediafusion': ('MediaFusion P2P', lambda: scrape_p2p_mediafusion(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'p2p_speedapp': ('SpeedApp', lambda: scrape_speedapp(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'p2p_seedpool': ('SeedPool', lambda: scrape_seedpool(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'p2p_knaben': ('Knaben', lambda: scrape_knaben(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'p2p_thepiratebay': ('The Pirate Bay', lambda: scrape_thepiratebay(imdb_id, content_type, season, episode, title_query=extra_title, year_query=extra_year)),
        'p2p_custom1': ('P2P Custom 1', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'p2p_custom1', ADDON.getSetting('p2p_custom1_name') or 'P2P Custom 1')),
        'p2p_custom2': ('P2P Custom 2', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'p2p_custom2', ADDON.getSetting('p2p_custom2_name') or 'P2P Custom 2')),
        'p2p_custom3': ('P2P Custom 3', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'p2p_custom3', ADDON.getSetting('p2p_custom3_name') or 'P2P Custom 3')),
        'p2p_custom4': ('P2P Custom 4', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'p2p_custom4', ADDON.getSetting('p2p_custom4_name') or 'P2P Custom 4')),
        'p2p_custom5': ('P2P Custom 5', lambda: scrape_stremio_addon(imdb_id, content_type, season, episode, 'p2p_custom5', ADDON.getSetting('p2p_custom5_name') or 'P2P Custom 5')),
    }

    # 3. SELECTIE PROVIDERI ACTIVI (CU LOGICA MASTER SWITCH)
    to_run = []
    http_master_enabled = ADDON.getSetting('enable_http_scrapers') == 'true'
    p2p_master_enabled = ADDON.getSetting('enable_p2p_providers') == 'true'
    debrid_providers = ['aiostreams', 'torrentio', 'mediafusion', 'comet', 'meteor', 'torz', 'usenet', 'custom1', 'custom2', 'custom3', 'custom4', 'custom5']
    p2p_providers = ['p2p_yts', 'p2p_torrentio', 'p2p_comet', 'p2p_mediafusion', 'p2p_filelist', 'p2p_speedapp', 'p2p_seedpool', 'p2p_knaben', 'p2p_thepiratebay', 'p2p_custom1', 'p2p_custom2', 'p2p_custom3', 'p2p_custom4', 'p2p_custom5']

    if target_providers is not None:
        for pid in target_providers:
            if pid in providers_map:
                setting_id = f'use_{pid}'
                is_enabled = ADDON.getSetting(setting_id)
                if is_enabled == '' and pid == 'flixer': is_enabled = 'true'
                # Executam daca (e Debrid) SAU (Master HTTP e On si setarea individuala e On) SAU (P2P)
                if pid in debrid_providers or (http_master_enabled and pid not in p2p_providers and is_enabled == 'true') or (pid in p2p_providers and p2p_master_enabled and is_enabled == 'true'):
                    if pid.startswith('custom') or pid.startswith('p2p_custom'):
                        display_name = ADDON.getSetting(f'{pid}_name') or providers_map[pid][0]
                    else:
                        display_name = providers_map[pid][0]
                    to_run.append((pid, display_name, providers_map[pid][1]))
    else:
        for pid, (pname, pfunc) in providers_map.items():
            setting_id = f'use_{pid}'
            is_enabled = ADDON.getSetting(setting_id)
            if is_enabled == '' and pid == 'flixer': is_enabled = 'true'
            if pid in debrid_providers or (http_master_enabled and pid not in p2p_providers and is_enabled == 'true') or (pid in p2p_providers and p2p_master_enabled and is_enabled == 'true'):
                if pid.startswith('custom') or pid.startswith('p2p_custom'):
                    display_name = ADDON.getSetting(f'{pid}_name') or pname
                else:
                    display_name = pname
                to_run.append((pid, display_name, pfunc))
    
    total_providers = len(to_run)
    if total_providers == 0:
        return [], [], [], False

    # 4. FUNCTIA WRAPPER PENTRU THREAD
    _scraper_results = []
    _scraper_lock = threading.Lock()

    def run_provider(provider_info):
        """
        Executa un provider si returneaza rezultatele.
        Returneaza: (pid, pname, result, status)
        status: 'success' = are rezultate, 'empty' = 0 rezultate, 'error' = exceptie/timeout
        """
        pid, pname, pfunc = provider_info
        
        try:
            result = pfunc()
            if result:
                with _scraper_lock:
                    _scraper_results.append((pid, pname, result, 'success'))
            else:
                with _scraper_lock:
                    _scraper_results.append((pid, pname, None, 'empty'))
            
        except Exception as e:
            log(f"[THREAD] Error in {pname}: {e}")
            with _scraper_lock:
                _scraper_results.append((pid, pname, None, 'error'))

    # 5. EXECUTIE PARALELA - DAEMON THREADS (Kodi nu asteapta dupa ele)
    try: MAX_TIMEOUT = int(ADDON.getSetting('scraper_timeout'))
    except: MAX_TIMEOUT = 25
    
    MAX_WORKERS = 20  # Toti providerii pornesc simultan
    
    import time
    _scraper_threads = []
    for p in to_run:
        t = threading.Thread(target=run_provider, args=(p,), daemon=True)
        _scraper_threads.append(t)
        t.start()
    
    start_time = time.time()
    _all_done = False
    processed_count = 0
    try:
        while not _all_done:
            elapsed = time.time() - start_time
            if elapsed > MAX_TIMEOUT:
                log(f"[SCRAPER] Global timeout forced ({MAX_TIMEOUT}s)")
                break
            
            time.sleep(0.25)
            
            # Check if all threads finished
            _all_done = all(not t.is_alive() for t in _scraper_threads)
            
            # --- 1. PROCESARE REZULTATE NOI (in timp real) ---
            with _scraper_lock:
                new_results = _scraper_results[processed_count:]
                processed_count += len(new_results)
            
            for pid, pname, result, status in new_results:
                if status == 'error':
                    failed_providers.append(pid)
                    log(f"[SCRAPER] ✗ {pname}: error/timeout")
                    continue
                elif status == 'empty':
                    empty_providers.append(pid)
                    log(f"[SCRAPER] ✗ {pname}: no results")
                    continue
                
                items_to_add = []
                if isinstance(result, dict):
                    items_to_add = [result]
                elif isinstance(result, list):
                    items_to_add = result
                
                added_count = 0
                for item in items_to_add:
                    if not isinstance(item, dict): continue
                    url = item.get('url', '')
                    if not url or not isinstance(url, str): continue
                    
                    clean_url = url.split('|')[0]
                    if filter_duplicates:
                        if clean_url in seen_urls: continue
                        seen_urls.add(clean_url)
                    
                    item.setdefault('name', pname)
                    item.setdefault('quality', 'SD')
                    item.setdefault('title', '')
                    
                    orig_info = item.get('info')
                    if not isinstance(orig_info, dict):
                        item['info'] = {'original_info_str': str(orig_info) if orig_info else ''}
                        
                    item['provider_id'] = pid
                    # Filtru centralizat gunoaie (telesync, cam, hdts etc.)
                    _garbage_text = str(item.get('title', '')) + ' ' + str(item.get('name', '')) + ' ' + str(item.get('info', ''))
                    if re.search(r'(?i)\b(trailer|sample|cam|camrip|hdts|hdtc|ts|telesync|telecine|hdcam|predvd|pre-dvd|spmusic)\b', _garbage_text):
                        log(f"[SCRAPER] ✗ Filtrat gunoi: {pname} | {str(item.get('title',''))[:60]}")
                        continue
                    all_streams.append(item)
                    added_count += 1
                
                if added_count > 0:
                    log(f"[SCRAPER] ✓ {pname}: {added_count} sources added")
                else:
                    empty_providers.append(pid)
            
            # --- 2. ACTUALIZARE UI ---
            if progress_callback:
                with _scraper_lock:
                    finished_count = len(_scraper_results)
                percent = int((finished_count / total_providers) * 100)
                
                alive_names = []
                for i, p in enumerate(to_run):
                    if _scraper_threads[i].is_alive():
                        alive_names.append(p[1])
                
                # Compute per-category source counts from all_streams
                cat_http = {'total': 0, '4K': 0, '1080p': 0, '720p': 0, 'SD': 0}
                cat_aio = {'total': 0, '4K': 0, '1080p': 0, '720p': 0, 'SD': 0}
                cat_p2p = {'total': 0, '4K': 0, '1080p': 0, '720p': 0, 'SD': 0}
                for s in all_streams:
                    pid = s.get('provider_id', '')
                    q = s.get('quality', 'SD')
                    if pid.startswith('p2p_'):
                        cat = cat_p2p
                    elif pid in debrid_providers:
                        cat = cat_aio
                    else:
                        cat = cat_http
                    cat['total'] += 1
                    if q == '4K':
                        cat['4K'] += 1
                    elif q == '1080p':
                        cat['1080p'] += 1
                    elif q == '720p':
                        cat['720p'] += 1
                    else:
                        cat['SD'] += 1
                
                if alive_names:
                    formatted_names = [f"[B][COLOR FFFF69B4]{alive_names[0]}[/COLOR][/B]"]
                    for name in alive_names[1:3]:
                        formatted_names.append(f"[B][COLOR white]{name}[/COLOR][/B]")
                    if len(alive_names) > 3:
                        display_pending = ", ".join(formatted_names) + f" [COLOR gray][I](+{len(alive_names)-3})[/I][/COLOR]"
                    else:
                        display_pending = ", ".join(formatted_names)
                else:
                    display_pending = "[B][COLOR lime]Finalizare...[/COLOR][/B]"

                msg_estuary = (
                    f"[COLOR gray]Scanning:[/COLOR] {display_pending}\n"
                    f"[COLOR gray]Scanned:[/COLOR] [B][COLOR cyan]{finished_count}/{total_providers}[/COLOR][/B] [COLOR gray]| Sources found:[/COLOR] [B][COLOR FF00FA9A]{len(all_streams)}[/COLOR][/B]"
                )
                active_prov = alive_names[0] if alive_names else "Finalizare..."
                msg_af3 = f"Scanning: [B][COLOR FFFF69B4]{active_prov}[/COLOR][/B] | Sources found: [B]{len(all_streams)}[/B]"
                status_data = {
                    'estuary': msg_estuary,
                    'af3': msg_af3,
                    'categories': {
                        'http': cat_http,
                        'aio': cat_aio,
                        'p2p': cat_p2p,
                    },
                    'alive': alive_names,
                    'percent': percent,
                }
                
                keep_going = progress_callback(percent, status_data)
                if keep_going is False:
                    was_canceled = True
                    break

        # Process any remaining results (e.g. after timeout break)
        with _scraper_lock:
            remaining_results = _scraper_results[processed_count:]
            processed_count += len(remaining_results)
        
        for pid, pname, result, status in remaining_results:
            if status == 'error':
                if pid not in failed_providers: failed_providers.append(pid)
            elif status == 'empty':
                if pid not in empty_providers: empty_providers.append(pid)
            else:
                items_to_add = []
                if isinstance(result, dict):
                    items_to_add = [result]
                elif isinstance(result, list):
                    items_to_add = result
                for item in items_to_add:
                    if not isinstance(item, dict): continue
                    url = item.get('url', '')
                    if not url or not isinstance(url, str): continue
                    clean_url = url.split('|')[0]
                    if filter_duplicates:
                        if clean_url in seen_urls: continue
                        seen_urls.add(clean_url)
                    item.setdefault('name', pname)
                    item.setdefault('quality', 'SD')
                    item.setdefault('title', '')
                    orig_info = item.get('info')
                    if not isinstance(orig_info, dict):
                        item['info'] = {'original_info_str': str(orig_info) if orig_info else ''}
                    item['provider_id'] = pid
                    _garbage_text = str(item.get('title', '')) + ' ' + str(item.get('name', '')) + ' ' + str(item.get('info', ''))
                    if re.search(r'(?i)\b(trailer|sample|cam|camrip|hdts|hdtc|ts|telesync|telecine|hdcam|predvd|pre-dvd|spmusic)\b', _garbage_text):
                        continue
                    all_streams.append(item)
        
        # Mark timed-out threads
        for i, p in enumerate(to_run):
            if _scraper_threads[i].is_alive():
                pid = p[0]
                pname = p[1]
                if pid not in failed_providers:
                    failed_providers.append(pid)
                    log(f"[SCRAPER] ✗ {pname}: Timeout!")

    except Exception as e:
        log(f"[SCRAPER] Fatal error in execution loop: {e}")

    log(f"[SCRAPER] Finalizat: {len(all_streams)} surse, {len(failed_providers)} erori, {len(empty_providers)} fara rezultate")
    return all_streams, failed_providers, empty_providers, was_canceled
